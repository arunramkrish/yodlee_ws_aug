package com.yodlee.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.xml.ws.AsyncHandler;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Response;
import javax.xml.ws.soap.SOAPFaultException;

import com.yodlee.service.Customer;
import com.yodlee.service.CustomerService;
import com.yodlee.service.CustomerServiceImplService;
import com.yodlee.service.FindCustomerResponse;
import com.yodlee.service.NoCustomerFoundException_Exception;

public class ServiceClient {

	public static void main(String[] args) {
		try {
			CustomerService svc = new CustomerServiceImplService()
					.getCustomerServiceImplPort();
			((BindingProvider) svc).getRequestContext().put(
					BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
					"http://localhost:9999/yodlee/customerService");

			Customer customer = svc.findCustomer("yodlee");
			System.out.println(customer.getName());

			// async using callback
			asyncUsingCallback(svc);

			// async using polling
			asyncUsingPolling(svc);

		} catch (SOAPFaultException fault) {
			System.err.println("Exception " + fault.getMessage());
		} catch (NoCustomerFoundException_Exception e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void asyncUsingPolling(CustomerService svc) {
		Response<FindCustomerResponse> response = svc
				.findCustomerAsync("yodlee");

		int i = 1;
		while (true) {
			try {
				System.out.println("waiting " + i++);
				
				FindCustomerResponse cr = response
						.get(1, TimeUnit.MILLISECONDS);

				System.out.println("from polling " + cr.getReturn().getName());
				break;
			} catch (InterruptedException | ExecutionException
					| TimeoutException e) {
				e.printStackTrace();
			}
		}

	}

	private static void asyncUsingCallback(CustomerService svc)
			throws InterruptedException, ExecutionException, TimeoutException {

		AsyncHandler<FindCustomerResponse> asyncHandler = new CustomerAsyncHandler();
		Future<FindCustomerResponse> future = (Future<FindCustomerResponse>) svc
				.findCustomerAsync("yodlee", asyncHandler);

		Thread.sleep(1000);
		// System.out.println("From async handler "
		// + future.get(500, TimeUnit.MILLISECONDS).getReturn());
	}

	public static class CustomerAsyncHandler implements
			AsyncHandler<FindCustomerResponse> {

		@Override
		public void handleResponse(Response<FindCustomerResponse> res) {
			try {
				System.out.println("From async handler "
						+ res.get(500, TimeUnit.MILLISECONDS).getReturn());
			} catch (InterruptedException | ExecutionException
					| TimeoutException e) {
				e.printStackTrace();
			}

		}

	}

}
