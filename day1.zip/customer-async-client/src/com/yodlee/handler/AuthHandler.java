package com.yodlee.handler;

import java.util.Iterator;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

public class AuthHandler implements SOAPHandler<SOAPMessageContext> {

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		try {
			System.out.println("handle message");

			Boolean isRequest = (Boolean) context
					.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY);

			if (isRequest) {
				// handler is invoked in the request path
				SOAPHeader header = context.getMessage().getSOAPHeader();
				
				if (header != null) {
					Iterator<Node> nodes = (Iterator<Node>) header
							.getChildElements(new QName("userId"));
					while (nodes.hasNext()) {
						System.out.println(nodes.next().getNodeValue());
						break;
					}
				} else {
					System.out.println("No header present");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		System.out.println("handle fault");
		return false;
	}

	@Override
	public void close(MessageContext context) {
		System.out.println("close");
	}

	@Override
	public Set<QName> getHeaders() {
		System.out.println("Handler : getHeaders");
		return null;
	}

}
