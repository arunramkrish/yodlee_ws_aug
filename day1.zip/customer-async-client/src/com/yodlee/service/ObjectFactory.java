
package com.yodlee.service;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _FindCustomer_QNAME = new QName("http://service.yodlee.com/", "findCustomer");
    private final static QName _FindCustomerResponse_QNAME = new QName("http://service.yodlee.com/", "findCustomerResponse");
    private final static QName _NoCustomerFoundException_QNAME = new QName("http://service.yodlee.com/", "NoCustomerFoundException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NoCustomerFoundException }
     * 
     */
    public NoCustomerFoundException createNoCustomerFoundException() {
        return new NoCustomerFoundException();
    }

    /**
     * Create an instance of {@link FindCustomerResponse }
     * 
     */
    public FindCustomerResponse createFindCustomerResponse() {
        return new FindCustomerResponse();
    }

    /**
     * Create an instance of {@link FindCustomer }
     * 
     */
    public FindCustomer createFindCustomer() {
        return new FindCustomer();
    }

    /**
     * Create an instance of {@link Transaction }
     * 
     */
    public Transaction createTransaction() {
        return new Transaction();
    }

    /**
     * Create an instance of {@link Customer }
     * 
     */
    public Customer createCustomer() {
        return new Customer();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindCustomer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.yodlee.com/", name = "findCustomer")
    public JAXBElement<FindCustomer> createFindCustomer(FindCustomer value) {
        return new JAXBElement<FindCustomer>(_FindCustomer_QNAME, FindCustomer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindCustomerResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.yodlee.com/", name = "findCustomerResponse")
    public JAXBElement<FindCustomerResponse> createFindCustomerResponse(FindCustomerResponse value) {
        return new JAXBElement<FindCustomerResponse>(_FindCustomerResponse_QNAME, FindCustomerResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NoCustomerFoundException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.yodlee.com/", name = "NoCustomerFoundException")
    public JAXBElement<NoCustomerFoundException> createNoCustomerFoundException(NoCustomerFoundException value) {
        return new JAXBElement<NoCustomerFoundException>(_NoCustomerFoundException_QNAME, NoCustomerFoundException.class, null, value);
    }

}
