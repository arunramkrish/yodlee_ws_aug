@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.yodlee.com/")
package com.yodlee.service;
