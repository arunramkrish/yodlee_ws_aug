package com.yodlee.client;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.soap.SOAPFaultException;

import com.yodlee.service.Customer;
import com.yodlee.service.CustomerService;
import com.yodlee.service.CustomerServiceImplService;
import com.yodlee.service.NoCustomerFoundException_Exception;

public class ServiceClient {

	public static void main(String[] args) {
		try {
			CustomerService svc = new CustomerServiceImplService()
					.getCustomerServiceImplPort();
			((BindingProvider) svc).getRequestContext().put(
					BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
					"http://localhost:9999/yodlee/customerService");

			Customer customer = svc.findCustomer("lee");
			System.out.println(customer.getName());
		} catch (SOAPFaultException fault) {
			System.err.println("Exception " + fault.getMessage());
		} catch (NoCustomerFoundException_Exception e) {
			e.printStackTrace();
		}

	}

}
