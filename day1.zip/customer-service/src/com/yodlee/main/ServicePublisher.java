package com.yodlee.main;

import javax.xml.ws.Endpoint;

import com.yodlee.service.CustomerServiceImpl;

public class ServicePublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:8888/yodlee/customerService",
				new CustomerServiceImpl());
	}

}
