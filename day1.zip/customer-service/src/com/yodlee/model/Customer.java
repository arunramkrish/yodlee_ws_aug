package com.yodlee.model;

import java.util.Date;
import java.util.List;

public class Customer {
	private String id;
	private String name;
	private Date dob;
	private List<Transaction> recentTransactions;

	public Customer() {
		super();
	}

	public Customer(String id, String name, Date dob,
			List<Transaction> recentTransactions) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.recentTransactions = recentTransactions;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public List<Transaction> getRecentTransactions() {
		return recentTransactions;
	}

	public void setRecentTransactions(List<Transaction> recentTransactions) {
		this.recentTransactions = recentTransactions;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", recentTransactions=" + recentTransactions + "]";
	}

}
