package com.yodlee.model;

import java.util.Date;

public class Transaction {
	private Long id;
	private Date timeStamp;
	private TxnType type;
	private Float amount;
	private String summary;
	public Transaction() {
		super();
	}
	
	public Transaction(Long id, Date timeStamp, TxnType type, Float amount,
			String summary) {
		super();
		this.id = id;
		this.timeStamp = timeStamp;
		this.type = type;
		this.amount = amount;
		this.summary = summary;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	public TxnType getType() {
		return type;
	}
	public void setType(TxnType type) {
		this.type = type;
	}
	public Float getAmount() {
		return amount;
	}
	public void setAmount(Float amount) {
		this.amount = amount;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	@Override
	public String toString() {
		return "Transaction [id=" + id + ", timeStamp=" + timeStamp + ", type="
				+ type + ", amount=" + amount + ", summary=" + summary + "]";
	}
	
}
