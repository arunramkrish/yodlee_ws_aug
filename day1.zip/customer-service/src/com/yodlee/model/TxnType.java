package com.yodlee.model;

public enum TxnType {
	DEBIT, CREDIT;
}
