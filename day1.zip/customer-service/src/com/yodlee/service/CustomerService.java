package com.yodlee.service;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.yodlee.model.Customer;

@WebService
@SOAPBinding(style = Style.DOCUMENT)
public interface CustomerService {
	@WebMethod
	Customer findCustomer(String id) throws NoCustomerFoundException;
}
