package com.yodlee.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.HandlerChain;
import javax.jws.WebService;

import com.yodlee.model.Customer;
import com.yodlee.model.Transaction;
import com.yodlee.model.TxnType;

@WebService(endpointInterface = "com.yodlee.service.CustomerService")
@HandlerChain(file="handlers.xml")
public class CustomerServiceImpl implements CustomerService {

	@Override
	public Customer findCustomer(String id) throws NoCustomerFoundException {
		if (!("yodlee".equals(id))) {
			throw new NoCustomerFoundException("Customer id should be yodlee");
		}
		List<Transaction> txns = new ArrayList<Transaction>();
		txns.add(new Transaction(1L, new Date(), TxnType.CREDIT, 1000000F,
				"Bonus"));
		txns.add(new Transaction(2L, new Date(), TxnType.DEBIT, 99999F, "Spent"));

		Customer customer = new Customer(id, "Name " + id, new Date(), txns);

		return customer;
	}

}
