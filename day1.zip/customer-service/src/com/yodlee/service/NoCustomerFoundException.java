package com.yodlee.service;

public class NoCustomerFoundException extends Exception {

	public NoCustomerFoundException() {
		// TODO Auto-generated constructor stub
	}

	public NoCustomerFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoCustomerFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NoCustomerFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoCustomerFoundException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
