
package com.yodlee.soap.collections;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.collections package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _LocaleLanguage_QNAME = new QName("", "language");
    private final static QName _LocaleVariant_QNAME = new QName("", "variant");
    private final static QName _LocaleCountry_QNAME = new QName("", "country");
    private final static QName _EntryValue_QNAME = new QName("", "value");
    private final static QName _EntryKey_QNAME = new QName("", "key");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.collections
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Entry }
     * 
     */
    public Entry createEntry() {
        return new Entry();
    }

    /**
     * Create an instance of {@link Map }
     * 
     */
    public Map createMap() {
        return new Map();
    }

    /**
     * Create an instance of {@link ArrayOfString }
     * 
     */
    public ArrayOfString createArrayOfString() {
        return new ArrayOfString();
    }

    /**
     * Create an instance of {@link Locale }
     * 
     */
    public Locale createLocale() {
        return new Locale();
    }

    /**
     * Create an instance of {@link List }
     * 
     */
    public List createList() {
        return new List();
    }

    /**
     * Create an instance of {@link ArrayOflong }
     * 
     */
    public ArrayOflong createArrayOflong() {
        return new ArrayOflong();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "language", scope = Locale.class)
    public JAXBElement<String> createLocaleLanguage(String value) {
        return new JAXBElement<String>(_LocaleLanguage_QNAME, String.class, Locale.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "variant", scope = Locale.class)
    public JAXBElement<String> createLocaleVariant(String value) {
        return new JAXBElement<String>(_LocaleVariant_QNAME, String.class, Locale.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country", scope = Locale.class)
    public JAXBElement<String> createLocaleCountry(String value) {
        return new JAXBElement<String>(_LocaleCountry_QNAME, String.class, Locale.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "value", scope = Entry.class)
    public JAXBElement<Object> createEntryValue(Object value) {
        return new JAXBElement<Object>(_EntryValue_QNAME, Object.class, Entry.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "key", scope = Entry.class)
    public JAXBElement<Object> createEntryKey(Object value) {
        return new JAXBElement<Object>(_EntryKey_QNAME, Object.class, Entry.class, value);
    }

}
