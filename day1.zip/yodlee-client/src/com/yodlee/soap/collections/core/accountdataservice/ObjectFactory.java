
package com.yodlee.soap.collections.core.accountdataservice;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.collections.core.accountdataservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.collections.core.accountdataservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ArrayOfItemInfo }
     * 
     */
    public ArrayOfItemInfo createArrayOfItemInfo() {
        return new ArrayOfItemInfo();
    }

    /**
     * Create an instance of {@link ArrayOfWirelessLineBilledInfo }
     * 
     */
    public ArrayOfWirelessLineBilledInfo createArrayOfWirelessLineBilledInfo() {
        return new ArrayOfWirelessLineBilledInfo();
    }

    /**
     * Create an instance of {@link ArrayOfBillPaymentStatus }
     * 
     */
    public ArrayOfBillPaymentStatus createArrayOfBillPaymentStatus() {
        return new ArrayOfBillPaymentStatus();
    }

    /**
     * Create an instance of {@link ArrayOfWirelessLineInfo }
     * 
     */
    public ArrayOfWirelessLineInfo createArrayOfWirelessLineInfo() {
        return new ArrayOfWirelessLineInfo();
    }

    /**
     * Create an instance of {@link ArrayOfWirelessUsage }
     * 
     */
    public ArrayOfWirelessUsage createArrayOfWirelessUsage() {
        return new ArrayOfWirelessUsage();
    }

    /**
     * Create an instance of {@link ArrayOfCardTransaction }
     * 
     */
    public ArrayOfCardTransaction createArrayOfCardTransaction() {
        return new ArrayOfCardTransaction();
    }

    /**
     * Create an instance of {@link ArrayOfInsuranceTransaction }
     * 
     */
    public ArrayOfInsuranceTransaction createArrayOfInsuranceTransaction() {
        return new ArrayOfInsuranceTransaction();
    }

    /**
     * Create an instance of {@link ArrayOfBillingPayment }
     * 
     */
    public ArrayOfBillingPayment createArrayOfBillingPayment() {
        return new ArrayOfBillingPayment();
    }

    /**
     * Create an instance of {@link ArrayOfBillingCharge }
     * 
     */
    public ArrayOfBillingCharge createArrayOfBillingCharge() {
        return new ArrayOfBillingCharge();
    }

    /**
     * Create an instance of {@link ArrayOfInsurancePolicy }
     * 
     */
    public ArrayOfInsurancePolicy createArrayOfInsurancePolicy() {
        return new ArrayOfInsurancePolicy();
    }

    /**
     * Create an instance of {@link ArrayOfDataType }
     * 
     */
    public ArrayOfDataType createArrayOfDataType() {
        return new ArrayOfDataType();
    }

    /**
     * Create an instance of {@link ArrayOfItemData }
     * 
     */
    public ArrayOfItemData createArrayOfItemData() {
        return new ArrayOfItemData();
    }

    /**
     * Create an instance of {@link ArrayOfBillingAccount }
     * 
     */
    public ArrayOfBillingAccount createArrayOfBillingAccount() {
        return new ArrayOfBillingAccount();
    }

    /**
     * Create an instance of {@link ArrayOfFinancialAccount }
     * 
     */
    public ArrayOfFinancialAccount createArrayOfFinancialAccount() {
        return new ArrayOfFinancialAccount();
    }

    /**
     * Create an instance of {@link ArrayOfBillingStatement }
     * 
     */
    public ArrayOfBillingStatement createArrayOfBillingStatement() {
        return new ArrayOfBillingStatement();
    }

    /**
     * Create an instance of {@link ArrayOfItemAccount }
     * 
     */
    public ArrayOfItemAccount createArrayOfItemAccount() {
        return new ArrayOfItemAccount();
    }

    /**
     * Create an instance of {@link ArrayOfBankTransaction }
     * 
     */
    public ArrayOfBankTransaction createArrayOfBankTransaction() {
        return new ArrayOfBankTransaction();
    }

    /**
     * Create an instance of {@link ArrayOfFinLoanTransaction }
     * 
     */
    public ArrayOfFinLoanTransaction createArrayOfFinLoanTransaction() {
        return new ArrayOfFinLoanTransaction();
    }

}
