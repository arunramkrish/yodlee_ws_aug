@javax.xml.bind.annotation.XmlSchema(namespace = "http://accountdataservice.core.collections.soap.yodlee.com")
package com.yodlee.soap.collections.core.accountdataservice;
