@javax.xml.bind.annotation.XmlSchema(namespace = "http://types.dataservice.core.collections.soap.yodlee.com")
package com.yodlee.soap.collections.core.dataservice.types;
