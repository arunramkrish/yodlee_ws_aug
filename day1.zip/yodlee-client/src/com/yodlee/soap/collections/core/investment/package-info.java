@javax.xml.bind.annotation.XmlSchema(namespace = "http://investment.core.collections.soap.yodlee.com")
package com.yodlee.soap.collections.core.investment;
