
package com.yodlee.soap.common;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.util.system.ycache.client.ClientCacheContext;


/**
 * <p>Java class for AppSharedUserContext complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AppSharedUserContext">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}SharedUserContext">
 *       &lt;sequence>
 *         &lt;element name="clientCacheContext" type="{http://client.ycache.system.util.soap.yodlee.com}ClientCacheContext" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AppSharedUserContext", propOrder = {
    "clientCacheContext"
})
public class AppSharedUserContext
    extends SharedUserContext
{

    @XmlElementRef(name = "clientCacheContext", type = JAXBElement.class, required = false)
    protected JAXBElement<ClientCacheContext> clientCacheContext;

    /**
     * Gets the value of the clientCacheContext property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ClientCacheContext }{@code >}
     *     
     */
    public JAXBElement<ClientCacheContext> getClientCacheContext() {
        return clientCacheContext;
    }

    /**
     * Sets the value of the clientCacheContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ClientCacheContext }{@code >}
     *     
     */
    public void setClientCacheContext(JAXBElement<ClientCacheContext> value) {
        this.clientCacheContext = value;
    }

}
