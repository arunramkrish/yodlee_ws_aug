
package com.yodlee.soap.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CardType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CardType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="VISA"/>
 *     &lt;enumeration value="MASTERCARD"/>
 *     &lt;enumeration value="AMERICAN_EXPRESS"/>
 *     &lt;enumeration value="DISCOVER_CARD"/>
 *     &lt;enumeration value="DINERS_CLUB"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CardType")
@XmlEnum
public enum CardType {

    UNKNOWN,
    VISA,
    MASTERCARD,
    AMERICAN_EXPRESS,
    DISCOVER_CARD,
    DINERS_CLUB;

    public String value() {
        return name();
    }

    public static CardType fromValue(String v) {
        return valueOf(v);
    }

}
