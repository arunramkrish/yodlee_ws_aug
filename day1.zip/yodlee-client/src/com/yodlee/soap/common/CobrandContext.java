
package com.yodlee.soap.common;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.Locale;


/**
 * <p>Java class for CobrandContext complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CobrandContext">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}CCobrandContext">
 *       &lt;sequence>
 *         &lt;element name="cobrandId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="channelId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="locale" type="{http://collections.soap.yodlee.com}Locale" minOccurs="0"/>
 *         &lt;element name="tncVersion" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="applicationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cobrandConversationCredentials" type="{http://common.soap.yodlee.com}ConversationCredentials" minOccurs="0"/>
 *         &lt;element name="validationHandler" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ipAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="preferenceInfo" type="{http://common.soap.yodlee.com}PreferenceInfo" minOccurs="0"/>
 *         &lt;element name="preferredLocale" type="{http://collections.soap.yodlee.com}Locale" minOccurs="0"/>
 *         &lt;element name="fetchAllLocaleData" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CobrandContext", propOrder = {
    "cobrandId",
    "channelId",
    "locale",
    "tncVersion",
    "applicationId",
    "cobrandConversationCredentials",
    "validationHandler",
    "ipAddress",
    "preferenceInfo",
    "preferredLocale",
    "fetchAllLocaleData"
})
@XmlSeeAlso({
    UserContext.class
})
public class CobrandContext
    extends CCobrandContext
{

    protected Long cobrandId;
    protected Long channelId;
    @XmlElementRef(name = "locale", type = JAXBElement.class, required = false)
    protected JAXBElement<Locale> locale;
    protected Long tncVersion;
    @XmlElementRef(name = "applicationId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> applicationId;
    @XmlElementRef(name = "cobrandConversationCredentials", type = JAXBElement.class, required = false)
    protected JAXBElement<ConversationCredentials> cobrandConversationCredentials;
    @XmlElementRef(name = "validationHandler", type = JAXBElement.class, required = false)
    protected JAXBElement<String> validationHandler;
    @XmlElementRef(name = "ipAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> ipAddress;
    @XmlElementRef(name = "preferenceInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<PreferenceInfo> preferenceInfo;
    @XmlElementRef(name = "preferredLocale", type = JAXBElement.class, required = false)
    protected JAXBElement<Locale> preferredLocale;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean fetchAllLocaleData;

    /**
     * Gets the value of the cobrandId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCobrandId() {
        return cobrandId;
    }

    /**
     * Sets the value of the cobrandId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCobrandId(Long value) {
        this.cobrandId = value;
    }

    /**
     * Gets the value of the channelId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getChannelId() {
        return channelId;
    }

    /**
     * Sets the value of the channelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setChannelId(Long value) {
        this.channelId = value;
    }

    /**
     * Gets the value of the locale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public JAXBElement<Locale> getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public void setLocale(JAXBElement<Locale> value) {
        this.locale = value;
    }

    /**
     * Gets the value of the tncVersion property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTncVersion() {
        return tncVersion;
    }

    /**
     * Sets the value of the tncVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTncVersion(Long value) {
        this.tncVersion = value;
    }

    /**
     * Gets the value of the applicationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApplicationId() {
        return applicationId;
    }

    /**
     * Sets the value of the applicationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApplicationId(JAXBElement<String> value) {
        this.applicationId = value;
    }

    /**
     * Gets the value of the cobrandConversationCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}
     *     
     */
    public JAXBElement<ConversationCredentials> getCobrandConversationCredentials() {
        return cobrandConversationCredentials;
    }

    /**
     * Sets the value of the cobrandConversationCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}
     *     
     */
    public void setCobrandConversationCredentials(JAXBElement<ConversationCredentials> value) {
        this.cobrandConversationCredentials = value;
    }

    /**
     * Gets the value of the validationHandler property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getValidationHandler() {
        return validationHandler;
    }

    /**
     * Sets the value of the validationHandler property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setValidationHandler(JAXBElement<String> value) {
        this.validationHandler = value;
    }

    /**
     * Gets the value of the ipAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIpAddress() {
        return ipAddress;
    }

    /**
     * Sets the value of the ipAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIpAddress(JAXBElement<String> value) {
        this.ipAddress = value;
    }

    /**
     * Gets the value of the preferenceInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PreferenceInfo }{@code >}
     *     
     */
    public JAXBElement<PreferenceInfo> getPreferenceInfo() {
        return preferenceInfo;
    }

    /**
     * Sets the value of the preferenceInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PreferenceInfo }{@code >}
     *     
     */
    public void setPreferenceInfo(JAXBElement<PreferenceInfo> value) {
        this.preferenceInfo = value;
    }

    /**
     * Gets the value of the preferredLocale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public JAXBElement<Locale> getPreferredLocale() {
        return preferredLocale;
    }

    /**
     * Sets the value of the preferredLocale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public void setPreferredLocale(JAXBElement<Locale> value) {
        this.preferredLocale = value;
    }

    /**
     * Gets the value of the fetchAllLocaleData property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFetchAllLocaleData() {
        return fetchAllLocaleData;
    }

    /**
     * Sets the value of the fetchAllLocaleData property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFetchAllLocaleData(Boolean value) {
        this.fetchAllLocaleData = value;
    }

}
