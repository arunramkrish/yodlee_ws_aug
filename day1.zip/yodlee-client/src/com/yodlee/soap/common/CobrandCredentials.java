
package com.yodlee.soap.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.CobrandPasswordCredentials;


/**
 * <p>Java class for CobrandCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CobrandCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}ConversationCredentials">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CobrandCredentials")
@XmlSeeAlso({
    CobrandPasswordCredentials.class
})
public class CobrandCredentials
    extends ConversationCredentials
{


}
