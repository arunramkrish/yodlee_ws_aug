
package com.yodlee.soap.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.PWSSessionCredentials;
import com.yodlee.soap.ext.login.SessionCredentials;
import com.yodlee.soap.ext.login.UncertifiedSessionCredentials;


/**
 * <p>Java class for ConversationCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConversationCredentials">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConversationCredentials")
@XmlSeeAlso({
    SessionCredentials.class,
    UncertifiedSessionCredentials.class,
    PWSSessionCredentials.class,
    CobrandCredentials.class,
    UserCredentials.class
})
public class ConversationCredentials {


}
