
package com.yodlee.soap.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CurrencyNotation.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CurrencyNotation">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TEXT_NOTATION"/>
 *     &lt;enumeration value="SYMBOL_NOTATION"/>
 *     &lt;enumeration value="TEXT_SYMBOL_NOTATION"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CurrencyNotation")
@XmlEnum
public enum CurrencyNotation {

    TEXT_NOTATION,
    SYMBOL_NOTATION,
    TEXT_SYMBOL_NOTATION;

    public String value() {
        return name();
    }

    public static CurrencyNotation fromValue(String v) {
        return valueOf(v);
    }

}
