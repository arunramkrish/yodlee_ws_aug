
package com.yodlee.soap.common;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.collections.Locale;
import com.yodlee.soap.core.permissioning.GrantorInfo;
import com.yodlee.soap.ext.login.OAuthAccessCredentials;
import com.yodlee.soap.util.system.ycache.client.ClientCacheContext;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.common package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UserContextOauthAccessCredentials_QNAME = new QName("", "oauthAccessCredentials");
    private final static QName _UserContextConversationCredentials_QNAME = new QName("", "conversationCredentials");
    private final static QName _CobrandContextCobrandConversationCredentials_QNAME = new QName("", "cobrandConversationCredentials");
    private final static QName _CobrandContextPreferenceInfo_QNAME = new QName("", "preferenceInfo");
    private final static QName _CobrandContextLocale_QNAME = new QName("", "locale");
    private final static QName _CobrandContextApplicationId_QNAME = new QName("", "applicationId");
    private final static QName _CobrandContextValidationHandler_QNAME = new QName("", "validationHandler");
    private final static QName _CobrandContextPreferredLocale_QNAME = new QName("", "preferredLocale");
    private final static QName _CobrandContextIpAddress_QNAME = new QName("", "ipAddress");
    private final static QName _NVPairValues_QNAME = new QName("", "values");
    private final static QName _NVPairName_QNAME = new QName("", "name");
    private final static QName _NumberFormatGroupingSeparator_QNAME = new QName("", "groupingSeparator");
    private final static QName _NumberFormatDecimalSeparator_QNAME = new QName("", "decimalSeparator");
    private final static QName _NumberFormatGroupPattern_QNAME = new QName("", "groupPattern");
    private final static QName _SharedUserContextGrantorInfo_QNAME = new QName("", "grantorInfo");
    private final static QName _MoneyAmount_QNAME = new QName("", "amount");
    private final static QName _MoneyCurrencyCode_QNAME = new QName("", "currencyCode");
    private final static QName _PreferenceInfoCurrencyNotationType_QNAME = new QName("", "currencyNotationType");
    private final static QName _PreferenceInfoNumberFormat_QNAME = new QName("", "numberFormat");
    private final static QName _PreferenceInfoDateFormat_QNAME = new QName("", "dateFormat");
    private final static QName _PreferenceInfoTimeZone_QNAME = new QName("", "timeZone");
    private final static QName _AppSharedUserContextClientCacheContext_QNAME = new QName("", "clientCacheContext");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.common
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UserContext }
     * 
     */
    public UserContext createUserContext() {
        return new UserContext();
    }

    /**
     * Create an instance of {@link CalendarDate }
     * 
     */
    public CalendarDate createCalendarDate() {
        return new CalendarDate();
    }

    /**
     * Create an instance of {@link Money }
     * 
     */
    public Money createMoney() {
        return new Money();
    }

    /**
     * Create an instance of {@link NumberFormat }
     * 
     */
    public NumberFormat createNumberFormat() {
        return new NumberFormat();
    }

    /**
     * Create an instance of {@link NVPair }
     * 
     */
    public NVPair createNVPair() {
        return new NVPair();
    }

    /**
     * Create an instance of {@link PreferenceInfo }
     * 
     */
    public PreferenceInfo createPreferenceInfo() {
        return new PreferenceInfo();
    }

    /**
     * Create an instance of {@link CobrandContext }
     * 
     */
    public CobrandContext createCobrandContext() {
        return new CobrandContext();
    }

    /**
     * Create an instance of {@link TempUserContext }
     * 
     */
    public TempUserContext createTempUserContext() {
        return new TempUserContext();
    }

    /**
     * Create an instance of {@link SharedUserContext }
     * 
     */
    public SharedUserContext createSharedUserContext() {
        return new SharedUserContext();
    }

    /**
     * Create an instance of {@link AppSharedUserContext }
     * 
     */
    public AppSharedUserContext createAppSharedUserContext() {
        return new AppSharedUserContext();
    }

    /**
     * Create an instance of {@link UserCredentials }
     * 
     */
    public UserCredentials createUserCredentials() {
        return new UserCredentials();
    }

    /**
     * Create an instance of {@link CobrandCredentials }
     * 
     */
    public CobrandCredentials createCobrandCredentials() {
        return new CobrandCredentials();
    }

    /**
     * Create an instance of {@link ConversationCredentials }
     * 
     */
    public ConversationCredentials createConversationCredentials() {
        return new ConversationCredentials();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OAuthAccessCredentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "oauthAccessCredentials", scope = UserContext.class)
    public JAXBElement<OAuthAccessCredentials> createUserContextOauthAccessCredentials(OAuthAccessCredentials value) {
        return new JAXBElement<OAuthAccessCredentials>(_UserContextOauthAccessCredentials_QNAME, OAuthAccessCredentials.class, UserContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "conversationCredentials", scope = UserContext.class)
    public JAXBElement<ConversationCredentials> createUserContextConversationCredentials(ConversationCredentials value) {
        return new JAXBElement<ConversationCredentials>(_UserContextConversationCredentials_QNAME, ConversationCredentials.class, UserContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cobrandConversationCredentials", scope = CobrandContext.class)
    public JAXBElement<ConversationCredentials> createCobrandContextCobrandConversationCredentials(ConversationCredentials value) {
        return new JAXBElement<ConversationCredentials>(_CobrandContextCobrandConversationCredentials_QNAME, ConversationCredentials.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreferenceInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "preferenceInfo", scope = CobrandContext.class)
    public JAXBElement<PreferenceInfo> createCobrandContextPreferenceInfo(PreferenceInfo value) {
        return new JAXBElement<PreferenceInfo>(_CobrandContextPreferenceInfo_QNAME, PreferenceInfo.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Locale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "locale", scope = CobrandContext.class)
    public JAXBElement<Locale> createCobrandContextLocale(Locale value) {
        return new JAXBElement<Locale>(_CobrandContextLocale_QNAME, Locale.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "applicationId", scope = CobrandContext.class)
    public JAXBElement<String> createCobrandContextApplicationId(String value) {
        return new JAXBElement<String>(_CobrandContextApplicationId_QNAME, String.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "validationHandler", scope = CobrandContext.class)
    public JAXBElement<String> createCobrandContextValidationHandler(String value) {
        return new JAXBElement<String>(_CobrandContextValidationHandler_QNAME, String.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Locale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "preferredLocale", scope = CobrandContext.class)
    public JAXBElement<Locale> createCobrandContextPreferredLocale(Locale value) {
        return new JAXBElement<Locale>(_CobrandContextPreferredLocale_QNAME, Locale.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ipAddress", scope = CobrandContext.class)
    public JAXBElement<String> createCobrandContextIpAddress(String value) {
        return new JAXBElement<String>(_CobrandContextIpAddress_QNAME, String.class, CobrandContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "values", scope = NVPair.class)
    public JAXBElement<List> createNVPairValues(List value) {
        return new JAXBElement<List>(_NVPairValues_QNAME, List.class, NVPair.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "name", scope = NVPair.class)
    public JAXBElement<String> createNVPairName(String value) {
        return new JAXBElement<String>(_NVPairName_QNAME, String.class, NVPair.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "groupingSeparator", scope = NumberFormat.class)
    public JAXBElement<String> createNumberFormatGroupingSeparator(String value) {
        return new JAXBElement<String>(_NumberFormatGroupingSeparator_QNAME, String.class, NumberFormat.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "decimalSeparator", scope = NumberFormat.class)
    public JAXBElement<String> createNumberFormatDecimalSeparator(String value) {
        return new JAXBElement<String>(_NumberFormatDecimalSeparator_QNAME, String.class, NumberFormat.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "groupPattern", scope = NumberFormat.class)
    public JAXBElement<String> createNumberFormatGroupPattern(String value) {
        return new JAXBElement<String>(_NumberFormatGroupPattern_QNAME, String.class, NumberFormat.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GrantorInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "grantorInfo", scope = SharedUserContext.class)
    public JAXBElement<GrantorInfo> createSharedUserContextGrantorInfo(GrantorInfo value) {
        return new JAXBElement<GrantorInfo>(_SharedUserContextGrantorInfo_QNAME, GrantorInfo.class, SharedUserContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = Money.class)
    public JAXBElement<BigDecimal> createMoneyAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_MoneyAmount_QNAME, BigDecimal.class, Money.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currencyCode", scope = Money.class)
    public JAXBElement<String> createMoneyCurrencyCode(String value) {
        return new JAXBElement<String>(_MoneyCurrencyCode_QNAME, String.class, Money.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currencyCode", scope = PreferenceInfo.class)
    public JAXBElement<String> createPreferenceInfoCurrencyCode(String value) {
        return new JAXBElement<String>(_MoneyCurrencyCode_QNAME, String.class, PreferenceInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CurrencyNotation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currencyNotationType", scope = PreferenceInfo.class)
    public JAXBElement<CurrencyNotation> createPreferenceInfoCurrencyNotationType(CurrencyNotation value) {
        return new JAXBElement<CurrencyNotation>(_PreferenceInfoCurrencyNotationType_QNAME, CurrencyNotation.class, PreferenceInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NumberFormat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "numberFormat", scope = PreferenceInfo.class)
    public JAXBElement<NumberFormat> createPreferenceInfoNumberFormat(NumberFormat value) {
        return new JAXBElement<NumberFormat>(_PreferenceInfoNumberFormat_QNAME, NumberFormat.class, PreferenceInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dateFormat", scope = PreferenceInfo.class)
    public JAXBElement<String> createPreferenceInfoDateFormat(String value) {
        return new JAXBElement<String>(_PreferenceInfoDateFormat_QNAME, String.class, PreferenceInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "timeZone", scope = PreferenceInfo.class)
    public JAXBElement<String> createPreferenceInfoTimeZone(String value) {
        return new JAXBElement<String>(_PreferenceInfoTimeZone_QNAME, String.class, PreferenceInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClientCacheContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "clientCacheContext", scope = AppSharedUserContext.class)
    public JAXBElement<ClientCacheContext> createAppSharedUserContextClientCacheContext(ClientCacheContext value) {
        return new JAXBElement<ClientCacheContext>(_AppSharedUserContextClientCacheContext_QNAME, ClientCacheContext.class, AppSharedUserContext.class, value);
    }

}
