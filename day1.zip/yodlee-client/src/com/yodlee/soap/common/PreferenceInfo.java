
package com.yodlee.soap.common;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PreferenceInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PreferenceInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="timeZone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateFormat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currencyNotationType" type="{http://common.soap.yodlee.com}CurrencyNotation" minOccurs="0"/>
 *         &lt;element name="numberFormat" type="{http://common.soap.yodlee.com}NumberFormat" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PreferenceInfo", propOrder = {
    "currencyCode",
    "timeZone",
    "dateFormat",
    "currencyNotationType",
    "numberFormat"
})
public class PreferenceInfo {

    @XmlElementRef(name = "currencyCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> currencyCode;
    @XmlElementRef(name = "timeZone", type = JAXBElement.class, required = false)
    protected JAXBElement<String> timeZone;
    @XmlElementRef(name = "dateFormat", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dateFormat;
    @XmlElementRef(name = "currencyNotationType", type = JAXBElement.class, required = false)
    protected JAXBElement<CurrencyNotation> currencyNotationType;
    @XmlElementRef(name = "numberFormat", type = JAXBElement.class, required = false)
    protected JAXBElement<NumberFormat> numberFormat;

    /**
     * Gets the value of the currencyCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Sets the value of the currencyCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrencyCode(JAXBElement<String> value) {
        this.currencyCode = value;
    }

    /**
     * Gets the value of the timeZone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTimeZone() {
        return timeZone;
    }

    /**
     * Sets the value of the timeZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTimeZone(JAXBElement<String> value) {
        this.timeZone = value;
    }

    /**
     * Gets the value of the dateFormat property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDateFormat() {
        return dateFormat;
    }

    /**
     * Sets the value of the dateFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDateFormat(JAXBElement<String> value) {
        this.dateFormat = value;
    }

    /**
     * Gets the value of the currencyNotationType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CurrencyNotation }{@code >}
     *     
     */
    public JAXBElement<CurrencyNotation> getCurrencyNotationType() {
        return currencyNotationType;
    }

    /**
     * Sets the value of the currencyNotationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CurrencyNotation }{@code >}
     *     
     */
    public void setCurrencyNotationType(JAXBElement<CurrencyNotation> value) {
        this.currencyNotationType = value;
    }

    /**
     * Gets the value of the numberFormat property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link NumberFormat }{@code >}
     *     
     */
    public JAXBElement<NumberFormat> getNumberFormat() {
        return numberFormat;
    }

    /**
     * Sets the value of the numberFormat property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link NumberFormat }{@code >}
     *     
     */
    public void setNumberFormat(JAXBElement<NumberFormat> value) {
        this.numberFormat = value;
    }

}
