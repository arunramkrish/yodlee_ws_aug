
package com.yodlee.soap.common;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.OAuthAccessCredentials;


/**
 * <p>Java class for UserContext complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserContext">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}CobrandContext">
 *       &lt;sequence>
 *         &lt;element name="conversationCredentials" type="{http://common.soap.yodlee.com}ConversationCredentials" minOccurs="0"/>
 *         &lt;element name="valid" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="isPasswordExpired" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="oauthAccessCredentials" type="{http://login.ext.soap.yodlee.com}OAuthAccessCredentials" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserContext", propOrder = {
    "conversationCredentials",
    "valid",
    "isPasswordExpired",
    "oauthAccessCredentials"
})
@XmlSeeAlso({
    TempUserContext.class,
    SharedUserContext.class
})
public class UserContext
    extends CobrandContext
{

    @XmlElementRef(name = "conversationCredentials", type = JAXBElement.class, required = false)
    protected JAXBElement<ConversationCredentials> conversationCredentials;
    protected boolean valid;
    protected boolean isPasswordExpired;
    @XmlElementRef(name = "oauthAccessCredentials", type = JAXBElement.class, required = false)
    protected JAXBElement<OAuthAccessCredentials> oauthAccessCredentials;

    /**
     * Gets the value of the conversationCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}
     *     
     */
    public JAXBElement<ConversationCredentials> getConversationCredentials() {
        return conversationCredentials;
    }

    /**
     * Sets the value of the conversationCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ConversationCredentials }{@code >}
     *     
     */
    public void setConversationCredentials(JAXBElement<ConversationCredentials> value) {
        this.conversationCredentials = value;
    }

    /**
     * Gets the value of the valid property.
     * 
     */
    public boolean isValid() {
        return valid;
    }

    /**
     * Sets the value of the valid property.
     * 
     */
    public void setValid(boolean value) {
        this.valid = value;
    }

    /**
     * Gets the value of the isPasswordExpired property.
     * 
     */
    public boolean isIsPasswordExpired() {
        return isPasswordExpired;
    }

    /**
     * Sets the value of the isPasswordExpired property.
     * 
     */
    public void setIsPasswordExpired(boolean value) {
        this.isPasswordExpired = value;
    }

    /**
     * Gets the value of the oauthAccessCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link OAuthAccessCredentials }{@code >}
     *     
     */
    public JAXBElement<OAuthAccessCredentials> getOauthAccessCredentials() {
        return oauthAccessCredentials;
    }

    /**
     * Sets the value of the oauthAccessCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link OAuthAccessCredentials }{@code >}
     *     
     */
    public void setOauthAccessCredentials(JAXBElement<OAuthAccessCredentials> value) {
        this.oauthAccessCredentials = value;
    }

}
