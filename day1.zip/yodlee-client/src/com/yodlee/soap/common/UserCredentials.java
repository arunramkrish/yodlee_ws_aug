
package com.yodlee.soap.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.ExternalAuthenticationCredentials;
import com.yodlee.soap.ext.login.OAuthAccessCredentials;
import com.yodlee.soap.ext.login.PWSCredentials;
import com.yodlee.soap.ext.login.PasswordCredentials;
import com.yodlee.soap.ext.login.PinCredentials;
import com.yodlee.soap.ext.login.SMSCredentials;
import com.yodlee.soap.ext.login.TokenizedCredentials;
import com.yodlee.soap.ext.login.YSSOCredentials;


/**
 * <p>Java class for UserCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}ConversationCredentials">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserCredentials")
@XmlSeeAlso({
    SMSCredentials.class,
    TokenizedCredentials.class,
    YSSOCredentials.class,
    PasswordCredentials.class,
    PinCredentials.class,
    OAuthAccessCredentials.class,
    PWSCredentials.class,
    ExternalAuthenticationCredentials.class
})
public class UserCredentials
    extends ConversationCredentials
{


}
