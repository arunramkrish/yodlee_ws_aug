@javax.xml.bind.annotation.XmlSchema(namespace = "http://common.soap.yodlee.com")
package com.yodlee.soap.common;
