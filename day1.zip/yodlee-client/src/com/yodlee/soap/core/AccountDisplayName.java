
package com.yodlee.soap.core;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.Map;


/**
 * <p>Java class for AccountDisplayName complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountDisplayName">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accountNames" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="htmlFormattedAccountName" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="SPANCLASS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountDisplayName", propOrder = {
    "accountNames",
    "htmlFormattedAccountName",
    "spanclass"
})
public class AccountDisplayName {

    @XmlElementRef(name = "accountNames", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> accountNames;
    @XmlElementRef(name = "htmlFormattedAccountName", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> htmlFormattedAccountName;
    @XmlElementRef(name = "SPANCLASS", type = JAXBElement.class, required = false)
    protected JAXBElement<String> spanclass;

    /**
     * Gets the value of the accountNames property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getAccountNames() {
        return accountNames;
    }

    /**
     * Sets the value of the accountNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setAccountNames(JAXBElement<Map> value) {
        this.accountNames = value;
    }

    /**
     * Gets the value of the htmlFormattedAccountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getHtmlFormattedAccountName() {
        return htmlFormattedAccountName;
    }

    /**
     * Sets the value of the htmlFormattedAccountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setHtmlFormattedAccountName(JAXBElement<Map> value) {
        this.htmlFormattedAccountName = value;
    }

    /**
     * Gets the value of the spanclass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSPANCLASS() {
        return spanclass;
    }

    /**
     * Sets the value of the spanclass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSPANCLASS(JAXBElement<String> value) {
        this.spanclass = value;
    }

}
