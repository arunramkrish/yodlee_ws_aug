
package com.yodlee.soap.core;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.Map;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _IllegalArgumentValueExceptionFaultFaultText_QNAME = new QName("", "faultText");
    private final static QName _AccountDisplayNameHtmlFormattedAccountName_QNAME = new QName("", "htmlFormattedAccountName");
    private final static QName _AccountDisplayNameSPANCLASS_QNAME = new QName("", "SPANCLASS");
    private final static QName _AccountDisplayNameAccountNames_QNAME = new QName("", "accountNames");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InvalidUserContextExceptionFault }
     * 
     */
    public InvalidUserContextExceptionFault createInvalidUserContextExceptionFault() {
        return new InvalidUserContextExceptionFault();
    }

    /**
     * Create an instance of {@link InvalidItemAccountIdExceptionFault }
     * 
     */
    public InvalidItemAccountIdExceptionFault createInvalidItemAccountIdExceptionFault() {
        return new InvalidItemAccountIdExceptionFault();
    }

    /**
     * Create an instance of {@link StaleConversationCredentialsExceptionFault }
     * 
     */
    public StaleConversationCredentialsExceptionFault createStaleConversationCredentialsExceptionFault() {
        return new StaleConversationCredentialsExceptionFault();
    }

    /**
     * Create an instance of {@link InvalidConversationCredentialsExceptionFault }
     * 
     */
    public InvalidConversationCredentialsExceptionFault createInvalidConversationCredentialsExceptionFault() {
        return new InvalidConversationCredentialsExceptionFault();
    }

    /**
     * Create an instance of {@link CoreExceptionFault }
     * 
     */
    public CoreExceptionFault createCoreExceptionFault() {
        return new CoreExceptionFault();
    }

    /**
     * Create an instance of {@link IllegalArgumentValueExceptionFault }
     * 
     */
    public IllegalArgumentValueExceptionFault createIllegalArgumentValueExceptionFault() {
        return new IllegalArgumentValueExceptionFault();
    }

    /**
     * Create an instance of {@link AccountDisplayName }
     * 
     */
    public AccountDisplayName createAccountDisplayName() {
        return new AccountDisplayName();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = IllegalArgumentValueExceptionFault.class)
    public JAXBElement<String> createIllegalArgumentValueExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, IllegalArgumentValueExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = InvalidConversationCredentialsExceptionFault.class)
    public JAXBElement<String> createInvalidConversationCredentialsExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, InvalidConversationCredentialsExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = StaleConversationCredentialsExceptionFault.class)
    public JAXBElement<String> createStaleConversationCredentialsExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, StaleConversationCredentialsExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = InvalidUserContextExceptionFault.class)
    public JAXBElement<String> createInvalidUserContextExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, InvalidUserContextExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = InvalidItemAccountIdExceptionFault.class)
    public JAXBElement<String> createInvalidItemAccountIdExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, InvalidItemAccountIdExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "faultText", scope = CoreExceptionFault.class)
    public JAXBElement<String> createCoreExceptionFaultFaultText(String value) {
        return new JAXBElement<String>(_IllegalArgumentValueExceptionFaultFaultText_QNAME, String.class, CoreExceptionFault.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "htmlFormattedAccountName", scope = AccountDisplayName.class)
    public JAXBElement<Map> createAccountDisplayNameHtmlFormattedAccountName(Map value) {
        return new JAXBElement<Map>(_AccountDisplayNameHtmlFormattedAccountName_QNAME, Map.class, AccountDisplayName.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SPANCLASS", scope = AccountDisplayName.class)
    public JAXBElement<String> createAccountDisplayNameSPANCLASS(String value) {
        return new JAXBElement<String>(_AccountDisplayNameSPANCLASS_QNAME, String.class, AccountDisplayName.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountNames", scope = AccountDisplayName.class)
    public JAXBElement<Map> createAccountDisplayNameAccountNames(Map value) {
        return new JAXBElement<Map>(_AccountDisplayNameAccountNames_QNAME, Map.class, AccountDisplayName.class, value);
    }

}
