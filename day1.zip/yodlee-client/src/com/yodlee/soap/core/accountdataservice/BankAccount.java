
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBankTransaction;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for BankAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}FinancialAccount">
 *       &lt;sequence>
 *         &lt;element name="annualPercentageYield" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="availableBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="bankAccountType" type="{http://accountdataservice.core.soap.yodlee.com}BankAccountType" minOccurs="0"/>
 *         &lt;element name="currentBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="interestRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="maturityDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="bankTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBankTransaction" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankAccount", propOrder = {
    "annualPercentageYield",
    "availableBalance",
    "bankAccountType",
    "currentBalance",
    "interestRate",
    "maturityDate",
    "bankTransactions"
})
public class BankAccount
    extends FinancialAccount
{

    @XmlElementRef(name = "annualPercentageYield", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> annualPercentageYield;
    @XmlElementRef(name = "availableBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> availableBalance;
    @XmlElementRef(name = "bankAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<BankAccountType> bankAccountType;
    @XmlElementRef(name = "currentBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> currentBalance;
    @XmlElementRef(name = "interestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> interestRate;
    @XmlElementRef(name = "maturityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> maturityDate;
    @XmlElementRef(name = "bankTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBankTransaction> bankTransactions;

    /**
     * Gets the value of the annualPercentageYield property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getAnnualPercentageYield() {
        return annualPercentageYield;
    }

    /**
     * Sets the value of the annualPercentageYield property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setAnnualPercentageYield(JAXBElement<BigDecimal> value) {
        this.annualPercentageYield = value;
    }

    /**
     * Gets the value of the availableBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAvailableBalance() {
        return availableBalance;
    }

    /**
     * Sets the value of the availableBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAvailableBalance(JAXBElement<Money> value) {
        this.availableBalance = value;
    }

    /**
     * Gets the value of the bankAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BankAccountType }{@code >}
     *     
     */
    public JAXBElement<BankAccountType> getBankAccountType() {
        return bankAccountType;
    }

    /**
     * Sets the value of the bankAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BankAccountType }{@code >}
     *     
     */
    public void setBankAccountType(JAXBElement<BankAccountType> value) {
        this.bankAccountType = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setCurrentBalance(JAXBElement<Money> value) {
        this.currentBalance = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setInterestRate(JAXBElement<BigDecimal> value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setMaturityDate(JAXBElement<CalendarDate> value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the bankTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBankTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBankTransaction> getBankTransactions() {
        return bankTransactions;
    }

    /**
     * Sets the value of the bankTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBankTransaction }{@code >}
     *     
     */
    public void setBankTransactions(JAXBElement<ArrayOfBankTransaction> value) {
        this.bankTransactions = value;
    }

}
