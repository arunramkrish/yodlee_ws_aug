
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillPaymentStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BillPaymentStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="INBOX"/>
 *     &lt;enumeration value="OUTBOX"/>
 *     &lt;enumeration value="PAID"/>
 *     &lt;enumeration value="FILED"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="PROCESSING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BillPaymentStatus")
@XmlEnum
public enum BillPaymentStatus {

    INBOX,
    OUTBOX,
    PAID,
    FILED,
    UNKNOWN,
    PROCESSING;

    public String value() {
        return name();
    }

    public static BillPaymentStatus fromValue(String v) {
        return valueOf(v);
    }

}
