
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingPayment;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingStatement;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for BillingAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillingAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}FinancialAccount">
 *       &lt;sequence>
 *         &lt;element name="outstandingAmountDue" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="outstandingMinimumAmountDue" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="lastPaymentAmount" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="lastPaymentDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="payments" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="billingStatements" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillingStatement" minOccurs="0"/>
 *         &lt;element name="billingPayments" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillingPayment" minOccurs="0"/>
 *         &lt;element name="userAutoPayEnrollmentStatus" type="{http://accountdataservice.core.soap.yodlee.com}AutoPayEnrollmentStatus" minOccurs="0"/>
 *         &lt;element name="userAutoPayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillingAccount", propOrder = {
    "outstandingAmountDue",
    "outstandingMinimumAmountDue",
    "lastPaymentAmount",
    "lastPaymentDate",
    "payments",
    "billingStatements",
    "billingPayments",
    "userAutoPayEnrollmentStatus",
    "userAutoPayEnrollmentStatusLastUpdated"
})
@XmlSeeAlso({
    InsuranceAccount.class,
    CardAccount.class,
    LoanAccount.class,
    WirelessAccount.class
})
public class BillingAccount
    extends FinancialAccount
{

    @XmlElementRef(name = "outstandingAmountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> outstandingAmountDue;
    @XmlElementRef(name = "outstandingMinimumAmountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> outstandingMinimumAmountDue;
    @XmlElementRef(name = "lastPaymentAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> lastPaymentAmount;
    @XmlElementRef(name = "lastPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> lastPaymentDate;
    @XmlElementRef(name = "payments", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> payments;
    @XmlElementRef(name = "billingStatements", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillingStatement> billingStatements;
    @XmlElementRef(name = "billingPayments", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillingPayment> billingPayments;
    @XmlElementRef(name = "userAutoPayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<AutoPayEnrollmentStatus> userAutoPayEnrollmentStatus;
    @XmlElementRef(name = "userAutoPayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> userAutoPayEnrollmentStatusLastUpdated;

    /**
     * Gets the value of the outstandingAmountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getOutstandingAmountDue() {
        return outstandingAmountDue;
    }

    /**
     * Sets the value of the outstandingAmountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setOutstandingAmountDue(JAXBElement<Money> value) {
        this.outstandingAmountDue = value;
    }

    /**
     * Gets the value of the outstandingMinimumAmountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getOutstandingMinimumAmountDue() {
        return outstandingMinimumAmountDue;
    }

    /**
     * Sets the value of the outstandingMinimumAmountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setOutstandingMinimumAmountDue(JAXBElement<Money> value) {
        this.outstandingMinimumAmountDue = value;
    }

    /**
     * Gets the value of the lastPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Sets the value of the lastPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setLastPaymentAmount(JAXBElement<Money> value) {
        this.lastPaymentAmount = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setLastPaymentDate(JAXBElement<CalendarDate> value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the payments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPayments() {
        return payments;
    }

    /**
     * Sets the value of the payments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPayments(JAXBElement<Money> value) {
        this.payments = value;
    }

    /**
     * Gets the value of the billingStatements property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingStatement }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillingStatement> getBillingStatements() {
        return billingStatements;
    }

    /**
     * Sets the value of the billingStatements property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingStatement }{@code >}
     *     
     */
    public void setBillingStatements(JAXBElement<ArrayOfBillingStatement> value) {
        this.billingStatements = value;
    }

    /**
     * Gets the value of the billingPayments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillingPayment> getBillingPayments() {
        return billingPayments;
    }

    /**
     * Sets the value of the billingPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}
     *     
     */
    public void setBillingPayments(JAXBElement<ArrayOfBillingPayment> value) {
        this.billingPayments = value;
    }

    /**
     * Gets the value of the userAutoPayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AutoPayEnrollmentStatus }{@code >}
     *     
     */
    public JAXBElement<AutoPayEnrollmentStatus> getUserAutoPayEnrollmentStatus() {
        return userAutoPayEnrollmentStatus;
    }

    /**
     * Sets the value of the userAutoPayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AutoPayEnrollmentStatus }{@code >}
     *     
     */
    public void setUserAutoPayEnrollmentStatus(JAXBElement<AutoPayEnrollmentStatus> value) {
        this.userAutoPayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the userAutoPayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getUserAutoPayEnrollmentStatusLastUpdated() {
        return userAutoPayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the userAutoPayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setUserAutoPayEnrollmentStatusLastUpdated(JAXBElement<XMLGregorianCalendar> value) {
        this.userAutoPayEnrollmentStatusLastUpdated = value;
    }

}
