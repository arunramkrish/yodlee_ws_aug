
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingCharge;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for BillingStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillingStatement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}SummaryData">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="statementDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="amountDue" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="minimumAmountDue" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="billingCharges" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillingCharge" minOccurs="0"/>
 *         &lt;element name="periodEndDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="periodStartDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="dueDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="newCharges" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="pastDueAmount" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="adjustments" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="payments" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="adjustmentsAndPayments" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="latePaymentCharge" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="dueOnReceipt" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="dueDateEstimated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="derivedBillStatus" type="{http://accountdataservice.core.soap.yodlee.com}BillPaymentStatus" minOccurs="0"/>
 *         &lt;element name="userBillStatus" type="{http://accountdataservice.core.soap.yodlee.com}BillPaymentStatus" minOccurs="0"/>
 *         &lt;element name="userBillStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillingStatement", propOrder = {
    "id",
    "accountNumber",
    "statementDate",
    "amountDue",
    "minimumAmountDue",
    "billingCharges",
    "periodEndDate",
    "periodStartDate",
    "dueDate",
    "newCharges",
    "pastDueAmount",
    "adjustments",
    "payments",
    "adjustmentsAndPayments",
    "latePaymentCharge",
    "dueOnReceipt",
    "dueDateEstimated",
    "derivedBillStatus",
    "userBillStatus",
    "userBillStatusLastUpdated"
})
@XmlSeeAlso({
    CardStatement.class,
    InsuranceStatement.class,
    WirelessStatement.class
})
public class BillingStatement
    extends SummaryData
{

    @XmlElementRef(name = "id", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> id;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "statementDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> statementDate;
    @XmlElementRef(name = "amountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> amountDue;
    @XmlElementRef(name = "minimumAmountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> minimumAmountDue;
    @XmlElementRef(name = "billingCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillingCharge> billingCharges;
    @XmlElementRef(name = "periodEndDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> periodEndDate;
    @XmlElementRef(name = "periodStartDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> periodStartDate;
    @XmlElementRef(name = "dueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> dueDate;
    @XmlElementRef(name = "newCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> newCharges;
    @XmlElementRef(name = "pastDueAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> pastDueAmount;
    @XmlElementRef(name = "adjustments", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> adjustments;
    @XmlElementRef(name = "payments", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> payments;
    @XmlElementRef(name = "adjustmentsAndPayments", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> adjustmentsAndPayments;
    @XmlElementRef(name = "latePaymentCharge", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> latePaymentCharge;
    protected boolean dueOnReceipt;
    protected boolean dueDateEstimated;
    @XmlElementRef(name = "derivedBillStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<BillPaymentStatus> derivedBillStatus;
    @XmlElementRef(name = "userBillStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<BillPaymentStatus> userBillStatus;
    @XmlElementRef(name = "userBillStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> userBillStatusLastUpdated;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setId(JAXBElement<Long> value) {
        this.id = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the statementDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getStatementDate() {
        return statementDate;
    }

    /**
     * Sets the value of the statementDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setStatementDate(JAXBElement<CalendarDate> value) {
        this.statementDate = value;
    }

    /**
     * Gets the value of the amountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAmountDue() {
        return amountDue;
    }

    /**
     * Sets the value of the amountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAmountDue(JAXBElement<Money> value) {
        this.amountDue = value;
    }

    /**
     * Gets the value of the minimumAmountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getMinimumAmountDue() {
        return minimumAmountDue;
    }

    /**
     * Sets the value of the minimumAmountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setMinimumAmountDue(JAXBElement<Money> value) {
        this.minimumAmountDue = value;
    }

    /**
     * Gets the value of the billingCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingCharge }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillingCharge> getBillingCharges() {
        return billingCharges;
    }

    /**
     * Sets the value of the billingCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingCharge }{@code >}
     *     
     */
    public void setBillingCharges(JAXBElement<ArrayOfBillingCharge> value) {
        this.billingCharges = value;
    }

    /**
     * Gets the value of the periodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getPeriodEndDate() {
        return periodEndDate;
    }

    /**
     * Sets the value of the periodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setPeriodEndDate(JAXBElement<CalendarDate> value) {
        this.periodEndDate = value;
    }

    /**
     * Gets the value of the periodStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getPeriodStartDate() {
        return periodStartDate;
    }

    /**
     * Sets the value of the periodStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setPeriodStartDate(JAXBElement<CalendarDate> value) {
        this.periodStartDate = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setDueDate(JAXBElement<CalendarDate> value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the newCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getNewCharges() {
        return newCharges;
    }

    /**
     * Sets the value of the newCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setNewCharges(JAXBElement<Money> value) {
        this.newCharges = value;
    }

    /**
     * Gets the value of the pastDueAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPastDueAmount() {
        return pastDueAmount;
    }

    /**
     * Sets the value of the pastDueAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPastDueAmount(JAXBElement<Money> value) {
        this.pastDueAmount = value;
    }

    /**
     * Gets the value of the adjustments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAdjustments() {
        return adjustments;
    }

    /**
     * Sets the value of the adjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAdjustments(JAXBElement<Money> value) {
        this.adjustments = value;
    }

    /**
     * Gets the value of the payments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPayments() {
        return payments;
    }

    /**
     * Sets the value of the payments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPayments(JAXBElement<Money> value) {
        this.payments = value;
    }

    /**
     * Gets the value of the adjustmentsAndPayments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAdjustmentsAndPayments() {
        return adjustmentsAndPayments;
    }

    /**
     * Sets the value of the adjustmentsAndPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAdjustmentsAndPayments(JAXBElement<Money> value) {
        this.adjustmentsAndPayments = value;
    }

    /**
     * Gets the value of the latePaymentCharge property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getLatePaymentCharge() {
        return latePaymentCharge;
    }

    /**
     * Sets the value of the latePaymentCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setLatePaymentCharge(JAXBElement<Money> value) {
        this.latePaymentCharge = value;
    }

    /**
     * Gets the value of the dueOnReceipt property.
     * 
     */
    public boolean isDueOnReceipt() {
        return dueOnReceipt;
    }

    /**
     * Sets the value of the dueOnReceipt property.
     * 
     */
    public void setDueOnReceipt(boolean value) {
        this.dueOnReceipt = value;
    }

    /**
     * Gets the value of the dueDateEstimated property.
     * 
     */
    public boolean isDueDateEstimated() {
        return dueDateEstimated;
    }

    /**
     * Sets the value of the dueDateEstimated property.
     * 
     */
    public void setDueDateEstimated(boolean value) {
        this.dueDateEstimated = value;
    }

    /**
     * Gets the value of the derivedBillStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}
     *     
     */
    public JAXBElement<BillPaymentStatus> getDerivedBillStatus() {
        return derivedBillStatus;
    }

    /**
     * Sets the value of the derivedBillStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}
     *     
     */
    public void setDerivedBillStatus(JAXBElement<BillPaymentStatus> value) {
        this.derivedBillStatus = value;
    }

    /**
     * Gets the value of the userBillStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}
     *     
     */
    public JAXBElement<BillPaymentStatus> getUserBillStatus() {
        return userBillStatus;
    }

    /**
     * Sets the value of the userBillStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}
     *     
     */
    public void setUserBillStatus(JAXBElement<BillPaymentStatus> value) {
        this.userBillStatus = value;
    }

    /**
     * Gets the value of the userBillStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getUserBillStatusLastUpdated() {
        return userBillStatusLastUpdated;
    }

    /**
     * Sets the value of the userBillStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setUserBillStatusLastUpdated(JAXBElement<XMLGregorianCalendar> value) {
        this.userBillStatusLastUpdated = value;
    }

}
