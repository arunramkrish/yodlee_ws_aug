
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfCardTransaction;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for CardAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingAccount">
 *       &lt;sequence>
 *         &lt;element name="apr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="availableCredit" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="runningBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="totalCreditLine" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="availableCash" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="cashApr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="totalCashLimit" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="newCharges" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="cardTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfCardTransaction" minOccurs="0"/>
 *         &lt;element name="unbilledCardTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfCardTransaction" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardAccount", propOrder = {
    "apr",
    "availableCredit",
    "runningBalance",
    "totalCreditLine",
    "availableCash",
    "cashApr",
    "totalCashLimit",
    "newCharges",
    "cardTransactions",
    "unbilledCardTransactions"
})
public class CardAccount
    extends BillingAccount
{

    @XmlElementRef(name = "apr", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> apr;
    @XmlElementRef(name = "availableCredit", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> availableCredit;
    @XmlElementRef(name = "runningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> runningBalance;
    @XmlElementRef(name = "totalCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> totalCreditLine;
    @XmlElementRef(name = "availableCash", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> availableCash;
    @XmlElementRef(name = "cashApr", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> cashApr;
    @XmlElementRef(name = "totalCashLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> totalCashLimit;
    @XmlElementRef(name = "newCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> newCharges;
    @XmlElementRef(name = "cardTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfCardTransaction> cardTransactions;
    @XmlElementRef(name = "unbilledCardTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfCardTransaction> unbilledCardTransactions;

    /**
     * Gets the value of the apr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getApr() {
        return apr;
    }

    /**
     * Sets the value of the apr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setApr(JAXBElement<BigDecimal> value) {
        this.apr = value;
    }

    /**
     * Gets the value of the availableCredit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAvailableCredit() {
        return availableCredit;
    }

    /**
     * Sets the value of the availableCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAvailableCredit(JAXBElement<Money> value) {
        this.availableCredit = value;
    }

    /**
     * Gets the value of the runningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getRunningBalance() {
        return runningBalance;
    }

    /**
     * Sets the value of the runningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setRunningBalance(JAXBElement<Money> value) {
        this.runningBalance = value;
    }

    /**
     * Gets the value of the totalCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getTotalCreditLine() {
        return totalCreditLine;
    }

    /**
     * Sets the value of the totalCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setTotalCreditLine(JAXBElement<Money> value) {
        this.totalCreditLine = value;
    }

    /**
     * Gets the value of the availableCash property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAvailableCash() {
        return availableCash;
    }

    /**
     * Sets the value of the availableCash property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAvailableCash(JAXBElement<Money> value) {
        this.availableCash = value;
    }

    /**
     * Gets the value of the cashApr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCashApr() {
        return cashApr;
    }

    /**
     * Sets the value of the cashApr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCashApr(JAXBElement<BigDecimal> value) {
        this.cashApr = value;
    }

    /**
     * Gets the value of the totalCashLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getTotalCashLimit() {
        return totalCashLimit;
    }

    /**
     * Sets the value of the totalCashLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setTotalCashLimit(JAXBElement<Money> value) {
        this.totalCashLimit = value;
    }

    /**
     * Gets the value of the newCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getNewCharges() {
        return newCharges;
    }

    /**
     * Sets the value of the newCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setNewCharges(JAXBElement<Money> value) {
        this.newCharges = value;
    }

    /**
     * Gets the value of the cardTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfCardTransaction> getCardTransactions() {
        return cardTransactions;
    }

    /**
     * Sets the value of the cardTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public void setCardTransactions(JAXBElement<ArrayOfCardTransaction> value) {
        this.cardTransactions = value;
    }

    /**
     * Gets the value of the unbilledCardTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfCardTransaction> getUnbilledCardTransactions() {
        return unbilledCardTransactions;
    }

    /**
     * Sets the value of the unbilledCardTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public void setUnbilledCardTransactions(JAXBElement<ArrayOfCardTransaction> value) {
        this.unbilledCardTransactions = value;
    }

}
