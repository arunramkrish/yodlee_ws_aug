
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfCardTransaction;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for CardStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardStatement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingStatement">
 *       &lt;sequence>
 *         &lt;element name="apr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="availableCredit" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="totalCreditLine" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="credits" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="financeCharges" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="availableCash" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="cashApr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="totalCashLimit" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="cashAdvance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="interestPaidThisPeriod" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="interestPaidYearToDate" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="cardTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfCardTransaction" minOccurs="0"/>
 *         &lt;element name="endingBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="previousEndingBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardStatement", propOrder = {
    "apr",
    "availableCredit",
    "totalCreditLine",
    "credits",
    "financeCharges",
    "availableCash",
    "cashApr",
    "totalCashLimit",
    "cashAdvance",
    "interestPaidThisPeriod",
    "interestPaidYearToDate",
    "cardTransactions",
    "endingBalance",
    "previousEndingBalance"
})
public class CardStatement
    extends BillingStatement
{

    @XmlElementRef(name = "apr", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> apr;
    @XmlElementRef(name = "availableCredit", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> availableCredit;
    @XmlElementRef(name = "totalCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> totalCreditLine;
    @XmlElementRef(name = "credits", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> credits;
    @XmlElementRef(name = "financeCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> financeCharges;
    @XmlElementRef(name = "availableCash", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> availableCash;
    @XmlElementRef(name = "cashApr", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> cashApr;
    @XmlElementRef(name = "totalCashLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> totalCashLimit;
    @XmlElementRef(name = "cashAdvance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> cashAdvance;
    @XmlElementRef(name = "interestPaidThisPeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> interestPaidThisPeriod;
    @XmlElementRef(name = "interestPaidYearToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> interestPaidYearToDate;
    @XmlElementRef(name = "cardTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfCardTransaction> cardTransactions;
    @XmlElementRef(name = "endingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> endingBalance;
    @XmlElementRef(name = "previousEndingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> previousEndingBalance;

    /**
     * Gets the value of the apr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getApr() {
        return apr;
    }

    /**
     * Sets the value of the apr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setApr(JAXBElement<BigDecimal> value) {
        this.apr = value;
    }

    /**
     * Gets the value of the availableCredit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAvailableCredit() {
        return availableCredit;
    }

    /**
     * Sets the value of the availableCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAvailableCredit(JAXBElement<Money> value) {
        this.availableCredit = value;
    }

    /**
     * Gets the value of the totalCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getTotalCreditLine() {
        return totalCreditLine;
    }

    /**
     * Sets the value of the totalCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setTotalCreditLine(JAXBElement<Money> value) {
        this.totalCreditLine = value;
    }

    /**
     * Gets the value of the credits property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getCredits() {
        return credits;
    }

    /**
     * Sets the value of the credits property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setCredits(JAXBElement<Money> value) {
        this.credits = value;
    }

    /**
     * Gets the value of the financeCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getFinanceCharges() {
        return financeCharges;
    }

    /**
     * Sets the value of the financeCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setFinanceCharges(JAXBElement<Money> value) {
        this.financeCharges = value;
    }

    /**
     * Gets the value of the availableCash property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAvailableCash() {
        return availableCash;
    }

    /**
     * Sets the value of the availableCash property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAvailableCash(JAXBElement<Money> value) {
        this.availableCash = value;
    }

    /**
     * Gets the value of the cashApr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getCashApr() {
        return cashApr;
    }

    /**
     * Sets the value of the cashApr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setCashApr(JAXBElement<BigDecimal> value) {
        this.cashApr = value;
    }

    /**
     * Gets the value of the totalCashLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getTotalCashLimit() {
        return totalCashLimit;
    }

    /**
     * Sets the value of the totalCashLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setTotalCashLimit(JAXBElement<Money> value) {
        this.totalCashLimit = value;
    }

    /**
     * Gets the value of the cashAdvance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getCashAdvance() {
        return cashAdvance;
    }

    /**
     * Sets the value of the cashAdvance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setCashAdvance(JAXBElement<Money> value) {
        this.cashAdvance = value;
    }

    /**
     * Gets the value of the interestPaidThisPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getInterestPaidThisPeriod() {
        return interestPaidThisPeriod;
    }

    /**
     * Sets the value of the interestPaidThisPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setInterestPaidThisPeriod(JAXBElement<Money> value) {
        this.interestPaidThisPeriod = value;
    }

    /**
     * Gets the value of the interestPaidYearToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getInterestPaidYearToDate() {
        return interestPaidYearToDate;
    }

    /**
     * Sets the value of the interestPaidYearToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setInterestPaidYearToDate(JAXBElement<Money> value) {
        this.interestPaidYearToDate = value;
    }

    /**
     * Gets the value of the cardTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfCardTransaction> getCardTransactions() {
        return cardTransactions;
    }

    /**
     * Sets the value of the cardTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}
     *     
     */
    public void setCardTransactions(JAXBElement<ArrayOfCardTransaction> value) {
        this.cardTransactions = value;
    }

    /**
     * Gets the value of the endingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getEndingBalance() {
        return endingBalance;
    }

    /**
     * Sets the value of the endingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setEndingBalance(JAXBElement<Money> value) {
        this.endingBalance = value;
    }

    /**
     * Gets the value of the previousEndingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPreviousEndingBalance() {
        return previousEndingBalance;
    }

    /**
     * Sets the value of the previousEndingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPreviousEndingBalance(JAXBElement<Money> value) {
        this.previousEndingBalance = value;
    }

}
