
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DataType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DataType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CREDIT_CARD"/>
 *     &lt;enumeration value="LOAN"/>
 *     &lt;enumeration value="MORTGAGE"/>
 *     &lt;enumeration value="INSURANCE"/>
 *     &lt;enumeration value="TELEPHONE"/>
 *     &lt;enumeration value="WIRELESS"/>
 *     &lt;enumeration value="CABLE_AND_SATELLITE"/>
 *     &lt;enumeration value="UTILITIES"/>
 *     &lt;enumeration value="OTHER_BILLER"/>
 *     &lt;enumeration value="BANKING"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DataType")
@XmlEnum
public enum DataType {

    CREDIT_CARD,
    LOAN,
    MORTGAGE,
    INSURANCE,
    TELEPHONE,
    WIRELESS,
    CABLE_AND_SATELLITE,
    UTILITIES,
    OTHER_BILLER,
    BANKING;

    public String value() {
        return name();
    }

    public static DataType fromValue(String v) {
        return valueOf(v);
    }

}
