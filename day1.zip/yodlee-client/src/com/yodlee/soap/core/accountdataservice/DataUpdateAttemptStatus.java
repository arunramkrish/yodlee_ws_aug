
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DataUpdateAttemptStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DataUpdateAttemptStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SUCCESS"/>
 *     &lt;enumeration value="IN_PROCESS"/>
 *     &lt;enumeration value="USER_ACTION_REQUIRED"/>
 *     &lt;enumeration value="LOGIN_FAILURE"/>
 *     &lt;enumeration value="DATA_SOURCE_ERROR"/>
 *     &lt;enumeration value="OTHER_ERROR"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DataUpdateAttemptStatus")
@XmlEnum
public enum DataUpdateAttemptStatus {

    SUCCESS,
    IN_PROCESS,
    USER_ACTION_REQUIRED,
    LOGIN_FAILURE,
    DATA_SOURCE_ERROR,
    OTHER_ERROR;

    public String value() {
        return name();
    }

    public static DataUpdateAttemptStatus fromValue(String v) {
        return valueOf(v);
    }

}
