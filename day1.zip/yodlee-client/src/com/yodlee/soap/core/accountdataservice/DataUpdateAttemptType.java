
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DataUpdateAttemptType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DataUpdateAttemptType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="USER_REQUESTED"/>
 *     &lt;enumeration value="SCHEDULED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DataUpdateAttemptType")
@XmlEnum
public enum DataUpdateAttemptType {

    USER_REQUESTED,
    SCHEDULED;

    public String value() {
        return name();
    }

    public static DataUpdateAttemptType fromValue(String v) {
        return valueOf(v);
    }

}
