
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for FinancialTransaction complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialTransaction">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}SummaryData">
 *       &lt;sequence>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="transactionDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="amount" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="transactionType" type="{http://accountdataservice.core.soap.yodlee.com}TransactionType" minOccurs="0"/>
 *         &lt;element name="referenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialTransaction", propOrder = {
    "description",
    "postDate",
    "transactionDate",
    "amount",
    "transactionType",
    "referenceNumber"
})
@XmlSeeAlso({
    CardTransaction.class,
    FinLoanTransaction.class,
    InsuranceTransaction.class,
    BankTransaction.class
})
public abstract class FinancialTransaction
    extends SummaryData
{

    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "postDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> postDate;
    @XmlElementRef(name = "transactionDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> transactionDate;
    @XmlElementRef(name = "amount", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> amount;
    @XmlElementRef(name = "transactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<TransactionType> transactionType;
    @XmlElementRef(name = "referenceNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> referenceNumber;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the postDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getPostDate() {
        return postDate;
    }

    /**
     * Sets the value of the postDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setPostDate(JAXBElement<CalendarDate> value) {
        this.postDate = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setTransactionDate(JAXBElement<CalendarDate> value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setAmount(JAXBElement<Money> value) {
        this.amount = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link TransactionType }{@code >}
     *     
     */
    public JAXBElement<TransactionType> getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link TransactionType }{@code >}
     *     
     */
    public void setTransactionType(JAXBElement<TransactionType> value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the referenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getReferenceNumber() {
        return referenceNumber;
    }

    /**
     * Sets the value of the referenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setReferenceNumber(JAXBElement<String> value) {
        this.referenceNumber = value;
    }

}
