
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfInsurancePolicy;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfInsuranceTransaction;


/**
 * <p>Java class for InsuranceAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuranceAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingAccount">
 *       &lt;sequence>
 *         &lt;element name="insurancePolicies" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfInsurancePolicy" minOccurs="0"/>
 *         &lt;element name="insuranceTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfInsuranceTransaction" minOccurs="0"/>
 *         &lt;element name="unbilledInsuranceTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfInsuranceTransaction" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuranceAccount", propOrder = {
    "insurancePolicies",
    "insuranceTransactions",
    "unbilledInsuranceTransactions"
})
public class InsuranceAccount
    extends BillingAccount
{

    @XmlElementRef(name = "insurancePolicies", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfInsurancePolicy> insurancePolicies;
    @XmlElementRef(name = "insuranceTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfInsuranceTransaction> insuranceTransactions;
    @XmlElementRef(name = "unbilledInsuranceTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfInsuranceTransaction> unbilledInsuranceTransactions;

    /**
     * Gets the value of the insurancePolicies property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsurancePolicy }{@code >}
     *     
     */
    public JAXBElement<ArrayOfInsurancePolicy> getInsurancePolicies() {
        return insurancePolicies;
    }

    /**
     * Sets the value of the insurancePolicies property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsurancePolicy }{@code >}
     *     
     */
    public void setInsurancePolicies(JAXBElement<ArrayOfInsurancePolicy> value) {
        this.insurancePolicies = value;
    }

    /**
     * Gets the value of the insuranceTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfInsuranceTransaction> getInsuranceTransactions() {
        return insuranceTransactions;
    }

    /**
     * Sets the value of the insuranceTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public void setInsuranceTransactions(JAXBElement<ArrayOfInsuranceTransaction> value) {
        this.insuranceTransactions = value;
    }

    /**
     * Gets the value of the unbilledInsuranceTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfInsuranceTransaction> getUnbilledInsuranceTransactions() {
        return unbilledInsuranceTransactions;
    }

    /**
     * Sets the value of the unbilledInsuranceTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public void setUnbilledInsuranceTransactions(JAXBElement<ArrayOfInsuranceTransaction> value) {
        this.unbilledInsuranceTransactions = value;
    }

}
