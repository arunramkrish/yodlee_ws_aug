
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for InsurancePolicy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsurancePolicy">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}SummaryData">
 *       &lt;sequence>
 *         &lt;element name="policyHolder" type="{http://accountdataservice.core.soap.yodlee.com}PersonInformation" minOccurs="0"/>
 *         &lt;element name="policyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policyNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="effectiveDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="expirationDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="insurancePolicyType" type="{http://accountdataservice.core.soap.yodlee.com}InsurancePolicyType" minOccurs="0"/>
 *         &lt;element name="premiumAmount" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsurancePolicy", propOrder = {
    "policyHolder",
    "policyName",
    "policyNumber",
    "effectiveDate",
    "expirationDate",
    "insurancePolicyType",
    "premiumAmount"
})
public class InsurancePolicy
    extends SummaryData
{

    @XmlElementRef(name = "policyHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonInformation> policyHolder;
    @XmlElementRef(name = "policyName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> policyName;
    @XmlElementRef(name = "policyNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> policyNumber;
    @XmlElementRef(name = "effectiveDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> effectiveDate;
    @XmlElementRef(name = "expirationDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> expirationDate;
    @XmlElementRef(name = "insurancePolicyType", type = JAXBElement.class, required = false)
    protected JAXBElement<InsurancePolicyType> insurancePolicyType;
    @XmlElementRef(name = "premiumAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> premiumAmount;

    /**
     * Gets the value of the policyHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonInformation }{@code >}
     *     
     */
    public JAXBElement<PersonInformation> getPolicyHolder() {
        return policyHolder;
    }

    /**
     * Sets the value of the policyHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonInformation }{@code >}
     *     
     */
    public void setPolicyHolder(JAXBElement<PersonInformation> value) {
        this.policyHolder = value;
    }

    /**
     * Gets the value of the policyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyName() {
        return policyName;
    }

    /**
     * Sets the value of the policyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyName(JAXBElement<String> value) {
        this.policyName = value;
    }

    /**
     * Gets the value of the policyNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyNumber() {
        return policyNumber;
    }

    /**
     * Sets the value of the policyNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyNumber(JAXBElement<String> value) {
        this.policyNumber = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setEffectiveDate(JAXBElement<CalendarDate> value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setExpirationDate(JAXBElement<CalendarDate> value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the insurancePolicyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link InsurancePolicyType }{@code >}
     *     
     */
    public JAXBElement<InsurancePolicyType> getInsurancePolicyType() {
        return insurancePolicyType;
    }

    /**
     * Sets the value of the insurancePolicyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link InsurancePolicyType }{@code >}
     *     
     */
    public void setInsurancePolicyType(JAXBElement<InsurancePolicyType> value) {
        this.insurancePolicyType = value;
    }

    /**
     * Gets the value of the premiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPremiumAmount() {
        return premiumAmount;
    }

    /**
     * Sets the value of the premiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPremiumAmount(JAXBElement<Money> value) {
        this.premiumAmount = value;
    }

}
