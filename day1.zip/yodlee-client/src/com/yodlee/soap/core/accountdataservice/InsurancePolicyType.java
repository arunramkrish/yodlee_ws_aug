
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for InsurancePolicyType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="InsurancePolicyType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HEALTH"/>
 *     &lt;enumeration value="HOME"/>
 *     &lt;enumeration value="AUTO"/>
 *     &lt;enumeration value="LIFE"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "InsurancePolicyType")
@XmlEnum
public enum InsurancePolicyType {

    HEALTH,
    HOME,
    AUTO,
    LIFE,
    OTHER,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static InsurancePolicyType fromValue(String v) {
        return valueOf(v);
    }

}
