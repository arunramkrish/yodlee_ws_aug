
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfInsuranceTransaction;


/**
 * <p>Java class for InsuranceStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuranceStatement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingStatement">
 *       &lt;sequence>
 *         &lt;element name="insuranceTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfInsuranceTransaction" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuranceStatement", propOrder = {
    "insuranceTransactions"
})
public class InsuranceStatement
    extends BillingStatement
{

    @XmlElementRef(name = "insuranceTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfInsuranceTransaction> insuranceTransactions;

    /**
     * Gets the value of the insuranceTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfInsuranceTransaction> getInsuranceTransactions() {
        return insuranceTransactions;
    }

    /**
     * Sets the value of the insuranceTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}
     *     
     */
    public void setInsuranceTransactions(JAXBElement<ArrayOfInsuranceTransaction> value) {
        this.insuranceTransactions = value;
    }

}
