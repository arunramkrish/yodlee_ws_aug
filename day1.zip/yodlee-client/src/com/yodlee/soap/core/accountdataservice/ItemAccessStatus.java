
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ItemAccessStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ItemAccessStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="AUTO_REGISTRATION_INCOMPLETE"/>
 *     &lt;enumeration value="ACCESS_PENDING_REVERIFICATION"/>
 *     &lt;enumeration value="ACCESS_VERIFIED"/>
 *     &lt;enumeration value="ACCESS_NOT_VERIFIED"/>
 *     &lt;enumeration value="DELETED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ItemAccessStatus")
@XmlEnum
public enum ItemAccessStatus {

    AUTO_REGISTRATION_INCOMPLETE,
    ACCESS_PENDING_REVERIFICATION,
    ACCESS_VERIFIED,
    ACCESS_NOT_VERIFIED,
    DELETED;

    public String value() {
        return name();
    }

    public static ItemAccessStatus fromValue(String v) {
        return valueOf(v);
    }

}
