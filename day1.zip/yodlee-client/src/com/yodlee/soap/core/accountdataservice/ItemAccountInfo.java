
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ItemAccountInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemAccountInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="itemAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemAccountStatus" type="{http://accountdataservice.core.soap.yodlee.com}ItemAccountStatus" minOccurs="0"/>
 *         &lt;element name="itemAccountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemInfo" type="{http://accountdataservice.core.soap.yodlee.com}ItemInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemAccountInfo", propOrder = {
    "itemAccountId",
    "itemAccountNumber",
    "itemAccountStatus",
    "itemAccountName",
    "itemInfo"
})
public class ItemAccountInfo {

    protected Long itemAccountId;
    @XmlElementRef(name = "itemAccountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> itemAccountNumber;
    @XmlElementRef(name = "itemAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<ItemAccountStatus> itemAccountStatus;
    @XmlElementRef(name = "itemAccountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> itemAccountName;
    @XmlElementRef(name = "itemInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<ItemInfo> itemInfo;

    /**
     * Gets the value of the itemAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getItemAccountId() {
        return itemAccountId;
    }

    /**
     * Sets the value of the itemAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setItemAccountId(Long value) {
        this.itemAccountId = value;
    }

    /**
     * Gets the value of the itemAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getItemAccountNumber() {
        return itemAccountNumber;
    }

    /**
     * Sets the value of the itemAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setItemAccountNumber(JAXBElement<String> value) {
        this.itemAccountNumber = value;
    }

    /**
     * Gets the value of the itemAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ItemAccountStatus }{@code >}
     *     
     */
    public JAXBElement<ItemAccountStatus> getItemAccountStatus() {
        return itemAccountStatus;
    }

    /**
     * Sets the value of the itemAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ItemAccountStatus }{@code >}
     *     
     */
    public void setItemAccountStatus(JAXBElement<ItemAccountStatus> value) {
        this.itemAccountStatus = value;
    }

    /**
     * Gets the value of the itemAccountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getItemAccountName() {
        return itemAccountName;
    }

    /**
     * Sets the value of the itemAccountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setItemAccountName(JAXBElement<String> value) {
        this.itemAccountName = value;
    }

    /**
     * Gets the value of the itemInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}
     *     
     */
    public JAXBElement<ItemInfo> getItemInfo() {
        return itemInfo;
    }

    /**
     * Sets the value of the itemInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}
     *     
     */
    public void setItemInfo(JAXBElement<ItemInfo> value) {
        this.itemInfo = value;
    }

}
