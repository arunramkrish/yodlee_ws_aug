
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ItemAccountStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ItemAccountStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NOT_LINKED"/>
 *     &lt;enumeration value="LINKED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ItemAccountStatus")
@XmlEnum
public enum ItemAccountStatus {

    NOT_LINKED,
    LINKED;

    public String value() {
        return name();
    }

    public static ItemAccountStatus fromValue(String v) {
        return valueOf(v);
    }

}
