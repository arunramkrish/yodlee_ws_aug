
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfItemAccount;


/**
 * <p>Java class for ItemData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="itemInfo" type="{http://accountdataservice.core.soap.yodlee.com}ItemInfo" minOccurs="0"/>
 *         &lt;element name="itemAccounts" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfItemAccount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemData", propOrder = {
    "itemInfo",
    "itemAccounts"
})
public class ItemData {

    @XmlElementRef(name = "itemInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<ItemInfo> itemInfo;
    @XmlElementRef(name = "itemAccounts", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfItemAccount> itemAccounts;

    /**
     * Gets the value of the itemInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}
     *     
     */
    public JAXBElement<ItemInfo> getItemInfo() {
        return itemInfo;
    }

    /**
     * Sets the value of the itemInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}
     *     
     */
    public void setItemInfo(JAXBElement<ItemInfo> value) {
        this.itemInfo = value;
    }

    /**
     * Gets the value of the itemAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfItemAccount }{@code >}
     *     
     */
    public JAXBElement<ArrayOfItemAccount> getItemAccounts() {
        return itemAccounts;
    }

    /**
     * Sets the value of the itemAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfItemAccount }{@code >}
     *     
     */
    public void setItemAccounts(JAXBElement<ArrayOfItemAccount> value) {
        this.itemAccounts = value;
    }

}
