
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ItemInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="contentServiceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountDataType" type="{http://accountdataservice.core.soap.yodlee.com}DataType" minOccurs="0"/>
 *         &lt;element name="customItem" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="itemAccessStatus" type="{http://accountdataservice.core.soap.yodlee.com}ItemAccessStatus" minOccurs="0"/>
 *         &lt;element name="userActionRequiredType" type="{http://accountdataservice.core.soap.yodlee.com}UserActionRequiredType" minOccurs="0"/>
 *         &lt;element name="userActionRequiredCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="userActionRequiredSince" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="lastDataUpdateAttempt" type="{http://accountdataservice.core.soap.yodlee.com}DataUpdateAttempt" minOccurs="0"/>
 *         &lt;element name="lastUserRequestedDataUpdateAttempt" type="{http://accountdataservice.core.soap.yodlee.com}DataUpdateAttempt" minOccurs="0"/>
 *         &lt;element name="createDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="lastSuccessfulDataUpdate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemInfo", propOrder = {
    "contentServiceId",
    "itemId",
    "accountDataType",
    "customItem",
    "itemAccessStatus",
    "userActionRequiredType",
    "userActionRequiredCode",
    "userActionRequiredSince",
    "lastDataUpdateAttempt",
    "lastUserRequestedDataUpdateAttempt",
    "createDate",
    "lastSuccessfulDataUpdate"
})
public class ItemInfo {

    protected Long contentServiceId;
    protected Long itemId;
    @XmlElementRef(name = "accountDataType", type = JAXBElement.class, required = false)
    protected JAXBElement<DataType> accountDataType;
    protected boolean customItem;
    @XmlElementRef(name = "itemAccessStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<ItemAccessStatus> itemAccessStatus;
    @XmlElementRef(name = "userActionRequiredType", type = JAXBElement.class, required = false)
    protected JAXBElement<UserActionRequiredType> userActionRequiredType;
    @XmlElementRef(name = "userActionRequiredCode", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> userActionRequiredCode;
    @XmlElementRef(name = "userActionRequiredSince", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> userActionRequiredSince;
    @XmlElementRef(name = "lastDataUpdateAttempt", type = JAXBElement.class, required = false)
    protected JAXBElement<DataUpdateAttempt> lastDataUpdateAttempt;
    @XmlElementRef(name = "lastUserRequestedDataUpdateAttempt", type = JAXBElement.class, required = false)
    protected JAXBElement<DataUpdateAttempt> lastUserRequestedDataUpdateAttempt;
    @XmlElementRef(name = "createDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> createDate;
    @XmlElementRef(name = "lastSuccessfulDataUpdate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> lastSuccessfulDataUpdate;

    /**
     * Gets the value of the contentServiceId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getContentServiceId() {
        return contentServiceId;
    }

    /**
     * Sets the value of the contentServiceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setContentServiceId(Long value) {
        this.contentServiceId = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setItemId(Long value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the accountDataType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DataType }{@code >}
     *     
     */
    public JAXBElement<DataType> getAccountDataType() {
        return accountDataType;
    }

    /**
     * Sets the value of the accountDataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DataType }{@code >}
     *     
     */
    public void setAccountDataType(JAXBElement<DataType> value) {
        this.accountDataType = value;
    }

    /**
     * Gets the value of the customItem property.
     * 
     */
    public boolean isCustomItem() {
        return customItem;
    }

    /**
     * Sets the value of the customItem property.
     * 
     */
    public void setCustomItem(boolean value) {
        this.customItem = value;
    }

    /**
     * Gets the value of the itemAccessStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ItemAccessStatus }{@code >}
     *     
     */
    public JAXBElement<ItemAccessStatus> getItemAccessStatus() {
        return itemAccessStatus;
    }

    /**
     * Sets the value of the itemAccessStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ItemAccessStatus }{@code >}
     *     
     */
    public void setItemAccessStatus(JAXBElement<ItemAccessStatus> value) {
        this.itemAccessStatus = value;
    }

    /**
     * Gets the value of the userActionRequiredType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserActionRequiredType }{@code >}
     *     
     */
    public JAXBElement<UserActionRequiredType> getUserActionRequiredType() {
        return userActionRequiredType;
    }

    /**
     * Sets the value of the userActionRequiredType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserActionRequiredType }{@code >}
     *     
     */
    public void setUserActionRequiredType(JAXBElement<UserActionRequiredType> value) {
        this.userActionRequiredType = value;
    }

    /**
     * Gets the value of the userActionRequiredCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getUserActionRequiredCode() {
        return userActionRequiredCode;
    }

    /**
     * Sets the value of the userActionRequiredCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setUserActionRequiredCode(JAXBElement<Integer> value) {
        this.userActionRequiredCode = value;
    }

    /**
     * Gets the value of the userActionRequiredSince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getUserActionRequiredSince() {
        return userActionRequiredSince;
    }

    /**
     * Sets the value of the userActionRequiredSince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setUserActionRequiredSince(JAXBElement<XMLGregorianCalendar> value) {
        this.userActionRequiredSince = value;
    }

    /**
     * Gets the value of the lastDataUpdateAttempt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}
     *     
     */
    public JAXBElement<DataUpdateAttempt> getLastDataUpdateAttempt() {
        return lastDataUpdateAttempt;
    }

    /**
     * Sets the value of the lastDataUpdateAttempt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}
     *     
     */
    public void setLastDataUpdateAttempt(JAXBElement<DataUpdateAttempt> value) {
        this.lastDataUpdateAttempt = value;
    }

    /**
     * Gets the value of the lastUserRequestedDataUpdateAttempt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}
     *     
     */
    public JAXBElement<DataUpdateAttempt> getLastUserRequestedDataUpdateAttempt() {
        return lastUserRequestedDataUpdateAttempt;
    }

    /**
     * Sets the value of the lastUserRequestedDataUpdateAttempt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}
     *     
     */
    public void setLastUserRequestedDataUpdateAttempt(JAXBElement<DataUpdateAttempt> value) {
        this.lastUserRequestedDataUpdateAttempt = value;
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCreateDate(JAXBElement<XMLGregorianCalendar> value) {
        this.createDate = value;
    }

    /**
     * Gets the value of the lastSuccessfulDataUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastSuccessfulDataUpdate() {
        return lastSuccessfulDataUpdate;
    }

    /**
     * Sets the value of the lastSuccessfulDataUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastSuccessfulDataUpdate(JAXBElement<XMLGregorianCalendar> value) {
        this.lastSuccessfulDataUpdate = value;
    }

}
