
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfFinLoanTransaction;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for LoanAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingAccount">
 *       &lt;sequence>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="interestRate" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="loanAccountType" type="{http://accountdataservice.core.soap.yodlee.com}LoanAccountType" minOccurs="0"/>
 *         &lt;element name="originalLoanAmount" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="principalBalance" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *         &lt;element name="maturityDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="originationDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="loanTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfFinLoanTransaction" minOccurs="0"/>
 *         &lt;element name="unbilledLoanTransactions" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfFinLoanTransaction" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanAccount", propOrder = {
    "description",
    "interestRate",
    "loanAccountType",
    "originalLoanAmount",
    "principalBalance",
    "maturityDate",
    "originationDate",
    "loanTransactions",
    "unbilledLoanTransactions"
})
public class LoanAccount
    extends BillingAccount
{

    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "interestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> interestRate;
    @XmlElementRef(name = "loanAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<LoanAccountType> loanAccountType;
    @XmlElementRef(name = "originalLoanAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> originalLoanAmount;
    @XmlElementRef(name = "principalBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> principalBalance;
    @XmlElementRef(name = "maturityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> maturityDate;
    @XmlElementRef(name = "originationDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> originationDate;
    @XmlElementRef(name = "loanTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfFinLoanTransaction> loanTransactions;
    @XmlElementRef(name = "unbilledLoanTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfFinLoanTransaction> unbilledLoanTransactions;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setInterestRate(JAXBElement<BigDecimal> value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the loanAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link LoanAccountType }{@code >}
     *     
     */
    public JAXBElement<LoanAccountType> getLoanAccountType() {
        return loanAccountType;
    }

    /**
     * Sets the value of the loanAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link LoanAccountType }{@code >}
     *     
     */
    public void setLoanAccountType(JAXBElement<LoanAccountType> value) {
        this.loanAccountType = value;
    }

    /**
     * Gets the value of the originalLoanAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getOriginalLoanAmount() {
        return originalLoanAmount;
    }

    /**
     * Sets the value of the originalLoanAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setOriginalLoanAmount(JAXBElement<Money> value) {
        this.originalLoanAmount = value;
    }

    /**
     * Gets the value of the principalBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * Sets the value of the principalBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setPrincipalBalance(JAXBElement<Money> value) {
        this.principalBalance = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setMaturityDate(JAXBElement<CalendarDate> value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the originationDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getOriginationDate() {
        return originationDate;
    }

    /**
     * Sets the value of the originationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setOriginationDate(JAXBElement<CalendarDate> value) {
        this.originationDate = value;
    }

    /**
     * Gets the value of the loanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfFinLoanTransaction> getLoanTransactions() {
        return loanTransactions;
    }

    /**
     * Sets the value of the loanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}
     *     
     */
    public void setLoanTransactions(JAXBElement<ArrayOfFinLoanTransaction> value) {
        this.loanTransactions = value;
    }

    /**
     * Gets the value of the unbilledLoanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}
     *     
     */
    public JAXBElement<ArrayOfFinLoanTransaction> getUnbilledLoanTransactions() {
        return unbilledLoanTransactions;
    }

    /**
     * Sets the value of the unbilledLoanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}
     *     
     */
    public void setUnbilledLoanTransactions(JAXBElement<ArrayOfFinLoanTransaction> value) {
        this.unbilledLoanTransactions = value;
    }

}
