
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LoanAccountType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="LoanAccountType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MORTGAGE"/>
 *     &lt;enumeration value="STUDENT"/>
 *     &lt;enumeration value="AUTO"/>
 *     &lt;enumeration value="LINE_OF_CREDIT"/>
 *     &lt;enumeration value="HOME_EQUITY_LINE_OF_CREDIT"/>
 *     &lt;enumeration value="PERSONAL"/>
 *     &lt;enumeration value="INSTALLMENT"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "LoanAccountType")
@XmlEnum
public enum LoanAccountType {

    MORTGAGE,
    STUDENT,
    AUTO,
    LINE_OF_CREDIT,
    HOME_EQUITY_LINE_OF_CREDIT,
    PERSONAL,
    INSTALLMENT,
    OTHER,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static LoanAccountType fromValue(String v) {
        return valueOf(v);
    }

}
