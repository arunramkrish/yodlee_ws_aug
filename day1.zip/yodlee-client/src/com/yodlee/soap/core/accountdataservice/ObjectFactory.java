
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBankTransaction;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingCharge;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingPayment;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingStatement;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfCardTransaction;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfFinLoanTransaction;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfInsurancePolicy;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfInsuranceTransaction;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfItemAccount;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessLineBilledInfo;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessLineInfo;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessUsage;
import com.yodlee.soap.common.CalendarDate;
import com.yodlee.soap.common.Money;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.accountdataservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _WirelessStatementWirelessLineBilledInfoList_QNAME = new QName("", "wirelessLineBilledInfoList");
    private final static QName _WirelessStatementWirelessUsageList_QNAME = new QName("", "wirelessUsageList");
    private final static QName _FinancialTransactionAmount_QNAME = new QName("", "amount");
    private final static QName _FinancialTransactionTransactionType_QNAME = new QName("", "transactionType");
    private final static QName _FinancialTransactionPostDate_QNAME = new QName("", "postDate");
    private final static QName _FinancialTransactionDescription_QNAME = new QName("", "description");
    private final static QName _FinancialTransactionReferenceNumber_QNAME = new QName("", "referenceNumber");
    private final static QName _FinancialTransactionTransactionDate_QNAME = new QName("", "transactionDate");
    private final static QName _BankAccountBankAccountType_QNAME = new QName("", "bankAccountType");
    private final static QName _BankAccountAnnualPercentageYield_QNAME = new QName("", "annualPercentageYield");
    private final static QName _BankAccountMaturityDate_QNAME = new QName("", "maturityDate");
    private final static QName _BankAccountCurrentBalance_QNAME = new QName("", "currentBalance");
    private final static QName _BankAccountBankTransactions_QNAME = new QName("", "bankTransactions");
    private final static QName _BankAccountAvailableBalance_QNAME = new QName("", "availableBalance");
    private final static QName _BankAccountInterestRate_QNAME = new QName("", "interestRate");
    private final static QName _PersonInformationSurname_QNAME = new QName("", "surname");
    private final static QName _PersonInformationGivenName_QNAME = new QName("", "givenName");
    private final static QName _PersonInformationFullName_QNAME = new QName("", "fullName");
    private final static QName _InsuranceStatementInsuranceTransactions_QNAME = new QName("", "insuranceTransactions");
    private final static QName _BillingAccountUserAutoPayEnrollmentStatus_QNAME = new QName("", "userAutoPayEnrollmentStatus");
    private final static QName _BillingAccountBillingStatements_QNAME = new QName("", "billingStatements");
    private final static QName _BillingAccountBillingPayments_QNAME = new QName("", "billingPayments");
    private final static QName _BillingAccountLastPaymentAmount_QNAME = new QName("", "lastPaymentAmount");
    private final static QName _BillingAccountLastPaymentDate_QNAME = new QName("", "lastPaymentDate");
    private final static QName _BillingAccountOutstandingMinimumAmountDue_QNAME = new QName("", "outstandingMinimumAmountDue");
    private final static QName _BillingAccountPayments_QNAME = new QName("", "payments");
    private final static QName _BillingAccountOutstandingAmountDue_QNAME = new QName("", "outstandingAmountDue");
    private final static QName _BillingAccountUserAutoPayEnrollmentStatusLastUpdated_QNAME = new QName("", "userAutoPayEnrollmentStatusLastUpdated");
    private final static QName _WirelessLineBilledInfoLineNumber_QNAME = new QName("", "lineNumber");
    private final static QName _WirelessLineBilledInfoBillingCharges_QNAME = new QName("", "billingCharges");
    private final static QName _DataUpdateAttemptStatusCode_QNAME = new QName("", "statusCode");
    private final static QName _DataUpdateAttemptStatus_QNAME = new QName("", "status");
    private final static QName _DataUpdateAttemptType_QNAME = new QName("", "type");
    private final static QName _DataUpdateAttemptDate_QNAME = new QName("", "date");
    private final static QName _WirelessAccountWirelessLineInfoList_QNAME = new QName("", "wirelessLineInfoList");
    private final static QName _CardAccountApr_QNAME = new QName("", "apr");
    private final static QName _CardAccountAvailableCash_QNAME = new QName("", "availableCash");
    private final static QName _CardAccountUnbilledCardTransactions_QNAME = new QName("", "unbilledCardTransactions");
    private final static QName _CardAccountTotalCreditLine_QNAME = new QName("", "totalCreditLine");
    private final static QName _CardAccountCardTransactions_QNAME = new QName("", "cardTransactions");
    private final static QName _CardAccountNewCharges_QNAME = new QName("", "newCharges");
    private final static QName _CardAccountCashApr_QNAME = new QName("", "cashApr");
    private final static QName _CardAccountTotalCashLimit_QNAME = new QName("", "totalCashLimit");
    private final static QName _CardAccountRunningBalance_QNAME = new QName("", "runningBalance");
    private final static QName _CardAccountAvailableCredit_QNAME = new QName("", "availableCredit");
    private final static QName _LoanAccountOriginationDate_QNAME = new QName("", "originationDate");
    private final static QName _LoanAccountUnbilledLoanTransactions_QNAME = new QName("", "unbilledLoanTransactions");
    private final static QName _LoanAccountOriginalLoanAmount_QNAME = new QName("", "originalLoanAmount");
    private final static QName _LoanAccountLoanAccountType_QNAME = new QName("", "loanAccountType");
    private final static QName _LoanAccountLoanTransactions_QNAME = new QName("", "loanTransactions");
    private final static QName _LoanAccountPrincipalBalance_QNAME = new QName("", "principalBalance");
    private final static QName _BillingPaymentId_QNAME = new QName("", "id");
    private final static QName _BillingPaymentPaymentDate_QNAME = new QName("", "paymentDate");
    private final static QName _BillingPaymentConfirmationNumber_QNAME = new QName("", "confirmationNumber");
    private final static QName _BillingStatementLatePaymentCharge_QNAME = new QName("", "latePaymentCharge");
    private final static QName _BillingStatementAdjustmentsAndPayments_QNAME = new QName("", "adjustmentsAndPayments");
    private final static QName _BillingStatementPeriodStartDate_QNAME = new QName("", "periodStartDate");
    private final static QName _BillingStatementDerivedBillStatus_QNAME = new QName("", "derivedBillStatus");
    private final static QName _BillingStatementUserBillStatus_QNAME = new QName("", "userBillStatus");
    private final static QName _BillingStatementStatementDate_QNAME = new QName("", "statementDate");
    private final static QName _BillingStatementUserBillStatusLastUpdated_QNAME = new QName("", "userBillStatusLastUpdated");
    private final static QName _BillingStatementAdjustments_QNAME = new QName("", "adjustments");
    private final static QName _BillingStatementAccountNumber_QNAME = new QName("", "accountNumber");
    private final static QName _BillingStatementMinimumAmountDue_QNAME = new QName("", "minimumAmountDue");
    private final static QName _BillingStatementPeriodEndDate_QNAME = new QName("", "periodEndDate");
    private final static QName _BillingStatementPastDueAmount_QNAME = new QName("", "pastDueAmount");
    private final static QName _BillingStatementAmountDue_QNAME = new QName("", "amountDue");
    private final static QName _BillingStatementDueDate_QNAME = new QName("", "dueDate");
    private final static QName _ItemAccountAsOf_QNAME = new QName("", "asOf");
    private final static QName _ItemAccountInfoItemAccountNumber_QNAME = new QName("", "itemAccountNumber");
    private final static QName _ItemAccountInfoItemInfo_QNAME = new QName("", "itemInfo");
    private final static QName _ItemAccountInfoItemAccountName_QNAME = new QName("", "itemAccountName");
    private final static QName _ItemAccountInfoItemAccountStatus_QNAME = new QName("", "itemAccountStatus");
    private final static QName _InsurancePolicyPolicyName_QNAME = new QName("", "policyName");
    private final static QName _InsurancePolicyInsurancePolicyType_QNAME = new QName("", "insurancePolicyType");
    private final static QName _InsurancePolicyExpirationDate_QNAME = new QName("", "expirationDate");
    private final static QName _InsurancePolicyPolicyNumber_QNAME = new QName("", "policyNumber");
    private final static QName _InsurancePolicyPremiumAmount_QNAME = new QName("", "premiumAmount");
    private final static QName _InsurancePolicyEffectiveDate_QNAME = new QName("", "effectiveDate");
    private final static QName _InsurancePolicyPolicyHolder_QNAME = new QName("", "policyHolder");
    private final static QName _ItemInfoItemAccessStatus_QNAME = new QName("", "itemAccessStatus");
    private final static QName _ItemInfoLastDataUpdateAttempt_QNAME = new QName("", "lastDataUpdateAttempt");
    private final static QName _ItemInfoUserActionRequiredCode_QNAME = new QName("", "userActionRequiredCode");
    private final static QName _ItemInfoLastUserRequestedDataUpdateAttempt_QNAME = new QName("", "lastUserRequestedDataUpdateAttempt");
    private final static QName _ItemInfoCreateDate_QNAME = new QName("", "createDate");
    private final static QName _ItemInfoUserActionRequiredType_QNAME = new QName("", "userActionRequiredType");
    private final static QName _ItemInfoUserActionRequiredSince_QNAME = new QName("", "userActionRequiredSince");
    private final static QName _ItemInfoLastSuccessfulDataUpdate_QNAME = new QName("", "lastSuccessfulDataUpdate");
    private final static QName _ItemInfoAccountDataType_QNAME = new QName("", "accountDataType");
    private final static QName _CardStatementInterestPaidThisPeriod_QNAME = new QName("", "interestPaidThisPeriod");
    private final static QName _CardStatementFinanceCharges_QNAME = new QName("", "financeCharges");
    private final static QName _CardStatementCredits_QNAME = new QName("", "credits");
    private final static QName _CardStatementPreviousEndingBalance_QNAME = new QName("", "previousEndingBalance");
    private final static QName _CardStatementEndingBalance_QNAME = new QName("", "endingBalance");
    private final static QName _CardStatementCashAdvance_QNAME = new QName("", "cashAdvance");
    private final static QName _CardStatementInterestPaidYearToDate_QNAME = new QName("", "interestPaidYearToDate");
    private final static QName _ItemDataItemAccounts_QNAME = new QName("", "itemAccounts");
    private final static QName _InsuranceAccountInsurancePolicies_QNAME = new QName("", "insurancePolicies");
    private final static QName _InsuranceAccountUnbilledInsuranceTransactions_QNAME = new QName("", "unbilledInsuranceTransactions");
    private final static QName _BankTransactionCheckNumber_QNAME = new QName("", "checkNumber");
    private final static QName _SummaryDataItemAccountInfo_QNAME = new QName("", "itemAccountInfo");
    private final static QName _FinancialAccountAccountHolder_QNAME = new QName("", "accountHolder");
    private final static QName _WirelessUsageUnitsOverLimit_QNAME = new QName("", "unitsOverLimit");
    private final static QName _WirelessUsageWirelessUsageTimePeriod_QNAME = new QName("", "wirelessUsageTimePeriod");
    private final static QName _WirelessUsageUnitsRemaining_QNAME = new QName("", "unitsRemaining");
    private final static QName _WirelessUsageWirelessUsageUnit_QNAME = new QName("", "wirelessUsageUnit");
    private final static QName _WirelessUsageChargesIncurred_QNAME = new QName("", "chargesIncurred");
    private final static QName _WirelessUsageUnitsUsed_QNAME = new QName("", "unitsUsed");
    private final static QName _WirelessUsageUnitsIncluded_QNAME = new QName("", "unitsIncluded");
    private final static QName _WirelessUsageWirelessUsageType_QNAME = new QName("", "wirelessUsageType");
    private final static QName _WirelessUsageWirelessUsageDirection_QNAME = new QName("", "wirelessUsageDirection");
    private final static QName _FinLoanTransactionAmountAppliedToPrincipal_QNAME = new QName("", "amountAppliedToPrincipal");
    private final static QName _FinLoanTransactionAmountAppliedToInterest_QNAME = new QName("", "amountAppliedToInterest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.accountdataservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CardStatement }
     * 
     */
    public CardStatement createCardStatement() {
        return new CardStatement();
    }

    /**
     * Create an instance of {@link InsuranceStatement }
     * 
     */
    public InsuranceStatement createInsuranceStatement() {
        return new InsuranceStatement();
    }

    /**
     * Create an instance of {@link InsurancePolicy }
     * 
     */
    public InsurancePolicy createInsurancePolicy() {
        return new InsurancePolicy();
    }

    /**
     * Create an instance of {@link WirelessLineInfo }
     * 
     */
    public WirelessLineInfo createWirelessLineInfo() {
        return new WirelessLineInfo();
    }

    /**
     * Create an instance of {@link ItemAccountInfo }
     * 
     */
    public ItemAccountInfo createItemAccountInfo() {
        return new ItemAccountInfo();
    }

    /**
     * Create an instance of {@link BillingAccount }
     * 
     */
    public BillingAccount createBillingAccount() {
        return new BillingAccount();
    }

    /**
     * Create an instance of {@link DataUpdateAttempt }
     * 
     */
    public DataUpdateAttempt createDataUpdateAttempt() {
        return new DataUpdateAttempt();
    }

    /**
     * Create an instance of {@link ItemData }
     * 
     */
    public ItemData createItemData() {
        return new ItemData();
    }

    /**
     * Create an instance of {@link BillingCharge }
     * 
     */
    public BillingCharge createBillingCharge() {
        return new BillingCharge();
    }

    /**
     * Create an instance of {@link CardTransaction }
     * 
     */
    public CardTransaction createCardTransaction() {
        return new CardTransaction();
    }

    /**
     * Create an instance of {@link BillingStatement }
     * 
     */
    public BillingStatement createBillingStatement() {
        return new BillingStatement();
    }

    /**
     * Create an instance of {@link WirelessUsage }
     * 
     */
    public WirelessUsage createWirelessUsage() {
        return new WirelessUsage();
    }

    /**
     * Create an instance of {@link ItemInfo }
     * 
     */
    public ItemInfo createItemInfo() {
        return new ItemInfo();
    }

    /**
     * Create an instance of {@link BillingPayment }
     * 
     */
    public BillingPayment createBillingPayment() {
        return new BillingPayment();
    }

    /**
     * Create an instance of {@link FinLoanTransaction }
     * 
     */
    public FinLoanTransaction createFinLoanTransaction() {
        return new FinLoanTransaction();
    }

    /**
     * Create an instance of {@link InsuranceTransaction }
     * 
     */
    public InsuranceTransaction createInsuranceTransaction() {
        return new InsuranceTransaction();
    }

    /**
     * Create an instance of {@link InsuranceAccount }
     * 
     */
    public InsuranceAccount createInsuranceAccount() {
        return new InsuranceAccount();
    }

    /**
     * Create an instance of {@link WirelessLineBilledInfo }
     * 
     */
    public WirelessLineBilledInfo createWirelessLineBilledInfo() {
        return new WirelessLineBilledInfo();
    }

    /**
     * Create an instance of {@link CardAccount }
     * 
     */
    public CardAccount createCardAccount() {
        return new CardAccount();
    }

    /**
     * Create an instance of {@link WirelessStatement }
     * 
     */
    public WirelessStatement createWirelessStatement() {
        return new WirelessStatement();
    }

    /**
     * Create an instance of {@link BankTransaction }
     * 
     */
    public BankTransaction createBankTransaction() {
        return new BankTransaction();
    }

    /**
     * Create an instance of {@link BankAccount }
     * 
     */
    public BankAccount createBankAccount() {
        return new BankAccount();
    }

    /**
     * Create an instance of {@link LoanAccount }
     * 
     */
    public LoanAccount createLoanAccount() {
        return new LoanAccount();
    }

    /**
     * Create an instance of {@link PersonInformation }
     * 
     */
    public PersonInformation createPersonInformation() {
        return new PersonInformation();
    }

    /**
     * Create an instance of {@link WirelessAccount }
     * 
     */
    public WirelessAccount createWirelessAccount() {
        return new WirelessAccount();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineBilledInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessLineBilledInfoList", scope = WirelessStatement.class)
    public JAXBElement<ArrayOfWirelessLineBilledInfo> createWirelessStatementWirelessLineBilledInfoList(ArrayOfWirelessLineBilledInfo value) {
        return new JAXBElement<ArrayOfWirelessLineBilledInfo>(_WirelessStatementWirelessLineBilledInfoList_QNAME, ArrayOfWirelessLineBilledInfo.class, WirelessStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageList", scope = WirelessStatement.class)
    public JAXBElement<ArrayOfWirelessUsage> createWirelessStatementWirelessUsageList(ArrayOfWirelessUsage value) {
        return new JAXBElement<ArrayOfWirelessUsage>(_WirelessStatementWirelessUsageList_QNAME, ArrayOfWirelessUsage.class, WirelessStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = FinancialTransaction.class)
    public JAXBElement<Money> createFinancialTransactionAmount(Money value) {
        return new JAXBElement<Money>(_FinancialTransactionAmount_QNAME, Money.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "transactionType", scope = FinancialTransaction.class)
    public JAXBElement<TransactionType> createFinancialTransactionTransactionType(TransactionType value) {
        return new JAXBElement<TransactionType>(_FinancialTransactionTransactionType_QNAME, TransactionType.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postDate", scope = FinancialTransaction.class)
    public JAXBElement<CalendarDate> createFinancialTransactionPostDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_FinancialTransactionPostDate_QNAME, CalendarDate.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = FinancialTransaction.class)
    public JAXBElement<String> createFinancialTransactionDescription(String value) {
        return new JAXBElement<String>(_FinancialTransactionDescription_QNAME, String.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "referenceNumber", scope = FinancialTransaction.class)
    public JAXBElement<String> createFinancialTransactionReferenceNumber(String value) {
        return new JAXBElement<String>(_FinancialTransactionReferenceNumber_QNAME, String.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "transactionDate", scope = FinancialTransaction.class)
    public JAXBElement<CalendarDate> createFinancialTransactionTransactionDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_FinancialTransactionTransactionDate_QNAME, CalendarDate.class, FinancialTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankAccountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bankAccountType", scope = BankAccount.class)
    public JAXBElement<BankAccountType> createBankAccountBankAccountType(BankAccountType value) {
        return new JAXBElement<BankAccountType>(_BankAccountBankAccountType_QNAME, BankAccountType.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "annualPercentageYield", scope = BankAccount.class)
    public JAXBElement<BigDecimal> createBankAccountAnnualPercentageYield(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BankAccountAnnualPercentageYield_QNAME, BigDecimal.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maturityDate", scope = BankAccount.class)
    public JAXBElement<CalendarDate> createBankAccountMaturityDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BankAccountMaturityDate_QNAME, CalendarDate.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currentBalance", scope = BankAccount.class)
    public JAXBElement<Money> createBankAccountCurrentBalance(Money value) {
        return new JAXBElement<Money>(_BankAccountCurrentBalance_QNAME, Money.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBankTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bankTransactions", scope = BankAccount.class)
    public JAXBElement<ArrayOfBankTransaction> createBankAccountBankTransactions(ArrayOfBankTransaction value) {
        return new JAXBElement<ArrayOfBankTransaction>(_BankAccountBankTransactions_QNAME, ArrayOfBankTransaction.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "availableBalance", scope = BankAccount.class)
    public JAXBElement<Money> createBankAccountAvailableBalance(Money value) {
        return new JAXBElement<Money>(_BankAccountAvailableBalance_QNAME, Money.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "interestRate", scope = BankAccount.class)
    public JAXBElement<BigDecimal> createBankAccountInterestRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BankAccountInterestRate_QNAME, BigDecimal.class, BankAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "surname", scope = PersonInformation.class)
    public JAXBElement<String> createPersonInformationSurname(String value) {
        return new JAXBElement<String>(_PersonInformationSurname_QNAME, String.class, PersonInformation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "givenName", scope = PersonInformation.class)
    public JAXBElement<String> createPersonInformationGivenName(String value) {
        return new JAXBElement<String>(_PersonInformationGivenName_QNAME, String.class, PersonInformation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fullName", scope = PersonInformation.class)
    public JAXBElement<String> createPersonInformationFullName(String value) {
        return new JAXBElement<String>(_PersonInformationFullName_QNAME, String.class, PersonInformation.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insuranceTransactions", scope = InsuranceStatement.class)
    public JAXBElement<ArrayOfInsuranceTransaction> createInsuranceStatementInsuranceTransactions(ArrayOfInsuranceTransaction value) {
        return new JAXBElement<ArrayOfInsuranceTransaction>(_InsuranceStatementInsuranceTransactions_QNAME, ArrayOfInsuranceTransaction.class, InsuranceStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AutoPayEnrollmentStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userAutoPayEnrollmentStatus", scope = BillingAccount.class)
    public JAXBElement<AutoPayEnrollmentStatus> createBillingAccountUserAutoPayEnrollmentStatus(AutoPayEnrollmentStatus value) {
        return new JAXBElement<AutoPayEnrollmentStatus>(_BillingAccountUserAutoPayEnrollmentStatus_QNAME, AutoPayEnrollmentStatus.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingStatement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "billingStatements", scope = BillingAccount.class)
    public JAXBElement<ArrayOfBillingStatement> createBillingAccountBillingStatements(ArrayOfBillingStatement value) {
        return new JAXBElement<ArrayOfBillingStatement>(_BillingAccountBillingStatements_QNAME, ArrayOfBillingStatement.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "billingPayments", scope = BillingAccount.class)
    public JAXBElement<ArrayOfBillingPayment> createBillingAccountBillingPayments(ArrayOfBillingPayment value) {
        return new JAXBElement<ArrayOfBillingPayment>(_BillingAccountBillingPayments_QNAME, ArrayOfBillingPayment.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastPaymentAmount", scope = BillingAccount.class)
    public JAXBElement<Money> createBillingAccountLastPaymentAmount(Money value) {
        return new JAXBElement<Money>(_BillingAccountLastPaymentAmount_QNAME, Money.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastPaymentDate", scope = BillingAccount.class)
    public JAXBElement<CalendarDate> createBillingAccountLastPaymentDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingAccountLastPaymentDate_QNAME, CalendarDate.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "outstandingMinimumAmountDue", scope = BillingAccount.class)
    public JAXBElement<Money> createBillingAccountOutstandingMinimumAmountDue(Money value) {
        return new JAXBElement<Money>(_BillingAccountOutstandingMinimumAmountDue_QNAME, Money.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "payments", scope = BillingAccount.class)
    public JAXBElement<Money> createBillingAccountPayments(Money value) {
        return new JAXBElement<Money>(_BillingAccountPayments_QNAME, Money.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "outstandingAmountDue", scope = BillingAccount.class)
    public JAXBElement<Money> createBillingAccountOutstandingAmountDue(Money value) {
        return new JAXBElement<Money>(_BillingAccountOutstandingAmountDue_QNAME, Money.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userAutoPayEnrollmentStatusLastUpdated", scope = BillingAccount.class)
    public JAXBElement<XMLGregorianCalendar> createBillingAccountUserAutoPayEnrollmentStatusLastUpdated(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BillingAccountUserAutoPayEnrollmentStatusLastUpdated_QNAME, XMLGregorianCalendar.class, BillingAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lineNumber", scope = WirelessLineBilledInfo.class)
    public JAXBElement<String> createWirelessLineBilledInfoLineNumber(String value) {
        return new JAXBElement<String>(_WirelessLineBilledInfoLineNumber_QNAME, String.class, WirelessLineBilledInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingCharge }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "billingCharges", scope = WirelessLineBilledInfo.class)
    public JAXBElement<ArrayOfBillingCharge> createWirelessLineBilledInfoBillingCharges(ArrayOfBillingCharge value) {
        return new JAXBElement<ArrayOfBillingCharge>(_WirelessLineBilledInfoBillingCharges_QNAME, ArrayOfBillingCharge.class, WirelessLineBilledInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageList", scope = WirelessLineBilledInfo.class)
    public JAXBElement<ArrayOfWirelessUsage> createWirelessLineBilledInfoWirelessUsageList(ArrayOfWirelessUsage value) {
        return new JAXBElement<ArrayOfWirelessUsage>(_WirelessStatementWirelessUsageList_QNAME, ArrayOfWirelessUsage.class, WirelessLineBilledInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "statusCode", scope = DataUpdateAttempt.class)
    public JAXBElement<Integer> createDataUpdateAttemptStatusCode(Integer value) {
        return new JAXBElement<Integer>(_DataUpdateAttemptStatusCode_QNAME, Integer.class, DataUpdateAttempt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataUpdateAttemptStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "status", scope = DataUpdateAttempt.class)
    public JAXBElement<DataUpdateAttemptStatus> createDataUpdateAttemptStatus(DataUpdateAttemptStatus value) {
        return new JAXBElement<DataUpdateAttemptStatus>(_DataUpdateAttemptStatus_QNAME, DataUpdateAttemptStatus.class, DataUpdateAttempt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataUpdateAttemptType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "type", scope = DataUpdateAttempt.class)
    public JAXBElement<DataUpdateAttemptType> createDataUpdateAttemptType(DataUpdateAttemptType value) {
        return new JAXBElement<DataUpdateAttemptType>(_DataUpdateAttemptType_QNAME, DataUpdateAttemptType.class, DataUpdateAttempt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date", scope = DataUpdateAttempt.class)
    public JAXBElement<XMLGregorianCalendar> createDataUpdateAttemptDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DataUpdateAttemptDate_QNAME, XMLGregorianCalendar.class, DataUpdateAttempt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessLineInfoList", scope = WirelessAccount.class)
    public JAXBElement<ArrayOfWirelessLineInfo> createWirelessAccountWirelessLineInfoList(ArrayOfWirelessLineInfo value) {
        return new JAXBElement<ArrayOfWirelessLineInfo>(_WirelessAccountWirelessLineInfoList_QNAME, ArrayOfWirelessLineInfo.class, WirelessAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageList", scope = WirelessAccount.class)
    public JAXBElement<ArrayOfWirelessUsage> createWirelessAccountWirelessUsageList(ArrayOfWirelessUsage value) {
        return new JAXBElement<ArrayOfWirelessUsage>(_WirelessStatementWirelessUsageList_QNAME, ArrayOfWirelessUsage.class, WirelessAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "apr", scope = CardAccount.class)
    public JAXBElement<BigDecimal> createCardAccountApr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CardAccountApr_QNAME, BigDecimal.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "availableCash", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountAvailableCash(Money value) {
        return new JAXBElement<Money>(_CardAccountAvailableCash_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unbilledCardTransactions", scope = CardAccount.class)
    public JAXBElement<ArrayOfCardTransaction> createCardAccountUnbilledCardTransactions(ArrayOfCardTransaction value) {
        return new JAXBElement<ArrayOfCardTransaction>(_CardAccountUnbilledCardTransactions_QNAME, ArrayOfCardTransaction.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "totalCreditLine", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountTotalCreditLine(Money value) {
        return new JAXBElement<Money>(_CardAccountTotalCreditLine_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cardTransactions", scope = CardAccount.class)
    public JAXBElement<ArrayOfCardTransaction> createCardAccountCardTransactions(ArrayOfCardTransaction value) {
        return new JAXBElement<ArrayOfCardTransaction>(_CardAccountCardTransactions_QNAME, ArrayOfCardTransaction.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "newCharges", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountNewCharges(Money value) {
        return new JAXBElement<Money>(_CardAccountNewCharges_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cashApr", scope = CardAccount.class)
    public JAXBElement<BigDecimal> createCardAccountCashApr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CardAccountCashApr_QNAME, BigDecimal.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "totalCashLimit", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountTotalCashLimit(Money value) {
        return new JAXBElement<Money>(_CardAccountTotalCashLimit_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "runningBalance", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountRunningBalance(Money value) {
        return new JAXBElement<Money>(_CardAccountRunningBalance_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "availableCredit", scope = CardAccount.class)
    public JAXBElement<Money> createCardAccountAvailableCredit(Money value) {
        return new JAXBElement<Money>(_CardAccountAvailableCredit_QNAME, Money.class, CardAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "originationDate", scope = LoanAccount.class)
    public JAXBElement<CalendarDate> createLoanAccountOriginationDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_LoanAccountOriginationDate_QNAME, CalendarDate.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unbilledLoanTransactions", scope = LoanAccount.class)
    public JAXBElement<ArrayOfFinLoanTransaction> createLoanAccountUnbilledLoanTransactions(ArrayOfFinLoanTransaction value) {
        return new JAXBElement<ArrayOfFinLoanTransaction>(_LoanAccountUnbilledLoanTransactions_QNAME, ArrayOfFinLoanTransaction.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "originalLoanAmount", scope = LoanAccount.class)
    public JAXBElement<Money> createLoanAccountOriginalLoanAmount(Money value) {
        return new JAXBElement<Money>(_LoanAccountOriginalLoanAmount_QNAME, Money.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoanAccountType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loanAccountType", scope = LoanAccount.class)
    public JAXBElement<LoanAccountType> createLoanAccountLoanAccountType(LoanAccountType value) {
        return new JAXBElement<LoanAccountType>(_LoanAccountLoanAccountType_QNAME, LoanAccountType.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = LoanAccount.class)
    public JAXBElement<String> createLoanAccountDescription(String value) {
        return new JAXBElement<String>(_FinancialTransactionDescription_QNAME, String.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "maturityDate", scope = LoanAccount.class)
    public JAXBElement<CalendarDate> createLoanAccountMaturityDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BankAccountMaturityDate_QNAME, CalendarDate.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "interestRate", scope = LoanAccount.class)
    public JAXBElement<BigDecimal> createLoanAccountInterestRate(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BankAccountInterestRate_QNAME, BigDecimal.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfFinLoanTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loanTransactions", scope = LoanAccount.class)
    public JAXBElement<ArrayOfFinLoanTransaction> createLoanAccountLoanTransactions(ArrayOfFinLoanTransaction value) {
        return new JAXBElement<ArrayOfFinLoanTransaction>(_LoanAccountLoanTransactions_QNAME, ArrayOfFinLoanTransaction.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "principalBalance", scope = LoanAccount.class)
    public JAXBElement<Money> createLoanAccountPrincipalBalance(Money value) {
        return new JAXBElement<Money>(_LoanAccountPrincipalBalance_QNAME, Money.class, LoanAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = BillingPayment.class)
    public JAXBElement<Money> createBillingPaymentAmount(Money value) {
        return new JAXBElement<Money>(_FinancialTransactionAmount_QNAME, Money.class, BillingPayment.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = BillingPayment.class)
    public JAXBElement<Long> createBillingPaymentId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, BillingPayment.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paymentDate", scope = BillingPayment.class)
    public JAXBElement<CalendarDate> createBillingPaymentPaymentDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingPaymentPaymentDate_QNAME, CalendarDate.class, BillingPayment.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "confirmationNumber", scope = BillingPayment.class)
    public JAXBElement<String> createBillingPaymentConfirmationNumber(String value) {
        return new JAXBElement<String>(_BillingPaymentConfirmationNumber_QNAME, String.class, BillingPayment.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "latePaymentCharge", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementLatePaymentCharge(Money value) {
        return new JAXBElement<Money>(_BillingStatementLatePaymentCharge_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "adjustmentsAndPayments", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementAdjustmentsAndPayments(Money value) {
        return new JAXBElement<Money>(_BillingStatementAdjustmentsAndPayments_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "periodStartDate", scope = BillingStatement.class)
    public JAXBElement<CalendarDate> createBillingStatementPeriodStartDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementPeriodStartDate_QNAME, CalendarDate.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "derivedBillStatus", scope = BillingStatement.class)
    public JAXBElement<BillPaymentStatus> createBillingStatementDerivedBillStatus(BillPaymentStatus value) {
        return new JAXBElement<BillPaymentStatus>(_BillingStatementDerivedBillStatus_QNAME, BillPaymentStatus.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BillPaymentStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userBillStatus", scope = BillingStatement.class)
    public JAXBElement<BillPaymentStatus> createBillingStatementUserBillStatus(BillPaymentStatus value) {
        return new JAXBElement<BillPaymentStatus>(_BillingStatementUserBillStatus_QNAME, BillPaymentStatus.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "statementDate", scope = BillingStatement.class)
    public JAXBElement<CalendarDate> createBillingStatementStatementDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementStatementDate_QNAME, CalendarDate.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "newCharges", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementNewCharges(Money value) {
        return new JAXBElement<Money>(_CardAccountNewCharges_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userBillStatusLastUpdated", scope = BillingStatement.class)
    public JAXBElement<XMLGregorianCalendar> createBillingStatementUserBillStatusLastUpdated(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_BillingStatementUserBillStatusLastUpdated_QNAME, XMLGregorianCalendar.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingCharge }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "billingCharges", scope = BillingStatement.class)
    public JAXBElement<ArrayOfBillingCharge> createBillingStatementBillingCharges(ArrayOfBillingCharge value) {
        return new JAXBElement<ArrayOfBillingCharge>(_WirelessLineBilledInfoBillingCharges_QNAME, ArrayOfBillingCharge.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "adjustments", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementAdjustments(Money value) {
        return new JAXBElement<Money>(_BillingStatementAdjustments_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = BillingStatement.class)
    public JAXBElement<Long> createBillingStatementId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountNumber", scope = BillingStatement.class)
    public JAXBElement<String> createBillingStatementAccountNumber(String value) {
        return new JAXBElement<String>(_BillingStatementAccountNumber_QNAME, String.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "minimumAmountDue", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementMinimumAmountDue(Money value) {
        return new JAXBElement<Money>(_BillingStatementMinimumAmountDue_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "periodEndDate", scope = BillingStatement.class)
    public JAXBElement<CalendarDate> createBillingStatementPeriodEndDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementPeriodEndDate_QNAME, CalendarDate.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "payments", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementPayments(Money value) {
        return new JAXBElement<Money>(_BillingAccountPayments_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pastDueAmount", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementPastDueAmount(Money value) {
        return new JAXBElement<Money>(_BillingStatementPastDueAmount_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amountDue", scope = BillingStatement.class)
    public JAXBElement<Money> createBillingStatementAmountDue(Money value) {
        return new JAXBElement<Money>(_BillingStatementAmountDue_QNAME, Money.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dueDate", scope = BillingStatement.class)
    public JAXBElement<CalendarDate> createBillingStatementDueDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementDueDate_QNAME, CalendarDate.class, BillingStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = ItemAccount.class)
    public JAXBElement<Long> createItemAccountId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, ItemAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "asOf", scope = ItemAccount.class)
    public JAXBElement<CalendarDate> createItemAccountAsOf(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_ItemAccountAsOf_QNAME, CalendarDate.class, ItemAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = CardTransaction.class)
    public JAXBElement<Long> createCardTransactionId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, CardTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lineNumber", scope = WirelessLineInfo.class)
    public JAXBElement<String> createWirelessLineInfoLineNumber(String value) {
        return new JAXBElement<String>(_WirelessLineBilledInfoLineNumber_QNAME, String.class, WirelessLineInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageList", scope = WirelessLineInfo.class)
    public JAXBElement<ArrayOfWirelessUsage> createWirelessLineInfoWirelessUsageList(ArrayOfWirelessUsage value) {
        return new JAXBElement<ArrayOfWirelessUsage>(_WirelessStatementWirelessUsageList_QNAME, ArrayOfWirelessUsage.class, WirelessLineInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccountNumber", scope = ItemAccountInfo.class)
    public JAXBElement<String> createItemAccountInfoItemAccountNumber(String value) {
        return new JAXBElement<String>(_ItemAccountInfoItemAccountNumber_QNAME, String.class, ItemAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemInfo", scope = ItemAccountInfo.class)
    public JAXBElement<ItemInfo> createItemAccountInfoItemInfo(ItemInfo value) {
        return new JAXBElement<ItemInfo>(_ItemAccountInfoItemInfo_QNAME, ItemInfo.class, ItemAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccountName", scope = ItemAccountInfo.class)
    public JAXBElement<String> createItemAccountInfoItemAccountName(String value) {
        return new JAXBElement<String>(_ItemAccountInfoItemAccountName_QNAME, String.class, ItemAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemAccountStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccountStatus", scope = ItemAccountInfo.class)
    public JAXBElement<ItemAccountStatus> createItemAccountInfoItemAccountStatus(ItemAccountStatus value) {
        return new JAXBElement<ItemAccountStatus>(_ItemAccountInfoItemAccountStatus_QNAME, ItemAccountStatus.class, ItemAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "policyName", scope = InsurancePolicy.class)
    public JAXBElement<String> createInsurancePolicyPolicyName(String value) {
        return new JAXBElement<String>(_InsurancePolicyPolicyName_QNAME, String.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsurancePolicyType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insurancePolicyType", scope = InsurancePolicy.class)
    public JAXBElement<InsurancePolicyType> createInsurancePolicyInsurancePolicyType(InsurancePolicyType value) {
        return new JAXBElement<InsurancePolicyType>(_InsurancePolicyInsurancePolicyType_QNAME, InsurancePolicyType.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "expirationDate", scope = InsurancePolicy.class)
    public JAXBElement<CalendarDate> createInsurancePolicyExpirationDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_InsurancePolicyExpirationDate_QNAME, CalendarDate.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "policyNumber", scope = InsurancePolicy.class)
    public JAXBElement<String> createInsurancePolicyPolicyNumber(String value) {
        return new JAXBElement<String>(_InsurancePolicyPolicyNumber_QNAME, String.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "premiumAmount", scope = InsurancePolicy.class)
    public JAXBElement<Money> createInsurancePolicyPremiumAmount(Money value) {
        return new JAXBElement<Money>(_InsurancePolicyPremiumAmount_QNAME, Money.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "effectiveDate", scope = InsurancePolicy.class)
    public JAXBElement<CalendarDate> createInsurancePolicyEffectiveDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_InsurancePolicyEffectiveDate_QNAME, CalendarDate.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "policyHolder", scope = InsurancePolicy.class)
    public JAXBElement<PersonInformation> createInsurancePolicyPolicyHolder(PersonInformation value) {
        return new JAXBElement<PersonInformation>(_InsurancePolicyPolicyHolder_QNAME, PersonInformation.class, InsurancePolicy.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemAccessStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccessStatus", scope = ItemInfo.class)
    public JAXBElement<ItemAccessStatus> createItemInfoItemAccessStatus(ItemAccessStatus value) {
        return new JAXBElement<ItemAccessStatus>(_ItemInfoItemAccessStatus_QNAME, ItemAccessStatus.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastDataUpdateAttempt", scope = ItemInfo.class)
    public JAXBElement<DataUpdateAttempt> createItemInfoLastDataUpdateAttempt(DataUpdateAttempt value) {
        return new JAXBElement<DataUpdateAttempt>(_ItemInfoLastDataUpdateAttempt_QNAME, DataUpdateAttempt.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userActionRequiredCode", scope = ItemInfo.class)
    public JAXBElement<Integer> createItemInfoUserActionRequiredCode(Integer value) {
        return new JAXBElement<Integer>(_ItemInfoUserActionRequiredCode_QNAME, Integer.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataUpdateAttempt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastUserRequestedDataUpdateAttempt", scope = ItemInfo.class)
    public JAXBElement<DataUpdateAttempt> createItemInfoLastUserRequestedDataUpdateAttempt(DataUpdateAttempt value) {
        return new JAXBElement<DataUpdateAttempt>(_ItemInfoLastUserRequestedDataUpdateAttempt_QNAME, DataUpdateAttempt.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "createDate", scope = ItemInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemInfoCreateDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemInfoCreateDate_QNAME, XMLGregorianCalendar.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserActionRequiredType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userActionRequiredType", scope = ItemInfo.class)
    public JAXBElement<UserActionRequiredType> createItemInfoUserActionRequiredType(UserActionRequiredType value) {
        return new JAXBElement<UserActionRequiredType>(_ItemInfoUserActionRequiredType_QNAME, UserActionRequiredType.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userActionRequiredSince", scope = ItemInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemInfoUserActionRequiredSince(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemInfoUserActionRequiredSince_QNAME, XMLGregorianCalendar.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastSuccessfulDataUpdate", scope = ItemInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemInfoLastSuccessfulDataUpdate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemInfoLastSuccessfulDataUpdate_QNAME, XMLGregorianCalendar.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountDataType", scope = ItemInfo.class)
    public JAXBElement<DataType> createItemInfoAccountDataType(DataType value) {
        return new JAXBElement<DataType>(_ItemInfoAccountDataType_QNAME, DataType.class, ItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "interestPaidThisPeriod", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementInterestPaidThisPeriod(Money value) {
        return new JAXBElement<Money>(_CardStatementInterestPaidThisPeriod_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "apr", scope = CardStatement.class)
    public JAXBElement<BigDecimal> createCardStatementApr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CardAccountApr_QNAME, BigDecimal.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "availableCash", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementAvailableCash(Money value) {
        return new JAXBElement<Money>(_CardAccountAvailableCash_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "financeCharges", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementFinanceCharges(Money value) {
        return new JAXBElement<Money>(_CardStatementFinanceCharges_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "credits", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementCredits(Money value) {
        return new JAXBElement<Money>(_CardStatementCredits_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfCardTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cardTransactions", scope = CardStatement.class)
    public JAXBElement<ArrayOfCardTransaction> createCardStatementCardTransactions(ArrayOfCardTransaction value) {
        return new JAXBElement<ArrayOfCardTransaction>(_CardAccountCardTransactions_QNAME, ArrayOfCardTransaction.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "previousEndingBalance", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementPreviousEndingBalance(Money value) {
        return new JAXBElement<Money>(_CardStatementPreviousEndingBalance_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "endingBalance", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementEndingBalance(Money value) {
        return new JAXBElement<Money>(_CardStatementEndingBalance_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "totalCashLimit", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementTotalCashLimit(Money value) {
        return new JAXBElement<Money>(_CardAccountTotalCashLimit_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cashAdvance", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementCashAdvance(Money value) {
        return new JAXBElement<Money>(_CardStatementCashAdvance_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "interestPaidYearToDate", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementInterestPaidYearToDate(Money value) {
        return new JAXBElement<Money>(_CardStatementInterestPaidYearToDate_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "totalCreditLine", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementTotalCreditLine(Money value) {
        return new JAXBElement<Money>(_CardAccountTotalCreditLine_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cashApr", scope = CardStatement.class)
    public JAXBElement<BigDecimal> createCardStatementCashApr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_CardAccountCashApr_QNAME, BigDecimal.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "availableCredit", scope = CardStatement.class)
    public JAXBElement<Money> createCardStatementAvailableCredit(Money value) {
        return new JAXBElement<Money>(_CardAccountAvailableCredit_QNAME, Money.class, CardStatement.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfItemAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccounts", scope = ItemData.class)
    public JAXBElement<ArrayOfItemAccount> createItemDataItemAccounts(ArrayOfItemAccount value) {
        return new JAXBElement<ArrayOfItemAccount>(_ItemDataItemAccounts_QNAME, ArrayOfItemAccount.class, ItemData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemInfo", scope = ItemData.class)
    public JAXBElement<ItemInfo> createItemDataItemInfo(ItemInfo value) {
        return new JAXBElement<ItemInfo>(_ItemAccountInfoItemInfo_QNAME, ItemInfo.class, ItemData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insuranceTransactions", scope = InsuranceAccount.class)
    public JAXBElement<ArrayOfInsuranceTransaction> createInsuranceAccountInsuranceTransactions(ArrayOfInsuranceTransaction value) {
        return new JAXBElement<ArrayOfInsuranceTransaction>(_InsuranceStatementInsuranceTransactions_QNAME, ArrayOfInsuranceTransaction.class, InsuranceAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfInsurancePolicy }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "insurancePolicies", scope = InsuranceAccount.class)
    public JAXBElement<ArrayOfInsurancePolicy> createInsuranceAccountInsurancePolicies(ArrayOfInsurancePolicy value) {
        return new JAXBElement<ArrayOfInsurancePolicy>(_InsuranceAccountInsurancePolicies_QNAME, ArrayOfInsurancePolicy.class, InsuranceAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfInsuranceTransaction }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unbilledInsuranceTransactions", scope = InsuranceAccount.class)
    public JAXBElement<ArrayOfInsuranceTransaction> createInsuranceAccountUnbilledInsuranceTransactions(ArrayOfInsuranceTransaction value) {
        return new JAXBElement<ArrayOfInsuranceTransaction>(_InsuranceAccountUnbilledInsuranceTransactions_QNAME, ArrayOfInsuranceTransaction.class, InsuranceAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = BankTransaction.class)
    public JAXBElement<Long> createBankTransactionId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, BankTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "checkNumber", scope = BankTransaction.class)
    public JAXBElement<String> createBankTransactionCheckNumber(String value) {
        return new JAXBElement<String>(_BankTransactionCheckNumber_QNAME, String.class, BankTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ItemAccountInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccountInfo", scope = SummaryData.class)
    public JAXBElement<ItemAccountInfo> createSummaryDataItemAccountInfo(ItemAccountInfo value) {
        return new JAXBElement<ItemAccountInfo>(_SummaryDataItemAccountInfo_QNAME, ItemAccountInfo.class, SummaryData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PersonInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountHolder", scope = FinancialAccount.class)
    public JAXBElement<PersonInformation> createFinancialAccountAccountHolder(PersonInformation value) {
        return new JAXBElement<PersonInformation>(_FinancialAccountAccountHolder_QNAME, PersonInformation.class, FinancialAccount.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = WirelessUsage.class)
    public JAXBElement<Long> createWirelessUsageId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unitsOverLimit", scope = WirelessUsage.class)
    public JAXBElement<BigDecimal> createWirelessUsageUnitsOverLimit(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_WirelessUsageUnitsOverLimit_QNAME, BigDecimal.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WirelessUsageTimePeriod }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageTimePeriod", scope = WirelessUsage.class)
    public JAXBElement<WirelessUsageTimePeriod> createWirelessUsageWirelessUsageTimePeriod(WirelessUsageTimePeriod value) {
        return new JAXBElement<WirelessUsageTimePeriod>(_WirelessUsageWirelessUsageTimePeriod_QNAME, WirelessUsageTimePeriod.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unitsRemaining", scope = WirelessUsage.class)
    public JAXBElement<BigDecimal> createWirelessUsageUnitsRemaining(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_WirelessUsageUnitsRemaining_QNAME, BigDecimal.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WirelessUsageUnit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageUnit", scope = WirelessUsage.class)
    public JAXBElement<WirelessUsageUnit> createWirelessUsageWirelessUsageUnit(WirelessUsageUnit value) {
        return new JAXBElement<WirelessUsageUnit>(_WirelessUsageWirelessUsageUnit_QNAME, WirelessUsageUnit.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "chargesIncurred", scope = WirelessUsage.class)
    public JAXBElement<Money> createWirelessUsageChargesIncurred(Money value) {
        return new JAXBElement<Money>(_WirelessUsageChargesIncurred_QNAME, Money.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unitsUsed", scope = WirelessUsage.class)
    public JAXBElement<BigDecimal> createWirelessUsageUnitsUsed(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_WirelessUsageUnitsUsed_QNAME, BigDecimal.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = WirelessUsage.class)
    public JAXBElement<String> createWirelessUsageDescription(String value) {
        return new JAXBElement<String>(_FinancialTransactionDescription_QNAME, String.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "unitsIncluded", scope = WirelessUsage.class)
    public JAXBElement<BigDecimal> createWirelessUsageUnitsIncluded(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_WirelessUsageUnitsIncluded_QNAME, BigDecimal.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WirelessUsageType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageType", scope = WirelessUsage.class)
    public JAXBElement<WirelessUsageType> createWirelessUsageWirelessUsageType(WirelessUsageType value) {
        return new JAXBElement<WirelessUsageType>(_WirelessUsageWirelessUsageType_QNAME, WirelessUsageType.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WirelessUsageDirection }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "wirelessUsageDirection", scope = WirelessUsage.class)
    public JAXBElement<WirelessUsageDirection> createWirelessUsageWirelessUsageDirection(WirelessUsageDirection value) {
        return new JAXBElement<WirelessUsageDirection>(_WirelessUsageWirelessUsageDirection_QNAME, WirelessUsageDirection.class, WirelessUsage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = InsuranceTransaction.class)
    public JAXBElement<Long> createInsuranceTransactionId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, InsuranceTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = BillingCharge.class)
    public JAXBElement<Money> createBillingChargeAmount(Money value) {
        return new JAXBElement<Money>(_FinancialTransactionAmount_QNAME, Money.class, BillingCharge.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = BillingCharge.class)
    public JAXBElement<String> createBillingChargeDescription(String value) {
        return new JAXBElement<String>(_FinancialTransactionDescription_QNAME, String.class, BillingCharge.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = FinLoanTransaction.class)
    public JAXBElement<Long> createFinLoanTransactionId(Long value) {
        return new JAXBElement<Long>(_BillingPaymentId_QNAME, Long.class, FinLoanTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amountAppliedToPrincipal", scope = FinLoanTransaction.class)
    public JAXBElement<Money> createFinLoanTransactionAmountAppliedToPrincipal(Money value) {
        return new JAXBElement<Money>(_FinLoanTransactionAmountAppliedToPrincipal_QNAME, Money.class, FinLoanTransaction.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Money }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amountAppliedToInterest", scope = FinLoanTransaction.class)
    public JAXBElement<Money> createFinLoanTransactionAmountAppliedToInterest(Money value) {
        return new JAXBElement<Money>(_FinLoanTransactionAmountAppliedToInterest_QNAME, Money.class, FinLoanTransaction.class, value);
    }

}
