
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessLineInfo;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessUsage;


/**
 * <p>Java class for WirelessAccount complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WirelessAccount">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingAccount">
 *       &lt;sequence>
 *         &lt;element name="wirelessLineInfoList" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfWirelessLineInfo" minOccurs="0"/>
 *         &lt;element name="wirelessUsageList" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfWirelessUsage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WirelessAccount", propOrder = {
    "wirelessLineInfoList",
    "wirelessUsageList"
})
public class WirelessAccount
    extends BillingAccount
{

    @XmlElementRef(name = "wirelessLineInfoList", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfWirelessLineInfo> wirelessLineInfoList;
    @XmlElementRef(name = "wirelessUsageList", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfWirelessUsage> wirelessUsageList;

    /**
     * Gets the value of the wirelessLineInfoList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineInfo }{@code >}
     *     
     */
    public JAXBElement<ArrayOfWirelessLineInfo> getWirelessLineInfoList() {
        return wirelessLineInfoList;
    }

    /**
     * Sets the value of the wirelessLineInfoList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineInfo }{@code >}
     *     
     */
    public void setWirelessLineInfoList(JAXBElement<ArrayOfWirelessLineInfo> value) {
        this.wirelessLineInfoList = value;
    }

    /**
     * Gets the value of the wirelessUsageList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}
     *     
     */
    public JAXBElement<ArrayOfWirelessUsage> getWirelessUsageList() {
        return wirelessUsageList;
    }

    /**
     * Sets the value of the wirelessUsageList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}
     *     
     */
    public void setWirelessUsageList(JAXBElement<ArrayOfWirelessUsage> value) {
        this.wirelessUsageList = value;
    }

}
