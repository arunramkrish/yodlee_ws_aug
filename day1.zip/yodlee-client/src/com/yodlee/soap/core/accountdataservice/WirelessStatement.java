
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessLineBilledInfo;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfWirelessUsage;


/**
 * <p>Java class for WirelessStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WirelessStatement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}BillingStatement">
 *       &lt;sequence>
 *         &lt;element name="wirelessLineBilledInfoList" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfWirelessLineBilledInfo" minOccurs="0"/>
 *         &lt;element name="wirelessUsageList" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfWirelessUsage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WirelessStatement", propOrder = {
    "wirelessLineBilledInfoList",
    "wirelessUsageList"
})
public class WirelessStatement
    extends BillingStatement
{

    @XmlElementRef(name = "wirelessLineBilledInfoList", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfWirelessLineBilledInfo> wirelessLineBilledInfoList;
    @XmlElementRef(name = "wirelessUsageList", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfWirelessUsage> wirelessUsageList;

    /**
     * Gets the value of the wirelessLineBilledInfoList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineBilledInfo }{@code >}
     *     
     */
    public JAXBElement<ArrayOfWirelessLineBilledInfo> getWirelessLineBilledInfoList() {
        return wirelessLineBilledInfoList;
    }

    /**
     * Sets the value of the wirelessLineBilledInfoList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessLineBilledInfo }{@code >}
     *     
     */
    public void setWirelessLineBilledInfoList(JAXBElement<ArrayOfWirelessLineBilledInfo> value) {
        this.wirelessLineBilledInfoList = value;
    }

    /**
     * Gets the value of the wirelessUsageList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}
     *     
     */
    public JAXBElement<ArrayOfWirelessUsage> getWirelessUsageList() {
        return wirelessUsageList;
    }

    /**
     * Sets the value of the wirelessUsageList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWirelessUsage }{@code >}
     *     
     */
    public void setWirelessUsageList(JAXBElement<ArrayOfWirelessUsage> value) {
        this.wirelessUsageList = value;
    }

}
