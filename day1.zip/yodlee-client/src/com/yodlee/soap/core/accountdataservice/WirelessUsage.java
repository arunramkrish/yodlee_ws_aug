
package com.yodlee.soap.core.accountdataservice;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.Money;


/**
 * <p>Java class for WirelessUsage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WirelessUsage">
 *   &lt;complexContent>
 *     &lt;extension base="{http://accountdataservice.core.soap.yodlee.com}SummaryData">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitsUsed" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="unitsIncluded" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="unitsRemaining" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="unitsOverLimit" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="wirelessUsageUnit" type="{http://accountdataservice.core.soap.yodlee.com}WirelessUsageUnit" minOccurs="0"/>
 *         &lt;element name="wirelessUsageType" type="{http://accountdataservice.core.soap.yodlee.com}WirelessUsageType" minOccurs="0"/>
 *         &lt;element name="wirelessUsageTimePeriod" type="{http://accountdataservice.core.soap.yodlee.com}WirelessUsageTimePeriod" minOccurs="0"/>
 *         &lt;element name="wirelessUsageDirection" type="{http://accountdataservice.core.soap.yodlee.com}WirelessUsageDirection" minOccurs="0"/>
 *         &lt;element name="chargesIncurred" type="{http://common.soap.yodlee.com}Money" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WirelessUsage", propOrder = {
    "id",
    "description",
    "unitsUsed",
    "unitsIncluded",
    "unitsRemaining",
    "unitsOverLimit",
    "wirelessUsageUnit",
    "wirelessUsageType",
    "wirelessUsageTimePeriod",
    "wirelessUsageDirection",
    "chargesIncurred"
})
public class WirelessUsage
    extends SummaryData
{

    @XmlElementRef(name = "id", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> id;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "unitsUsed", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> unitsUsed;
    @XmlElementRef(name = "unitsIncluded", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> unitsIncluded;
    @XmlElementRef(name = "unitsRemaining", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> unitsRemaining;
    @XmlElementRef(name = "unitsOverLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<BigDecimal> unitsOverLimit;
    @XmlElementRef(name = "wirelessUsageUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<WirelessUsageUnit> wirelessUsageUnit;
    @XmlElementRef(name = "wirelessUsageType", type = JAXBElement.class, required = false)
    protected JAXBElement<WirelessUsageType> wirelessUsageType;
    @XmlElementRef(name = "wirelessUsageTimePeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<WirelessUsageTimePeriod> wirelessUsageTimePeriod;
    @XmlElementRef(name = "wirelessUsageDirection", type = JAXBElement.class, required = false)
    protected JAXBElement<WirelessUsageDirection> wirelessUsageDirection;
    @XmlElementRef(name = "chargesIncurred", type = JAXBElement.class, required = false)
    protected JAXBElement<Money> chargesIncurred;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setId(JAXBElement<Long> value) {
        this.id = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the unitsUsed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getUnitsUsed() {
        return unitsUsed;
    }

    /**
     * Sets the value of the unitsUsed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setUnitsUsed(JAXBElement<BigDecimal> value) {
        this.unitsUsed = value;
    }

    /**
     * Gets the value of the unitsIncluded property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getUnitsIncluded() {
        return unitsIncluded;
    }

    /**
     * Sets the value of the unitsIncluded property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setUnitsIncluded(JAXBElement<BigDecimal> value) {
        this.unitsIncluded = value;
    }

    /**
     * Gets the value of the unitsRemaining property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getUnitsRemaining() {
        return unitsRemaining;
    }

    /**
     * Sets the value of the unitsRemaining property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setUnitsRemaining(JAXBElement<BigDecimal> value) {
        this.unitsRemaining = value;
    }

    /**
     * Gets the value of the unitsOverLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getUnitsOverLimit() {
        return unitsOverLimit;
    }

    /**
     * Sets the value of the unitsOverLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setUnitsOverLimit(JAXBElement<BigDecimal> value) {
        this.unitsOverLimit = value;
    }

    /**
     * Gets the value of the wirelessUsageUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageUnit }{@code >}
     *     
     */
    public JAXBElement<WirelessUsageUnit> getWirelessUsageUnit() {
        return wirelessUsageUnit;
    }

    /**
     * Sets the value of the wirelessUsageUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageUnit }{@code >}
     *     
     */
    public void setWirelessUsageUnit(JAXBElement<WirelessUsageUnit> value) {
        this.wirelessUsageUnit = value;
    }

    /**
     * Gets the value of the wirelessUsageType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageType }{@code >}
     *     
     */
    public JAXBElement<WirelessUsageType> getWirelessUsageType() {
        return wirelessUsageType;
    }

    /**
     * Sets the value of the wirelessUsageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageType }{@code >}
     *     
     */
    public void setWirelessUsageType(JAXBElement<WirelessUsageType> value) {
        this.wirelessUsageType = value;
    }

    /**
     * Gets the value of the wirelessUsageTimePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageTimePeriod }{@code >}
     *     
     */
    public JAXBElement<WirelessUsageTimePeriod> getWirelessUsageTimePeriod() {
        return wirelessUsageTimePeriod;
    }

    /**
     * Sets the value of the wirelessUsageTimePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageTimePeriod }{@code >}
     *     
     */
    public void setWirelessUsageTimePeriod(JAXBElement<WirelessUsageTimePeriod> value) {
        this.wirelessUsageTimePeriod = value;
    }

    /**
     * Gets the value of the wirelessUsageDirection property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageDirection }{@code >}
     *     
     */
    public JAXBElement<WirelessUsageDirection> getWirelessUsageDirection() {
        return wirelessUsageDirection;
    }

    /**
     * Sets the value of the wirelessUsageDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WirelessUsageDirection }{@code >}
     *     
     */
    public void setWirelessUsageDirection(JAXBElement<WirelessUsageDirection> value) {
        this.wirelessUsageDirection = value;
    }

    /**
     * Gets the value of the chargesIncurred property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public JAXBElement<Money> getChargesIncurred() {
        return chargesIncurred;
    }

    /**
     * Sets the value of the chargesIncurred property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Money }{@code >}
     *     
     */
    public void setChargesIncurred(JAXBElement<Money> value) {
        this.chargesIncurred = value;
    }

}
