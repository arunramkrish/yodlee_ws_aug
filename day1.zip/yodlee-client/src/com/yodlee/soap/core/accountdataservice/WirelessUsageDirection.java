
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WirelessUsageDirection.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WirelessUsageDirection">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="INCOMING"/>
 *     &lt;enumeration value="OUTGOING"/>
 *     &lt;enumeration value="INCOMING_AND_OUTGOING"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="NOT_APPLICABLE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WirelessUsageDirection")
@XmlEnum
public enum WirelessUsageDirection {

    INCOMING,
    OUTGOING,
    INCOMING_AND_OUTGOING,
    UNKNOWN,
    NOT_APPLICABLE;

    public String value() {
        return name();
    }

    public static WirelessUsageDirection fromValue(String v) {
        return valueOf(v);
    }

}
