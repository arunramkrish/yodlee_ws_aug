
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WirelessUsageTimePeriod.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WirelessUsageTimePeriod">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ANYTIME"/>
 *     &lt;enumeration value="WEEK_NIGHT"/>
 *     &lt;enumeration value="WEEKEND"/>
 *     &lt;enumeration value="NIGHT_AND_WEEKEND"/>
 *     &lt;enumeration value="ALL"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WirelessUsageTimePeriod")
@XmlEnum
public enum WirelessUsageTimePeriod {

    ANYTIME,
    WEEK_NIGHT,
    WEEKEND,
    NIGHT_AND_WEEKEND,
    ALL,
    OTHER,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static WirelessUsageTimePeriod fromValue(String v) {
        return valueOf(v);
    }

}
