
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WirelessUsageType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WirelessUsageType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="VOICE"/>
 *     &lt;enumeration value="MOBILE_TO_MOBILE"/>
 *     &lt;enumeration value="ROLLOVER"/>
 *     &lt;enumeration value="DOMESTIC_ROAMING"/>
 *     &lt;enumeration value="INTERNATIONAL_ROAMING"/>
 *     &lt;enumeration value="LOCAL"/>
 *     &lt;enumeration value="DOMESTIC_LONG_DISTANCE"/>
 *     &lt;enumeration value="INTERNATIONAL_LONG_DISTANCE"/>
 *     &lt;enumeration value="INTERNATIONAL"/>
 *     &lt;enumeration value="TEXT_MESSAGE"/>
 *     &lt;enumeration value="MULTIMEDIA_MESSAGE"/>
 *     &lt;enumeration value="DATA"/>
 *     &lt;enumeration value="WIRELESS_INTERNET"/>
 *     &lt;enumeration value="DIRECTORY_ASSISTANCE"/>
 *     &lt;enumeration value="VOICE_SERVICES"/>
 *     &lt;enumeration value="MOBILE_ASSIST"/>
 *     &lt;enumeration value="GAME_DOWNLOADS"/>
 *     &lt;enumeration value="GRAPHICS_DOWNLOADS"/>
 *     &lt;enumeration value="RINGTONE_DOWNLOADS"/>
 *     &lt;enumeration value="OTHER_DOWNLOADS"/>
 *     &lt;enumeration value="DOWNLOADS"/>
 *     &lt;enumeration value="PUSH_TO_TALK"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WirelessUsageType")
@XmlEnum
public enum WirelessUsageType {

    VOICE,
    MOBILE_TO_MOBILE,
    ROLLOVER,
    DOMESTIC_ROAMING,
    INTERNATIONAL_ROAMING,
    LOCAL,
    DOMESTIC_LONG_DISTANCE,
    INTERNATIONAL_LONG_DISTANCE,
    INTERNATIONAL,
    TEXT_MESSAGE,
    MULTIMEDIA_MESSAGE,
    DATA,
    WIRELESS_INTERNET,
    DIRECTORY_ASSISTANCE,
    VOICE_SERVICES,
    MOBILE_ASSIST,
    GAME_DOWNLOADS,
    GRAPHICS_DOWNLOADS,
    RINGTONE_DOWNLOADS,
    OTHER_DOWNLOADS,
    DOWNLOADS,
    PUSH_TO_TALK,
    OTHER,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static WirelessUsageType fromValue(String v) {
        return valueOf(v);
    }

}
