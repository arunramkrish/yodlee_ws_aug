
package com.yodlee.soap.core.accountdataservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WirelessUsageUnit.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="WirelessUsageUnit">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MINUTES"/>
 *     &lt;enumeration value="KILOBYTES"/>
 *     &lt;enumeration value="MEGABYTES"/>
 *     &lt;enumeration value="CALLS"/>
 *     &lt;enumeration value="DOWNLOADS"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "WirelessUsageUnit")
@XmlEnum
public enum WirelessUsageUnit {

    MINUTES,
    KILOBYTES,
    MEGABYTES,
    CALLS,
    DOWNLOADS,
    OTHER,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static WirelessUsageUnit fromValue(String v) {
        return valueOf(v);
    }

}
