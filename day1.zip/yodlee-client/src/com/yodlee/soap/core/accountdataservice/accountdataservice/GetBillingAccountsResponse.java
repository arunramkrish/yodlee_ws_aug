
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingAccount;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getBillingAccountsReturn" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillingAccount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getBillingAccountsReturn"
})
@XmlRootElement(name = "getBillingAccountsResponse")
public class GetBillingAccountsResponse {

    @XmlElementRef(name = "getBillingAccountsReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillingAccount> getBillingAccountsReturn;

    /**
     * Gets the value of the getBillingAccountsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingAccount }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillingAccount> getGetBillingAccountsReturn() {
        return getBillingAccountsReturn;
    }

    /**
     * Sets the value of the getBillingAccountsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingAccount }{@code >}
     *     
     */
    public void setGetBillingAccountsReturn(JAXBElement<ArrayOfBillingAccount> value) {
        this.getBillingAccountsReturn = value;
    }

}
