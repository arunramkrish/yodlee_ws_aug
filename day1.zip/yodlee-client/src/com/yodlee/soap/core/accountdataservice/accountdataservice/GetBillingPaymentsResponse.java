
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingPayment;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getBillingPaymentsReturn" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillingPayment" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getBillingPaymentsReturn"
})
@XmlRootElement(name = "getBillingPaymentsResponse")
public class GetBillingPaymentsResponse {

    @XmlElementRef(name = "getBillingPaymentsReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillingPayment> getBillingPaymentsReturn;

    /**
     * Gets the value of the getBillingPaymentsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillingPayment> getGetBillingPaymentsReturn() {
        return getBillingPaymentsReturn;
    }

    /**
     * Sets the value of the getBillingPaymentsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}
     *     
     */
    public void setGetBillingPaymentsReturn(JAXBElement<ArrayOfBillingPayment> value) {
        this.getBillingPaymentsReturn = value;
    }

}
