
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.ArrayOflong;
import com.yodlee.soap.collections.core.accountdataservice.selectors.ArrayOfAccountDataSelector;
import com.yodlee.soap.common.UserContext;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userContext" type="{http://common.soap.yodlee.com}UserContext" minOccurs="0"/>
 *         &lt;element name="itemIds" type="{http://collections.soap.yodlee.com}ArrayOflong" minOccurs="0"/>
 *         &lt;element name="includeDeletedAccounts" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="selectors" type="{http://selectors.accountdataservice.core.collections.soap.yodlee.com}ArrayOfAccountDataSelector" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "userContext",
    "itemIds",
    "includeDeletedAccounts",
    "selectors"
})
@XmlRootElement(name = "getBillingStatements")
public class GetBillingStatements {

    @XmlElementRef(name = "userContext", type = JAXBElement.class, required = false)
    protected JAXBElement<UserContext> userContext;
    @XmlElementRef(name = "itemIds", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOflong> itemIds;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean includeDeletedAccounts;
    @XmlElementRef(name = "selectors", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfAccountDataSelector> selectors;

    /**
     * Gets the value of the userContext property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserContext }{@code >}
     *     
     */
    public JAXBElement<UserContext> getUserContext() {
        return userContext;
    }

    /**
     * Sets the value of the userContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserContext }{@code >}
     *     
     */
    public void setUserContext(JAXBElement<UserContext> value) {
        this.userContext = value;
    }

    /**
     * Gets the value of the itemIds property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}
     *     
     */
    public JAXBElement<ArrayOflong> getItemIds() {
        return itemIds;
    }

    /**
     * Sets the value of the itemIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}
     *     
     */
    public void setItemIds(JAXBElement<ArrayOflong> value) {
        this.itemIds = value;
    }

    /**
     * Gets the value of the includeDeletedAccounts property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeDeletedAccounts() {
        return includeDeletedAccounts;
    }

    /**
     * Sets the value of the includeDeletedAccounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeDeletedAccounts(Boolean value) {
        this.includeDeletedAccounts = value;
    }

    /**
     * Gets the value of the selectors property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}
     *     
     */
    public JAXBElement<ArrayOfAccountDataSelector> getSelectors() {
        return selectors;
    }

    /**
     * Sets the value of the selectors property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}
     *     
     */
    public void setSelectors(JAXBElement<ArrayOfAccountDataSelector> value) {
        this.selectors = value;
    }

}
