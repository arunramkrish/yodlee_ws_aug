
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfFinancialAccount;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getFinancialAccountsReturn" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfFinancialAccount" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getFinancialAccountsReturn"
})
@XmlRootElement(name = "getFinancialAccountsResponse")
public class GetFinancialAccountsResponse {

    @XmlElementRef(name = "getFinancialAccountsReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfFinancialAccount> getFinancialAccountsReturn;

    /**
     * Gets the value of the getFinancialAccountsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinancialAccount }{@code >}
     *     
     */
    public JAXBElement<ArrayOfFinancialAccount> getGetFinancialAccountsReturn() {
        return getFinancialAccountsReturn;
    }

    /**
     * Sets the value of the getFinancialAccountsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfFinancialAccount }{@code >}
     *     
     */
    public void setGetFinancialAccountsReturn(JAXBElement<ArrayOfFinancialAccount> value) {
        this.getFinancialAccountsReturn = value;
    }

}
