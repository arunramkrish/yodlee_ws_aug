
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.ArrayOflong;
import com.yodlee.soap.common.UserContext;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userContext" type="{http://common.soap.yodlee.com}UserContext" minOccurs="0"/>
 *         &lt;element name="itemAccountIds" type="{http://collections.soap.yodlee.com}ArrayOflong" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "userContext",
    "itemAccountIds"
})
@XmlRootElement(name = "getHoldingHistory")
public class GetHoldingHistory {

    @XmlElementRef(name = "userContext", type = JAXBElement.class, required = false)
    protected JAXBElement<UserContext> userContext;
    @XmlElementRef(name = "itemAccountIds", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOflong> itemAccountIds;

    /**
     * Gets the value of the userContext property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserContext }{@code >}
     *     
     */
    public JAXBElement<UserContext> getUserContext() {
        return userContext;
    }

    /**
     * Sets the value of the userContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserContext }{@code >}
     *     
     */
    public void setUserContext(JAXBElement<UserContext> value) {
        this.userContext = value;
    }

    /**
     * Gets the value of the itemAccountIds property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}
     *     
     */
    public JAXBElement<ArrayOflong> getItemAccountIds() {
        return itemAccountIds;
    }

    /**
     * Sets the value of the itemAccountIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}
     *     
     */
    public void setItemAccountIds(JAXBElement<ArrayOflong> value) {
        this.itemAccountIds = value;
    }

}
