
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfItemData;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getItemDataReturn" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfItemData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getItemDataReturn"
})
@XmlRootElement(name = "getItemDataResponse")
public class GetItemDataResponse {

    @XmlElementRef(name = "getItemDataReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfItemData> getItemDataReturn;

    /**
     * Gets the value of the getItemDataReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfItemData }{@code >}
     *     
     */
    public JAXBElement<ArrayOfItemData> getGetItemDataReturn() {
        return getItemDataReturn;
    }

    /**
     * Sets the value of the getItemDataReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfItemData }{@code >}
     *     
     */
    public void setGetItemDataReturn(JAXBElement<ArrayOfItemData> value) {
        this.getItemDataReturn = value;
    }

}
