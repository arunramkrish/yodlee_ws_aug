
package com.yodlee.soap.core.accountdataservice.accountdataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.ArrayOflong;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingAccount;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingPayment;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillingStatement;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfFinancialAccount;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfItemData;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfItemInfo;
import com.yodlee.soap.collections.core.accountdataservice.selectors.ArrayOfAccountDataSelector;
import com.yodlee.soap.collections.core.dataservice.types.ArrayOfHoldingData;
import com.yodlee.soap.common.UserContext;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.accountdataservice.accountdataservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetItemDataResponseGetItemDataReturn_QNAME = new QName("", "getItemDataReturn");
    private final static QName _GetBillingAccountsItemIds_QNAME = new QName("", "itemIds");
    private final static QName _GetBillingAccountsSelectors_QNAME = new QName("", "selectors");
    private final static QName _GetBillingAccountsUserContext_QNAME = new QName("", "userContext");
    private final static QName _GetBillingAccountsResponseGetBillingAccountsReturn_QNAME = new QName("", "getBillingAccountsReturn");
    private final static QName _GetHoldingHistoryResponseGetHoldingHistoryReturn_QNAME = new QName("", "getHoldingHistoryReturn");
    private final static QName _GetHoldingHistoryItemAccountIds_QNAME = new QName("", "itemAccountIds");
    private final static QName _GetBillingPaymentsResponseGetBillingPaymentsReturn_QNAME = new QName("", "getBillingPaymentsReturn");
    private final static QName _GetFinancialAccountsResponseGetFinancialAccountsReturn_QNAME = new QName("", "getFinancialAccountsReturn");
    private final static QName _GetBillingStatementsResponseGetBillingStatementsReturn_QNAME = new QName("", "getBillingStatementsReturn");
    private final static QName _GetItemInfoResponseGetItemInfoReturn_QNAME = new QName("", "getItemInfoReturn");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.accountdataservice.accountdataservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetFinancialAccountsResponse }
     * 
     */
    public GetFinancialAccountsResponse createGetFinancialAccountsResponse() {
        return new GetFinancialAccountsResponse();
    }

    /**
     * Create an instance of {@link GetBillingPaymentsResponse }
     * 
     */
    public GetBillingPaymentsResponse createGetBillingPaymentsResponse() {
        return new GetBillingPaymentsResponse();
    }

    /**
     * Create an instance of {@link GetBillingPayments }
     * 
     */
    public GetBillingPayments createGetBillingPayments() {
        return new GetBillingPayments();
    }

    /**
     * Create an instance of {@link GetHoldingHistoryResponse }
     * 
     */
    public GetHoldingHistoryResponse createGetHoldingHistoryResponse() {
        return new GetHoldingHistoryResponse();
    }

    /**
     * Create an instance of {@link GetItemInfoResponse }
     * 
     */
    public GetItemInfoResponse createGetItemInfoResponse() {
        return new GetItemInfoResponse();
    }

    /**
     * Create an instance of {@link GetItemInfo }
     * 
     */
    public GetItemInfo createGetItemInfo() {
        return new GetItemInfo();
    }

    /**
     * Create an instance of {@link GetBillingAccountsResponse }
     * 
     */
    public GetBillingAccountsResponse createGetBillingAccountsResponse() {
        return new GetBillingAccountsResponse();
    }

    /**
     * Create an instance of {@link GetBillingStatements }
     * 
     */
    public GetBillingStatements createGetBillingStatements() {
        return new GetBillingStatements();
    }

    /**
     * Create an instance of {@link GetBillingAccounts }
     * 
     */
    public GetBillingAccounts createGetBillingAccounts() {
        return new GetBillingAccounts();
    }

    /**
     * Create an instance of {@link GetItemData }
     * 
     */
    public GetItemData createGetItemData() {
        return new GetItemData();
    }

    /**
     * Create an instance of {@link GetBillingStatementsResponse }
     * 
     */
    public GetBillingStatementsResponse createGetBillingStatementsResponse() {
        return new GetBillingStatementsResponse();
    }

    /**
     * Create an instance of {@link GetItemDataResponse }
     * 
     */
    public GetItemDataResponse createGetItemDataResponse() {
        return new GetItemDataResponse();
    }

    /**
     * Create an instance of {@link GetHoldingHistory }
     * 
     */
    public GetHoldingHistory createGetHoldingHistory() {
        return new GetHoldingHistory();
    }

    /**
     * Create an instance of {@link GetFinancialAccounts }
     * 
     */
    public GetFinancialAccounts createGetFinancialAccounts() {
        return new GetFinancialAccounts();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfItemData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getItemDataReturn", scope = GetItemDataResponse.class)
    public JAXBElement<ArrayOfItemData> createGetItemDataResponseGetItemDataReturn(ArrayOfItemData value) {
        return new JAXBElement<ArrayOfItemData>(_GetItemDataResponseGetItemDataReturn_QNAME, ArrayOfItemData.class, GetItemDataResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetBillingAccounts.class)
    public JAXBElement<ArrayOflong> createGetBillingAccountsItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetBillingAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selectors", scope = GetBillingAccounts.class)
    public JAXBElement<ArrayOfAccountDataSelector> createGetBillingAccountsSelectors(ArrayOfAccountDataSelector value) {
        return new JAXBElement<ArrayOfAccountDataSelector>(_GetBillingAccountsSelectors_QNAME, ArrayOfAccountDataSelector.class, GetBillingAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetBillingAccounts.class)
    public JAXBElement<UserContext> createGetBillingAccountsUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetBillingAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetItemInfo.class)
    public JAXBElement<ArrayOflong> createGetItemInfoItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetItemInfo.class)
    public JAXBElement<UserContext> createGetItemInfoUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetItemInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getBillingAccountsReturn", scope = GetBillingAccountsResponse.class)
    public JAXBElement<ArrayOfBillingAccount> createGetBillingAccountsResponseGetBillingAccountsReturn(ArrayOfBillingAccount value) {
        return new JAXBElement<ArrayOfBillingAccount>(_GetBillingAccountsResponseGetBillingAccountsReturn_QNAME, ArrayOfBillingAccount.class, GetBillingAccountsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfHoldingData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getHoldingHistoryReturn", scope = GetHoldingHistoryResponse.class)
    public JAXBElement<ArrayOfHoldingData> createGetHoldingHistoryResponseGetHoldingHistoryReturn(ArrayOfHoldingData value) {
        return new JAXBElement<ArrayOfHoldingData>(_GetHoldingHistoryResponseGetHoldingHistoryReturn_QNAME, ArrayOfHoldingData.class, GetHoldingHistoryResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemAccountIds", scope = GetHoldingHistory.class)
    public JAXBElement<ArrayOflong> createGetHoldingHistoryItemAccountIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetHoldingHistoryItemAccountIds_QNAME, ArrayOflong.class, GetHoldingHistory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetHoldingHistory.class)
    public JAXBElement<UserContext> createGetHoldingHistoryUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetHoldingHistory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetFinancialAccounts.class)
    public JAXBElement<ArrayOflong> createGetFinancialAccountsItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetFinancialAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selectors", scope = GetFinancialAccounts.class)
    public JAXBElement<ArrayOfAccountDataSelector> createGetFinancialAccountsSelectors(ArrayOfAccountDataSelector value) {
        return new JAXBElement<ArrayOfAccountDataSelector>(_GetBillingAccountsSelectors_QNAME, ArrayOfAccountDataSelector.class, GetFinancialAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetFinancialAccounts.class)
    public JAXBElement<UserContext> createGetFinancialAccountsUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetFinancialAccounts.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingPayment }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getBillingPaymentsReturn", scope = GetBillingPaymentsResponse.class)
    public JAXBElement<ArrayOfBillingPayment> createGetBillingPaymentsResponseGetBillingPaymentsReturn(ArrayOfBillingPayment value) {
        return new JAXBElement<ArrayOfBillingPayment>(_GetBillingPaymentsResponseGetBillingPaymentsReturn_QNAME, ArrayOfBillingPayment.class, GetBillingPaymentsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfFinancialAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getFinancialAccountsReturn", scope = GetFinancialAccountsResponse.class)
    public JAXBElement<ArrayOfFinancialAccount> createGetFinancialAccountsResponseGetFinancialAccountsReturn(ArrayOfFinancialAccount value) {
        return new JAXBElement<ArrayOfFinancialAccount>(_GetFinancialAccountsResponseGetFinancialAccountsReturn_QNAME, ArrayOfFinancialAccount.class, GetFinancialAccountsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillingStatement }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getBillingStatementsReturn", scope = GetBillingStatementsResponse.class)
    public JAXBElement<ArrayOfBillingStatement> createGetBillingStatementsResponseGetBillingStatementsReturn(ArrayOfBillingStatement value) {
        return new JAXBElement<ArrayOfBillingStatement>(_GetBillingStatementsResponseGetBillingStatementsReturn_QNAME, ArrayOfBillingStatement.class, GetBillingStatementsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetBillingPayments.class)
    public JAXBElement<ArrayOflong> createGetBillingPaymentsItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetBillingPayments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selectors", scope = GetBillingPayments.class)
    public JAXBElement<ArrayOfAccountDataSelector> createGetBillingPaymentsSelectors(ArrayOfAccountDataSelector value) {
        return new JAXBElement<ArrayOfAccountDataSelector>(_GetBillingAccountsSelectors_QNAME, ArrayOfAccountDataSelector.class, GetBillingPayments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetBillingPayments.class)
    public JAXBElement<UserContext> createGetBillingPaymentsUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetBillingPayments.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfItemInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "getItemInfoReturn", scope = GetItemInfoResponse.class)
    public JAXBElement<ArrayOfItemInfo> createGetItemInfoResponseGetItemInfoReturn(ArrayOfItemInfo value) {
        return new JAXBElement<ArrayOfItemInfo>(_GetItemInfoResponseGetItemInfoReturn_QNAME, ArrayOfItemInfo.class, GetItemInfoResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetBillingStatements.class)
    public JAXBElement<ArrayOflong> createGetBillingStatementsItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetBillingStatements.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selectors", scope = GetBillingStatements.class)
    public JAXBElement<ArrayOfAccountDataSelector> createGetBillingStatementsSelectors(ArrayOfAccountDataSelector value) {
        return new JAXBElement<ArrayOfAccountDataSelector>(_GetBillingAccountsSelectors_QNAME, ArrayOfAccountDataSelector.class, GetBillingStatements.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetBillingStatements.class)
    public JAXBElement<UserContext> createGetBillingStatementsUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetBillingStatements.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOflong }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "itemIds", scope = GetItemData.class)
    public JAXBElement<ArrayOflong> createGetItemDataItemIds(ArrayOflong value) {
        return new JAXBElement<ArrayOflong>(_GetBillingAccountsItemIds_QNAME, ArrayOflong.class, GetItemData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAccountDataSelector }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "selectors", scope = GetItemData.class)
    public JAXBElement<ArrayOfAccountDataSelector> createGetItemDataSelectors(ArrayOfAccountDataSelector value) {
        return new JAXBElement<ArrayOfAccountDataSelector>(_GetBillingAccountsSelectors_QNAME, ArrayOfAccountDataSelector.class, GetItemData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserContext }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userContext", scope = GetItemData.class)
    public JAXBElement<UserContext> createGetItemDataUserContext(UserContext value) {
        return new JAXBElement<UserContext>(_GetBillingAccountsUserContext_QNAME, UserContext.class, GetItemData.class, value);
    }

}
