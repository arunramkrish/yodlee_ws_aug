@javax.xml.bind.annotation.XmlSchema(namespace = "http://accountdataservice.accountdataservice.core.soap.yodlee.com")
package com.yodlee.soap.core.accountdataservice.accountdataservice;
