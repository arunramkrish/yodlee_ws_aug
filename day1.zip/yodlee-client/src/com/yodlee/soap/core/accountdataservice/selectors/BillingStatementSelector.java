
package com.yodlee.soap.core.accountdataservice.selectors;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillPaymentStatus;
import com.yodlee.soap.common.CalendarDate;


/**
 * <p>Java class for BillingStatementSelector complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillingStatementSelector">
 *   &lt;complexContent>
 *     &lt;extension base="{http://selectors.accountdataservice.core.soap.yodlee.com}AccountDataSelector">
 *       &lt;sequence>
 *         &lt;element name="dueDateFrom" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="dueDateTo" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="billPaymentStatuses" type="{http://accountdataservice.core.collections.soap.yodlee.com}ArrayOfBillPaymentStatus" minOccurs="0"/>
 *         &lt;element name="onlyLatestBills" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="billingChargeListIncluded" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="transactionListIncluded" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillingStatementSelector", propOrder = {
    "dueDateFrom",
    "dueDateTo",
    "billPaymentStatuses",
    "onlyLatestBills",
    "billingChargeListIncluded",
    "transactionListIncluded"
})
public class BillingStatementSelector
    extends AccountDataSelector
{

    @XmlElementRef(name = "dueDateFrom", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> dueDateFrom;
    @XmlElementRef(name = "dueDateTo", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> dueDateTo;
    @XmlElementRef(name = "billPaymentStatuses", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfBillPaymentStatus> billPaymentStatuses;
    protected boolean onlyLatestBills;
    protected boolean billingChargeListIncluded;
    protected boolean transactionListIncluded;

    /**
     * Gets the value of the dueDateFrom property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getDueDateFrom() {
        return dueDateFrom;
    }

    /**
     * Sets the value of the dueDateFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setDueDateFrom(JAXBElement<CalendarDate> value) {
        this.dueDateFrom = value;
    }

    /**
     * Gets the value of the dueDateTo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getDueDateTo() {
        return dueDateTo;
    }

    /**
     * Sets the value of the dueDateTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setDueDateTo(JAXBElement<CalendarDate> value) {
        this.dueDateTo = value;
    }

    /**
     * Gets the value of the billPaymentStatuses property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillPaymentStatus }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBillPaymentStatus> getBillPaymentStatuses() {
        return billPaymentStatuses;
    }

    /**
     * Sets the value of the billPaymentStatuses property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBillPaymentStatus }{@code >}
     *     
     */
    public void setBillPaymentStatuses(JAXBElement<ArrayOfBillPaymentStatus> value) {
        this.billPaymentStatuses = value;
    }

    /**
     * Gets the value of the onlyLatestBills property.
     * 
     */
    public boolean isOnlyLatestBills() {
        return onlyLatestBills;
    }

    /**
     * Sets the value of the onlyLatestBills property.
     * 
     */
    public void setOnlyLatestBills(boolean value) {
        this.onlyLatestBills = value;
    }

    /**
     * Gets the value of the billingChargeListIncluded property.
     * 
     */
    public boolean isBillingChargeListIncluded() {
        return billingChargeListIncluded;
    }

    /**
     * Sets the value of the billingChargeListIncluded property.
     * 
     */
    public void setBillingChargeListIncluded(boolean value) {
        this.billingChargeListIncluded = value;
    }

    /**
     * Gets the value of the transactionListIncluded property.
     * 
     */
    public boolean isTransactionListIncluded() {
        return transactionListIncluded;
    }

    /**
     * Sets the value of the transactionListIncluded property.
     * 
     */
    public void setTransactionListIncluded(boolean value) {
        this.transactionListIncluded = value;
    }

}
