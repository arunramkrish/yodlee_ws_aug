
package com.yodlee.soap.core.accountdataservice.selectors;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfBillPaymentStatus;
import com.yodlee.soap.collections.core.accountdataservice.ArrayOfDataType;
import com.yodlee.soap.common.CalendarDate;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.accountdataservice.selectors package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BillingStatementSelectorDueDateTo_QNAME = new QName("", "dueDateTo");
    private final static QName _BillingStatementSelectorBillPaymentStatuses_QNAME = new QName("", "billPaymentStatuses");
    private final static QName _BillingStatementSelectorDueDateFrom_QNAME = new QName("", "dueDateFrom");
    private final static QName _BillingPaymentSelectorFromDate_QNAME = new QName("", "fromDate");
    private final static QName _BillingPaymentSelectorToDate_QNAME = new QName("", "toDate");
    private final static QName _AccountDataTypeSelectorAccountDataTypes_QNAME = new QName("", "accountDataTypes");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.accountdataservice.selectors
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AccountUsageSelector }
     * 
     */
    public AccountUsageSelector createAccountUsageSelector() {
        return new AccountUsageSelector();
    }

    /**
     * Create an instance of {@link TransactionSelector }
     * 
     */
    public TransactionSelector createTransactionSelector() {
        return new TransactionSelector();
    }

    /**
     * Create an instance of {@link AccountDataTypeSelector }
     * 
     */
    public AccountDataTypeSelector createAccountDataTypeSelector() {
        return new AccountDataTypeSelector();
    }

    /**
     * Create an instance of {@link BillingStatementSelector }
     * 
     */
    public BillingStatementSelector createBillingStatementSelector() {
        return new BillingStatementSelector();
    }

    /**
     * Create an instance of {@link BillingPaymentSelector }
     * 
     */
    public BillingPaymentSelector createBillingPaymentSelector() {
        return new BillingPaymentSelector();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dueDateTo", scope = BillingStatementSelector.class)
    public JAXBElement<CalendarDate> createBillingStatementSelectorDueDateTo(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementSelectorDueDateTo_QNAME, CalendarDate.class, BillingStatementSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBillPaymentStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "billPaymentStatuses", scope = BillingStatementSelector.class)
    public JAXBElement<ArrayOfBillPaymentStatus> createBillingStatementSelectorBillPaymentStatuses(ArrayOfBillPaymentStatus value) {
        return new JAXBElement<ArrayOfBillPaymentStatus>(_BillingStatementSelectorBillPaymentStatuses_QNAME, ArrayOfBillPaymentStatus.class, BillingStatementSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dueDateFrom", scope = BillingStatementSelector.class)
    public JAXBElement<CalendarDate> createBillingStatementSelectorDueDateFrom(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingStatementSelectorDueDateFrom_QNAME, CalendarDate.class, BillingStatementSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fromDate", scope = BillingPaymentSelector.class)
    public JAXBElement<CalendarDate> createBillingPaymentSelectorFromDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingPaymentSelectorFromDate_QNAME, CalendarDate.class, BillingPaymentSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "toDate", scope = BillingPaymentSelector.class)
    public JAXBElement<CalendarDate> createBillingPaymentSelectorToDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingPaymentSelectorToDate_QNAME, CalendarDate.class, BillingPaymentSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfDataType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountDataTypes", scope = AccountDataTypeSelector.class)
    public JAXBElement<ArrayOfDataType> createAccountDataTypeSelectorAccountDataTypes(ArrayOfDataType value) {
        return new JAXBElement<ArrayOfDataType>(_AccountDataTypeSelectorAccountDataTypes_QNAME, ArrayOfDataType.class, AccountDataTypeSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "fromDate", scope = TransactionSelector.class)
    public JAXBElement<CalendarDate> createTransactionSelectorFromDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingPaymentSelectorFromDate_QNAME, CalendarDate.class, TransactionSelector.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "toDate", scope = TransactionSelector.class)
    public JAXBElement<CalendarDate> createTransactionSelectorToDate(CalendarDate value) {
        return new JAXBElement<CalendarDate>(_BillingPaymentSelectorToDate_QNAME, CalendarDate.class, TransactionSelector.class, value);
    }

}
