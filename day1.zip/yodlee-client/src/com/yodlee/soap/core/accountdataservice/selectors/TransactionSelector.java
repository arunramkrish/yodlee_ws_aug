
package com.yodlee.soap.core.accountdataservice.selectors;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.CalendarDate;


/**
 * <p>Java class for TransactionSelector complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransactionSelector">
 *   &lt;complexContent>
 *     &lt;extension base="{http://selectors.accountdataservice.core.soap.yodlee.com}AccountDataSelector">
 *       &lt;sequence>
 *         &lt;element name="fromDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="toDate" type="{http://common.soap.yodlee.com}CalendarDate" minOccurs="0"/>
 *         &lt;element name="numberOfDaysOfHistory" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="onlyUnbilledHistoryIncluded" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionSelector", propOrder = {
    "fromDate",
    "toDate",
    "numberOfDaysOfHistory",
    "onlyUnbilledHistoryIncluded"
})
public class TransactionSelector
    extends AccountDataSelector
{

    @XmlElementRef(name = "fromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> fromDate;
    @XmlElementRef(name = "toDate", type = JAXBElement.class, required = false)
    protected JAXBElement<CalendarDate> toDate;
    protected Integer numberOfDaysOfHistory;
    protected boolean onlyUnbilledHistoryIncluded;

    /**
     * Gets the value of the fromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getFromDate() {
        return fromDate;
    }

    /**
     * Sets the value of the fromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setFromDate(JAXBElement<CalendarDate> value) {
        this.fromDate = value;
    }

    /**
     * Gets the value of the toDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public JAXBElement<CalendarDate> getToDate() {
        return toDate;
    }

    /**
     * Sets the value of the toDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CalendarDate }{@code >}
     *     
     */
    public void setToDate(JAXBElement<CalendarDate> value) {
        this.toDate = value;
    }

    /**
     * Gets the value of the numberOfDaysOfHistory property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfDaysOfHistory() {
        return numberOfDaysOfHistory;
    }

    /**
     * Sets the value of the numberOfDaysOfHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfDaysOfHistory(Integer value) {
        this.numberOfDaysOfHistory = value;
    }

    /**
     * Gets the value of the onlyUnbilledHistoryIncluded property.
     * 
     */
    public boolean isOnlyUnbilledHistoryIncluded() {
        return onlyUnbilledHistoryIncluded;
    }

    /**
     * Sets the value of the onlyUnbilledHistoryIncluded property.
     * 
     */
    public void setOnlyUnbilledHistoryIncluded(boolean value) {
        this.onlyUnbilledHistoryIncluded = value;
    }

}
