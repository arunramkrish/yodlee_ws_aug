@javax.xml.bind.annotation.XmlSchema(namespace = "http://selectors.accountdataservice.core.soap.yodlee.com")
package com.yodlee.soap.core.accountdataservice.selectors;
