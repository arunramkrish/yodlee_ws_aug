
package com.yodlee.soap.core.dataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;


/**
 * <p>Java class for DataExtension complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DataExtension">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="values" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="hasExtensialDependancy" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DataExtension", propOrder = {
    "key",
    "values",
    "hasExtensialDependancy"
})
public class DataExtension {

    @XmlElementRef(name = "key", type = JAXBElement.class, required = false)
    protected JAXBElement<String> key;
    @XmlElementRef(name = "values", type = JAXBElement.class, required = false)
    protected JAXBElement<List> values;
    protected boolean hasExtensialDependancy;

    /**
     * Gets the value of the key property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getKey() {
        return key;
    }

    /**
     * Sets the value of the key property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setKey(JAXBElement<String> value) {
        this.key = value;
    }

    /**
     * Gets the value of the values property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getValues() {
        return values;
    }

    /**
     * Sets the value of the values property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setValues(JAXBElement<List> value) {
        this.values = value;
    }

    /**
     * Gets the value of the hasExtensialDependancy property.
     * 
     */
    public boolean isHasExtensialDependancy() {
        return hasExtensialDependancy;
    }

    /**
     * Sets the value of the hasExtensialDependancy property.
     * 
     */
    public void setHasExtensialDependancy(boolean value) {
        this.hasExtensialDependancy = value;
    }

}
