
package com.yodlee.soap.core.dataservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.List;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.dataservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _YDateTimezone_QNAME = new QName("", "timezone");
    private final static QName _YDateDisplayTimezone_QNAME = new QName("", "displayTimezone");
    private final static QName _YDateLocalFormat_QNAME = new QName("", "localFormat");
    private final static QName _YDateDate_QNAME = new QName("", "date");
    private final static QName _DataExtensionValues_QNAME = new QName("", "values");
    private final static QName _DataExtensionKey_QNAME = new QName("", "key");
    private final static QName _YMoneyAmount_QNAME = new QName("", "amount");
    private final static QName _YMoneyCurrencyCode_QNAME = new QName("", "currencyCode");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.dataservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link YMoney }
     * 
     */
    public YMoney createYMoney() {
        return new YMoney();
    }

    /**
     * Create an instance of {@link DataExtension }
     * 
     */
    public DataExtension createDataExtension() {
        return new DataExtension();
    }

    /**
     * Create an instance of {@link YDate }
     * 
     */
    public YDate createYDate() {
        return new YDate();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "timezone", scope = YDate.class)
    public JAXBElement<String> createYDateTimezone(String value) {
        return new JAXBElement<String>(_YDateTimezone_QNAME, String.class, YDate.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "displayTimezone", scope = YDate.class)
    public JAXBElement<String> createYDateDisplayTimezone(String value) {
        return new JAXBElement<String>(_YDateDisplayTimezone_QNAME, String.class, YDate.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "localFormat", scope = YDate.class)
    public JAXBElement<String> createYDateLocalFormat(String value) {
        return new JAXBElement<String>(_YDateLocalFormat_QNAME, String.class, YDate.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date", scope = YDate.class)
    public JAXBElement<XMLGregorianCalendar> createYDateDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_YDateDate_QNAME, XMLGregorianCalendar.class, YDate.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "values", scope = DataExtension.class)
    public JAXBElement<List> createDataExtensionValues(List value) {
        return new JAXBElement<List>(_DataExtensionValues_QNAME, List.class, DataExtension.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "key", scope = DataExtension.class)
    public JAXBElement<String> createDataExtensionKey(String value) {
        return new JAXBElement<String>(_DataExtensionKey_QNAME, String.class, DataExtension.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = YMoney.class)
    public JAXBElement<Double> createYMoneyAmount(Double value) {
        return new JAXBElement<Double>(_YMoneyAmount_QNAME, Double.class, YMoney.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currencyCode", scope = YMoney.class)
    public JAXBElement<String> createYMoneyCurrencyCode(String value) {
        return new JAXBElement<String>(_YMoneyCurrencyCode_QNAME, String.class, YMoney.class, value);
    }

}
