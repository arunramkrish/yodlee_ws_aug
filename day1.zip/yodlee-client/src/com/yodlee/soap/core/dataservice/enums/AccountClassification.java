
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountClassification.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccountClassification">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="PERSONAL"/>
 *     &lt;enumeration value="CORPORATE"/>
 *     &lt;enumeration value="SMALL_BUSINESS"/>
 *     &lt;enumeration value="TRUST"/>
 *     &lt;enumeration value="ADD_ON_CARD"/>
 *     &lt;enumeration value="VIRTUAL_CARD"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AccountClassification", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum AccountClassification {

    OTHER,
    PERSONAL,
    CORPORATE,
    SMALL_BUSINESS,
    TRUST,
    ADD_ON_CARD,
    VIRTUAL_CARD;

    public String value() {
        return name();
    }

    public static AccountClassification fromValue(String v) {
        return valueOf(v);
    }

}
