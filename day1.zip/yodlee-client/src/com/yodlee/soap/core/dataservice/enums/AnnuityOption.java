
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AnnuityOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AnnuityOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="IMMEDIATE"/>
 *     &lt;enumeration value="DEFERRED"/>
 *     &lt;enumeration value="OTHER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AnnuityOption", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum AnnuityOption {

    IMMEDIATE,
    DEFERRED,
    OTHER;

    public String value() {
        return name();
    }

    public static AnnuityOption fromValue(String v) {
        return valueOf(v);
    }

}
