
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BenefitFrequency.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="BenefitFrequency">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="WEEKLY"/>
 *     &lt;enumeration value="BIWEEKLY"/>
 *     &lt;enumeration value="MONTHLY"/>
 *     &lt;enumeration value="QUARTERLY"/>
 *     &lt;enumeration value="BIMONTHLY"/>
 *     &lt;enumeration value="SEMIANNUAL"/>
 *     &lt;enumeration value="ANNUAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "BenefitFrequency", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum BenefitFrequency {

    UNKNOWN,
    OTHER,
    WEEKLY,
    BIWEEKLY,
    MONTHLY,
    QUARTERLY,
    BIMONTHLY,
    SEMIANNUAL,
    ANNUAL;

    public String value() {
        return name();
    }

    public static BenefitFrequency fromValue(String v) {
        return valueOf(v);
    }

}
