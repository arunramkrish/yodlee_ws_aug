
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Exchange.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Exchange">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NSE"/>
 *     &lt;enumeration value="LSE"/>
 *     &lt;enumeration value="VNE"/>
 *     &lt;enumeration value="TOE"/>
 *     &lt;enumeration value="ASX"/>
 *     &lt;enumeration value="BSE"/>
 *     &lt;enumeration value="BME"/>
 *     &lt;enumeration value="JSE"/>
 *     &lt;enumeration value="NASDAQ"/>
 *     &lt;enumeration value="CNSX"/>
 *     &lt;enumeration value="NYSE"/>
 *     &lt;enumeration value="NZX"/>
 *     &lt;enumeration value="ENP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "Exchange", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum Exchange {

    NSE,
    LSE,
    VNE,
    TOE,
    ASX,
    BSE,
    BME,
    JSE,
    NASDAQ,
    CNSX,
    NYSE,
    NZX,
    ENP;

    public String value() {
        return name();
    }

    public static Exchange fromValue(String v) {
        return valueOf(v);
    }

}
