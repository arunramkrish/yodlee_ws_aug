
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HoldingType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="HoldingType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="STOCK"/>
 *     &lt;enumeration value="MUTUALFUND"/>
 *     &lt;enumeration value="BOND"/>
 *     &lt;enumeration value="CD"/>
 *     &lt;enumeration value="OPTION"/>
 *     &lt;enumeration value="MONEYMARKETFUND"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="REMIC"/>
 *     &lt;enumeration value="FUTURE"/>
 *     &lt;enumeration value="COMMODITY"/>
 *     &lt;enumeration value="CURRENCY"/>
 *     &lt;enumeration value="UNITINVESTMENTTRUST"/>
 *     &lt;enumeration value="EMPLOYEESTOCKOPTION"/>
 *     &lt;enumeration value="INSURANCEANNUITY"/>
 *     &lt;enumeration value="PREFERREDSTOCK"/>
 *     &lt;enumeration value="ETF"/>
 *     &lt;enumeration value="WARRANTS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "HoldingType", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum HoldingType {

    UNKNOWN,
    STOCK,
    MUTUALFUND,
    BOND,
    CD,
    OPTION,
    MONEYMARKETFUND,
    OTHER,
    REMIC,
    FUTURE,
    COMMODITY,
    CURRENCY,
    UNITINVESTMENTTRUST,
    EMPLOYEESTOCKOPTION,
    INSURANCEANNUITY,
    PREFERREDSTOCK,
    ETF,
    WARRANTS;

    public String value() {
        return name();
    }

    public static HoldingType fromValue(String v) {
        return valueOf(v);
    }

}
