
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PlanOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PlanOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="DIVIDENDREINVESTMENT"/>
 *     &lt;enumeration value="DIVIDENDPAYOUT"/>
 *     &lt;enumeration value="GROWTH"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PlanOption", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum PlanOption {

    DIVIDENDREINVESTMENT,
    DIVIDENDPAYOUT,
    GROWTH;

    public String value() {
        return name();
    }

    public static PlanOption fromValue(String v) {
        return valueOf(v);
    }

}
