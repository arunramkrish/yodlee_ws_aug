
package com.yodlee.soap.core.dataservice.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SiteAccountStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SiteAccountStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ACTIVE"/>
 *     &lt;enumeration value="INACTIVE"/>
 *     &lt;enumeration value="SUSPENDED"/>
 *     &lt;enumeration value="BLOCKED"/>
 *     &lt;enumeration value="DELETED"/>
 *     &lt;enumeration value="CLOSED"/>
 *     &lt;enumeration value="DORMANT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SiteAccountStatus", namespace = "http://enums.dataservice.core.soap.yodlee.com")
@XmlEnum
public enum SiteAccountStatus {

    ACTIVE,
    INACTIVE,
    SUSPENDED,
    BLOCKED,
    DELETED,
    CLOSED,
    DORMANT;

    public String value() {
        return name();
    }

    public static SiteAccountStatus fromValue(String v) {
        return valueOf(v);
    }

}
