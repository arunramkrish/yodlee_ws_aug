@javax.xml.bind.annotation.XmlSchema(namespace = "http://dataservice.core.soap.yodlee.com")
package com.yodlee.soap.core.dataservice;
