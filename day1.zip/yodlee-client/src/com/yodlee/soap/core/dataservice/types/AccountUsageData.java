
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for AccountUsageData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountUsageData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountUsageId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billingAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="unitRate" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="usageTimePeriodId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="usageTimePeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUsageTimePeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitsIncluded" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="acctUsageUnitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctUsageUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctUsageUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="usageTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="usageType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUsageType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitsUsed" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="unitString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitsRemaining" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="chargesIncurred" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="usageDirectionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="usageDirection" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUsageDirection" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="usageFor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unitsOverLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountUsageData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "accountUsageId",
    "billId",
    "billingAccountId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "unitRate",
    "usageTimePeriodId",
    "usageTimePeriod",
    "localizedUsageTimePeriod",
    "unitsIncluded",
    "acctUsageUnitId",
    "acctUsageUnit",
    "localizedAcctUsageUnit",
    "link",
    "usageTypeId",
    "usageType",
    "localizedUsageType",
    "unitsUsed",
    "unitString",
    "unitsRemaining",
    "description",
    "chargesIncurred",
    "usageDirectionId",
    "usageDirection",
    "localizedUsageDirection",
    "usageFor",
    "unitsOverLimit"
})
public class AccountUsageData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "accountUsageId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> accountUsageId;
    @XmlElementRef(name = "billId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billId;
    @XmlElementRef(name = "billingAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billingAccountId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "unitRate", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unitRate;
    @XmlElementRef(name = "usageTimePeriodId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> usageTimePeriodId;
    @XmlElementRef(name = "usageTimePeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<String> usageTimePeriod;
    @XmlElementRef(name = "localizedUsageTimePeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUsageTimePeriod;
    @XmlElementRef(name = "unitsIncluded", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> unitsIncluded;
    @XmlElementRef(name = "acctUsageUnitId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctUsageUnitId;
    @XmlElementRef(name = "acctUsageUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctUsageUnit;
    @XmlElementRef(name = "localizedAcctUsageUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctUsageUnit;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "usageTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> usageTypeId;
    @XmlElementRef(name = "usageType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> usageType;
    @XmlElementRef(name = "localizedUsageType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUsageType;
    @XmlElementRef(name = "unitsUsed", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> unitsUsed;
    @XmlElementRef(name = "unitString", type = JAXBElement.class, required = false)
    protected JAXBElement<String> unitString;
    @XmlElementRef(name = "unitsRemaining", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> unitsRemaining;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "chargesIncurred", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> chargesIncurred;
    @XmlElementRef(name = "usageDirectionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> usageDirectionId;
    @XmlElementRef(name = "usageDirection", type = JAXBElement.class, required = false)
    protected JAXBElement<String> usageDirection;
    @XmlElementRef(name = "localizedUsageDirection", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUsageDirection;
    @XmlElementRef(name = "usageFor", type = JAXBElement.class, required = false)
    protected JAXBElement<String> usageFor;
    @XmlElementRef(name = "unitsOverLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> unitsOverLimit;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the accountUsageId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAccountUsageId() {
        return accountUsageId;
    }

    /**
     * Sets the value of the accountUsageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAccountUsageId(JAXBElement<Long> value) {
        this.accountUsageId = value;
    }

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillId(JAXBElement<Long> value) {
        this.billId = value;
    }

    /**
     * Gets the value of the billingAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillingAccountId() {
        return billingAccountId;
    }

    /**
     * Sets the value of the billingAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillingAccountId(JAXBElement<Long> value) {
        this.billingAccountId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the unitRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnitRate() {
        return unitRate;
    }

    /**
     * Sets the value of the unitRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnitRate(JAXBElement<YMoney> value) {
        this.unitRate = value;
    }

    /**
     * Gets the value of the usageTimePeriodId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUsageTimePeriodId() {
        return usageTimePeriodId;
    }

    /**
     * Sets the value of the usageTimePeriodId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUsageTimePeriodId(JAXBElement<Long> value) {
        this.usageTimePeriodId = value;
    }

    /**
     * Gets the value of the usageTimePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUsageTimePeriod() {
        return usageTimePeriod;
    }

    /**
     * Sets the value of the usageTimePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUsageTimePeriod(JAXBElement<String> value) {
        this.usageTimePeriod = value;
    }

    /**
     * Gets the value of the localizedUsageTimePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUsageTimePeriod() {
        return localizedUsageTimePeriod;
    }

    /**
     * Sets the value of the localizedUsageTimePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUsageTimePeriod(JAXBElement<String> value) {
        this.localizedUsageTimePeriod = value;
    }

    /**
     * Gets the value of the unitsIncluded property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getUnitsIncluded() {
        return unitsIncluded;
    }

    /**
     * Sets the value of the unitsIncluded property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setUnitsIncluded(JAXBElement<Double> value) {
        this.unitsIncluded = value;
    }

    /**
     * Gets the value of the acctUsageUnitId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctUsageUnitId() {
        return acctUsageUnitId;
    }

    /**
     * Sets the value of the acctUsageUnitId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctUsageUnitId(JAXBElement<Long> value) {
        this.acctUsageUnitId = value;
    }

    /**
     * Gets the value of the acctUsageUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctUsageUnit() {
        return acctUsageUnit;
    }

    /**
     * Sets the value of the acctUsageUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctUsageUnit(JAXBElement<String> value) {
        this.acctUsageUnit = value;
    }

    /**
     * Gets the value of the localizedAcctUsageUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctUsageUnit() {
        return localizedAcctUsageUnit;
    }

    /**
     * Sets the value of the localizedAcctUsageUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctUsageUnit(JAXBElement<String> value) {
        this.localizedAcctUsageUnit = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the usageTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUsageTypeId() {
        return usageTypeId;
    }

    /**
     * Sets the value of the usageTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUsageTypeId(JAXBElement<Long> value) {
        this.usageTypeId = value;
    }

    /**
     * Gets the value of the usageType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUsageType() {
        return usageType;
    }

    /**
     * Sets the value of the usageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUsageType(JAXBElement<String> value) {
        this.usageType = value;
    }

    /**
     * Gets the value of the localizedUsageType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUsageType() {
        return localizedUsageType;
    }

    /**
     * Sets the value of the localizedUsageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUsageType(JAXBElement<String> value) {
        this.localizedUsageType = value;
    }

    /**
     * Gets the value of the unitsUsed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getUnitsUsed() {
        return unitsUsed;
    }

    /**
     * Sets the value of the unitsUsed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setUnitsUsed(JAXBElement<Double> value) {
        this.unitsUsed = value;
    }

    /**
     * Gets the value of the unitString property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUnitString() {
        return unitString;
    }

    /**
     * Sets the value of the unitString property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUnitString(JAXBElement<String> value) {
        this.unitString = value;
    }

    /**
     * Gets the value of the unitsRemaining property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getUnitsRemaining() {
        return unitsRemaining;
    }

    /**
     * Sets the value of the unitsRemaining property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setUnitsRemaining(JAXBElement<Double> value) {
        this.unitsRemaining = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the chargesIncurred property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getChargesIncurred() {
        return chargesIncurred;
    }

    /**
     * Sets the value of the chargesIncurred property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setChargesIncurred(JAXBElement<YMoney> value) {
        this.chargesIncurred = value;
    }

    /**
     * Gets the value of the usageDirectionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUsageDirectionId() {
        return usageDirectionId;
    }

    /**
     * Sets the value of the usageDirectionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUsageDirectionId(JAXBElement<Long> value) {
        this.usageDirectionId = value;
    }

    /**
     * Gets the value of the usageDirection property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUsageDirection() {
        return usageDirection;
    }

    /**
     * Sets the value of the usageDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUsageDirection(JAXBElement<String> value) {
        this.usageDirection = value;
    }

    /**
     * Gets the value of the localizedUsageDirection property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUsageDirection() {
        return localizedUsageDirection;
    }

    /**
     * Sets the value of the localizedUsageDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUsageDirection(JAXBElement<String> value) {
        this.localizedUsageDirection = value;
    }

    /**
     * Gets the value of the usageFor property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUsageFor() {
        return usageFor;
    }

    /**
     * Sets the value of the usageFor property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUsageFor(JAXBElement<String> value) {
        this.usageFor = value;
    }

    /**
     * Gets the value of the unitsOverLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getUnitsOverLimit() {
        return unitsOverLimit;
    }

    /**
     * Sets the value of the unitsOverLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setUnitsOverLimit(JAXBElement<Double> value) {
        this.unitsOverLimit = value;
    }

}
