
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for AuctionData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuctionData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="aucSellerId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aucShippingId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aucPmtMethodsAcceptedId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="auctionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aucLoginAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="totalQuantityBeingSold" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="auctionTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isOpen" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="escrowProvider" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reservePrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="auctionNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalNumBids" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="buyItNowPrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="hasProxyAmt" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemLocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="auctionTimeRemaining" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="auctionStartPrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="auctionStartDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="auctionEndDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="itemDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPrivateAuction" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="quantityLeftOver" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="incrementByAmt" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isEscrow" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isWinning" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasBuyItNowPrice" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasReservePrice" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="proxyAmt" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="aucUserRoleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aucUserRole" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAucUserRole" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDutchAuction" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isReservePriceMet" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bids" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="seller" type="{http://types.dataservice.core.soap.yodlee.com}AucSellerData" minOccurs="0"/>
 *         &lt;element name="shippingInformation" type="{http://types.dataservice.core.soap.yodlee.com}ShippingData" minOccurs="0"/>
 *         &lt;element name="paymentMethodsAccepted" type="{http://types.dataservice.core.soap.yodlee.com}PaymentMethodsAcceptedData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuctionData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "aucSellerId",
    "aucShippingId",
    "aucPmtMethodsAcceptedId",
    "auctionId",
    "aucLoginAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "totalQuantityBeingSold",
    "auctionTitle",
    "isOpen",
    "escrowProvider",
    "reservePrice",
    "auctionNumber",
    "totalNumBids",
    "buyItNowPrice",
    "hasProxyAmt",
    "itemLocation",
    "auctionTimeRemaining",
    "auctionStartPrice",
    "auctionStartDate",
    "auctionEndDate",
    "itemDescription",
    "isPrivateAuction",
    "quantityLeftOver",
    "incrementByAmt",
    "link",
    "isEscrow",
    "isWinning",
    "hasBuyItNowPrice",
    "hasReservePrice",
    "proxyAmt",
    "aucUserRoleId",
    "aucUserRole",
    "localizedAucUserRole",
    "isDutchAuction",
    "isReservePriceMet",
    "bids",
    "seller",
    "shippingInformation",
    "paymentMethodsAccepted"
})
public class AuctionData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "aucSellerId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucSellerId;
    @XmlElementRef(name = "aucShippingId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucShippingId;
    @XmlElementRef(name = "aucPmtMethodsAcceptedId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucPmtMethodsAcceptedId;
    @XmlElementRef(name = "auctionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> auctionId;
    @XmlElementRef(name = "aucLoginAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucLoginAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "totalQuantityBeingSold", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> totalQuantityBeingSold;
    @XmlElementRef(name = "auctionTitle", type = JAXBElement.class, required = false)
    protected JAXBElement<String> auctionTitle;
    @XmlElementRef(name = "isOpen", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isOpen;
    @XmlElementRef(name = "escrowProvider", type = JAXBElement.class, required = false)
    protected JAXBElement<String> escrowProvider;
    @XmlElementRef(name = "reservePrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> reservePrice;
    @XmlElementRef(name = "auctionNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> auctionNumber;
    @XmlElementRef(name = "totalNumBids", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> totalNumBids;
    @XmlElementRef(name = "buyItNowPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> buyItNowPrice;
    @XmlElementRef(name = "hasProxyAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasProxyAmt;
    @XmlElementRef(name = "itemLocation", type = JAXBElement.class, required = false)
    protected JAXBElement<String> itemLocation;
    @XmlElementRef(name = "auctionTimeRemaining", type = JAXBElement.class, required = false)
    protected JAXBElement<String> auctionTimeRemaining;
    @XmlElementRef(name = "auctionStartPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> auctionStartPrice;
    @XmlElementRef(name = "auctionStartDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> auctionStartDate;
    @XmlElementRef(name = "auctionEndDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> auctionEndDate;
    @XmlElementRef(name = "itemDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> itemDescription;
    @XmlElementRef(name = "isPrivateAuction", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPrivateAuction;
    @XmlElementRef(name = "quantityLeftOver", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> quantityLeftOver;
    @XmlElementRef(name = "incrementByAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> incrementByAmt;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "isEscrow", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isEscrow;
    @XmlElementRef(name = "isWinning", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isWinning;
    @XmlElementRef(name = "hasBuyItNowPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasBuyItNowPrice;
    @XmlElementRef(name = "hasReservePrice", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasReservePrice;
    @XmlElementRef(name = "proxyAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> proxyAmt;
    @XmlElementRef(name = "aucUserRoleId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucUserRoleId;
    @XmlElementRef(name = "aucUserRole", type = JAXBElement.class, required = false)
    protected JAXBElement<String> aucUserRole;
    @XmlElementRef(name = "localizedAucUserRole", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAucUserRole;
    @XmlElementRef(name = "isDutchAuction", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDutchAuction;
    @XmlElementRef(name = "isReservePriceMet", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isReservePriceMet;
    @XmlElementRef(name = "bids", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bids;
    @XmlElementRef(name = "seller", type = JAXBElement.class, required = false)
    protected JAXBElement<AucSellerData> seller;
    @XmlElementRef(name = "shippingInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<ShippingData> shippingInformation;
    @XmlElementRef(name = "paymentMethodsAccepted", type = JAXBElement.class, required = false)
    protected JAXBElement<PaymentMethodsAcceptedData> paymentMethodsAccepted;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the aucSellerId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucSellerId() {
        return aucSellerId;
    }

    /**
     * Sets the value of the aucSellerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucSellerId(JAXBElement<Long> value) {
        this.aucSellerId = value;
    }

    /**
     * Gets the value of the aucShippingId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucShippingId() {
        return aucShippingId;
    }

    /**
     * Sets the value of the aucShippingId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucShippingId(JAXBElement<Long> value) {
        this.aucShippingId = value;
    }

    /**
     * Gets the value of the aucPmtMethodsAcceptedId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucPmtMethodsAcceptedId() {
        return aucPmtMethodsAcceptedId;
    }

    /**
     * Sets the value of the aucPmtMethodsAcceptedId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucPmtMethodsAcceptedId(JAXBElement<Long> value) {
        this.aucPmtMethodsAcceptedId = value;
    }

    /**
     * Gets the value of the auctionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAuctionId() {
        return auctionId;
    }

    /**
     * Sets the value of the auctionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAuctionId(JAXBElement<Long> value) {
        this.auctionId = value;
    }

    /**
     * Gets the value of the aucLoginAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucLoginAccountId() {
        return aucLoginAccountId;
    }

    /**
     * Sets the value of the aucLoginAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucLoginAccountId(JAXBElement<Long> value) {
        this.aucLoginAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the totalQuantityBeingSold property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTotalQuantityBeingSold() {
        return totalQuantityBeingSold;
    }

    /**
     * Sets the value of the totalQuantityBeingSold property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTotalQuantityBeingSold(JAXBElement<Long> value) {
        this.totalQuantityBeingSold = value;
    }

    /**
     * Gets the value of the auctionTitle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAuctionTitle() {
        return auctionTitle;
    }

    /**
     * Sets the value of the auctionTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAuctionTitle(JAXBElement<String> value) {
        this.auctionTitle = value;
    }

    /**
     * Gets the value of the isOpen property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsOpen() {
        return isOpen;
    }

    /**
     * Sets the value of the isOpen property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsOpen(JAXBElement<Long> value) {
        this.isOpen = value;
    }

    /**
     * Gets the value of the escrowProvider property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEscrowProvider() {
        return escrowProvider;
    }

    /**
     * Sets the value of the escrowProvider property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEscrowProvider(JAXBElement<String> value) {
        this.escrowProvider = value;
    }

    /**
     * Gets the value of the reservePrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getReservePrice() {
        return reservePrice;
    }

    /**
     * Sets the value of the reservePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setReservePrice(JAXBElement<YMoney> value) {
        this.reservePrice = value;
    }

    /**
     * Gets the value of the auctionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAuctionNumber() {
        return auctionNumber;
    }

    /**
     * Sets the value of the auctionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAuctionNumber(JAXBElement<String> value) {
        this.auctionNumber = value;
    }

    /**
     * Gets the value of the totalNumBids property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTotalNumBids() {
        return totalNumBids;
    }

    /**
     * Sets the value of the totalNumBids property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTotalNumBids(JAXBElement<Long> value) {
        this.totalNumBids = value;
    }

    /**
     * Gets the value of the buyItNowPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBuyItNowPrice() {
        return buyItNowPrice;
    }

    /**
     * Sets the value of the buyItNowPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBuyItNowPrice(JAXBElement<YMoney> value) {
        this.buyItNowPrice = value;
    }

    /**
     * Gets the value of the hasProxyAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasProxyAmt() {
        return hasProxyAmt;
    }

    /**
     * Sets the value of the hasProxyAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasProxyAmt(JAXBElement<Long> value) {
        this.hasProxyAmt = value;
    }

    /**
     * Gets the value of the itemLocation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getItemLocation() {
        return itemLocation;
    }

    /**
     * Sets the value of the itemLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setItemLocation(JAXBElement<String> value) {
        this.itemLocation = value;
    }

    /**
     * Gets the value of the auctionTimeRemaining property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAuctionTimeRemaining() {
        return auctionTimeRemaining;
    }

    /**
     * Sets the value of the auctionTimeRemaining property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAuctionTimeRemaining(JAXBElement<String> value) {
        this.auctionTimeRemaining = value;
    }

    /**
     * Gets the value of the auctionStartPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAuctionStartPrice() {
        return auctionStartPrice;
    }

    /**
     * Sets the value of the auctionStartPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAuctionStartPrice(JAXBElement<YMoney> value) {
        this.auctionStartPrice = value;
    }

    /**
     * Gets the value of the auctionStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAuctionStartDate() {
        return auctionStartDate;
    }

    /**
     * Sets the value of the auctionStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAuctionStartDate(JAXBElement<YDate> value) {
        this.auctionStartDate = value;
    }

    /**
     * Gets the value of the auctionEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAuctionEndDate() {
        return auctionEndDate;
    }

    /**
     * Sets the value of the auctionEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAuctionEndDate(JAXBElement<YDate> value) {
        this.auctionEndDate = value;
    }

    /**
     * Gets the value of the itemDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the value of the itemDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setItemDescription(JAXBElement<String> value) {
        this.itemDescription = value;
    }

    /**
     * Gets the value of the isPrivateAuction property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPrivateAuction() {
        return isPrivateAuction;
    }

    /**
     * Sets the value of the isPrivateAuction property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPrivateAuction(JAXBElement<Long> value) {
        this.isPrivateAuction = value;
    }

    /**
     * Gets the value of the quantityLeftOver property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getQuantityLeftOver() {
        return quantityLeftOver;
    }

    /**
     * Sets the value of the quantityLeftOver property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setQuantityLeftOver(JAXBElement<Long> value) {
        this.quantityLeftOver = value;
    }

    /**
     * Gets the value of the incrementByAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getIncrementByAmt() {
        return incrementByAmt;
    }

    /**
     * Sets the value of the incrementByAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setIncrementByAmt(JAXBElement<YMoney> value) {
        this.incrementByAmt = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the isEscrow property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsEscrow() {
        return isEscrow;
    }

    /**
     * Sets the value of the isEscrow property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsEscrow(JAXBElement<Long> value) {
        this.isEscrow = value;
    }

    /**
     * Gets the value of the isWinning property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsWinning() {
        return isWinning;
    }

    /**
     * Sets the value of the isWinning property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsWinning(JAXBElement<Long> value) {
        this.isWinning = value;
    }

    /**
     * Gets the value of the hasBuyItNowPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasBuyItNowPrice() {
        return hasBuyItNowPrice;
    }

    /**
     * Sets the value of the hasBuyItNowPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasBuyItNowPrice(JAXBElement<Long> value) {
        this.hasBuyItNowPrice = value;
    }

    /**
     * Gets the value of the hasReservePrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasReservePrice() {
        return hasReservePrice;
    }

    /**
     * Sets the value of the hasReservePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasReservePrice(JAXBElement<Long> value) {
        this.hasReservePrice = value;
    }

    /**
     * Gets the value of the proxyAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getProxyAmt() {
        return proxyAmt;
    }

    /**
     * Sets the value of the proxyAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setProxyAmt(JAXBElement<YMoney> value) {
        this.proxyAmt = value;
    }

    /**
     * Gets the value of the aucUserRoleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucUserRoleId() {
        return aucUserRoleId;
    }

    /**
     * Sets the value of the aucUserRoleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucUserRoleId(JAXBElement<Long> value) {
        this.aucUserRoleId = value;
    }

    /**
     * Gets the value of the aucUserRole property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAucUserRole() {
        return aucUserRole;
    }

    /**
     * Sets the value of the aucUserRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAucUserRole(JAXBElement<String> value) {
        this.aucUserRole = value;
    }

    /**
     * Gets the value of the localizedAucUserRole property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAucUserRole() {
        return localizedAucUserRole;
    }

    /**
     * Sets the value of the localizedAucUserRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAucUserRole(JAXBElement<String> value) {
        this.localizedAucUserRole = value;
    }

    /**
     * Gets the value of the isDutchAuction property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDutchAuction() {
        return isDutchAuction;
    }

    /**
     * Sets the value of the isDutchAuction property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDutchAuction(JAXBElement<Long> value) {
        this.isDutchAuction = value;
    }

    /**
     * Gets the value of the isReservePriceMet property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsReservePriceMet() {
        return isReservePriceMet;
    }

    /**
     * Sets the value of the isReservePriceMet property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsReservePriceMet(JAXBElement<Long> value) {
        this.isReservePriceMet = value;
    }

    /**
     * Gets the value of the bids property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBids() {
        return bids;
    }

    /**
     * Sets the value of the bids property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBids(JAXBElement<List> value) {
        this.bids = value;
    }

    /**
     * Gets the value of the seller property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AucSellerData }{@code >}
     *     
     */
    public JAXBElement<AucSellerData> getSeller() {
        return seller;
    }

    /**
     * Sets the value of the seller property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AucSellerData }{@code >}
     *     
     */
    public void setSeller(JAXBElement<AucSellerData> value) {
        this.seller = value;
    }

    /**
     * Gets the value of the shippingInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ShippingData }{@code >}
     *     
     */
    public JAXBElement<ShippingData> getShippingInformation() {
        return shippingInformation;
    }

    /**
     * Sets the value of the shippingInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ShippingData }{@code >}
     *     
     */
    public void setShippingInformation(JAXBElement<ShippingData> value) {
        this.shippingInformation = value;
    }

    /**
     * Gets the value of the paymentMethodsAccepted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PaymentMethodsAcceptedData }{@code >}
     *     
     */
    public JAXBElement<PaymentMethodsAcceptedData> getPaymentMethodsAccepted() {
        return paymentMethodsAccepted;
    }

    /**
     * Sets the value of the paymentMethodsAccepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PaymentMethodsAcceptedData }{@code >}
     *     
     */
    public void setPaymentMethodsAccepted(JAXBElement<PaymentMethodsAcceptedData> value) {
        this.paymentMethodsAccepted = value;
    }

}
