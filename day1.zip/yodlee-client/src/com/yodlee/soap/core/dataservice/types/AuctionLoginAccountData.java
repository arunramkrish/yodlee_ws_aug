
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;


/**
 * <p>Java class for AuctionLoginAccountData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuctionLoginAccountData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="personInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aucLoginAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="auctionLaHolderRating" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="auctions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="personInformation" type="{http://types.dataservice.core.soap.yodlee.com}PersonData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuctionLoginAccountData", propOrder = {
    "personInformationId",
    "aucLoginAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "auctionLaHolderRating",
    "auctions",
    "personInformation"
})
public class AuctionLoginAccountData
    extends BaseTagData
{

    @XmlElementRef(name = "personInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> personInformationId;
    @XmlElementRef(name = "aucLoginAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> aucLoginAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "auctionLaHolderRating", type = JAXBElement.class, required = false)
    protected JAXBElement<String> auctionLaHolderRating;
    @XmlElementRef(name = "auctions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> auctions;
    @XmlElementRef(name = "personInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonData> personInformation;

    /**
     * Gets the value of the personInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPersonInformationId() {
        return personInformationId;
    }

    /**
     * Sets the value of the personInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPersonInformationId(JAXBElement<Long> value) {
        this.personInformationId = value;
    }

    /**
     * Gets the value of the aucLoginAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAucLoginAccountId() {
        return aucLoginAccountId;
    }

    /**
     * Sets the value of the aucLoginAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAucLoginAccountId(JAXBElement<Long> value) {
        this.aucLoginAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the auctionLaHolderRating property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAuctionLaHolderRating() {
        return auctionLaHolderRating;
    }

    /**
     * Sets the value of the auctionLaHolderRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAuctionLaHolderRating(JAXBElement<String> value) {
        this.auctionLaHolderRating = value;
    }

    /**
     * Gets the value of the auctions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getAuctions() {
        return auctions;
    }

    /**
     * Sets the value of the auctions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setAuctions(JAXBElement<List> value) {
        this.auctions = value;
    }

    /**
     * Gets the value of the personInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public JAXBElement<PersonData> getPersonInformation() {
        return personInformation;
    }

    /**
     * Sets the value of the personInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public void setPersonInformation(JAXBElement<PersonData> value) {
        this.personInformation = value;
    }

}
