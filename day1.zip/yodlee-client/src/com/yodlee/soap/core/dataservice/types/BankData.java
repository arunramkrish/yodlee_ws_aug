
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.AccountClassification;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for BankData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="individualInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="interestRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tranListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="tranListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="availableBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="currentBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestEarnedYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="prevYrInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="overdraftProtection" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="term" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="annualPercentYield" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="routingNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="maturityDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="asOfDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="bankTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="bankStatements" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="individualInformation" type="{http://types.dataservice.core.soap.yodlee.com}IndividualInformation" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaperlessStmtOn" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="nomineeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="maturityAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxesWithheldYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxesPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="budgetBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="straightBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accountClassification" type="{http://enums.dataservice.core.soap.yodlee.com}AccountClassification" minOccurs="0"/>
 *         &lt;element name="srcAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unclearedBal" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="minimumBal" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pendingDebits" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pendingCredits" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="installmentAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pendingAuthorizonAmt" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="bankTransferCodeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "acctTypeId",
    "acctType",
    "localizedAcctType",
    "srcElementId",
    "individualInformationId",
    "bankAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "interestRate",
    "accountNumber",
    "link",
    "accountHolder",
    "tranListToDate",
    "tranListFromDate",
    "availableBalance",
    "currentBalance",
    "interestEarnedYtd",
    "prevYrInterest",
    "overdraftProtection",
    "term",
    "accountName",
    "annualPercentYield",
    "routingNumber",
    "maturityDate",
    "asOfDate",
    "bankTransactions",
    "bankStatements",
    "individualInformation",
    "accountNicknameAtSrcSite",
    "isPaperlessStmtOn",
    "siteAccountStatus",
    "created",
    "nomineeName",
    "secondaryAccountHolderName",
    "accountOpenDate",
    "accountCloseDate",
    "maturityAmount",
    "taxesWithheldYtd",
    "taxesPaidYtd",
    "budgetBalance",
    "straightBalance",
    "accountClassification",
    "srcAccountType",
    "unclearedBal",
    "minimumBal",
    "pendingDebits",
    "pendingCredits",
    "installmentAmount",
    "pendingAuthorizonAmt",
    "bankTransferCodeId"
})
public class BankData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "acctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctTypeId;
    @XmlElementRef(name = "acctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctType;
    @XmlElementRef(name = "localizedAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctType;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "individualInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> individualInformationId;
    @XmlElementRef(name = "bankAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bankAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "interestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> interestRate;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "tranListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListToDate;
    @XmlElementRef(name = "tranListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListFromDate;
    @XmlElementRef(name = "availableBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableBalance;
    @XmlElementRef(name = "currentBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> currentBalance;
    @XmlElementRef(name = "interestEarnedYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestEarnedYtd;
    @XmlElementRef(name = "prevYrInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> prevYrInterest;
    @XmlElementRef(name = "overdraftProtection", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> overdraftProtection;
    @XmlElementRef(name = "term", type = JAXBElement.class, required = false)
    protected JAXBElement<String> term;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "annualPercentYield", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> annualPercentYield;
    @XmlElementRef(name = "routingNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> routingNumber;
    @XmlElementRef(name = "maturityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> maturityDate;
    @XmlElementRef(name = "asOfDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asOfDate;
    @XmlElementRef(name = "bankTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bankTransactions;
    @XmlElementRef(name = "bankStatements", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bankStatements;
    @XmlElementRef(name = "individualInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<IndividualInformation> individualInformation;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "isPaperlessStmtOn", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaperlessStmtOn;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "nomineeName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nomineeName;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "maturityAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> maturityAmount;
    @XmlElementRef(name = "taxesWithheldYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxesWithheldYtd;
    @XmlElementRef(name = "taxesPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxesPaidYtd;
    @XmlElementRef(name = "budgetBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> budgetBalance;
    @XmlElementRef(name = "straightBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> straightBalance;
    @XmlElementRef(name = "accountClassification", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountClassification> accountClassification;
    @XmlElementRef(name = "srcAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcAccountType;
    @XmlElementRef(name = "unclearedBal", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unclearedBal;
    @XmlElementRef(name = "minimumBal", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> minimumBal;
    @XmlElementRef(name = "pendingDebits", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pendingDebits;
    @XmlElementRef(name = "pendingCredits", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pendingCredits;
    @XmlElementRef(name = "installmentAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> installmentAmount;
    @XmlElementRef(name = "pendingAuthorizonAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pendingAuthorizonAmt;
    @XmlElementRef(name = "bankTransferCodeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bankTransferCodeId;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the acctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctTypeId() {
        return acctTypeId;
    }

    /**
     * Sets the value of the acctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctTypeId(JAXBElement<Long> value) {
        this.acctTypeId = value;
    }

    /**
     * Gets the value of the acctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctType() {
        return acctType;
    }

    /**
     * Sets the value of the acctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctType(JAXBElement<String> value) {
        this.acctType = value;
    }

    /**
     * Gets the value of the localizedAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctType() {
        return localizedAcctType;
    }

    /**
     * Sets the value of the localizedAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctType(JAXBElement<String> value) {
        this.localizedAcctType = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the individualInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIndividualInformationId() {
        return individualInformationId;
    }

    /**
     * Sets the value of the individualInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIndividualInformationId(JAXBElement<Long> value) {
        this.individualInformationId = value;
    }

    /**
     * Gets the value of the bankAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBankAccountId() {
        return bankAccountId;
    }

    /**
     * Sets the value of the bankAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBankAccountId(JAXBElement<Long> value) {
        this.bankAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setInterestRate(JAXBElement<Double> value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the tranListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListToDate() {
        return tranListToDate;
    }

    /**
     * Sets the value of the tranListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListToDate(JAXBElement<YDate> value) {
        this.tranListToDate = value;
    }

    /**
     * Gets the value of the tranListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListFromDate() {
        return tranListFromDate;
    }

    /**
     * Sets the value of the tranListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListFromDate(JAXBElement<YDate> value) {
        this.tranListFromDate = value;
    }

    /**
     * Gets the value of the availableBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableBalance() {
        return availableBalance;
    }

    /**
     * Sets the value of the availableBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableBalance(JAXBElement<YMoney> value) {
        this.availableBalance = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCurrentBalance(JAXBElement<YMoney> value) {
        this.currentBalance = value;
    }

    /**
     * Gets the value of the interestEarnedYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestEarnedYtd() {
        return interestEarnedYtd;
    }

    /**
     * Sets the value of the interestEarnedYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestEarnedYtd(JAXBElement<YMoney> value) {
        this.interestEarnedYtd = value;
    }

    /**
     * Gets the value of the prevYrInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrevYrInterest() {
        return prevYrInterest;
    }

    /**
     * Sets the value of the prevYrInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrevYrInterest(JAXBElement<YMoney> value) {
        this.prevYrInterest = value;
    }

    /**
     * Gets the value of the overdraftProtection property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOverdraftProtection() {
        return overdraftProtection;
    }

    /**
     * Sets the value of the overdraftProtection property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOverdraftProtection(JAXBElement<YMoney> value) {
        this.overdraftProtection = value;
    }

    /**
     * Gets the value of the term property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTerm() {
        return term;
    }

    /**
     * Sets the value of the term property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTerm(JAXBElement<String> value) {
        this.term = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the annualPercentYield property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAnnualPercentYield() {
        return annualPercentYield;
    }

    /**
     * Sets the value of the annualPercentYield property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAnnualPercentYield(JAXBElement<Double> value) {
        this.annualPercentYield = value;
    }

    /**
     * Gets the value of the routingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRoutingNumber() {
        return routingNumber;
    }

    /**
     * Sets the value of the routingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRoutingNumber(JAXBElement<String> value) {
        this.routingNumber = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setMaturityDate(JAXBElement<YDate> value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the asOfDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsOfDate() {
        return asOfDate;
    }

    /**
     * Sets the value of the asOfDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsOfDate(JAXBElement<YDate> value) {
        this.asOfDate = value;
    }

    /**
     * Gets the value of the bankTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBankTransactions() {
        return bankTransactions;
    }

    /**
     * Sets the value of the bankTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBankTransactions(JAXBElement<List> value) {
        this.bankTransactions = value;
    }

    /**
     * Gets the value of the bankStatements property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBankStatements() {
        return bankStatements;
    }

    /**
     * Sets the value of the bankStatements property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBankStatements(JAXBElement<List> value) {
        this.bankStatements = value;
    }

    /**
     * Gets the value of the individualInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public JAXBElement<IndividualInformation> getIndividualInformation() {
        return individualInformation;
    }

    /**
     * Sets the value of the individualInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public void setIndividualInformation(JAXBElement<IndividualInformation> value) {
        this.individualInformation = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the isPaperlessStmtOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaperlessStmtOn() {
        return isPaperlessStmtOn;
    }

    /**
     * Sets the value of the isPaperlessStmtOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaperlessStmtOn(JAXBElement<Long> value) {
        this.isPaperlessStmtOn = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the nomineeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNomineeName() {
        return nomineeName;
    }

    /**
     * Sets the value of the nomineeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNomineeName(JAXBElement<String> value) {
        this.nomineeName = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the maturityAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMaturityAmount() {
        return maturityAmount;
    }

    /**
     * Sets the value of the maturityAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMaturityAmount(JAXBElement<YMoney> value) {
        this.maturityAmount = value;
    }

    /**
     * Gets the value of the taxesWithheldYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxesWithheldYtd() {
        return taxesWithheldYtd;
    }

    /**
     * Sets the value of the taxesWithheldYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxesWithheldYtd(JAXBElement<YMoney> value) {
        this.taxesWithheldYtd = value;
    }

    /**
     * Gets the value of the taxesPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxesPaidYtd() {
        return taxesPaidYtd;
    }

    /**
     * Sets the value of the taxesPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxesPaidYtd(JAXBElement<YMoney> value) {
        this.taxesPaidYtd = value;
    }

    /**
     * Gets the value of the budgetBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBudgetBalance() {
        return budgetBalance;
    }

    /**
     * Sets the value of the budgetBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBudgetBalance(JAXBElement<YMoney> value) {
        this.budgetBalance = value;
    }

    /**
     * Gets the value of the straightBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStraightBalance() {
        return straightBalance;
    }

    /**
     * Sets the value of the straightBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStraightBalance(JAXBElement<YMoney> value) {
        this.straightBalance = value;
    }

    /**
     * Gets the value of the accountClassification property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public JAXBElement<AccountClassification> getAccountClassification() {
        return accountClassification;
    }

    /**
     * Sets the value of the accountClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public void setAccountClassification(JAXBElement<AccountClassification> value) {
        this.accountClassification = value;
    }

    /**
     * Gets the value of the srcAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcAccountType() {
        return srcAccountType;
    }

    /**
     * Sets the value of the srcAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcAccountType(JAXBElement<String> value) {
        this.srcAccountType = value;
    }

    /**
     * Gets the value of the unclearedBal property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnclearedBal() {
        return unclearedBal;
    }

    /**
     * Sets the value of the unclearedBal property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnclearedBal(JAXBElement<YMoney> value) {
        this.unclearedBal = value;
    }

    /**
     * Gets the value of the minimumBal property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMinimumBal() {
        return minimumBal;
    }

    /**
     * Sets the value of the minimumBal property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMinimumBal(JAXBElement<YMoney> value) {
        this.minimumBal = value;
    }

    /**
     * Gets the value of the pendingDebits property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPendingDebits() {
        return pendingDebits;
    }

    /**
     * Sets the value of the pendingDebits property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPendingDebits(JAXBElement<YMoney> value) {
        this.pendingDebits = value;
    }

    /**
     * Gets the value of the pendingCredits property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPendingCredits() {
        return pendingCredits;
    }

    /**
     * Sets the value of the pendingCredits property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPendingCredits(JAXBElement<YMoney> value) {
        this.pendingCredits = value;
    }

    /**
     * Gets the value of the installmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInstallmentAmount() {
        return installmentAmount;
    }

    /**
     * Sets the value of the installmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInstallmentAmount(JAXBElement<YMoney> value) {
        this.installmentAmount = value;
    }

    /**
     * Gets the value of the pendingAuthorizonAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPendingAuthorizonAmt() {
        return pendingAuthorizonAmt;
    }

    /**
     * Sets the value of the pendingAuthorizonAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPendingAuthorizonAmt(JAXBElement<YMoney> value) {
        this.pendingAuthorizonAmt = value;
    }

    /**
     * Gets the value of the bankTransferCodeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBankTransferCodeId() {
        return bankTransferCodeId;
    }

    /**
     * Sets the value of the bankTransferCodeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBankTransferCodeId(JAXBElement<Long> value) {
        this.bankTransferCodeId = value;
    }

}
