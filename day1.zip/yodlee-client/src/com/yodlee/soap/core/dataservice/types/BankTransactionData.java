
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for BankTransactionData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankTransactionData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionBaseTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="categoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankTransactionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bankStatementId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteCategoryType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="classUpdationSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastCategorised" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isReimbursable" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="mcCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prevLastCategorised" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="naicsCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="runningBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="userDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="parentId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isOlbUserDesc" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="categorisationSourceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plainTextDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="splitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="categoryLevelId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="calcRunningBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="prevTransactionCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isBusinessExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="descriptionViewPref" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="prevCategorisationSourceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="transactionPostingOrder" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="checkNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isTaxDeductible" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isMedicalExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="categorizationKeyword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sourceTransactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankTransactionData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "transactionTypeId",
    "transactionType",
    "localizedTransactionType",
    "transactionStatusId",
    "transactionStatus",
    "localizedTransactionStatus",
    "transactionBaseTypeId",
    "transactionBaseType",
    "localizedTransactionBaseType",
    "categoryId",
    "bankTransactionId",
    "bankAccountId",
    "bankStatementId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "transactionId",
    "transactionCategoryId",
    "siteCategoryType",
    "siteCategory",
    "classUpdationSource",
    "lastCategorised",
    "transactionDate",
    "isReimbursable",
    "mcCode",
    "prevLastCategorised",
    "naicsCode",
    "runningBalance",
    "userDescription",
    "customCategoryId",
    "memo",
    "parentId",
    "isOlbUserDesc",
    "categorisationSourceId",
    "plainTextDescription",
    "splitType",
    "categoryLevelId",
    "calcRunningBalance",
    "category",
    "link",
    "postDate",
    "prevTransactionCategoryId",
    "isBusinessExpense",
    "descriptionViewPref",
    "prevCategorisationSourceId",
    "transactionAmount",
    "transactionPostingOrder",
    "checkNumber",
    "description",
    "isTaxDeductible",
    "isMedicalExpense",
    "categorizationKeyword",
    "sourceTransactionType"
})
public class BankTransactionData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "transactionTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionTypeId;
    @XmlElementRef(name = "transactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionType;
    @XmlElementRef(name = "localizedTransactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionType;
    @XmlElementRef(name = "transactionStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionStatusId;
    @XmlElementRef(name = "transactionStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionStatus;
    @XmlElementRef(name = "localizedTransactionStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionStatus;
    @XmlElementRef(name = "transactionBaseTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionBaseTypeId;
    @XmlElementRef(name = "transactionBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionBaseType;
    @XmlElementRef(name = "localizedTransactionBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionBaseType;
    @XmlElementRef(name = "categoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> categoryId;
    @XmlElementRef(name = "bankTransactionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bankTransactionId;
    @XmlElementRef(name = "bankAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bankAccountId;
    @XmlElementRef(name = "bankStatementId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bankStatementId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "transactionId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionId;
    @XmlElementRef(name = "transactionCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionCategoryId;
    @XmlElementRef(name = "siteCategoryType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> siteCategoryType;
    @XmlElementRef(name = "siteCategory", type = JAXBElement.class, required = false)
    protected JAXBElement<String> siteCategory;
    @XmlElementRef(name = "classUpdationSource", type = JAXBElement.class, required = false)
    protected JAXBElement<String> classUpdationSource;
    @XmlElementRef(name = "lastCategorised", type = JAXBElement.class, required = false)
    protected JAXBElement<String> lastCategorised;
    @XmlElementRef(name = "transactionDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transactionDate;
    @XmlElementRef(name = "isReimbursable", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isReimbursable;
    @XmlElementRef(name = "mcCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mcCode;
    @XmlElementRef(name = "prevLastCategorised", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevLastCategorised;
    @XmlElementRef(name = "naicsCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> naicsCode;
    @XmlElementRef(name = "runningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> runningBalance;
    @XmlElementRef(name = "userDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userDescription;
    @XmlElementRef(name = "customCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> customCategoryId;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "parentId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> parentId;
    @XmlElementRef(name = "isOlbUserDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isOlbUserDesc;
    @XmlElementRef(name = "categorisationSourceId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> categorisationSourceId;
    @XmlElementRef(name = "plainTextDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plainTextDescription;
    @XmlElementRef(name = "splitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> splitType;
    @XmlElementRef(name = "categoryLevelId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> categoryLevelId;
    @XmlElementRef(name = "calcRunningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> calcRunningBalance;
    @XmlElementRef(name = "category", type = JAXBElement.class, required = false)
    protected JAXBElement<String> category;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "postDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> postDate;
    @XmlElementRef(name = "prevTransactionCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevTransactionCategoryId;
    @XmlElementRef(name = "isBusinessExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isBusinessExpense;
    @XmlElementRef(name = "descriptionViewPref", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> descriptionViewPref;
    @XmlElementRef(name = "prevCategorisationSourceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevCategorisationSourceId;
    @XmlElementRef(name = "transactionAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> transactionAmount;
    @XmlElementRef(name = "transactionPostingOrder", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionPostingOrder;
    @XmlElementRef(name = "checkNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> checkNumber;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "isTaxDeductible", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isTaxDeductible;
    @XmlElementRef(name = "isMedicalExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isMedicalExpense;
    @XmlElementRef(name = "categorizationKeyword", type = JAXBElement.class, required = false)
    protected JAXBElement<String> categorizationKeyword;
    @XmlElementRef(name = "sourceTransactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sourceTransactionType;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the transactionTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionTypeId() {
        return transactionTypeId;
    }

    /**
     * Sets the value of the transactionTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionTypeId(JAXBElement<Long> value) {
        this.transactionTypeId = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionType(JAXBElement<String> value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the localizedTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionType() {
        return localizedTransactionType;
    }

    /**
     * Sets the value of the localizedTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionType(JAXBElement<String> value) {
        this.localizedTransactionType = value;
    }

    /**
     * Gets the value of the transactionStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionStatusId() {
        return transactionStatusId;
    }

    /**
     * Sets the value of the transactionStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionStatusId(JAXBElement<Long> value) {
        this.transactionStatusId = value;
    }

    /**
     * Gets the value of the transactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Sets the value of the transactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionStatus(JAXBElement<String> value) {
        this.transactionStatus = value;
    }

    /**
     * Gets the value of the localizedTransactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionStatus() {
        return localizedTransactionStatus;
    }

    /**
     * Sets the value of the localizedTransactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionStatus(JAXBElement<String> value) {
        this.localizedTransactionStatus = value;
    }

    /**
     * Gets the value of the transactionBaseTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionBaseTypeId() {
        return transactionBaseTypeId;
    }

    /**
     * Sets the value of the transactionBaseTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionBaseTypeId(JAXBElement<Long> value) {
        this.transactionBaseTypeId = value;
    }

    /**
     * Gets the value of the transactionBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionBaseType() {
        return transactionBaseType;
    }

    /**
     * Sets the value of the transactionBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionBaseType(JAXBElement<String> value) {
        this.transactionBaseType = value;
    }

    /**
     * Gets the value of the localizedTransactionBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionBaseType() {
        return localizedTransactionBaseType;
    }

    /**
     * Sets the value of the localizedTransactionBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionBaseType(JAXBElement<String> value) {
        this.localizedTransactionBaseType = value;
    }

    /**
     * Gets the value of the categoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCategoryId() {
        return categoryId;
    }

    /**
     * Sets the value of the categoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCategoryId(JAXBElement<Long> value) {
        this.categoryId = value;
    }

    /**
     * Gets the value of the bankTransactionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBankTransactionId() {
        return bankTransactionId;
    }

    /**
     * Sets the value of the bankTransactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBankTransactionId(JAXBElement<Long> value) {
        this.bankTransactionId = value;
    }

    /**
     * Gets the value of the bankAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBankAccountId() {
        return bankAccountId;
    }

    /**
     * Sets the value of the bankAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBankAccountId(JAXBElement<Long> value) {
        this.bankAccountId = value;
    }

    /**
     * Gets the value of the bankStatementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBankStatementId() {
        return bankStatementId;
    }

    /**
     * Sets the value of the bankStatementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBankStatementId(JAXBElement<Long> value) {
        this.bankStatementId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionId(JAXBElement<String> value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the transactionCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionCategoryId() {
        return transactionCategoryId;
    }

    /**
     * Sets the value of the transactionCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionCategoryId(JAXBElement<String> value) {
        this.transactionCategoryId = value;
    }

    /**
     * Gets the value of the siteCategoryType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSiteCategoryType() {
        return siteCategoryType;
    }

    /**
     * Sets the value of the siteCategoryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSiteCategoryType(JAXBElement<String> value) {
        this.siteCategoryType = value;
    }

    /**
     * Gets the value of the siteCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSiteCategory() {
        return siteCategory;
    }

    /**
     * Sets the value of the siteCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSiteCategory(JAXBElement<String> value) {
        this.siteCategory = value;
    }

    /**
     * Gets the value of the classUpdationSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getClassUpdationSource() {
        return classUpdationSource;
    }

    /**
     * Sets the value of the classUpdationSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setClassUpdationSource(JAXBElement<String> value) {
        this.classUpdationSource = value;
    }

    /**
     * Gets the value of the lastCategorised property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLastCategorised() {
        return lastCategorised;
    }

    /**
     * Sets the value of the lastCategorised property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLastCategorised(JAXBElement<String> value) {
        this.lastCategorised = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransactionDate(JAXBElement<YDate> value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the isReimbursable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsReimbursable() {
        return isReimbursable;
    }

    /**
     * Sets the value of the isReimbursable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsReimbursable(JAXBElement<Long> value) {
        this.isReimbursable = value;
    }

    /**
     * Gets the value of the mcCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMcCode() {
        return mcCode;
    }

    /**
     * Sets the value of the mcCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMcCode(JAXBElement<String> value) {
        this.mcCode = value;
    }

    /**
     * Gets the value of the prevLastCategorised property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevLastCategorised() {
        return prevLastCategorised;
    }

    /**
     * Sets the value of the prevLastCategorised property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevLastCategorised(JAXBElement<Long> value) {
        this.prevLastCategorised = value;
    }

    /**
     * Gets the value of the naicsCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNaicsCode() {
        return naicsCode;
    }

    /**
     * Sets the value of the naicsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNaicsCode(JAXBElement<String> value) {
        this.naicsCode = value;
    }

    /**
     * Gets the value of the runningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRunningBalance() {
        return runningBalance;
    }

    /**
     * Sets the value of the runningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRunningBalance(JAXBElement<YMoney> value) {
        this.runningBalance = value;
    }

    /**
     * Gets the value of the userDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserDescription() {
        return userDescription;
    }

    /**
     * Sets the value of the userDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserDescription(JAXBElement<String> value) {
        this.userDescription = value;
    }

    /**
     * Gets the value of the customCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCustomCategoryId() {
        return customCategoryId;
    }

    /**
     * Sets the value of the customCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCustomCategoryId(JAXBElement<Long> value) {
        this.customCategoryId = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the parentId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getParentId() {
        return parentId;
    }

    /**
     * Sets the value of the parentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setParentId(JAXBElement<Long> value) {
        this.parentId = value;
    }

    /**
     * Gets the value of the isOlbUserDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsOlbUserDesc() {
        return isOlbUserDesc;
    }

    /**
     * Sets the value of the isOlbUserDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsOlbUserDesc(JAXBElement<Long> value) {
        this.isOlbUserDesc = value;
    }

    /**
     * Gets the value of the categorisationSourceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategorisationSourceId() {
        return categorisationSourceId;
    }

    /**
     * Sets the value of the categorisationSourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategorisationSourceId(JAXBElement<String> value) {
        this.categorisationSourceId = value;
    }

    /**
     * Gets the value of the plainTextDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlainTextDescription() {
        return plainTextDescription;
    }

    /**
     * Sets the value of the plainTextDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlainTextDescription(JAXBElement<String> value) {
        this.plainTextDescription = value;
    }

    /**
     * Gets the value of the splitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSplitType() {
        return splitType;
    }

    /**
     * Sets the value of the splitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSplitType(JAXBElement<String> value) {
        this.splitType = value;
    }

    /**
     * Gets the value of the categoryLevelId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCategoryLevelId() {
        return categoryLevelId;
    }

    /**
     * Sets the value of the categoryLevelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCategoryLevelId(JAXBElement<Long> value) {
        this.categoryLevelId = value;
    }

    /**
     * Gets the value of the calcRunningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCalcRunningBalance() {
        return calcRunningBalance;
    }

    /**
     * Sets the value of the calcRunningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCalcRunningBalance(JAXBElement<YMoney> value) {
        this.calcRunningBalance = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategory(JAXBElement<String> value) {
        this.category = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the postDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPostDate() {
        return postDate;
    }

    /**
     * Sets the value of the postDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPostDate(JAXBElement<YDate> value) {
        this.postDate = value;
    }

    /**
     * Gets the value of the prevTransactionCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevTransactionCategoryId() {
        return prevTransactionCategoryId;
    }

    /**
     * Sets the value of the prevTransactionCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevTransactionCategoryId(JAXBElement<Long> value) {
        this.prevTransactionCategoryId = value;
    }

    /**
     * Gets the value of the isBusinessExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsBusinessExpense() {
        return isBusinessExpense;
    }

    /**
     * Sets the value of the isBusinessExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsBusinessExpense(JAXBElement<Long> value) {
        this.isBusinessExpense = value;
    }

    /**
     * Gets the value of the descriptionViewPref property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDescriptionViewPref() {
        return descriptionViewPref;
    }

    /**
     * Sets the value of the descriptionViewPref property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDescriptionViewPref(JAXBElement<Long> value) {
        this.descriptionViewPref = value;
    }

    /**
     * Gets the value of the prevCategorisationSourceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevCategorisationSourceId() {
        return prevCategorisationSourceId;
    }

    /**
     * Sets the value of the prevCategorisationSourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevCategorisationSourceId(JAXBElement<Long> value) {
        this.prevCategorisationSourceId = value;
    }

    /**
     * Gets the value of the transactionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTransactionAmount() {
        return transactionAmount;
    }

    /**
     * Sets the value of the transactionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTransactionAmount(JAXBElement<YMoney> value) {
        this.transactionAmount = value;
    }

    /**
     * Gets the value of the transactionPostingOrder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionPostingOrder() {
        return transactionPostingOrder;
    }

    /**
     * Sets the value of the transactionPostingOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionPostingOrder(JAXBElement<Long> value) {
        this.transactionPostingOrder = value;
    }

    /**
     * Gets the value of the checkNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCheckNumber() {
        return checkNumber;
    }

    /**
     * Sets the value of the checkNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCheckNumber(JAXBElement<String> value) {
        this.checkNumber = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the isTaxDeductible property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsTaxDeductible() {
        return isTaxDeductible;
    }

    /**
     * Sets the value of the isTaxDeductible property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsTaxDeductible(JAXBElement<Long> value) {
        this.isTaxDeductible = value;
    }

    /**
     * Gets the value of the isMedicalExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsMedicalExpense() {
        return isMedicalExpense;
    }

    /**
     * Sets the value of the isMedicalExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsMedicalExpense(JAXBElement<Long> value) {
        this.isMedicalExpense = value;
    }

    /**
     * Gets the value of the categorizationKeyword property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategorizationKeyword() {
        return categorizationKeyword;
    }

    /**
     * Sets the value of the categorizationKeyword property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategorizationKeyword(JAXBElement<String> value) {
        this.categorizationKeyword = value;
    }

    /**
     * Gets the value of the sourceTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSourceTransactionType() {
        return sourceTransactionType;
    }

    /**
     * Sets the value of the sourceTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSourceTransactionType(JAXBElement<String> value) {
        this.sourceTransactionType = value;
    }

}
