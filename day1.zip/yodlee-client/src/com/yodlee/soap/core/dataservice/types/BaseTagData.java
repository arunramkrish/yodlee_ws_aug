
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.collections.Map;
import com.yodlee.soap.core.AccountDisplayName;


/**
 * <p>Java class for BaseTagData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseTagData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cacheItemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isItemAccountDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="level" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="accountDisplayName" type="{http://core.soap.yodlee.com}AccountDisplayName" minOccurs="0"/>
 *         &lt;element name="itemAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="dataExtensionMap" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="baseTagDataId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="refreshTime" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sharedAccountList" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseTagData", propOrder = {
    "cacheItemId",
    "isItemAccountDeleted",
    "accountId",
    "level",
    "accountDisplayName",
    "itemAccountId",
    "dataExtensionMap",
    "baseTagDataId",
    "refreshTime",
    "sharedAccountList"
})
@XmlSeeAlso({
    BankStatementData.class,
    ChartData.class,
    ChatData.class,
    PaymentMethodsAcceptedData.class,
    BpsSchdPaym.class,
    BpsPayeeData.class,
    BillPreferenceData.class,
    InsuranceLoginAccountData.class,
    AucBidData.class,
    Driver.class,
    LoanTransaction.class,
    ExtApCardAcctData.class,
    ExtAutopaySetupData.class,
    InsDiscountData.class,
    PersonData.class,
    LoanPaymentDue.class,
    Equipment.class,
    PropertyInfoData.class,
    InsPolicyHolderData.class,
    InsBeneficiaryData.class,
    AirTravelData.class,
    NewsData.class,
    InsInsuredData.class,
    HotelRoomData.class,
    BillContract.class,
    InsMutualFund.class,
    LoanLoginAccountData.class,
    DealData.class,
    IndividualInformation.class,
    AucSellerData.class,
    BillCharge.class,
    BalanceTransfer.class,
    ConsumerGuideData.class,
    HotelReservationData.class,
    AirReservationData.class,
    MailHeaderData.class,
    AucBidderData.class,
    Bill.class,
    InsStatementData.class,
    FlightLegData.class,
    TaxLot.class,
    CardTransactionData.class,
    AccountUsageData.class,
    CardStatementData.class,
    MiscellaneousData.class,
    RewardActivity.class,
    ReservationData.class,
    InvestmentOptionData.class,
    InsPaymentDueData.class,
    LienHolder.class,
    InsAnnuity.class,
    LoanCosigner.class,
    InsClaimData.class,
    BankTransactionData.class,
    Vehicle.class,
    CarReservationData.class,
    BillingPlanData.class,
    ShippingData.class,
    OrdersData.class,
    CrcExchangeRateData.class,
    InsVehicleData.class,
    InsPrescriptionData.class,
    BpsRecurPaym.class,
    InsDriverData.class,
    MailData.class,
    InvestmentTransactionsData.class,
    InsCoverageLimitData.class,
    InsTransactionData.class,
    CalendarData.class,
    JobData.class,
    MessageBoardData.class,
    RemitAddressData.class,
    AuctionLoginAccountData.class,
    LoanBorrower.class,
    ExtApBankAcctData.class,
    InvestmentPlanData.class,
    RewardBalance.class,
    AuctionData.class,
    ShippingMethodData.class,
    PaymentMethodData.class,
    PaymentDetail.class,
    InsCoverageData.class,
    LoanStatement.class,
    TaxFormData.class,
    LoanPayoff.class,
    ItemAccountData.class,
    HoldingData.class
})
public abstract class BaseTagData {

    @XmlElementRef(name = "cacheItemId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cacheItemId;
    @XmlElementRef(name = "isItemAccountDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isItemAccountDeleted;
    @XmlElementRef(name = "accountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> accountId;
    protected Integer level;
    @XmlElementRef(name = "accountDisplayName", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountDisplayName> accountDisplayName;
    @XmlElementRef(name = "itemAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> itemAccountId;
    @XmlElementRef(name = "dataExtensionMap", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> dataExtensionMap;
    @XmlElementRef(name = "baseTagDataId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> baseTagDataId;
    @XmlElementRef(name = "refreshTime", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> refreshTime;
    @XmlElementRef(name = "sharedAccountList", type = JAXBElement.class, required = false)
    protected JAXBElement<List> sharedAccountList;

    /**
     * Gets the value of the cacheItemId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCacheItemId() {
        return cacheItemId;
    }

    /**
     * Sets the value of the cacheItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCacheItemId(JAXBElement<Long> value) {
        this.cacheItemId = value;
    }

    /**
     * Gets the value of the isItemAccountDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsItemAccountDeleted() {
        return isItemAccountDeleted;
    }

    /**
     * Sets the value of the isItemAccountDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsItemAccountDeleted(JAXBElement<Long> value) {
        this.isItemAccountDeleted = value;
    }

    /**
     * Gets the value of the accountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAccountId() {
        return accountId;
    }

    /**
     * Sets the value of the accountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAccountId(JAXBElement<Long> value) {
        this.accountId = value;
    }

    /**
     * Gets the value of the level property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLevel() {
        return level;
    }

    /**
     * Sets the value of the level property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLevel(Integer value) {
        this.level = value;
    }

    /**
     * Gets the value of the accountDisplayName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountDisplayName }{@code >}
     *     
     */
    public JAXBElement<AccountDisplayName> getAccountDisplayName() {
        return accountDisplayName;
    }

    /**
     * Sets the value of the accountDisplayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountDisplayName }{@code >}
     *     
     */
    public void setAccountDisplayName(JAXBElement<AccountDisplayName> value) {
        this.accountDisplayName = value;
    }

    /**
     * Gets the value of the itemAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getItemAccountId() {
        return itemAccountId;
    }

    /**
     * Sets the value of the itemAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setItemAccountId(JAXBElement<Long> value) {
        this.itemAccountId = value;
    }

    /**
     * Gets the value of the dataExtensionMap property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getDataExtensionMap() {
        return dataExtensionMap;
    }

    /**
     * Sets the value of the dataExtensionMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setDataExtensionMap(JAXBElement<Map> value) {
        this.dataExtensionMap = value;
    }

    /**
     * Gets the value of the baseTagDataId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBaseTagDataId() {
        return baseTagDataId;
    }

    /**
     * Sets the value of the baseTagDataId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBaseTagDataId(JAXBElement<String> value) {
        this.baseTagDataId = value;
    }

    /**
     * Gets the value of the refreshTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRefreshTime() {
        return refreshTime;
    }

    /**
     * Sets the value of the refreshTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRefreshTime(JAXBElement<Long> value) {
        this.refreshTime = value;
    }

    /**
     * Gets the value of the sharedAccountList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getSharedAccountList() {
        return sharedAccountList;
    }

    /**
     * Sets the value of the sharedAccountList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setSharedAccountList(JAXBElement<List> value) {
        this.sharedAccountList = value;
    }

}
