
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for Bill complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Bill">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="documentId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isHistoric" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billingAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPayServiceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="markAsPaidReasonId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="markAsPaidReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedMarkAsPaidReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentLink" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userPaymStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedPaymStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDerivedPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billPeriodEndDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="endingBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="newCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pastDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="lastPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="amountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="minPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="latePaymentCharge" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="prevEndingBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isDueDateEstimated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedPaymStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymFreqUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymRecvdDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="paymSourceAccNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="paymMaxAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="paymTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPaymType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymFreqCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="paymStatusDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymFreqDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payeeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPeriodStartDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="billDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="dueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isDueOnReceipt" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastPayDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="userPaymStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUserPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billingPlans" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="accountUsages" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="billCharges" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="billContracts" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="equipments" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="receiveDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Bill", propOrder = {
    "documentId",
    "documentStatus",
    "isSeidFromDataSource",
    "isHistoric",
    "isSeidMod",
    "acctTypeId",
    "acctType",
    "localizedAcctType",
    "srcElementId",
    "billId",
    "billingAccountId",
    "billPayServiceId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "markAsPaidReasonId",
    "markAsPaidReason",
    "localizedMarkAsPaidReason",
    "paymentLink",
    "accountNumber",
    "userPaymStatusLastUpdated",
    "derivedPaymStatusId",
    "derivedPaymStatus",
    "localizedDerivedPaymStatus",
    "accountHolder",
    "billPeriodEndDate",
    "endingBalance",
    "newCharges",
    "pastDue",
    "lastPayment",
    "amountDue",
    "minPayment",
    "adjustments",
    "latePaymentCharge",
    "prevEndingBalance",
    "isDueDateEstimated",
    "derivedPaymStatusLastUpdated",
    "paymSource",
    "paymFreqUnit",
    "paymRecvdDate",
    "paymSourceAccNumber",
    "payment",
    "paymMaxAmount",
    "paymTypeId",
    "paymType",
    "localizedPaymType",
    "paymFreqCode",
    "paymDate",
    "paymStatusDesc",
    "paymFreqDesc",
    "paymStatusId",
    "paymStatus",
    "localizedPaymStatus",
    "payee",
    "payeeId",
    "billPeriodStartDate",
    "billDate",
    "dueDate",
    "isDueOnReceipt",
    "link",
    "lastPayDate",
    "userPaymStatusId",
    "userPaymStatus",
    "localizedUserPaymStatus",
    "accountName",
    "billingPlans",
    "accountUsages",
    "billCharges",
    "billContracts",
    "equipments",
    "receiveDate"
})
public class Bill
    extends BaseTagData
{

    @XmlElementRef(name = "documentId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> documentId;
    @XmlElementRef(name = "documentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> documentStatus;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isHistoric", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isHistoric;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "acctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctTypeId;
    @XmlElementRef(name = "acctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctType;
    @XmlElementRef(name = "localizedAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctType;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "billId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billId;
    @XmlElementRef(name = "billingAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billingAccountId;
    @XmlElementRef(name = "billPayServiceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPayServiceId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "markAsPaidReasonId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> markAsPaidReasonId;
    @XmlElementRef(name = "markAsPaidReason", type = JAXBElement.class, required = false)
    protected JAXBElement<String> markAsPaidReason;
    @XmlElementRef(name = "localizedMarkAsPaidReason", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedMarkAsPaidReason;
    @XmlElementRef(name = "paymentLink", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentLink;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "userPaymStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userPaymStatusLastUpdated;
    @XmlElementRef(name = "derivedPaymStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedPaymStatusId;
    @XmlElementRef(name = "derivedPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> derivedPaymStatus;
    @XmlElementRef(name = "localizedDerivedPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDerivedPaymStatus;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "billPeriodEndDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> billPeriodEndDate;
    @XmlElementRef(name = "endingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> endingBalance;
    @XmlElementRef(name = "newCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> newCharges;
    @XmlElementRef(name = "pastDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pastDue;
    @XmlElementRef(name = "lastPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPayment;
    @XmlElementRef(name = "amountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountDue;
    @XmlElementRef(name = "minPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> minPayment;
    @XmlElementRef(name = "adjustments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustments;
    @XmlElementRef(name = "latePaymentCharge", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> latePaymentCharge;
    @XmlElementRef(name = "prevEndingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> prevEndingBalance;
    @XmlElementRef(name = "isDueDateEstimated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDueDateEstimated;
    @XmlElementRef(name = "derivedPaymStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedPaymStatusLastUpdated;
    @XmlElementRef(name = "paymSource", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymSource;
    @XmlElementRef(name = "paymFreqUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymFreqUnit;
    @XmlElementRef(name = "paymRecvdDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> paymRecvdDate;
    @XmlElementRef(name = "paymSourceAccNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymSourceAccNumber;
    @XmlElementRef(name = "payment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> payment;
    @XmlElementRef(name = "paymMaxAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> paymMaxAmount;
    @XmlElementRef(name = "paymTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymTypeId;
    @XmlElementRef(name = "paymType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymType;
    @XmlElementRef(name = "localizedPaymType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPaymType;
    @XmlElementRef(name = "paymFreqCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymFreqCode;
    @XmlElementRef(name = "paymDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> paymDate;
    @XmlElementRef(name = "paymStatusDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymStatusDesc;
    @XmlElementRef(name = "paymFreqDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymFreqDesc;
    @XmlElementRef(name = "paymStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymStatusId;
    @XmlElementRef(name = "paymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymStatus;
    @XmlElementRef(name = "localizedPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPaymStatus;
    @XmlElementRef(name = "payee", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payee;
    @XmlElementRef(name = "payeeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> payeeId;
    @XmlElementRef(name = "billPeriodStartDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> billPeriodStartDate;
    @XmlElementRef(name = "billDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> billDate;
    @XmlElementRef(name = "dueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dueDate;
    @XmlElementRef(name = "isDueOnReceipt", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDueOnReceipt;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "lastPayDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPayDate;
    @XmlElementRef(name = "userPaymStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userPaymStatusId;
    @XmlElementRef(name = "userPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userPaymStatus;
    @XmlElementRef(name = "localizedUserPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUserPaymStatus;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "billingPlans", type = JAXBElement.class, required = false)
    protected JAXBElement<List> billingPlans;
    @XmlElementRef(name = "accountUsages", type = JAXBElement.class, required = false)
    protected JAXBElement<List> accountUsages;
    @XmlElementRef(name = "billCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<List> billCharges;
    @XmlElementRef(name = "billContracts", type = JAXBElement.class, required = false)
    protected JAXBElement<List> billContracts;
    @XmlElementRef(name = "equipments", type = JAXBElement.class, required = false)
    protected JAXBElement<List> equipments;
    @XmlElementRef(name = "receiveDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> receiveDate;

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDocumentId(JAXBElement<String> value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the documentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDocumentStatus() {
        return documentStatus;
    }

    /**
     * Sets the value of the documentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDocumentStatus(JAXBElement<String> value) {
        this.documentStatus = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isHistoric property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsHistoric() {
        return isHistoric;
    }

    /**
     * Sets the value of the isHistoric property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsHistoric(JAXBElement<Long> value) {
        this.isHistoric = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the acctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctTypeId() {
        return acctTypeId;
    }

    /**
     * Sets the value of the acctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctTypeId(JAXBElement<Long> value) {
        this.acctTypeId = value;
    }

    /**
     * Gets the value of the acctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctType() {
        return acctType;
    }

    /**
     * Sets the value of the acctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctType(JAXBElement<String> value) {
        this.acctType = value;
    }

    /**
     * Gets the value of the localizedAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctType() {
        return localizedAcctType;
    }

    /**
     * Sets the value of the localizedAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctType(JAXBElement<String> value) {
        this.localizedAcctType = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillId(JAXBElement<Long> value) {
        this.billId = value;
    }

    /**
     * Gets the value of the billingAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillingAccountId() {
        return billingAccountId;
    }

    /**
     * Sets the value of the billingAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillingAccountId(JAXBElement<Long> value) {
        this.billingAccountId = value;
    }

    /**
     * Gets the value of the billPayServiceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPayServiceId() {
        return billPayServiceId;
    }

    /**
     * Sets the value of the billPayServiceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPayServiceId(JAXBElement<Long> value) {
        this.billPayServiceId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the markAsPaidReasonId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getMarkAsPaidReasonId() {
        return markAsPaidReasonId;
    }

    /**
     * Sets the value of the markAsPaidReasonId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setMarkAsPaidReasonId(JAXBElement<Long> value) {
        this.markAsPaidReasonId = value;
    }

    /**
     * Gets the value of the markAsPaidReason property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMarkAsPaidReason() {
        return markAsPaidReason;
    }

    /**
     * Sets the value of the markAsPaidReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMarkAsPaidReason(JAXBElement<String> value) {
        this.markAsPaidReason = value;
    }

    /**
     * Gets the value of the localizedMarkAsPaidReason property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedMarkAsPaidReason() {
        return localizedMarkAsPaidReason;
    }

    /**
     * Sets the value of the localizedMarkAsPaidReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedMarkAsPaidReason(JAXBElement<String> value) {
        this.localizedMarkAsPaidReason = value;
    }

    /**
     * Gets the value of the paymentLink property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentLink() {
        return paymentLink;
    }

    /**
     * Sets the value of the paymentLink property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentLink(JAXBElement<String> value) {
        this.paymentLink = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the userPaymStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserPaymStatusLastUpdated() {
        return userPaymStatusLastUpdated;
    }

    /**
     * Sets the value of the userPaymStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserPaymStatusLastUpdated(JAXBElement<Long> value) {
        this.userPaymStatusLastUpdated = value;
    }

    /**
     * Gets the value of the derivedPaymStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedPaymStatusId() {
        return derivedPaymStatusId;
    }

    /**
     * Sets the value of the derivedPaymStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedPaymStatusId(JAXBElement<Long> value) {
        this.derivedPaymStatusId = value;
    }

    /**
     * Gets the value of the derivedPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDerivedPaymStatus() {
        return derivedPaymStatus;
    }

    /**
     * Sets the value of the derivedPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDerivedPaymStatus(JAXBElement<String> value) {
        this.derivedPaymStatus = value;
    }

    /**
     * Gets the value of the localizedDerivedPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDerivedPaymStatus() {
        return localizedDerivedPaymStatus;
    }

    /**
     * Sets the value of the localizedDerivedPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDerivedPaymStatus(JAXBElement<String> value) {
        this.localizedDerivedPaymStatus = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the billPeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getBillPeriodEndDate() {
        return billPeriodEndDate;
    }

    /**
     * Sets the value of the billPeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setBillPeriodEndDate(JAXBElement<YDate> value) {
        this.billPeriodEndDate = value;
    }

    /**
     * Gets the value of the endingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEndingBalance() {
        return endingBalance;
    }

    /**
     * Sets the value of the endingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEndingBalance(JAXBElement<YMoney> value) {
        this.endingBalance = value;
    }

    /**
     * Gets the value of the newCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getNewCharges() {
        return newCharges;
    }

    /**
     * Sets the value of the newCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setNewCharges(JAXBElement<YMoney> value) {
        this.newCharges = value;
    }

    /**
     * Gets the value of the pastDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPastDue() {
        return pastDue;
    }

    /**
     * Sets the value of the pastDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPastDue(JAXBElement<YMoney> value) {
        this.pastDue = value;
    }

    /**
     * Gets the value of the lastPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPayment() {
        return lastPayment;
    }

    /**
     * Sets the value of the lastPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPayment(JAXBElement<YMoney> value) {
        this.lastPayment = value;
    }

    /**
     * Gets the value of the amountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountDue() {
        return amountDue;
    }

    /**
     * Sets the value of the amountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountDue(JAXBElement<YMoney> value) {
        this.amountDue = value;
    }

    /**
     * Gets the value of the minPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMinPayment() {
        return minPayment;
    }

    /**
     * Sets the value of the minPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMinPayment(JAXBElement<YMoney> value) {
        this.minPayment = value;
    }

    /**
     * Gets the value of the adjustments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustments() {
        return adjustments;
    }

    /**
     * Sets the value of the adjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustments(JAXBElement<YMoney> value) {
        this.adjustments = value;
    }

    /**
     * Gets the value of the latePaymentCharge property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLatePaymentCharge() {
        return latePaymentCharge;
    }

    /**
     * Sets the value of the latePaymentCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLatePaymentCharge(JAXBElement<YMoney> value) {
        this.latePaymentCharge = value;
    }

    /**
     * Gets the value of the prevEndingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrevEndingBalance() {
        return prevEndingBalance;
    }

    /**
     * Sets the value of the prevEndingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrevEndingBalance(JAXBElement<YMoney> value) {
        this.prevEndingBalance = value;
    }

    /**
     * Gets the value of the isDueDateEstimated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDueDateEstimated() {
        return isDueDateEstimated;
    }

    /**
     * Sets the value of the isDueDateEstimated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDueDateEstimated(JAXBElement<Long> value) {
        this.isDueDateEstimated = value;
    }

    /**
     * Gets the value of the derivedPaymStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedPaymStatusLastUpdated() {
        return derivedPaymStatusLastUpdated;
    }

    /**
     * Sets the value of the derivedPaymStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedPaymStatusLastUpdated(JAXBElement<Long> value) {
        this.derivedPaymStatusLastUpdated = value;
    }

    /**
     * Gets the value of the paymSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymSource() {
        return paymSource;
    }

    /**
     * Sets the value of the paymSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymSource(JAXBElement<String> value) {
        this.paymSource = value;
    }

    /**
     * Gets the value of the paymFreqUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymFreqUnit() {
        return paymFreqUnit;
    }

    /**
     * Sets the value of the paymFreqUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymFreqUnit(JAXBElement<String> value) {
        this.paymFreqUnit = value;
    }

    /**
     * Gets the value of the paymRecvdDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPaymRecvdDate() {
        return paymRecvdDate;
    }

    /**
     * Sets the value of the paymRecvdDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPaymRecvdDate(JAXBElement<YDate> value) {
        this.paymRecvdDate = value;
    }

    /**
     * Gets the value of the paymSourceAccNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymSourceAccNumber() {
        return paymSourceAccNumber;
    }

    /**
     * Sets the value of the paymSourceAccNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymSourceAccNumber(JAXBElement<String> value) {
        this.paymSourceAccNumber = value;
    }

    /**
     * Gets the value of the payment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPayment() {
        return payment;
    }

    /**
     * Sets the value of the payment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPayment(JAXBElement<YMoney> value) {
        this.payment = value;
    }

    /**
     * Gets the value of the paymMaxAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPaymMaxAmount() {
        return paymMaxAmount;
    }

    /**
     * Sets the value of the paymMaxAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPaymMaxAmount(JAXBElement<YMoney> value) {
        this.paymMaxAmount = value;
    }

    /**
     * Gets the value of the paymTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymTypeId() {
        return paymTypeId;
    }

    /**
     * Sets the value of the paymTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymTypeId(JAXBElement<Long> value) {
        this.paymTypeId = value;
    }

    /**
     * Gets the value of the paymType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymType() {
        return paymType;
    }

    /**
     * Sets the value of the paymType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymType(JAXBElement<String> value) {
        this.paymType = value;
    }

    /**
     * Gets the value of the localizedPaymType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPaymType() {
        return localizedPaymType;
    }

    /**
     * Sets the value of the localizedPaymType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPaymType(JAXBElement<String> value) {
        this.localizedPaymType = value;
    }

    /**
     * Gets the value of the paymFreqCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymFreqCode() {
        return paymFreqCode;
    }

    /**
     * Sets the value of the paymFreqCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymFreqCode(JAXBElement<String> value) {
        this.paymFreqCode = value;
    }

    /**
     * Gets the value of the paymDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPaymDate() {
        return paymDate;
    }

    /**
     * Sets the value of the paymDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPaymDate(JAXBElement<YDate> value) {
        this.paymDate = value;
    }

    /**
     * Gets the value of the paymStatusDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymStatusDesc() {
        return paymStatusDesc;
    }

    /**
     * Sets the value of the paymStatusDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymStatusDesc(JAXBElement<String> value) {
        this.paymStatusDesc = value;
    }

    /**
     * Gets the value of the paymFreqDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymFreqDesc() {
        return paymFreqDesc;
    }

    /**
     * Sets the value of the paymFreqDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymFreqDesc(JAXBElement<String> value) {
        this.paymFreqDesc = value;
    }

    /**
     * Gets the value of the paymStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymStatusId() {
        return paymStatusId;
    }

    /**
     * Sets the value of the paymStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymStatusId(JAXBElement<Long> value) {
        this.paymStatusId = value;
    }

    /**
     * Gets the value of the paymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymStatus() {
        return paymStatus;
    }

    /**
     * Sets the value of the paymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymStatus(JAXBElement<String> value) {
        this.paymStatus = value;
    }

    /**
     * Gets the value of the localizedPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPaymStatus() {
        return localizedPaymStatus;
    }

    /**
     * Sets the value of the localizedPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPaymStatus(JAXBElement<String> value) {
        this.localizedPaymStatus = value;
    }

    /**
     * Gets the value of the payee property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayee() {
        return payee;
    }

    /**
     * Sets the value of the payee property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayee(JAXBElement<String> value) {
        this.payee = value;
    }

    /**
     * Gets the value of the payeeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPayeeId() {
        return payeeId;
    }

    /**
     * Sets the value of the payeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPayeeId(JAXBElement<Long> value) {
        this.payeeId = value;
    }

    /**
     * Gets the value of the billPeriodStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getBillPeriodStartDate() {
        return billPeriodStartDate;
    }

    /**
     * Sets the value of the billPeriodStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setBillPeriodStartDate(JAXBElement<YDate> value) {
        this.billPeriodStartDate = value;
    }

    /**
     * Gets the value of the billDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getBillDate() {
        return billDate;
    }

    /**
     * Sets the value of the billDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setBillDate(JAXBElement<YDate> value) {
        this.billDate = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDueDate(JAXBElement<YDate> value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the isDueOnReceipt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDueOnReceipt() {
        return isDueOnReceipt;
    }

    /**
     * Sets the value of the isDueOnReceipt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDueOnReceipt(JAXBElement<Long> value) {
        this.isDueOnReceipt = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the lastPayDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPayDate() {
        return lastPayDate;
    }

    /**
     * Sets the value of the lastPayDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPayDate(JAXBElement<YDate> value) {
        this.lastPayDate = value;
    }

    /**
     * Gets the value of the userPaymStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserPaymStatusId() {
        return userPaymStatusId;
    }

    /**
     * Sets the value of the userPaymStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserPaymStatusId(JAXBElement<Long> value) {
        this.userPaymStatusId = value;
    }

    /**
     * Gets the value of the userPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserPaymStatus() {
        return userPaymStatus;
    }

    /**
     * Sets the value of the userPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserPaymStatus(JAXBElement<String> value) {
        this.userPaymStatus = value;
    }

    /**
     * Gets the value of the localizedUserPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUserPaymStatus() {
        return localizedUserPaymStatus;
    }

    /**
     * Sets the value of the localizedUserPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUserPaymStatus(JAXBElement<String> value) {
        this.localizedUserPaymStatus = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the billingPlans property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBillingPlans() {
        return billingPlans;
    }

    /**
     * Sets the value of the billingPlans property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBillingPlans(JAXBElement<List> value) {
        this.billingPlans = value;
    }

    /**
     * Gets the value of the accountUsages property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getAccountUsages() {
        return accountUsages;
    }

    /**
     * Sets the value of the accountUsages property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setAccountUsages(JAXBElement<List> value) {
        this.accountUsages = value;
    }

    /**
     * Gets the value of the billCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBillCharges() {
        return billCharges;
    }

    /**
     * Sets the value of the billCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBillCharges(JAXBElement<List> value) {
        this.billCharges = value;
    }

    /**
     * Gets the value of the billContracts property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBillContracts() {
        return billContracts;
    }

    /**
     * Sets the value of the billContracts property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBillContracts(JAXBElement<List> value) {
        this.billContracts = value;
    }

    /**
     * Gets the value of the equipments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getEquipments() {
        return equipments;
    }

    /**
     * Sets the value of the equipments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setEquipments(JAXBElement<List> value) {
        this.equipments = value;
    }

    /**
     * Gets the value of the receiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getReceiveDate() {
        return receiveDate;
    }

    /**
     * Sets the value of the receiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setReceiveDate(JAXBElement<YDate> value) {
        this.receiveDate = value;
    }

}
