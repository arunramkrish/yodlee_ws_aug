
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;


/**
 * <p>Java class for BillContract complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillContract">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billContractId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billingAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="startDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="contractLength" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="endDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="contractFor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillContract", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "billContractId",
    "billId",
    "billingAccountId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "startDate",
    "contractLength",
    "description",
    "link",
    "endDate",
    "contractFor"
})
public class BillContract
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "billContractId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billContractId;
    @XmlElementRef(name = "billId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billId;
    @XmlElementRef(name = "billingAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billingAccountId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "startDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> startDate;
    @XmlElementRef(name = "contractLength", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> contractLength;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "endDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> endDate;
    @XmlElementRef(name = "contractFor", type = JAXBElement.class, required = false)
    protected JAXBElement<String> contractFor;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the billContractId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillContractId() {
        return billContractId;
    }

    /**
     * Sets the value of the billContractId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillContractId(JAXBElement<Long> value) {
        this.billContractId = value;
    }

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillId(JAXBElement<Long> value) {
        this.billId = value;
    }

    /**
     * Gets the value of the billingAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillingAccountId() {
        return billingAccountId;
    }

    /**
     * Sets the value of the billingAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillingAccountId(JAXBElement<Long> value) {
        this.billingAccountId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStartDate(JAXBElement<YDate> value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the contractLength property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getContractLength() {
        return contractLength;
    }

    /**
     * Sets the value of the contractLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setContractLength(JAXBElement<Double> value) {
        this.contractLength = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setEndDate(JAXBElement<YDate> value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the contractFor property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getContractFor() {
        return contractFor;
    }

    /**
     * Sets the value of the contractFor property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setContractFor(JAXBElement<String> value) {
        this.contractFor = value;
    }

}
