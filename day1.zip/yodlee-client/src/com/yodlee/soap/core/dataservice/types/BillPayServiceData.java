
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for BillPayServiceData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillPayServiceData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billPayServiceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="totalDueAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalMinAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalScheduledAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isScrapedBillpayEnrolled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="billListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="numPayees" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="asofDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="bills" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="bpsPayees" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPayServiceData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "acctTypeId",
    "acctType",
    "localizedAcctType",
    "srcElementId",
    "billPayServiceId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "totalDueAmount",
    "totalMinAmount",
    "totalScheduledAmount",
    "accountOpenDate",
    "accountCloseDate",
    "secondaryAccountHolderName",
    "accountNicknameAtSrcSite",
    "siteAccountStatus",
    "accountNumber",
    "accountName",
    "link",
    "isScrapedBillpayEnrolled",
    "accountHolder",
    "billListToDate",
    "billListFromDate",
    "numPayees",
    "asofDate",
    "bills",
    "bpsPayees",
    "created"
})
public class BillPayServiceData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "acctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctTypeId;
    @XmlElementRef(name = "acctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctType;
    @XmlElementRef(name = "localizedAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctType;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "billPayServiceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPayServiceId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "totalDueAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalDueAmount;
    @XmlElementRef(name = "totalMinAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalMinAmount;
    @XmlElementRef(name = "totalScheduledAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalScheduledAmount;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "isScrapedBillpayEnrolled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isScrapedBillpayEnrolled;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "billListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> billListToDate;
    @XmlElementRef(name = "billListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> billListFromDate;
    @XmlElementRef(name = "numPayees", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> numPayees;
    @XmlElementRef(name = "asofDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asofDate;
    @XmlElementRef(name = "bills", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bills;
    @XmlElementRef(name = "bpsPayees", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bpsPayees;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the acctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctTypeId() {
        return acctTypeId;
    }

    /**
     * Sets the value of the acctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctTypeId(JAXBElement<Long> value) {
        this.acctTypeId = value;
    }

    /**
     * Gets the value of the acctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctType() {
        return acctType;
    }

    /**
     * Sets the value of the acctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctType(JAXBElement<String> value) {
        this.acctType = value;
    }

    /**
     * Gets the value of the localizedAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctType() {
        return localizedAcctType;
    }

    /**
     * Sets the value of the localizedAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctType(JAXBElement<String> value) {
        this.localizedAcctType = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the billPayServiceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPayServiceId() {
        return billPayServiceId;
    }

    /**
     * Sets the value of the billPayServiceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPayServiceId(JAXBElement<Long> value) {
        this.billPayServiceId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the totalDueAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalDueAmount() {
        return totalDueAmount;
    }

    /**
     * Sets the value of the totalDueAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalDueAmount(JAXBElement<YMoney> value) {
        this.totalDueAmount = value;
    }

    /**
     * Gets the value of the totalMinAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalMinAmount() {
        return totalMinAmount;
    }

    /**
     * Sets the value of the totalMinAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalMinAmount(JAXBElement<YMoney> value) {
        this.totalMinAmount = value;
    }

    /**
     * Gets the value of the totalScheduledAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalScheduledAmount() {
        return totalScheduledAmount;
    }

    /**
     * Sets the value of the totalScheduledAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalScheduledAmount(JAXBElement<YMoney> value) {
        this.totalScheduledAmount = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the isScrapedBillpayEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsScrapedBillpayEnrolled() {
        return isScrapedBillpayEnrolled;
    }

    /**
     * Sets the value of the isScrapedBillpayEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsScrapedBillpayEnrolled(JAXBElement<Long> value) {
        this.isScrapedBillpayEnrolled = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the billListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getBillListToDate() {
        return billListToDate;
    }

    /**
     * Sets the value of the billListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setBillListToDate(JAXBElement<YDate> value) {
        this.billListToDate = value;
    }

    /**
     * Gets the value of the billListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getBillListFromDate() {
        return billListFromDate;
    }

    /**
     * Sets the value of the billListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setBillListFromDate(JAXBElement<YDate> value) {
        this.billListFromDate = value;
    }

    /**
     * Gets the value of the numPayees property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getNumPayees() {
        return numPayees;
    }

    /**
     * Sets the value of the numPayees property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setNumPayees(JAXBElement<Long> value) {
        this.numPayees = value;
    }

    /**
     * Gets the value of the asofDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsofDate() {
        return asofDate;
    }

    /**
     * Sets the value of the asofDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsofDate(JAXBElement<YDate> value) {
        this.asofDate = value;
    }

    /**
     * Gets the value of the bills property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBills() {
        return bills;
    }

    /**
     * Sets the value of the bills property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBills(JAXBElement<List> value) {
        this.bills = value;
    }

    /**
     * Gets the value of the bpsPayees property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBpsPayees() {
        return bpsPayees;
    }

    /**
     * Sets the value of the bpsPayees property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBpsPayees(JAXBElement<List> value) {
        this.bpsPayees = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

}
