
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for BillPreferenceData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillPreferenceData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="frequencyTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="frequencyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedFrequencyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billPreferenceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billAmountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="nextDueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="startDueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="billerPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerApartmentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerAddress1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="billerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillPreferenceData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "frequencyTypeId",
    "frequencyType",
    "localizedFrequencyType",
    "billPreferenceId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "billAmountDue",
    "nextDueDate",
    "startDueDate",
    "billerPhone",
    "billerApartmentNumber",
    "billerAddress2",
    "billerCountry",
    "billerProvince",
    "billerState",
    "billerZip",
    "billerAddress1",
    "billerCity",
    "billerEmail",
    "billerName",
    "link"
})
public class BillPreferenceData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "frequencyTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> frequencyTypeId;
    @XmlElementRef(name = "frequencyType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> frequencyType;
    @XmlElementRef(name = "localizedFrequencyType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedFrequencyType;
    @XmlElementRef(name = "billPreferenceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPreferenceId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "billAmountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> billAmountDue;
    @XmlElementRef(name = "nextDueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> nextDueDate;
    @XmlElementRef(name = "startDueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> startDueDate;
    @XmlElementRef(name = "billerPhone", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerPhone;
    @XmlElementRef(name = "billerApartmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerApartmentNumber;
    @XmlElementRef(name = "billerAddress2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerAddress2;
    @XmlElementRef(name = "billerCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerCountry;
    @XmlElementRef(name = "billerProvince", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerProvince;
    @XmlElementRef(name = "billerState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerState;
    @XmlElementRef(name = "billerZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerZip;
    @XmlElementRef(name = "billerAddress1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerAddress1;
    @XmlElementRef(name = "billerCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerCity;
    @XmlElementRef(name = "billerEmail", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerEmail;
    @XmlElementRef(name = "billerName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> billerName;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the frequencyTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getFrequencyTypeId() {
        return frequencyTypeId;
    }

    /**
     * Sets the value of the frequencyTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setFrequencyTypeId(JAXBElement<Long> value) {
        this.frequencyTypeId = value;
    }

    /**
     * Gets the value of the frequencyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFrequencyType() {
        return frequencyType;
    }

    /**
     * Sets the value of the frequencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFrequencyType(JAXBElement<String> value) {
        this.frequencyType = value;
    }

    /**
     * Gets the value of the localizedFrequencyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedFrequencyType() {
        return localizedFrequencyType;
    }

    /**
     * Sets the value of the localizedFrequencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedFrequencyType(JAXBElement<String> value) {
        this.localizedFrequencyType = value;
    }

    /**
     * Gets the value of the billPreferenceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPreferenceId() {
        return billPreferenceId;
    }

    /**
     * Sets the value of the billPreferenceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPreferenceId(JAXBElement<Long> value) {
        this.billPreferenceId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the billAmountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBillAmountDue() {
        return billAmountDue;
    }

    /**
     * Sets the value of the billAmountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBillAmountDue(JAXBElement<YMoney> value) {
        this.billAmountDue = value;
    }

    /**
     * Gets the value of the nextDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getNextDueDate() {
        return nextDueDate;
    }

    /**
     * Sets the value of the nextDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setNextDueDate(JAXBElement<YDate> value) {
        this.nextDueDate = value;
    }

    /**
     * Gets the value of the startDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStartDueDate() {
        return startDueDate;
    }

    /**
     * Sets the value of the startDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStartDueDate(JAXBElement<YDate> value) {
        this.startDueDate = value;
    }

    /**
     * Gets the value of the billerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerPhone() {
        return billerPhone;
    }

    /**
     * Sets the value of the billerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerPhone(JAXBElement<String> value) {
        this.billerPhone = value;
    }

    /**
     * Gets the value of the billerApartmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerApartmentNumber() {
        return billerApartmentNumber;
    }

    /**
     * Sets the value of the billerApartmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerApartmentNumber(JAXBElement<String> value) {
        this.billerApartmentNumber = value;
    }

    /**
     * Gets the value of the billerAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerAddress2() {
        return billerAddress2;
    }

    /**
     * Sets the value of the billerAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerAddress2(JAXBElement<String> value) {
        this.billerAddress2 = value;
    }

    /**
     * Gets the value of the billerCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerCountry() {
        return billerCountry;
    }

    /**
     * Sets the value of the billerCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerCountry(JAXBElement<String> value) {
        this.billerCountry = value;
    }

    /**
     * Gets the value of the billerProvince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerProvince() {
        return billerProvince;
    }

    /**
     * Sets the value of the billerProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerProvince(JAXBElement<String> value) {
        this.billerProvince = value;
    }

    /**
     * Gets the value of the billerState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerState() {
        return billerState;
    }

    /**
     * Sets the value of the billerState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerState(JAXBElement<String> value) {
        this.billerState = value;
    }

    /**
     * Gets the value of the billerZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerZip() {
        return billerZip;
    }

    /**
     * Sets the value of the billerZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerZip(JAXBElement<String> value) {
        this.billerZip = value;
    }

    /**
     * Gets the value of the billerAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerAddress1() {
        return billerAddress1;
    }

    /**
     * Sets the value of the billerAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerAddress1(JAXBElement<String> value) {
        this.billerAddress1 = value;
    }

    /**
     * Gets the value of the billerCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerCity() {
        return billerCity;
    }

    /**
     * Sets the value of the billerCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerCity(JAXBElement<String> value) {
        this.billerCity = value;
    }

    /**
     * Gets the value of the billerEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerEmail() {
        return billerEmail;
    }

    /**
     * Sets the value of the billerEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerEmail(JAXBElement<String> value) {
        this.billerEmail = value;
    }

    /**
     * Gets the value of the billerName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBillerName() {
        return billerName;
    }

    /**
     * Sets the value of the billerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBillerName(JAXBElement<String> value) {
        this.billerName = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

}
