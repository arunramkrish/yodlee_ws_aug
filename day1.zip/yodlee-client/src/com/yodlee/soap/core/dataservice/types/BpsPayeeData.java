
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for BpsPayeeData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BpsPayeeData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="remitAddressId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsPayeeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPayServiceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpaaDestServiceTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpaaDestServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBpaaDestServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertResponseErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="bpsUserIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInputAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isAccountNumPartial" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="nameOnAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="nickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastPaymAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isQuickPaymEnabled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpaaDestPaymAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isEbillSupported" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="removeBpaaStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedRemoveBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInputNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInputNameOnAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payeeResponseMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isEbillEnabled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="payeeCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertBpaaStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="convertBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedConvertBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsPayeeStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsPayeeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBpsPayeeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastPaymDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="convertedPayeeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payeeResponseIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="removeCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="payeeAdditionalInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcUniqueId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payeeResponseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInputPayeeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payeeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInputRemitAddressId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeResponseErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isExcluded" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsSchdPayms" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="bpsRecurPayms" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="remitAddress" type="{http://types.dataservice.core.soap.yodlee.com}RemitAddressData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BpsPayeeData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "remitAddressId",
    "bpsPayeeId",
    "billPayServiceId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "bpaaDestServiceTypeId",
    "bpaaDestServiceType",
    "localizedBpaaDestServiceType",
    "convertResponseErrorMsg",
    "convertDate",
    "bpsUserIdentifier",
    "accountNumber",
    "userInputAccountNumber",
    "isAccountNumPartial",
    "nameOnAccount",
    "paymAccountId",
    "nickName",
    "lastPaymAmount",
    "isQuickPaymEnabled",
    "bpaaDestPaymAccountId",
    "isEbillSupported",
    "removeDate",
    "removeBpaaStatusId",
    "removeBpaaStatus",
    "localizedRemoveBpaaStatus",
    "memo",
    "userInputNickName",
    "userInputNameOnAccount",
    "payeeResponseMessage",
    "isEbillEnabled",
    "payeeCategory",
    "convertBpaaStatusId",
    "convertBpaaStatus",
    "localizedConvertBpaaStatus",
    "convertCode",
    "bpsPayeeStatusId",
    "bpsPayeeStatus",
    "localizedBpsPayeeStatus",
    "lastPaymDate",
    "convertedPayeeName",
    "payeeResponseIdentifier",
    "removeCode",
    "payeeAdditionalInfo",
    "srcUniqueId",
    "payeeResponseCode",
    "userInputPayeeName",
    "payeeName",
    "userInputRemitAddressId",
    "removeResponseErrorMsg",
    "isExcluded",
    "bpsSchdPayms",
    "bpsRecurPayms",
    "remitAddress"
})
public class BpsPayeeData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "remitAddressId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> remitAddressId;
    @XmlElementRef(name = "bpsPayeeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpsPayeeId;
    @XmlElementRef(name = "billPayServiceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPayServiceId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "bpaaDestServiceTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpaaDestServiceTypeId;
    @XmlElementRef(name = "bpaaDestServiceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpaaDestServiceType;
    @XmlElementRef(name = "localizedBpaaDestServiceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBpaaDestServiceType;
    @XmlElementRef(name = "convertResponseErrorMsg", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertResponseErrorMsg;
    @XmlElementRef(name = "convertDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> convertDate;
    @XmlElementRef(name = "bpsUserIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpsUserIdentifier;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "userInputAccountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userInputAccountNumber;
    @XmlElementRef(name = "isAccountNumPartial", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isAccountNumPartial;
    @XmlElementRef(name = "nameOnAccount", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nameOnAccount;
    @XmlElementRef(name = "paymAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymAccountId;
    @XmlElementRef(name = "nickName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nickName;
    @XmlElementRef(name = "lastPaymAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPaymAmount;
    @XmlElementRef(name = "isQuickPaymEnabled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isQuickPaymEnabled;
    @XmlElementRef(name = "bpaaDestPaymAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpaaDestPaymAccountId;
    @XmlElementRef(name = "isEbillSupported", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isEbillSupported;
    @XmlElementRef(name = "removeDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> removeDate;
    @XmlElementRef(name = "removeBpaaStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> removeBpaaStatusId;
    @XmlElementRef(name = "removeBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> removeBpaaStatus;
    @XmlElementRef(name = "localizedRemoveBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedRemoveBpaaStatus;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "userInputNickName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userInputNickName;
    @XmlElementRef(name = "userInputNameOnAccount", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userInputNameOnAccount;
    @XmlElementRef(name = "payeeResponseMessage", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeResponseMessage;
    @XmlElementRef(name = "isEbillEnabled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isEbillEnabled;
    @XmlElementRef(name = "payeeCategory", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeCategory;
    @XmlElementRef(name = "convertBpaaStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> convertBpaaStatusId;
    @XmlElementRef(name = "convertBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertBpaaStatus;
    @XmlElementRef(name = "localizedConvertBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedConvertBpaaStatus;
    @XmlElementRef(name = "convertCode", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> convertCode;
    @XmlElementRef(name = "bpsPayeeStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpsPayeeStatusId;
    @XmlElementRef(name = "bpsPayeeStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpsPayeeStatus;
    @XmlElementRef(name = "localizedBpsPayeeStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBpsPayeeStatus;
    @XmlElementRef(name = "lastPaymDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPaymDate;
    @XmlElementRef(name = "convertedPayeeName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertedPayeeName;
    @XmlElementRef(name = "payeeResponseIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeResponseIdentifier;
    @XmlElementRef(name = "removeCode", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> removeCode;
    @XmlElementRef(name = "payeeAdditionalInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeAdditionalInfo;
    @XmlElementRef(name = "srcUniqueId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcUniqueId;
    @XmlElementRef(name = "payeeResponseCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeResponseCode;
    @XmlElementRef(name = "userInputPayeeName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userInputPayeeName;
    @XmlElementRef(name = "payeeName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payeeName;
    @XmlElementRef(name = "userInputRemitAddressId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userInputRemitAddressId;
    @XmlElementRef(name = "removeResponseErrorMsg", type = JAXBElement.class, required = false)
    protected JAXBElement<String> removeResponseErrorMsg;
    @XmlElementRef(name = "isExcluded", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExcluded;
    @XmlElementRef(name = "bpsSchdPayms", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bpsSchdPayms;
    @XmlElementRef(name = "bpsRecurPayms", type = JAXBElement.class, required = false)
    protected JAXBElement<List> bpsRecurPayms;
    @XmlElementRef(name = "remitAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<RemitAddressData> remitAddress;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the remitAddressId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRemitAddressId() {
        return remitAddressId;
    }

    /**
     * Sets the value of the remitAddressId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRemitAddressId(JAXBElement<Long> value) {
        this.remitAddressId = value;
    }

    /**
     * Gets the value of the bpsPayeeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpsPayeeId() {
        return bpsPayeeId;
    }

    /**
     * Sets the value of the bpsPayeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpsPayeeId(JAXBElement<Long> value) {
        this.bpsPayeeId = value;
    }

    /**
     * Gets the value of the billPayServiceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPayServiceId() {
        return billPayServiceId;
    }

    /**
     * Sets the value of the billPayServiceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPayServiceId(JAXBElement<Long> value) {
        this.billPayServiceId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the bpaaDestServiceTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpaaDestServiceTypeId() {
        return bpaaDestServiceTypeId;
    }

    /**
     * Sets the value of the bpaaDestServiceTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpaaDestServiceTypeId(JAXBElement<Long> value) {
        this.bpaaDestServiceTypeId = value;
    }

    /**
     * Gets the value of the bpaaDestServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpaaDestServiceType() {
        return bpaaDestServiceType;
    }

    /**
     * Sets the value of the bpaaDestServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpaaDestServiceType(JAXBElement<String> value) {
        this.bpaaDestServiceType = value;
    }

    /**
     * Gets the value of the localizedBpaaDestServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBpaaDestServiceType() {
        return localizedBpaaDestServiceType;
    }

    /**
     * Sets the value of the localizedBpaaDestServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBpaaDestServiceType(JAXBElement<String> value) {
        this.localizedBpaaDestServiceType = value;
    }

    /**
     * Gets the value of the convertResponseErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertResponseErrorMsg() {
        return convertResponseErrorMsg;
    }

    /**
     * Sets the value of the convertResponseErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertResponseErrorMsg(JAXBElement<String> value) {
        this.convertResponseErrorMsg = value;
    }

    /**
     * Gets the value of the convertDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getConvertDate() {
        return convertDate;
    }

    /**
     * Sets the value of the convertDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setConvertDate(JAXBElement<YDate> value) {
        this.convertDate = value;
    }

    /**
     * Gets the value of the bpsUserIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpsUserIdentifier() {
        return bpsUserIdentifier;
    }

    /**
     * Sets the value of the bpsUserIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpsUserIdentifier(JAXBElement<String> value) {
        this.bpsUserIdentifier = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the userInputAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserInputAccountNumber() {
        return userInputAccountNumber;
    }

    /**
     * Sets the value of the userInputAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserInputAccountNumber(JAXBElement<String> value) {
        this.userInputAccountNumber = value;
    }

    /**
     * Gets the value of the isAccountNumPartial property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsAccountNumPartial() {
        return isAccountNumPartial;
    }

    /**
     * Sets the value of the isAccountNumPartial property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsAccountNumPartial(JAXBElement<Long> value) {
        this.isAccountNumPartial = value;
    }

    /**
     * Gets the value of the nameOnAccount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNameOnAccount() {
        return nameOnAccount;
    }

    /**
     * Sets the value of the nameOnAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNameOnAccount(JAXBElement<String> value) {
        this.nameOnAccount = value;
    }

    /**
     * Gets the value of the paymAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymAccountId() {
        return paymAccountId;
    }

    /**
     * Sets the value of the paymAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymAccountId(JAXBElement<Long> value) {
        this.paymAccountId = value;
    }

    /**
     * Gets the value of the nickName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNickName() {
        return nickName;
    }

    /**
     * Sets the value of the nickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNickName(JAXBElement<String> value) {
        this.nickName = value;
    }

    /**
     * Gets the value of the lastPaymAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPaymAmount() {
        return lastPaymAmount;
    }

    /**
     * Sets the value of the lastPaymAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPaymAmount(JAXBElement<YMoney> value) {
        this.lastPaymAmount = value;
    }

    /**
     * Gets the value of the isQuickPaymEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsQuickPaymEnabled() {
        return isQuickPaymEnabled;
    }

    /**
     * Sets the value of the isQuickPaymEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsQuickPaymEnabled(JAXBElement<Long> value) {
        this.isQuickPaymEnabled = value;
    }

    /**
     * Gets the value of the bpaaDestPaymAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpaaDestPaymAccountId() {
        return bpaaDestPaymAccountId;
    }

    /**
     * Sets the value of the bpaaDestPaymAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpaaDestPaymAccountId(JAXBElement<Long> value) {
        this.bpaaDestPaymAccountId = value;
    }

    /**
     * Gets the value of the isEbillSupported property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsEbillSupported() {
        return isEbillSupported;
    }

    /**
     * Sets the value of the isEbillSupported property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsEbillSupported(JAXBElement<Long> value) {
        this.isEbillSupported = value;
    }

    /**
     * Gets the value of the removeDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getRemoveDate() {
        return removeDate;
    }

    /**
     * Sets the value of the removeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setRemoveDate(JAXBElement<YDate> value) {
        this.removeDate = value;
    }

    /**
     * Gets the value of the removeBpaaStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRemoveBpaaStatusId() {
        return removeBpaaStatusId;
    }

    /**
     * Sets the value of the removeBpaaStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRemoveBpaaStatusId(JAXBElement<Long> value) {
        this.removeBpaaStatusId = value;
    }

    /**
     * Gets the value of the removeBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRemoveBpaaStatus() {
        return removeBpaaStatus;
    }

    /**
     * Sets the value of the removeBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRemoveBpaaStatus(JAXBElement<String> value) {
        this.removeBpaaStatus = value;
    }

    /**
     * Gets the value of the localizedRemoveBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedRemoveBpaaStatus() {
        return localizedRemoveBpaaStatus;
    }

    /**
     * Sets the value of the localizedRemoveBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedRemoveBpaaStatus(JAXBElement<String> value) {
        this.localizedRemoveBpaaStatus = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the userInputNickName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserInputNickName() {
        return userInputNickName;
    }

    /**
     * Sets the value of the userInputNickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserInputNickName(JAXBElement<String> value) {
        this.userInputNickName = value;
    }

    /**
     * Gets the value of the userInputNameOnAccount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserInputNameOnAccount() {
        return userInputNameOnAccount;
    }

    /**
     * Sets the value of the userInputNameOnAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserInputNameOnAccount(JAXBElement<String> value) {
        this.userInputNameOnAccount = value;
    }

    /**
     * Gets the value of the payeeResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeResponseMessage() {
        return payeeResponseMessage;
    }

    /**
     * Sets the value of the payeeResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeResponseMessage(JAXBElement<String> value) {
        this.payeeResponseMessage = value;
    }

    /**
     * Gets the value of the isEbillEnabled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsEbillEnabled() {
        return isEbillEnabled;
    }

    /**
     * Sets the value of the isEbillEnabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsEbillEnabled(JAXBElement<Long> value) {
        this.isEbillEnabled = value;
    }

    /**
     * Gets the value of the payeeCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeCategory() {
        return payeeCategory;
    }

    /**
     * Sets the value of the payeeCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeCategory(JAXBElement<String> value) {
        this.payeeCategory = value;
    }

    /**
     * Gets the value of the convertBpaaStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getConvertBpaaStatusId() {
        return convertBpaaStatusId;
    }

    /**
     * Sets the value of the convertBpaaStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setConvertBpaaStatusId(JAXBElement<Long> value) {
        this.convertBpaaStatusId = value;
    }

    /**
     * Gets the value of the convertBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertBpaaStatus() {
        return convertBpaaStatus;
    }

    /**
     * Sets the value of the convertBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertBpaaStatus(JAXBElement<String> value) {
        this.convertBpaaStatus = value;
    }

    /**
     * Gets the value of the localizedConvertBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedConvertBpaaStatus() {
        return localizedConvertBpaaStatus;
    }

    /**
     * Sets the value of the localizedConvertBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedConvertBpaaStatus(JAXBElement<String> value) {
        this.localizedConvertBpaaStatus = value;
    }

    /**
     * Gets the value of the convertCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getConvertCode() {
        return convertCode;
    }

    /**
     * Sets the value of the convertCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setConvertCode(JAXBElement<Long> value) {
        this.convertCode = value;
    }

    /**
     * Gets the value of the bpsPayeeStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpsPayeeStatusId() {
        return bpsPayeeStatusId;
    }

    /**
     * Sets the value of the bpsPayeeStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpsPayeeStatusId(JAXBElement<Long> value) {
        this.bpsPayeeStatusId = value;
    }

    /**
     * Gets the value of the bpsPayeeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpsPayeeStatus() {
        return bpsPayeeStatus;
    }

    /**
     * Sets the value of the bpsPayeeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpsPayeeStatus(JAXBElement<String> value) {
        this.bpsPayeeStatus = value;
    }

    /**
     * Gets the value of the localizedBpsPayeeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBpsPayeeStatus() {
        return localizedBpsPayeeStatus;
    }

    /**
     * Sets the value of the localizedBpsPayeeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBpsPayeeStatus(JAXBElement<String> value) {
        this.localizedBpsPayeeStatus = value;
    }

    /**
     * Gets the value of the lastPaymDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPaymDate() {
        return lastPaymDate;
    }

    /**
     * Sets the value of the lastPaymDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPaymDate(JAXBElement<YDate> value) {
        this.lastPaymDate = value;
    }

    /**
     * Gets the value of the convertedPayeeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertedPayeeName() {
        return convertedPayeeName;
    }

    /**
     * Sets the value of the convertedPayeeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertedPayeeName(JAXBElement<String> value) {
        this.convertedPayeeName = value;
    }

    /**
     * Gets the value of the payeeResponseIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeResponseIdentifier() {
        return payeeResponseIdentifier;
    }

    /**
     * Sets the value of the payeeResponseIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeResponseIdentifier(JAXBElement<String> value) {
        this.payeeResponseIdentifier = value;
    }

    /**
     * Gets the value of the removeCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRemoveCode() {
        return removeCode;
    }

    /**
     * Sets the value of the removeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRemoveCode(JAXBElement<Long> value) {
        this.removeCode = value;
    }

    /**
     * Gets the value of the payeeAdditionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeAdditionalInfo() {
        return payeeAdditionalInfo;
    }

    /**
     * Sets the value of the payeeAdditionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeAdditionalInfo(JAXBElement<String> value) {
        this.payeeAdditionalInfo = value;
    }

    /**
     * Gets the value of the srcUniqueId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcUniqueId() {
        return srcUniqueId;
    }

    /**
     * Sets the value of the srcUniqueId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcUniqueId(JAXBElement<String> value) {
        this.srcUniqueId = value;
    }

    /**
     * Gets the value of the payeeResponseCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeResponseCode() {
        return payeeResponseCode;
    }

    /**
     * Sets the value of the payeeResponseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeResponseCode(JAXBElement<String> value) {
        this.payeeResponseCode = value;
    }

    /**
     * Gets the value of the userInputPayeeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserInputPayeeName() {
        return userInputPayeeName;
    }

    /**
     * Sets the value of the userInputPayeeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserInputPayeeName(JAXBElement<String> value) {
        this.userInputPayeeName = value;
    }

    /**
     * Gets the value of the payeeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayeeName() {
        return payeeName;
    }

    /**
     * Sets the value of the payeeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayeeName(JAXBElement<String> value) {
        this.payeeName = value;
    }

    /**
     * Gets the value of the userInputRemitAddressId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserInputRemitAddressId() {
        return userInputRemitAddressId;
    }

    /**
     * Sets the value of the userInputRemitAddressId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserInputRemitAddressId(JAXBElement<Long> value) {
        this.userInputRemitAddressId = value;
    }

    /**
     * Gets the value of the removeResponseErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRemoveResponseErrorMsg() {
        return removeResponseErrorMsg;
    }

    /**
     * Sets the value of the removeResponseErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRemoveResponseErrorMsg(JAXBElement<String> value) {
        this.removeResponseErrorMsg = value;
    }

    /**
     * Gets the value of the isExcluded property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExcluded() {
        return isExcluded;
    }

    /**
     * Sets the value of the isExcluded property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExcluded(JAXBElement<Long> value) {
        this.isExcluded = value;
    }

    /**
     * Gets the value of the bpsSchdPayms property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBpsSchdPayms() {
        return bpsSchdPayms;
    }

    /**
     * Sets the value of the bpsSchdPayms property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBpsSchdPayms(JAXBElement<List> value) {
        this.bpsSchdPayms = value;
    }

    /**
     * Gets the value of the bpsRecurPayms property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBpsRecurPayms() {
        return bpsRecurPayms;
    }

    /**
     * Sets the value of the bpsRecurPayms property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBpsRecurPayms(JAXBElement<List> value) {
        this.bpsRecurPayms = value;
    }

    /**
     * Gets the value of the remitAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link RemitAddressData }{@code >}
     *     
     */
    public JAXBElement<RemitAddressData> getRemitAddress() {
        return remitAddress;
    }

    /**
     * Sets the value of the remitAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link RemitAddressData }{@code >}
     *     
     */
    public void setRemitAddress(JAXBElement<RemitAddressData> value) {
        this.remitAddress = value;
    }

}
