
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for BpsSchdPaym complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BpsSchdPaym">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bpsSchdPaymId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsPayeeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymModelId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPaymModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bpaaDestServiceTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpaaDestServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBpaaDestServiceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertResponseErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="bpsUserIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="canEditPayment" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymResponseMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymResponseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bpaaDestPaymAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="removeBpaaStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedRemoveBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="confirmationNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertBpaaStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="convertBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedConvertBpaaStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="convertCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsSchdPaymStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bpsSchdPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBpsSchdPaymStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymResponseIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="removeCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="leadTime" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="convertedConfirmationNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isEbillPayment" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymAccountTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPaymAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="schdDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="canCancelPayment" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="removeResponseErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BpsSchdPaym", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "bpsSchdPaymId",
    "bpsPayeeId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "paymModelId",
    "paymModel",
    "localizedPaymModel",
    "bpaaDestServiceTypeId",
    "bpaaDestServiceType",
    "localizedBpaaDestServiceType",
    "convertResponseErrorMsg",
    "convertDate",
    "bpsUserIdentifier",
    "canEditPayment",
    "paymResponseMessage",
    "paymAccountId",
    "paymResponseCode",
    "bpaaDestPaymAccountId",
    "removeDate",
    "removeBpaaStatusId",
    "removeBpaaStatus",
    "localizedRemoveBpaaStatus",
    "confirmationNum",
    "memo",
    "convertBpaaStatusId",
    "convertBpaaStatus",
    "localizedConvertBpaaStatus",
    "convertCode",
    "bpsSchdPaymStatusId",
    "bpsSchdPaymStatus",
    "localizedBpsSchdPaymStatus",
    "paymResponseIdentifier",
    "removeCode",
    "leadTime",
    "convertedConfirmationNum",
    "paymAmount",
    "isEbillPayment",
    "paymAccountTypeId",
    "paymAccountType",
    "localizedPaymAccountType",
    "schdDate",
    "canCancelPayment",
    "removeResponseErrorMsg"
})
public class BpsSchdPaym
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "bpsSchdPaymId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpsSchdPaymId;
    @XmlElementRef(name = "bpsPayeeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpsPayeeId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "paymModelId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymModelId;
    @XmlElementRef(name = "paymModel", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymModel;
    @XmlElementRef(name = "localizedPaymModel", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPaymModel;
    @XmlElementRef(name = "bpaaDestServiceTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpaaDestServiceTypeId;
    @XmlElementRef(name = "bpaaDestServiceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpaaDestServiceType;
    @XmlElementRef(name = "localizedBpaaDestServiceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBpaaDestServiceType;
    @XmlElementRef(name = "convertResponseErrorMsg", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertResponseErrorMsg;
    @XmlElementRef(name = "convertDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> convertDate;
    @XmlElementRef(name = "bpsUserIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpsUserIdentifier;
    @XmlElementRef(name = "canEditPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> canEditPayment;
    @XmlElementRef(name = "paymResponseMessage", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymResponseMessage;
    @XmlElementRef(name = "paymAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymAccountId;
    @XmlElementRef(name = "paymResponseCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymResponseCode;
    @XmlElementRef(name = "bpaaDestPaymAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpaaDestPaymAccountId;
    @XmlElementRef(name = "removeDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> removeDate;
    @XmlElementRef(name = "removeBpaaStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> removeBpaaStatusId;
    @XmlElementRef(name = "removeBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> removeBpaaStatus;
    @XmlElementRef(name = "localizedRemoveBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedRemoveBpaaStatus;
    @XmlElementRef(name = "confirmationNum", type = JAXBElement.class, required = false)
    protected JAXBElement<String> confirmationNum;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "convertBpaaStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> convertBpaaStatusId;
    @XmlElementRef(name = "convertBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertBpaaStatus;
    @XmlElementRef(name = "localizedConvertBpaaStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedConvertBpaaStatus;
    @XmlElementRef(name = "convertCode", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> convertCode;
    @XmlElementRef(name = "bpsSchdPaymStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bpsSchdPaymStatusId;
    @XmlElementRef(name = "bpsSchdPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bpsSchdPaymStatus;
    @XmlElementRef(name = "localizedBpsSchdPaymStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBpsSchdPaymStatus;
    @XmlElementRef(name = "paymResponseIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymResponseIdentifier;
    @XmlElementRef(name = "removeCode", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> removeCode;
    @XmlElementRef(name = "leadTime", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> leadTime;
    @XmlElementRef(name = "convertedConfirmationNum", type = JAXBElement.class, required = false)
    protected JAXBElement<String> convertedConfirmationNum;
    @XmlElementRef(name = "paymAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> paymAmount;
    @XmlElementRef(name = "isEbillPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isEbillPayment;
    @XmlElementRef(name = "paymAccountTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymAccountTypeId;
    @XmlElementRef(name = "paymAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymAccountType;
    @XmlElementRef(name = "localizedPaymAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPaymAccountType;
    @XmlElementRef(name = "schdDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> schdDate;
    @XmlElementRef(name = "canCancelPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> canCancelPayment;
    @XmlElementRef(name = "removeResponseErrorMsg", type = JAXBElement.class, required = false)
    protected JAXBElement<String> removeResponseErrorMsg;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the bpsSchdPaymId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpsSchdPaymId() {
        return bpsSchdPaymId;
    }

    /**
     * Sets the value of the bpsSchdPaymId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpsSchdPaymId(JAXBElement<Long> value) {
        this.bpsSchdPaymId = value;
    }

    /**
     * Gets the value of the bpsPayeeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpsPayeeId() {
        return bpsPayeeId;
    }

    /**
     * Sets the value of the bpsPayeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpsPayeeId(JAXBElement<Long> value) {
        this.bpsPayeeId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the paymModelId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymModelId() {
        return paymModelId;
    }

    /**
     * Sets the value of the paymModelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymModelId(JAXBElement<Long> value) {
        this.paymModelId = value;
    }

    /**
     * Gets the value of the paymModel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymModel() {
        return paymModel;
    }

    /**
     * Sets the value of the paymModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymModel(JAXBElement<String> value) {
        this.paymModel = value;
    }

    /**
     * Gets the value of the localizedPaymModel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPaymModel() {
        return localizedPaymModel;
    }

    /**
     * Sets the value of the localizedPaymModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPaymModel(JAXBElement<String> value) {
        this.localizedPaymModel = value;
    }

    /**
     * Gets the value of the bpaaDestServiceTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpaaDestServiceTypeId() {
        return bpaaDestServiceTypeId;
    }

    /**
     * Sets the value of the bpaaDestServiceTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpaaDestServiceTypeId(JAXBElement<Long> value) {
        this.bpaaDestServiceTypeId = value;
    }

    /**
     * Gets the value of the bpaaDestServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpaaDestServiceType() {
        return bpaaDestServiceType;
    }

    /**
     * Sets the value of the bpaaDestServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpaaDestServiceType(JAXBElement<String> value) {
        this.bpaaDestServiceType = value;
    }

    /**
     * Gets the value of the localizedBpaaDestServiceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBpaaDestServiceType() {
        return localizedBpaaDestServiceType;
    }

    /**
     * Sets the value of the localizedBpaaDestServiceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBpaaDestServiceType(JAXBElement<String> value) {
        this.localizedBpaaDestServiceType = value;
    }

    /**
     * Gets the value of the convertResponseErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertResponseErrorMsg() {
        return convertResponseErrorMsg;
    }

    /**
     * Sets the value of the convertResponseErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertResponseErrorMsg(JAXBElement<String> value) {
        this.convertResponseErrorMsg = value;
    }

    /**
     * Gets the value of the convertDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getConvertDate() {
        return convertDate;
    }

    /**
     * Sets the value of the convertDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setConvertDate(JAXBElement<YDate> value) {
        this.convertDate = value;
    }

    /**
     * Gets the value of the bpsUserIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpsUserIdentifier() {
        return bpsUserIdentifier;
    }

    /**
     * Sets the value of the bpsUserIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpsUserIdentifier(JAXBElement<String> value) {
        this.bpsUserIdentifier = value;
    }

    /**
     * Gets the value of the canEditPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCanEditPayment() {
        return canEditPayment;
    }

    /**
     * Sets the value of the canEditPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCanEditPayment(JAXBElement<Long> value) {
        this.canEditPayment = value;
    }

    /**
     * Gets the value of the paymResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymResponseMessage() {
        return paymResponseMessage;
    }

    /**
     * Sets the value of the paymResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymResponseMessage(JAXBElement<String> value) {
        this.paymResponseMessage = value;
    }

    /**
     * Gets the value of the paymAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymAccountId() {
        return paymAccountId;
    }

    /**
     * Sets the value of the paymAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymAccountId(JAXBElement<Long> value) {
        this.paymAccountId = value;
    }

    /**
     * Gets the value of the paymResponseCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymResponseCode() {
        return paymResponseCode;
    }

    /**
     * Sets the value of the paymResponseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymResponseCode(JAXBElement<String> value) {
        this.paymResponseCode = value;
    }

    /**
     * Gets the value of the bpaaDestPaymAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpaaDestPaymAccountId() {
        return bpaaDestPaymAccountId;
    }

    /**
     * Sets the value of the bpaaDestPaymAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpaaDestPaymAccountId(JAXBElement<Long> value) {
        this.bpaaDestPaymAccountId = value;
    }

    /**
     * Gets the value of the removeDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getRemoveDate() {
        return removeDate;
    }

    /**
     * Sets the value of the removeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setRemoveDate(JAXBElement<YDate> value) {
        this.removeDate = value;
    }

    /**
     * Gets the value of the removeBpaaStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRemoveBpaaStatusId() {
        return removeBpaaStatusId;
    }

    /**
     * Sets the value of the removeBpaaStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRemoveBpaaStatusId(JAXBElement<Long> value) {
        this.removeBpaaStatusId = value;
    }

    /**
     * Gets the value of the removeBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRemoveBpaaStatus() {
        return removeBpaaStatus;
    }

    /**
     * Sets the value of the removeBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRemoveBpaaStatus(JAXBElement<String> value) {
        this.removeBpaaStatus = value;
    }

    /**
     * Gets the value of the localizedRemoveBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedRemoveBpaaStatus() {
        return localizedRemoveBpaaStatus;
    }

    /**
     * Sets the value of the localizedRemoveBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedRemoveBpaaStatus(JAXBElement<String> value) {
        this.localizedRemoveBpaaStatus = value;
    }

    /**
     * Gets the value of the confirmationNum property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConfirmationNum() {
        return confirmationNum;
    }

    /**
     * Sets the value of the confirmationNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConfirmationNum(JAXBElement<String> value) {
        this.confirmationNum = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the convertBpaaStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getConvertBpaaStatusId() {
        return convertBpaaStatusId;
    }

    /**
     * Sets the value of the convertBpaaStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setConvertBpaaStatusId(JAXBElement<Long> value) {
        this.convertBpaaStatusId = value;
    }

    /**
     * Gets the value of the convertBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertBpaaStatus() {
        return convertBpaaStatus;
    }

    /**
     * Sets the value of the convertBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertBpaaStatus(JAXBElement<String> value) {
        this.convertBpaaStatus = value;
    }

    /**
     * Gets the value of the localizedConvertBpaaStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedConvertBpaaStatus() {
        return localizedConvertBpaaStatus;
    }

    /**
     * Sets the value of the localizedConvertBpaaStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedConvertBpaaStatus(JAXBElement<String> value) {
        this.localizedConvertBpaaStatus = value;
    }

    /**
     * Gets the value of the convertCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getConvertCode() {
        return convertCode;
    }

    /**
     * Sets the value of the convertCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setConvertCode(JAXBElement<Long> value) {
        this.convertCode = value;
    }

    /**
     * Gets the value of the bpsSchdPaymStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBpsSchdPaymStatusId() {
        return bpsSchdPaymStatusId;
    }

    /**
     * Sets the value of the bpsSchdPaymStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBpsSchdPaymStatusId(JAXBElement<Long> value) {
        this.bpsSchdPaymStatusId = value;
    }

    /**
     * Gets the value of the bpsSchdPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBpsSchdPaymStatus() {
        return bpsSchdPaymStatus;
    }

    /**
     * Sets the value of the bpsSchdPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBpsSchdPaymStatus(JAXBElement<String> value) {
        this.bpsSchdPaymStatus = value;
    }

    /**
     * Gets the value of the localizedBpsSchdPaymStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBpsSchdPaymStatus() {
        return localizedBpsSchdPaymStatus;
    }

    /**
     * Sets the value of the localizedBpsSchdPaymStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBpsSchdPaymStatus(JAXBElement<String> value) {
        this.localizedBpsSchdPaymStatus = value;
    }

    /**
     * Gets the value of the paymResponseIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymResponseIdentifier() {
        return paymResponseIdentifier;
    }

    /**
     * Sets the value of the paymResponseIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymResponseIdentifier(JAXBElement<String> value) {
        this.paymResponseIdentifier = value;
    }

    /**
     * Gets the value of the removeCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRemoveCode() {
        return removeCode;
    }

    /**
     * Sets the value of the removeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRemoveCode(JAXBElement<Long> value) {
        this.removeCode = value;
    }

    /**
     * Gets the value of the leadTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLeadTime() {
        return leadTime;
    }

    /**
     * Sets the value of the leadTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLeadTime(JAXBElement<Long> value) {
        this.leadTime = value;
    }

    /**
     * Gets the value of the convertedConfirmationNum property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConvertedConfirmationNum() {
        return convertedConfirmationNum;
    }

    /**
     * Sets the value of the convertedConfirmationNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConvertedConfirmationNum(JAXBElement<String> value) {
        this.convertedConfirmationNum = value;
    }

    /**
     * Gets the value of the paymAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPaymAmount() {
        return paymAmount;
    }

    /**
     * Sets the value of the paymAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPaymAmount(JAXBElement<YMoney> value) {
        this.paymAmount = value;
    }

    /**
     * Gets the value of the isEbillPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsEbillPayment() {
        return isEbillPayment;
    }

    /**
     * Sets the value of the isEbillPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsEbillPayment(JAXBElement<Long> value) {
        this.isEbillPayment = value;
    }

    /**
     * Gets the value of the paymAccountTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymAccountTypeId() {
        return paymAccountTypeId;
    }

    /**
     * Sets the value of the paymAccountTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymAccountTypeId(JAXBElement<Long> value) {
        this.paymAccountTypeId = value;
    }

    /**
     * Gets the value of the paymAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymAccountType() {
        return paymAccountType;
    }

    /**
     * Sets the value of the paymAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymAccountType(JAXBElement<String> value) {
        this.paymAccountType = value;
    }

    /**
     * Gets the value of the localizedPaymAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPaymAccountType() {
        return localizedPaymAccountType;
    }

    /**
     * Sets the value of the localizedPaymAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPaymAccountType(JAXBElement<String> value) {
        this.localizedPaymAccountType = value;
    }

    /**
     * Gets the value of the schdDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getSchdDate() {
        return schdDate;
    }

    /**
     * Sets the value of the schdDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setSchdDate(JAXBElement<YDate> value) {
        this.schdDate = value;
    }

    /**
     * Gets the value of the canCancelPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCanCancelPayment() {
        return canCancelPayment;
    }

    /**
     * Sets the value of the canCancelPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCanCancelPayment(JAXBElement<Long> value) {
        this.canCancelPayment = value;
    }

    /**
     * Gets the value of the removeResponseErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRemoveResponseErrorMsg() {
        return removeResponseErrorMsg;
    }

    /**
     * Sets the value of the removeResponseErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRemoveResponseErrorMsg(JAXBElement<String> value) {
        this.removeResponseErrorMsg = value;
    }

}
