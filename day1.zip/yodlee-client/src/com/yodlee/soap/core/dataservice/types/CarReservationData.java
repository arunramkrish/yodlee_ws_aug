
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for CarReservationData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CarReservationData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="carResId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="resId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="taxInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="optionalEquipment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocStreet2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocFullAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocStreet1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocFax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plocCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dropoffDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="carDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="overTimeInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="weeklyRate" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="carType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rateDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="confirmationNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numDrivers" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="pickupDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isTaxIncluded" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="maxDistance" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="dlocPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocStreet2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocFullAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocStreet1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocFax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dlocCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalTax" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cancelPolicy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="travelRule" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="changePolicy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="companyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="statusInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaid" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isConfirmed" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="distanceUnitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="distanceUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDistanceUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numDays" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="dailyRate" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="customerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="companyPhone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="carrier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalCost" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="overDistanceInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CarReservationData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "plocCode",
    "dlocCode",
    "carResId",
    "resId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "taxInfo",
    "optionalEquipment",
    "plocPhone",
    "plocStreet2",
    "plocCountry",
    "plocEmail",
    "plocState",
    "plocFullAddress",
    "plocZip",
    "plocStreet1",
    "plocFax",
    "plocName",
    "plocCity",
    "dropoffDate",
    "carDescription",
    "overTimeInfo",
    "weeklyRate",
    "customDescription",
    "carType",
    "rateDescription",
    "confirmationNo",
    "numDrivers",
    "pickupDate",
    "isTaxIncluded",
    "maxDistance",
    "dlocPhone",
    "dlocStreet2",
    "dlocCountry",
    "dlocEmail",
    "dlocState",
    "dlocFullAddress",
    "dlocZip",
    "dlocStreet1",
    "dlocFax",
    "dlocName",
    "dlocCity",
    "totalTax",
    "cancelPolicy",
    "travelRule",
    "changePolicy",
    "link",
    "customName",
    "companyName",
    "statusInfo",
    "isPaid",
    "isConfirmed",
    "distanceUnitId",
    "distanceUnit",
    "localizedDistanceUnit",
    "numDays",
    "dailyRate",
    "customerName",
    "companyPhone",
    "carrier",
    "totalCost",
    "overDistanceInfo"
})
public class CarReservationData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "plocCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocCode;
    @XmlElementRef(name = "dlocCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocCode;
    @XmlElementRef(name = "carResId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> carResId;
    @XmlElementRef(name = "resId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> resId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "taxInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> taxInfo;
    @XmlElementRef(name = "optionalEquipment", type = JAXBElement.class, required = false)
    protected JAXBElement<String> optionalEquipment;
    @XmlElementRef(name = "plocPhone", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocPhone;
    @XmlElementRef(name = "plocStreet2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocStreet2;
    @XmlElementRef(name = "plocCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocCountry;
    @XmlElementRef(name = "plocEmail", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocEmail;
    @XmlElementRef(name = "plocState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocState;
    @XmlElementRef(name = "plocFullAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocFullAddress;
    @XmlElementRef(name = "plocZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocZip;
    @XmlElementRef(name = "plocStreet1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocStreet1;
    @XmlElementRef(name = "plocFax", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocFax;
    @XmlElementRef(name = "plocName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocName;
    @XmlElementRef(name = "plocCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plocCity;
    @XmlElementRef(name = "dropoffDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dropoffDate;
    @XmlElementRef(name = "carDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> carDescription;
    @XmlElementRef(name = "overTimeInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> overTimeInfo;
    @XmlElementRef(name = "weeklyRate", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> weeklyRate;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "carType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> carType;
    @XmlElementRef(name = "rateDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> rateDescription;
    @XmlElementRef(name = "confirmationNo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> confirmationNo;
    @XmlElementRef(name = "numDrivers", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> numDrivers;
    @XmlElementRef(name = "pickupDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> pickupDate;
    @XmlElementRef(name = "isTaxIncluded", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isTaxIncluded;
    @XmlElementRef(name = "maxDistance", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> maxDistance;
    @XmlElementRef(name = "dlocPhone", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocPhone;
    @XmlElementRef(name = "dlocStreet2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocStreet2;
    @XmlElementRef(name = "dlocCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocCountry;
    @XmlElementRef(name = "dlocEmail", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocEmail;
    @XmlElementRef(name = "dlocState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocState;
    @XmlElementRef(name = "dlocFullAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocFullAddress;
    @XmlElementRef(name = "dlocZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocZip;
    @XmlElementRef(name = "dlocStreet1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocStreet1;
    @XmlElementRef(name = "dlocFax", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocFax;
    @XmlElementRef(name = "dlocName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocName;
    @XmlElementRef(name = "dlocCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dlocCity;
    @XmlElementRef(name = "totalTax", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalTax;
    @XmlElementRef(name = "cancelPolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cancelPolicy;
    @XmlElementRef(name = "travelRule", type = JAXBElement.class, required = false)
    protected JAXBElement<String> travelRule;
    @XmlElementRef(name = "changePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<String> changePolicy;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "companyName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> companyName;
    @XmlElementRef(name = "statusInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> statusInfo;
    @XmlElementRef(name = "isPaid", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaid;
    @XmlElementRef(name = "isConfirmed", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isConfirmed;
    @XmlElementRef(name = "distanceUnitId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> distanceUnitId;
    @XmlElementRef(name = "distanceUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> distanceUnit;
    @XmlElementRef(name = "localizedDistanceUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDistanceUnit;
    @XmlElementRef(name = "numDays", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> numDays;
    @XmlElementRef(name = "dailyRate", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dailyRate;
    @XmlElementRef(name = "customerName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customerName;
    @XmlElementRef(name = "companyPhone", type = JAXBElement.class, required = false)
    protected JAXBElement<String> companyPhone;
    @XmlElementRef(name = "carrier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> carrier;
    @XmlElementRef(name = "totalCost", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCost;
    @XmlElementRef(name = "overDistanceInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> overDistanceInfo;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the plocCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocCode() {
        return plocCode;
    }

    /**
     * Sets the value of the plocCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocCode(JAXBElement<String> value) {
        this.plocCode = value;
    }

    /**
     * Gets the value of the dlocCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocCode() {
        return dlocCode;
    }

    /**
     * Sets the value of the dlocCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocCode(JAXBElement<String> value) {
        this.dlocCode = value;
    }

    /**
     * Gets the value of the carResId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCarResId() {
        return carResId;
    }

    /**
     * Sets the value of the carResId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCarResId(JAXBElement<Long> value) {
        this.carResId = value;
    }

    /**
     * Gets the value of the resId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getResId() {
        return resId;
    }

    /**
     * Sets the value of the resId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setResId(JAXBElement<Long> value) {
        this.resId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the taxInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTaxInfo() {
        return taxInfo;
    }

    /**
     * Sets the value of the taxInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTaxInfo(JAXBElement<String> value) {
        this.taxInfo = value;
    }

    /**
     * Gets the value of the optionalEquipment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOptionalEquipment() {
        return optionalEquipment;
    }

    /**
     * Sets the value of the optionalEquipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOptionalEquipment(JAXBElement<String> value) {
        this.optionalEquipment = value;
    }

    /**
     * Gets the value of the plocPhone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocPhone() {
        return plocPhone;
    }

    /**
     * Sets the value of the plocPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocPhone(JAXBElement<String> value) {
        this.plocPhone = value;
    }

    /**
     * Gets the value of the plocStreet2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocStreet2() {
        return plocStreet2;
    }

    /**
     * Sets the value of the plocStreet2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocStreet2(JAXBElement<String> value) {
        this.plocStreet2 = value;
    }

    /**
     * Gets the value of the plocCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocCountry() {
        return plocCountry;
    }

    /**
     * Sets the value of the plocCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocCountry(JAXBElement<String> value) {
        this.plocCountry = value;
    }

    /**
     * Gets the value of the plocEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocEmail() {
        return plocEmail;
    }

    /**
     * Sets the value of the plocEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocEmail(JAXBElement<String> value) {
        this.plocEmail = value;
    }

    /**
     * Gets the value of the plocState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocState() {
        return plocState;
    }

    /**
     * Sets the value of the plocState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocState(JAXBElement<String> value) {
        this.plocState = value;
    }

    /**
     * Gets the value of the plocFullAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocFullAddress() {
        return plocFullAddress;
    }

    /**
     * Sets the value of the plocFullAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocFullAddress(JAXBElement<String> value) {
        this.plocFullAddress = value;
    }

    /**
     * Gets the value of the plocZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocZip() {
        return plocZip;
    }

    /**
     * Sets the value of the plocZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocZip(JAXBElement<String> value) {
        this.plocZip = value;
    }

    /**
     * Gets the value of the plocStreet1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocStreet1() {
        return plocStreet1;
    }

    /**
     * Sets the value of the plocStreet1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocStreet1(JAXBElement<String> value) {
        this.plocStreet1 = value;
    }

    /**
     * Gets the value of the plocFax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocFax() {
        return plocFax;
    }

    /**
     * Sets the value of the plocFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocFax(JAXBElement<String> value) {
        this.plocFax = value;
    }

    /**
     * Gets the value of the plocName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocName() {
        return plocName;
    }

    /**
     * Sets the value of the plocName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocName(JAXBElement<String> value) {
        this.plocName = value;
    }

    /**
     * Gets the value of the plocCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlocCity() {
        return plocCity;
    }

    /**
     * Sets the value of the plocCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlocCity(JAXBElement<String> value) {
        this.plocCity = value;
    }

    /**
     * Gets the value of the dropoffDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDropoffDate() {
        return dropoffDate;
    }

    /**
     * Sets the value of the dropoffDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDropoffDate(JAXBElement<YDate> value) {
        this.dropoffDate = value;
    }

    /**
     * Gets the value of the carDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCarDescription() {
        return carDescription;
    }

    /**
     * Sets the value of the carDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCarDescription(JAXBElement<String> value) {
        this.carDescription = value;
    }

    /**
     * Gets the value of the overTimeInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOverTimeInfo() {
        return overTimeInfo;
    }

    /**
     * Sets the value of the overTimeInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOverTimeInfo(JAXBElement<String> value) {
        this.overTimeInfo = value;
    }

    /**
     * Gets the value of the weeklyRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getWeeklyRate() {
        return weeklyRate;
    }

    /**
     * Sets the value of the weeklyRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setWeeklyRate(JAXBElement<YMoney> value) {
        this.weeklyRate = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the carType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCarType() {
        return carType;
    }

    /**
     * Sets the value of the carType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCarType(JAXBElement<String> value) {
        this.carType = value;
    }

    /**
     * Gets the value of the rateDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRateDescription() {
        return rateDescription;
    }

    /**
     * Sets the value of the rateDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRateDescription(JAXBElement<String> value) {
        this.rateDescription = value;
    }

    /**
     * Gets the value of the confirmationNo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConfirmationNo() {
        return confirmationNo;
    }

    /**
     * Sets the value of the confirmationNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConfirmationNo(JAXBElement<String> value) {
        this.confirmationNo = value;
    }

    /**
     * Gets the value of the numDrivers property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getNumDrivers() {
        return numDrivers;
    }

    /**
     * Sets the value of the numDrivers property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setNumDrivers(JAXBElement<Long> value) {
        this.numDrivers = value;
    }

    /**
     * Gets the value of the pickupDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPickupDate() {
        return pickupDate;
    }

    /**
     * Sets the value of the pickupDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPickupDate(JAXBElement<YDate> value) {
        this.pickupDate = value;
    }

    /**
     * Gets the value of the isTaxIncluded property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsTaxIncluded() {
        return isTaxIncluded;
    }

    /**
     * Sets the value of the isTaxIncluded property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsTaxIncluded(JAXBElement<Long> value) {
        this.isTaxIncluded = value;
    }

    /**
     * Gets the value of the maxDistance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getMaxDistance() {
        return maxDistance;
    }

    /**
     * Sets the value of the maxDistance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setMaxDistance(JAXBElement<Double> value) {
        this.maxDistance = value;
    }

    /**
     * Gets the value of the dlocPhone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocPhone() {
        return dlocPhone;
    }

    /**
     * Sets the value of the dlocPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocPhone(JAXBElement<String> value) {
        this.dlocPhone = value;
    }

    /**
     * Gets the value of the dlocStreet2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocStreet2() {
        return dlocStreet2;
    }

    /**
     * Sets the value of the dlocStreet2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocStreet2(JAXBElement<String> value) {
        this.dlocStreet2 = value;
    }

    /**
     * Gets the value of the dlocCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocCountry() {
        return dlocCountry;
    }

    /**
     * Sets the value of the dlocCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocCountry(JAXBElement<String> value) {
        this.dlocCountry = value;
    }

    /**
     * Gets the value of the dlocEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocEmail() {
        return dlocEmail;
    }

    /**
     * Sets the value of the dlocEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocEmail(JAXBElement<String> value) {
        this.dlocEmail = value;
    }

    /**
     * Gets the value of the dlocState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocState() {
        return dlocState;
    }

    /**
     * Sets the value of the dlocState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocState(JAXBElement<String> value) {
        this.dlocState = value;
    }

    /**
     * Gets the value of the dlocFullAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocFullAddress() {
        return dlocFullAddress;
    }

    /**
     * Sets the value of the dlocFullAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocFullAddress(JAXBElement<String> value) {
        this.dlocFullAddress = value;
    }

    /**
     * Gets the value of the dlocZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocZip() {
        return dlocZip;
    }

    /**
     * Sets the value of the dlocZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocZip(JAXBElement<String> value) {
        this.dlocZip = value;
    }

    /**
     * Gets the value of the dlocStreet1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocStreet1() {
        return dlocStreet1;
    }

    /**
     * Sets the value of the dlocStreet1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocStreet1(JAXBElement<String> value) {
        this.dlocStreet1 = value;
    }

    /**
     * Gets the value of the dlocFax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocFax() {
        return dlocFax;
    }

    /**
     * Sets the value of the dlocFax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocFax(JAXBElement<String> value) {
        this.dlocFax = value;
    }

    /**
     * Gets the value of the dlocName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocName() {
        return dlocName;
    }

    /**
     * Sets the value of the dlocName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocName(JAXBElement<String> value) {
        this.dlocName = value;
    }

    /**
     * Gets the value of the dlocCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDlocCity() {
        return dlocCity;
    }

    /**
     * Sets the value of the dlocCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDlocCity(JAXBElement<String> value) {
        this.dlocCity = value;
    }

    /**
     * Gets the value of the totalTax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalTax() {
        return totalTax;
    }

    /**
     * Sets the value of the totalTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalTax(JAXBElement<YMoney> value) {
        this.totalTax = value;
    }

    /**
     * Gets the value of the cancelPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCancelPolicy() {
        return cancelPolicy;
    }

    /**
     * Sets the value of the cancelPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCancelPolicy(JAXBElement<String> value) {
        this.cancelPolicy = value;
    }

    /**
     * Gets the value of the travelRule property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTravelRule() {
        return travelRule;
    }

    /**
     * Sets the value of the travelRule property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTravelRule(JAXBElement<String> value) {
        this.travelRule = value;
    }

    /**
     * Gets the value of the changePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getChangePolicy() {
        return changePolicy;
    }

    /**
     * Sets the value of the changePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setChangePolicy(JAXBElement<String> value) {
        this.changePolicy = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyName(JAXBElement<String> value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the statusInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStatusInfo() {
        return statusInfo;
    }

    /**
     * Sets the value of the statusInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStatusInfo(JAXBElement<String> value) {
        this.statusInfo = value;
    }

    /**
     * Gets the value of the isPaid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaid() {
        return isPaid;
    }

    /**
     * Sets the value of the isPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaid(JAXBElement<Long> value) {
        this.isPaid = value;
    }

    /**
     * Gets the value of the isConfirmed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsConfirmed() {
        return isConfirmed;
    }

    /**
     * Sets the value of the isConfirmed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsConfirmed(JAXBElement<Long> value) {
        this.isConfirmed = value;
    }

    /**
     * Gets the value of the distanceUnitId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDistanceUnitId() {
        return distanceUnitId;
    }

    /**
     * Sets the value of the distanceUnitId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDistanceUnitId(JAXBElement<Long> value) {
        this.distanceUnitId = value;
    }

    /**
     * Gets the value of the distanceUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDistanceUnit() {
        return distanceUnit;
    }

    /**
     * Sets the value of the distanceUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDistanceUnit(JAXBElement<String> value) {
        this.distanceUnit = value;
    }

    /**
     * Gets the value of the localizedDistanceUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDistanceUnit() {
        return localizedDistanceUnit;
    }

    /**
     * Sets the value of the localizedDistanceUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDistanceUnit(JAXBElement<String> value) {
        this.localizedDistanceUnit = value;
    }

    /**
     * Gets the value of the numDays property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getNumDays() {
        return numDays;
    }

    /**
     * Sets the value of the numDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setNumDays(JAXBElement<Long> value) {
        this.numDays = value;
    }

    /**
     * Gets the value of the dailyRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDailyRate() {
        return dailyRate;
    }

    /**
     * Sets the value of the dailyRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDailyRate(JAXBElement<YMoney> value) {
        this.dailyRate = value;
    }

    /**
     * Gets the value of the customerName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomerName() {
        return customerName;
    }

    /**
     * Sets the value of the customerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomerName(JAXBElement<String> value) {
        this.customerName = value;
    }

    /**
     * Gets the value of the companyPhone property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyPhone() {
        return companyPhone;
    }

    /**
     * Sets the value of the companyPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyPhone(JAXBElement<String> value) {
        this.companyPhone = value;
    }

    /**
     * Gets the value of the carrier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCarrier() {
        return carrier;
    }

    /**
     * Sets the value of the carrier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCarrier(JAXBElement<String> value) {
        this.carrier = value;
    }

    /**
     * Gets the value of the totalCost property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCost() {
        return totalCost;
    }

    /**
     * Sets the value of the totalCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCost(JAXBElement<YMoney> value) {
        this.totalCost = value;
    }

    /**
     * Gets the value of the overDistanceInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOverDistanceInfo() {
        return overDistanceInfo;
    }

    /**
     * Sets the value of the overDistanceInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOverDistanceInfo(JAXBElement<String> value) {
        this.overDistanceInfo = value;
    }

}
