
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.common.CardType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.AccountClassification;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for CardData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetupId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPreferenceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="individualInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="cardAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayEnrolled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cashApr" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tranListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="tranListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="company" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="amountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="minPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="runningBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="newCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="payments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustmentsPayments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pendingCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="lastPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="disputedAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableCredit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableCash" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalCreditLine" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalCashLimit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidThisPeriod" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="asofDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="dueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastPaymentDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDerivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stmtListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="stmtListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="apr" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUserAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isExtAutopayScraped" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="extAutopaySetup" type="{http://types.dataservice.core.soap.yodlee.com}ExtAutopaySetupData" minOccurs="0"/>
 *         &lt;element name="cardTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="cardStatements" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="billPreference" type="{http://types.dataservice.core.soap.yodlee.com}BillPreferenceData" minOccurs="0"/>
 *         &lt;element name="paymentDetails" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="balanceTransfers" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="individualInformation" type="{http://types.dataservice.core.soap.yodlee.com}IndividualInformation" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaperlessStmtOn" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="straightBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="budgetBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountClassification" type="{http://enums.dataservice.core.soap.yodlee.com}AccountClassification" minOccurs="0"/>
 *         &lt;element name="cardType" type="{http://common.soap.yodlee.com}CardType" minOccurs="0"/>
 *         &lt;element name="srcAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcAccountIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pendingAuthorizonAmt" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="straightPendingcharge" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="budgetPendingCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="straightAvailableBal" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="budgetAvailableBal" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="budgetCreditLine" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="straightCreditLine" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "acctTypeId",
    "acctType",
    "localizedAcctType",
    "srcElementId",
    "extAutopaySetupId",
    "billPreferenceId",
    "individualInformationId",
    "cardAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "isExtAutopayEnrolled",
    "accountNumber",
    "cashApr",
    "accountHolder",
    "tranListToDate",
    "tranListFromDate",
    "company",
    "amountDue",
    "minPayment",
    "runningBalance",
    "newCharges",
    "payments",
    "adjustments",
    "adjustmentsPayments",
    "pendingCharges",
    "lastPayment",
    "disputedAmount",
    "availableCredit",
    "availableCash",
    "totalCreditLine",
    "totalCashLimit",
    "interestPaidThisPeriod",
    "interestPaidYtd",
    "userAutopayEnrollmentStatusLastUpdated",
    "asofDate",
    "dueDate",
    "link",
    "lastPaymentDate",
    "derivedAutopayEnrollmentStatusId",
    "derivedAutopayEnrollmentStatus",
    "localizedDerivedAutopayEnrollmentStatus",
    "stmtListToDate",
    "stmtListFromDate",
    "apr",
    "accountName",
    "userAutopayEnrollmentStatusId",
    "userAutopayEnrollmentStatus",
    "localizedUserAutopayEnrollmentStatus",
    "derivedAutopayEnrollmentStatusLastUpdated",
    "autopayEnrollmentStatusId",
    "autopayEnrollmentStatus",
    "localizedAutopayEnrollmentStatus",
    "isExtAutopayScraped",
    "extAutopaySetup",
    "cardTransactions",
    "cardStatements",
    "billPreference",
    "paymentDetails",
    "balanceTransfers",
    "individualInformation",
    "accountNicknameAtSrcSite",
    "isPaperlessStmtOn",
    "siteAccountStatus",
    "created",
    "accountOpenDate",
    "accountCloseDate",
    "straightBalance",
    "budgetBalance",
    "secondaryAccountHolderName",
    "accountClassification",
    "cardType",
    "srcAccountType",
    "srcAccountIdentifier",
    "pendingAuthorizonAmt",
    "straightPendingcharge",
    "budgetPendingCharges",
    "straightAvailableBal",
    "budgetAvailableBal",
    "budgetCreditLine",
    "straightCreditLine"
})
public class CardData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "acctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctTypeId;
    @XmlElementRef(name = "acctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctType;
    @XmlElementRef(name = "localizedAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctType;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "extAutopaySetupId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extAutopaySetupId;
    @XmlElementRef(name = "billPreferenceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPreferenceId;
    @XmlElementRef(name = "individualInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> individualInformationId;
    @XmlElementRef(name = "cardAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cardAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "isExtAutopayEnrolled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayEnrolled;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "cashApr", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> cashApr;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "tranListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListToDate;
    @XmlElementRef(name = "tranListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListFromDate;
    @XmlElementRef(name = "company", type = JAXBElement.class, required = false)
    protected JAXBElement<String> company;
    @XmlElementRef(name = "amountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountDue;
    @XmlElementRef(name = "minPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> minPayment;
    @XmlElementRef(name = "runningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> runningBalance;
    @XmlElementRef(name = "newCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> newCharges;
    @XmlElementRef(name = "payments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> payments;
    @XmlElementRef(name = "adjustments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustments;
    @XmlElementRef(name = "adjustmentsPayments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustmentsPayments;
    @XmlElementRef(name = "pendingCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pendingCharges;
    @XmlElementRef(name = "lastPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPayment;
    @XmlElementRef(name = "disputedAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> disputedAmount;
    @XmlElementRef(name = "availableCredit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableCredit;
    @XmlElementRef(name = "availableCash", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableCash;
    @XmlElementRef(name = "totalCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCreditLine;
    @XmlElementRef(name = "totalCashLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCashLimit;
    @XmlElementRef(name = "interestPaidThisPeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidThisPeriod;
    @XmlElementRef(name = "interestPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidYtd;
    @XmlElementRef(name = "userAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "asofDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asofDate;
    @XmlElementRef(name = "dueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dueDate;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "lastPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPaymentDate;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusId;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> derivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedDerivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDerivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "stmtListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListToDate;
    @XmlElementRef(name = "stmtListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListFromDate;
    @XmlElementRef(name = "apr", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> apr;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "userAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusId;
    @XmlElementRef(name = "userAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedUserAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUserAutopayEnrollmentStatus;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "autopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> autopayEnrollmentStatusId;
    @XmlElementRef(name = "autopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> autopayEnrollmentStatus;
    @XmlElementRef(name = "localizedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAutopayEnrollmentStatus;
    @XmlElementRef(name = "isExtAutopayScraped", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayScraped;
    @XmlElementRef(name = "extAutopaySetup", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtAutopaySetupData> extAutopaySetup;
    @XmlElementRef(name = "cardTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> cardTransactions;
    @XmlElementRef(name = "cardStatements", type = JAXBElement.class, required = false)
    protected JAXBElement<List> cardStatements;
    @XmlElementRef(name = "billPreference", type = JAXBElement.class, required = false)
    protected JAXBElement<BillPreferenceData> billPreference;
    @XmlElementRef(name = "paymentDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<List> paymentDetails;
    @XmlElementRef(name = "balanceTransfers", type = JAXBElement.class, required = false)
    protected JAXBElement<List> balanceTransfers;
    @XmlElementRef(name = "individualInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<IndividualInformation> individualInformation;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "isPaperlessStmtOn", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaperlessStmtOn;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "straightBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> straightBalance;
    @XmlElementRef(name = "budgetBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> budgetBalance;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "accountClassification", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountClassification> accountClassification;
    @XmlElementRef(name = "cardType", type = JAXBElement.class, required = false)
    protected JAXBElement<CardType> cardType;
    @XmlElementRef(name = "srcAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcAccountType;
    @XmlElementRef(name = "srcAccountIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcAccountIdentifier;
    @XmlElementRef(name = "pendingAuthorizonAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pendingAuthorizonAmt;
    @XmlElementRef(name = "straightPendingcharge", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> straightPendingcharge;
    @XmlElementRef(name = "budgetPendingCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> budgetPendingCharges;
    @XmlElementRef(name = "straightAvailableBal", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> straightAvailableBal;
    @XmlElementRef(name = "budgetAvailableBal", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> budgetAvailableBal;
    @XmlElementRef(name = "budgetCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> budgetCreditLine;
    @XmlElementRef(name = "straightCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> straightCreditLine;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the acctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctTypeId() {
        return acctTypeId;
    }

    /**
     * Sets the value of the acctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctTypeId(JAXBElement<Long> value) {
        this.acctTypeId = value;
    }

    /**
     * Gets the value of the acctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctType() {
        return acctType;
    }

    /**
     * Sets the value of the acctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctType(JAXBElement<String> value) {
        this.acctType = value;
    }

    /**
     * Gets the value of the localizedAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctType() {
        return localizedAcctType;
    }

    /**
     * Sets the value of the localizedAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctType(JAXBElement<String> value) {
        this.localizedAcctType = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the extAutopaySetupId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtAutopaySetupId() {
        return extAutopaySetupId;
    }

    /**
     * Sets the value of the extAutopaySetupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtAutopaySetupId(JAXBElement<Long> value) {
        this.extAutopaySetupId = value;
    }

    /**
     * Gets the value of the billPreferenceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPreferenceId() {
        return billPreferenceId;
    }

    /**
     * Sets the value of the billPreferenceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPreferenceId(JAXBElement<Long> value) {
        this.billPreferenceId = value;
    }

    /**
     * Gets the value of the individualInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIndividualInformationId() {
        return individualInformationId;
    }

    /**
     * Sets the value of the individualInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIndividualInformationId(JAXBElement<Long> value) {
        this.individualInformationId = value;
    }

    /**
     * Gets the value of the cardAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCardAccountId() {
        return cardAccountId;
    }

    /**
     * Sets the value of the cardAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCardAccountId(JAXBElement<Long> value) {
        this.cardAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the isExtAutopayEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayEnrolled() {
        return isExtAutopayEnrolled;
    }

    /**
     * Sets the value of the isExtAutopayEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayEnrolled(JAXBElement<Long> value) {
        this.isExtAutopayEnrolled = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the cashApr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getCashApr() {
        return cashApr;
    }

    /**
     * Sets the value of the cashApr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setCashApr(JAXBElement<Double> value) {
        this.cashApr = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the tranListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListToDate() {
        return tranListToDate;
    }

    /**
     * Sets the value of the tranListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListToDate(JAXBElement<YDate> value) {
        this.tranListToDate = value;
    }

    /**
     * Gets the value of the tranListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListFromDate() {
        return tranListFromDate;
    }

    /**
     * Sets the value of the tranListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListFromDate(JAXBElement<YDate> value) {
        this.tranListFromDate = value;
    }

    /**
     * Gets the value of the company property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompany() {
        return company;
    }

    /**
     * Sets the value of the company property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompany(JAXBElement<String> value) {
        this.company = value;
    }

    /**
     * Gets the value of the amountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountDue() {
        return amountDue;
    }

    /**
     * Sets the value of the amountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountDue(JAXBElement<YMoney> value) {
        this.amountDue = value;
    }

    /**
     * Gets the value of the minPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMinPayment() {
        return minPayment;
    }

    /**
     * Sets the value of the minPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMinPayment(JAXBElement<YMoney> value) {
        this.minPayment = value;
    }

    /**
     * Gets the value of the runningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRunningBalance() {
        return runningBalance;
    }

    /**
     * Sets the value of the runningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRunningBalance(JAXBElement<YMoney> value) {
        this.runningBalance = value;
    }

    /**
     * Gets the value of the newCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getNewCharges() {
        return newCharges;
    }

    /**
     * Sets the value of the newCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setNewCharges(JAXBElement<YMoney> value) {
        this.newCharges = value;
    }

    /**
     * Gets the value of the payments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPayments() {
        return payments;
    }

    /**
     * Sets the value of the payments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPayments(JAXBElement<YMoney> value) {
        this.payments = value;
    }

    /**
     * Gets the value of the adjustments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustments() {
        return adjustments;
    }

    /**
     * Sets the value of the adjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustments(JAXBElement<YMoney> value) {
        this.adjustments = value;
    }

    /**
     * Gets the value of the adjustmentsPayments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustmentsPayments() {
        return adjustmentsPayments;
    }

    /**
     * Sets the value of the adjustmentsPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustmentsPayments(JAXBElement<YMoney> value) {
        this.adjustmentsPayments = value;
    }

    /**
     * Gets the value of the pendingCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPendingCharges() {
        return pendingCharges;
    }

    /**
     * Sets the value of the pendingCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPendingCharges(JAXBElement<YMoney> value) {
        this.pendingCharges = value;
    }

    /**
     * Gets the value of the lastPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPayment() {
        return lastPayment;
    }

    /**
     * Sets the value of the lastPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPayment(JAXBElement<YMoney> value) {
        this.lastPayment = value;
    }

    /**
     * Gets the value of the disputedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDisputedAmount() {
        return disputedAmount;
    }

    /**
     * Sets the value of the disputedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDisputedAmount(JAXBElement<YMoney> value) {
        this.disputedAmount = value;
    }

    /**
     * Gets the value of the availableCredit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableCredit() {
        return availableCredit;
    }

    /**
     * Sets the value of the availableCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableCredit(JAXBElement<YMoney> value) {
        this.availableCredit = value;
    }

    /**
     * Gets the value of the availableCash property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableCash() {
        return availableCash;
    }

    /**
     * Sets the value of the availableCash property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableCash(JAXBElement<YMoney> value) {
        this.availableCash = value;
    }

    /**
     * Gets the value of the totalCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCreditLine() {
        return totalCreditLine;
    }

    /**
     * Sets the value of the totalCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCreditLine(JAXBElement<YMoney> value) {
        this.totalCreditLine = value;
    }

    /**
     * Gets the value of the totalCashLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCashLimit() {
        return totalCashLimit;
    }

    /**
     * Sets the value of the totalCashLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCashLimit(JAXBElement<YMoney> value) {
        this.totalCashLimit = value;
    }

    /**
     * Gets the value of the interestPaidThisPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidThisPeriod() {
        return interestPaidThisPeriod;
    }

    /**
     * Sets the value of the interestPaidThisPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidThisPeriod(JAXBElement<YMoney> value) {
        this.interestPaidThisPeriod = value;
    }

    /**
     * Gets the value of the interestPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidYtd() {
        return interestPaidYtd;
    }

    /**
     * Sets the value of the interestPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidYtd(JAXBElement<YMoney> value) {
        this.interestPaidYtd = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusLastUpdated() {
        return userAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the asofDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsofDate() {
        return asofDate;
    }

    /**
     * Sets the value of the asofDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsofDate(JAXBElement<YDate> value) {
        this.asofDate = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDueDate(JAXBElement<YDate> value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPaymentDate(JAXBElement<YDate> value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusId() {
        return derivedAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDerivedAutopayEnrollmentStatus() {
        return derivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.derivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDerivedAutopayEnrollmentStatus() {
        return localizedDerivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedDerivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the stmtListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListToDate() {
        return stmtListToDate;
    }

    /**
     * Sets the value of the stmtListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListToDate(JAXBElement<YDate> value) {
        this.stmtListToDate = value;
    }

    /**
     * Gets the value of the stmtListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListFromDate() {
        return stmtListFromDate;
    }

    /**
     * Sets the value of the stmtListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListFromDate(JAXBElement<YDate> value) {
        this.stmtListFromDate = value;
    }

    /**
     * Gets the value of the apr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getApr() {
        return apr;
    }

    /**
     * Sets the value of the apr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setApr(JAXBElement<Double> value) {
        this.apr = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusId() {
        return userAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserAutopayEnrollmentStatus() {
        return userAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.userAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUserAutopayEnrollmentStatus() {
        return localizedUserAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedUserAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusLastUpdated() {
        return derivedAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAutopayEnrollmentStatusId() {
        return autopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the autopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.autopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAutopayEnrollmentStatus() {
        return autopayEnrollmentStatus;
    }

    /**
     * Sets the value of the autopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.autopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAutopayEnrollmentStatus() {
        return localizedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the isExtAutopayScraped property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayScraped() {
        return isExtAutopayScraped;
    }

    /**
     * Sets the value of the isExtAutopayScraped property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayScraped(JAXBElement<Long> value) {
        this.isExtAutopayScraped = value;
    }

    /**
     * Gets the value of the extAutopaySetup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public JAXBElement<ExtAutopaySetupData> getExtAutopaySetup() {
        return extAutopaySetup;
    }

    /**
     * Sets the value of the extAutopaySetup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public void setExtAutopaySetup(JAXBElement<ExtAutopaySetupData> value) {
        this.extAutopaySetup = value;
    }

    /**
     * Gets the value of the cardTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getCardTransactions() {
        return cardTransactions;
    }

    /**
     * Sets the value of the cardTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setCardTransactions(JAXBElement<List> value) {
        this.cardTransactions = value;
    }

    /**
     * Gets the value of the cardStatements property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getCardStatements() {
        return cardStatements;
    }

    /**
     * Sets the value of the cardStatements property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setCardStatements(JAXBElement<List> value) {
        this.cardStatements = value;
    }

    /**
     * Gets the value of the billPreference property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public JAXBElement<BillPreferenceData> getBillPreference() {
        return billPreference;
    }

    /**
     * Sets the value of the billPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public void setBillPreference(JAXBElement<BillPreferenceData> value) {
        this.billPreference = value;
    }

    /**
     * Gets the value of the paymentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPaymentDetails() {
        return paymentDetails;
    }

    /**
     * Sets the value of the paymentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPaymentDetails(JAXBElement<List> value) {
        this.paymentDetails = value;
    }

    /**
     * Gets the value of the balanceTransfers property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBalanceTransfers() {
        return balanceTransfers;
    }

    /**
     * Sets the value of the balanceTransfers property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBalanceTransfers(JAXBElement<List> value) {
        this.balanceTransfers = value;
    }

    /**
     * Gets the value of the individualInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public JAXBElement<IndividualInformation> getIndividualInformation() {
        return individualInformation;
    }

    /**
     * Sets the value of the individualInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public void setIndividualInformation(JAXBElement<IndividualInformation> value) {
        this.individualInformation = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the isPaperlessStmtOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaperlessStmtOn() {
        return isPaperlessStmtOn;
    }

    /**
     * Sets the value of the isPaperlessStmtOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaperlessStmtOn(JAXBElement<Long> value) {
        this.isPaperlessStmtOn = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the straightBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStraightBalance() {
        return straightBalance;
    }

    /**
     * Sets the value of the straightBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStraightBalance(JAXBElement<YMoney> value) {
        this.straightBalance = value;
    }

    /**
     * Gets the value of the budgetBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBudgetBalance() {
        return budgetBalance;
    }

    /**
     * Sets the value of the budgetBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBudgetBalance(JAXBElement<YMoney> value) {
        this.budgetBalance = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the accountClassification property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public JAXBElement<AccountClassification> getAccountClassification() {
        return accountClassification;
    }

    /**
     * Sets the value of the accountClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public void setAccountClassification(JAXBElement<AccountClassification> value) {
        this.accountClassification = value;
    }

    /**
     * Gets the value of the cardType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CardType }{@code >}
     *     
     */
    public JAXBElement<CardType> getCardType() {
        return cardType;
    }

    /**
     * Sets the value of the cardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CardType }{@code >}
     *     
     */
    public void setCardType(JAXBElement<CardType> value) {
        this.cardType = value;
    }

    /**
     * Gets the value of the srcAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcAccountType() {
        return srcAccountType;
    }

    /**
     * Sets the value of the srcAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcAccountType(JAXBElement<String> value) {
        this.srcAccountType = value;
    }

    /**
     * Gets the value of the srcAccountIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcAccountIdentifier() {
        return srcAccountIdentifier;
    }

    /**
     * Sets the value of the srcAccountIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcAccountIdentifier(JAXBElement<String> value) {
        this.srcAccountIdentifier = value;
    }

    /**
     * Gets the value of the pendingAuthorizonAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPendingAuthorizonAmt() {
        return pendingAuthorizonAmt;
    }

    /**
     * Sets the value of the pendingAuthorizonAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPendingAuthorizonAmt(JAXBElement<YMoney> value) {
        this.pendingAuthorizonAmt = value;
    }

    /**
     * Gets the value of the straightPendingcharge property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStraightPendingcharge() {
        return straightPendingcharge;
    }

    /**
     * Sets the value of the straightPendingcharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStraightPendingcharge(JAXBElement<YMoney> value) {
        this.straightPendingcharge = value;
    }

    /**
     * Gets the value of the budgetPendingCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBudgetPendingCharges() {
        return budgetPendingCharges;
    }

    /**
     * Sets the value of the budgetPendingCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBudgetPendingCharges(JAXBElement<YMoney> value) {
        this.budgetPendingCharges = value;
    }

    /**
     * Gets the value of the straightAvailableBal property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStraightAvailableBal() {
        return straightAvailableBal;
    }

    /**
     * Sets the value of the straightAvailableBal property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStraightAvailableBal(JAXBElement<YMoney> value) {
        this.straightAvailableBal = value;
    }

    /**
     * Gets the value of the budgetAvailableBal property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBudgetAvailableBal() {
        return budgetAvailableBal;
    }

    /**
     * Sets the value of the budgetAvailableBal property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBudgetAvailableBal(JAXBElement<YMoney> value) {
        this.budgetAvailableBal = value;
    }

    /**
     * Gets the value of the budgetCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBudgetCreditLine() {
        return budgetCreditLine;
    }

    /**
     * Sets the value of the budgetCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBudgetCreditLine(JAXBElement<YMoney> value) {
        this.budgetCreditLine = value;
    }

    /**
     * Gets the value of the straightCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStraightCreditLine() {
        return straightCreditLine;
    }

    /**
     * Sets the value of the straightCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStraightCreditLine(JAXBElement<YMoney> value) {
        this.straightCreditLine = value;
    }

}
