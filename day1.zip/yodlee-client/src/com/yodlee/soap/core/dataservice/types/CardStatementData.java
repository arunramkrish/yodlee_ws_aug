
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for CardStatementData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardStatementData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="cardStatementId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="cardAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lateCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cashAdvance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="credit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="payments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustmentsPayments" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="financeCharges" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="disputedAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableCredit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableCash" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalCreditLine" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalCashLimit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidThisPeriod" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="apr" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="tranListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="tranListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="cardTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="bill" type="{http://types.dataservice.core.soap.yodlee.com}Bill" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardStatementData", propOrder = {
    "srcElementId",
    "isSeidMod",
    "isSeidFromDataSource",
    "billId",
    "cardStatementId",
    "cardAccountId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "lateCharges",
    "cashAdvance",
    "credit",
    "payments",
    "adjustments",
    "adjustmentsPayments",
    "financeCharges",
    "disputedAmount",
    "availableCredit",
    "availableCash",
    "totalCreditLine",
    "totalCashLimit",
    "interestPaidThisPeriod",
    "interestPaidYtd",
    "apr",
    "tranListToDate",
    "tranListFromDate",
    "cardTransactions",
    "bill"
})
public class CardStatementData
    extends BaseTagData
{

    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "billId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billId;
    @XmlElementRef(name = "cardStatementId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cardStatementId;
    @XmlElementRef(name = "cardAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> cardAccountId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "lateCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lateCharges;
    @XmlElementRef(name = "cashAdvance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cashAdvance;
    @XmlElementRef(name = "credit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> credit;
    @XmlElementRef(name = "payments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> payments;
    @XmlElementRef(name = "adjustments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustments;
    @XmlElementRef(name = "adjustmentsPayments", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustmentsPayments;
    @XmlElementRef(name = "financeCharges", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> financeCharges;
    @XmlElementRef(name = "disputedAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> disputedAmount;
    @XmlElementRef(name = "availableCredit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableCredit;
    @XmlElementRef(name = "availableCash", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableCash;
    @XmlElementRef(name = "totalCreditLine", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCreditLine;
    @XmlElementRef(name = "totalCashLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCashLimit;
    @XmlElementRef(name = "interestPaidThisPeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidThisPeriod;
    @XmlElementRef(name = "interestPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidYtd;
    @XmlElementRef(name = "apr", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> apr;
    @XmlElementRef(name = "tranListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListToDate;
    @XmlElementRef(name = "tranListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListFromDate;
    @XmlElementRef(name = "cardTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> cardTransactions;
    @XmlElementRef(name = "bill", type = JAXBElement.class, required = false)
    protected JAXBElement<Bill> bill;

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillId(JAXBElement<Long> value) {
        this.billId = value;
    }

    /**
     * Gets the value of the cardStatementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCardStatementId() {
        return cardStatementId;
    }

    /**
     * Sets the value of the cardStatementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCardStatementId(JAXBElement<Long> value) {
        this.cardStatementId = value;
    }

    /**
     * Gets the value of the cardAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCardAccountId() {
        return cardAccountId;
    }

    /**
     * Sets the value of the cardAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCardAccountId(JAXBElement<Long> value) {
        this.cardAccountId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the lateCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLateCharges() {
        return lateCharges;
    }

    /**
     * Sets the value of the lateCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLateCharges(JAXBElement<YMoney> value) {
        this.lateCharges = value;
    }

    /**
     * Gets the value of the cashAdvance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCashAdvance() {
        return cashAdvance;
    }

    /**
     * Sets the value of the cashAdvance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCashAdvance(JAXBElement<YMoney> value) {
        this.cashAdvance = value;
    }

    /**
     * Gets the value of the credit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCredit() {
        return credit;
    }

    /**
     * Sets the value of the credit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCredit(JAXBElement<YMoney> value) {
        this.credit = value;
    }

    /**
     * Gets the value of the payments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPayments() {
        return payments;
    }

    /**
     * Sets the value of the payments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPayments(JAXBElement<YMoney> value) {
        this.payments = value;
    }

    /**
     * Gets the value of the adjustments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustments() {
        return adjustments;
    }

    /**
     * Sets the value of the adjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustments(JAXBElement<YMoney> value) {
        this.adjustments = value;
    }

    /**
     * Gets the value of the adjustmentsPayments property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustmentsPayments() {
        return adjustmentsPayments;
    }

    /**
     * Sets the value of the adjustmentsPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustmentsPayments(JAXBElement<YMoney> value) {
        this.adjustmentsPayments = value;
    }

    /**
     * Gets the value of the financeCharges property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFinanceCharges() {
        return financeCharges;
    }

    /**
     * Sets the value of the financeCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFinanceCharges(JAXBElement<YMoney> value) {
        this.financeCharges = value;
    }

    /**
     * Gets the value of the disputedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDisputedAmount() {
        return disputedAmount;
    }

    /**
     * Sets the value of the disputedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDisputedAmount(JAXBElement<YMoney> value) {
        this.disputedAmount = value;
    }

    /**
     * Gets the value of the availableCredit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableCredit() {
        return availableCredit;
    }

    /**
     * Sets the value of the availableCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableCredit(JAXBElement<YMoney> value) {
        this.availableCredit = value;
    }

    /**
     * Gets the value of the availableCash property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableCash() {
        return availableCash;
    }

    /**
     * Sets the value of the availableCash property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableCash(JAXBElement<YMoney> value) {
        this.availableCash = value;
    }

    /**
     * Gets the value of the totalCreditLine property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCreditLine() {
        return totalCreditLine;
    }

    /**
     * Sets the value of the totalCreditLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCreditLine(JAXBElement<YMoney> value) {
        this.totalCreditLine = value;
    }

    /**
     * Gets the value of the totalCashLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCashLimit() {
        return totalCashLimit;
    }

    /**
     * Sets the value of the totalCashLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCashLimit(JAXBElement<YMoney> value) {
        this.totalCashLimit = value;
    }

    /**
     * Gets the value of the interestPaidThisPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidThisPeriod() {
        return interestPaidThisPeriod;
    }

    /**
     * Sets the value of the interestPaidThisPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidThisPeriod(JAXBElement<YMoney> value) {
        this.interestPaidThisPeriod = value;
    }

    /**
     * Gets the value of the interestPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidYtd() {
        return interestPaidYtd;
    }

    /**
     * Sets the value of the interestPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidYtd(JAXBElement<YMoney> value) {
        this.interestPaidYtd = value;
    }

    /**
     * Gets the value of the apr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getApr() {
        return apr;
    }

    /**
     * Sets the value of the apr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setApr(JAXBElement<Double> value) {
        this.apr = value;
    }

    /**
     * Gets the value of the tranListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListToDate() {
        return tranListToDate;
    }

    /**
     * Sets the value of the tranListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListToDate(JAXBElement<YDate> value) {
        this.tranListToDate = value;
    }

    /**
     * Gets the value of the tranListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListFromDate() {
        return tranListFromDate;
    }

    /**
     * Sets the value of the tranListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListFromDate(JAXBElement<YDate> value) {
        this.tranListFromDate = value;
    }

    /**
     * Gets the value of the cardTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getCardTransactions() {
        return cardTransactions;
    }

    /**
     * Sets the value of the cardTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setCardTransactions(JAXBElement<List> value) {
        this.cardTransactions = value;
    }

    /**
     * Gets the value of the bill property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Bill }{@code >}
     *     
     */
    public JAXBElement<Bill> getBill() {
        return bill;
    }

    /**
     * Sets the value of the bill property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Bill }{@code >}
     *     
     */
    public void setBill(JAXBElement<Bill> value) {
        this.bill = value;
    }

}
