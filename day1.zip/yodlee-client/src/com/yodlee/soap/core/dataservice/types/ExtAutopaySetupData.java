
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;


/**
 * <p>Java class for ExtAutopaySetupData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtAutopaySetupData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extApBankAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="extApCardAcctId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="extAutopaySetupId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="nextAutopayDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isAutopaySetup" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymAccountTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPaymAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extApBankAcct" type="{http://types.dataservice.core.soap.yodlee.com}ExtApBankAcctData" minOccurs="0"/>
 *         &lt;element name="extApCardAcct" type="{http://types.dataservice.core.soap.yodlee.com}ExtApCardAcctData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtAutopaySetupData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "extApBankAcctId",
    "extApCardAcctId",
    "extAutopaySetupId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "nextAutopayDate",
    "isAutopaySetup",
    "paymAccountTypeId",
    "paymAccountType",
    "localizedPaymAccountType",
    "extApBankAcct",
    "extApCardAcct"
})
public class ExtAutopaySetupData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "extApBankAcctId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extApBankAcctId;
    @XmlElementRef(name = "extApCardAcctId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extApCardAcctId;
    @XmlElementRef(name = "extAutopaySetupId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extAutopaySetupId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "nextAutopayDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> nextAutopayDate;
    @XmlElementRef(name = "isAutopaySetup", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isAutopaySetup;
    @XmlElementRef(name = "paymAccountTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymAccountTypeId;
    @XmlElementRef(name = "paymAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymAccountType;
    @XmlElementRef(name = "localizedPaymAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPaymAccountType;
    @XmlElementRef(name = "extApBankAcct", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtApBankAcctData> extApBankAcct;
    @XmlElementRef(name = "extApCardAcct", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtApCardAcctData> extApCardAcct;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the extApBankAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtApBankAcctId() {
        return extApBankAcctId;
    }

    /**
     * Sets the value of the extApBankAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtApBankAcctId(JAXBElement<Long> value) {
        this.extApBankAcctId = value;
    }

    /**
     * Gets the value of the extApCardAcctId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtApCardAcctId() {
        return extApCardAcctId;
    }

    /**
     * Sets the value of the extApCardAcctId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtApCardAcctId(JAXBElement<Long> value) {
        this.extApCardAcctId = value;
    }

    /**
     * Gets the value of the extAutopaySetupId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtAutopaySetupId() {
        return extAutopaySetupId;
    }

    /**
     * Sets the value of the extAutopaySetupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtAutopaySetupId(JAXBElement<Long> value) {
        this.extAutopaySetupId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the nextAutopayDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getNextAutopayDate() {
        return nextAutopayDate;
    }

    /**
     * Sets the value of the nextAutopayDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setNextAutopayDate(JAXBElement<YDate> value) {
        this.nextAutopayDate = value;
    }

    /**
     * Gets the value of the isAutopaySetup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsAutopaySetup() {
        return isAutopaySetup;
    }

    /**
     * Sets the value of the isAutopaySetup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsAutopaySetup(JAXBElement<Long> value) {
        this.isAutopaySetup = value;
    }

    /**
     * Gets the value of the paymAccountTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymAccountTypeId() {
        return paymAccountTypeId;
    }

    /**
     * Sets the value of the paymAccountTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymAccountTypeId(JAXBElement<Long> value) {
        this.paymAccountTypeId = value;
    }

    /**
     * Gets the value of the paymAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymAccountType() {
        return paymAccountType;
    }

    /**
     * Sets the value of the paymAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymAccountType(JAXBElement<String> value) {
        this.paymAccountType = value;
    }

    /**
     * Gets the value of the localizedPaymAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPaymAccountType() {
        return localizedPaymAccountType;
    }

    /**
     * Sets the value of the localizedPaymAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPaymAccountType(JAXBElement<String> value) {
        this.localizedPaymAccountType = value;
    }

    /**
     * Gets the value of the extApBankAcct property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtApBankAcctData }{@code >}
     *     
     */
    public JAXBElement<ExtApBankAcctData> getExtApBankAcct() {
        return extApBankAcct;
    }

    /**
     * Sets the value of the extApBankAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtApBankAcctData }{@code >}
     *     
     */
    public void setExtApBankAcct(JAXBElement<ExtApBankAcctData> value) {
        this.extApBankAcct = value;
    }

    /**
     * Gets the value of the extApCardAcct property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtApCardAcctData }{@code >}
     *     
     */
    public JAXBElement<ExtApCardAcctData> getExtApCardAcct() {
        return extApCardAcct;
    }

    /**
     * Sets the value of the extApCardAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtApCardAcctData }{@code >}
     *     
     */
    public void setExtApCardAcct(JAXBElement<ExtApCardAcctData> value) {
        this.extApCardAcct = value;
    }

}
