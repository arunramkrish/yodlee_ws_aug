
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.dataservice.types.ArrayOfProceedsInformationType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for ExtendedInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="proceedsInformation" type="{http://types.dataservice.core.collections.soap.yodlee.com}ArrayOfProceedsInformationType" minOccurs="0"/>
 *         &lt;element name="taxExemptInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pvtActivityInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxExemptDividend" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pvtActivityDividend" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedInformationType", propOrder = {
    "proceedsInformation",
    "taxExemptInterest",
    "pvtActivityInterest",
    "taxExemptDividend",
    "pvtActivityDividend"
})
public class ExtendedInformationType {

    @XmlElementRef(name = "proceedsInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfProceedsInformationType> proceedsInformation;
    @XmlElementRef(name = "taxExemptInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxExemptInterest;
    @XmlElementRef(name = "pvtActivityInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pvtActivityInterest;
    @XmlElementRef(name = "taxExemptDividend", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxExemptDividend;
    @XmlElementRef(name = "pvtActivityDividend", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pvtActivityDividend;

    /**
     * Gets the value of the proceedsInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProceedsInformationType }{@code >}
     *     
     */
    public JAXBElement<ArrayOfProceedsInformationType> getProceedsInformation() {
        return proceedsInformation;
    }

    /**
     * Sets the value of the proceedsInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfProceedsInformationType }{@code >}
     *     
     */
    public void setProceedsInformation(JAXBElement<ArrayOfProceedsInformationType> value) {
        this.proceedsInformation = value;
    }

    /**
     * Gets the value of the taxExemptInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxExemptInterest() {
        return taxExemptInterest;
    }

    /**
     * Sets the value of the taxExemptInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxExemptInterest(JAXBElement<YMoney> value) {
        this.taxExemptInterest = value;
    }

    /**
     * Gets the value of the pvtActivityInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPvtActivityInterest() {
        return pvtActivityInterest;
    }

    /**
     * Sets the value of the pvtActivityInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPvtActivityInterest(JAXBElement<YMoney> value) {
        this.pvtActivityInterest = value;
    }

    /**
     * Gets the value of the taxExemptDividend property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxExemptDividend() {
        return taxExemptDividend;
    }

    /**
     * Sets the value of the taxExemptDividend property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxExemptDividend(JAXBElement<YMoney> value) {
        this.taxExemptDividend = value;
    }

    /**
     * Gets the value of the pvtActivityDividend property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPvtActivityDividend() {
        return pvtActivityDividend;
    }

    /**
     * Sets the value of the pvtActivityDividend property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPvtActivityDividend(JAXBElement<YMoney> value) {
        this.pvtActivityDividend = value;
    }

}
