
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.Exchange;
import com.yodlee.soap.core.dataservice.enums.PlanOption;
import com.yodlee.soap.core.investment.InvestmentSecurity;


/**
 * <p>Java class for HoldingData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HoldingData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="optionTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="optionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedOptionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bondTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bondType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBondType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bondClassId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="bondClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedBondClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mutualFundTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="mutualFundType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedMutualFundType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="holdingTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="holdingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedHoldingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="holdingId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="investmentAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastContributionDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="futureHoldingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalPotentialValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="remicHoldingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastContribution" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="callTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="callType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedCallType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="faceValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="dailyChange" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="percentAllocation" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="nextCouponDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="daysRemaining" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="contractAdjustment" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="moodyRating" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nextCallDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="term" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="price" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="strikePrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="mfNumber" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="interestRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="yieldToCall" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="planNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="costBasis" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="employerContribution" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="vestedQuantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isMarginable" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="vestingDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="stockOptionTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="stockOptionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedStockOptionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="yield" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="newspaperAbbrev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shortDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="grantNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cusipNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSettleTypeAmerican" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mmfNumber" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="couponRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="unvestedQuantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="vestedValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="currencyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="commodityType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="vestedSharesEx" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="spRating" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentYield" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="quantityGrantsAccepted" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="planName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="assetClassId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="assetClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAssetClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nominalYield" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isRestricted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="internalRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="fiAssetClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="chngSinceLastPriced" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="value" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="employeeContribution" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="parValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="percentageChange" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contractQuantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="grantDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="companyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="symbol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="quantityGrantsNotaccepted" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isShort" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="yieldToMaturity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="couponFreqId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="couponFreq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedCouponFreq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unvestedValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="callPrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustmentFactor" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="expirationDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="maturityDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="yieldAsofDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="taxLots" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="marketValueAdjustment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="lotSize" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="linkedBankAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="realizedGain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="priceAsOfDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="planOptionType" type="{http://enums.dataservice.core.soap.yodlee.com}PlanOption" minOccurs="0"/>
 *         &lt;element name="isin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sedol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="exchange" type="{http://enums.dataservice.core.soap.yodlee.com}Exchange" minOccurs="0"/>
 *         &lt;element name="domicile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="securityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="securityInfo" type="{http://investment.core.soap.yodlee.com}InvestmentSecurity" minOccurs="0"/>
 *         &lt;element name="isUnderlyingSecurity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="scrapedPrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="scrapedQuantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isSymbolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isCusipNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isIsinNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSedolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HoldingData", propOrder = {
    "optionTypeId",
    "optionType",
    "localizedOptionType",
    "isSeidFromDataSource",
    "bondTypeId",
    "bondType",
    "localizedBondType",
    "isSeidMod",
    "bondClassId",
    "bondClass",
    "localizedBondClass",
    "srcElementId",
    "mutualFundTypeId",
    "mutualFundType",
    "localizedMutualFundType",
    "holdingTypeId",
    "holdingType",
    "localizedHoldingType",
    "holdingId",
    "investmentAccountId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "lastContributionDate",
    "futureHoldingName",
    "totalPotentialValue",
    "remicHoldingName",
    "lastContribution",
    "callTypeId",
    "callType",
    "localizedCallType",
    "faceValue",
    "dailyChange",
    "percentAllocation",
    "nextCouponDate",
    "daysRemaining",
    "contractAdjustment",
    "moodyRating",
    "nextCallDate",
    "term",
    "price",
    "strikePrice",
    "mfNumber",
    "interestRate",
    "yieldToCall",
    "planNumber",
    "costBasis",
    "employerContribution",
    "vestedQuantity",
    "isMarginable",
    "vestingDate",
    "stockOptionTypeId",
    "stockOptionType",
    "localizedStockOptionType",
    "yield",
    "newspaperAbbrev",
    "shortDescription",
    "riskCategory",
    "grantNumber",
    "cusipNumber",
    "isSettleTypeAmerican",
    "isid",
    "mmfNumber",
    "couponRate",
    "unvestedQuantity",
    "vestedValue",
    "currencyType",
    "commodityType",
    "vestedSharesEx",
    "spRating",
    "currentYield",
    "quantityGrantsAccepted",
    "planName",
    "assetClassId",
    "assetClass",
    "localizedAssetClass",
    "nominalYield",
    "isRestricted",
    "internalRefNo",
    "quantity",
    "fiAssetClass",
    "chngSinceLastPriced",
    "value",
    "employeeContribution",
    "parValue",
    "percentageChange",
    "link",
    "contractQuantity",
    "grantDate",
    "companyName",
    "symbol",
    "quantityGrantsNotaccepted",
    "isShort",
    "yieldToMaturity",
    "couponFreqId",
    "couponFreq",
    "localizedCouponFreq",
    "description",
    "unvestedValue",
    "callPrice",
    "adjustmentFactor",
    "expirationDate",
    "maturityDate",
    "yieldAsofDate",
    "taxLots",
    "marketValueAdjustment",
    "lotSize",
    "linkedBankAccountNumber",
    "realizedGain",
    "priceAsOfDate",
    "planOptionType",
    "isin",
    "sedol",
    "exchange",
    "domicile",
    "securityId",
    "securityInfo",
    "isUnderlyingSecurity",
    "scrapedPrice",
    "scrapedQuantity",
    "isSymbolNormalized",
    "isCusipNormalized",
    "isIsinNormalized",
    "isSedolNormalized"
})
public class HoldingData
    extends BaseTagData
{

    @XmlElementRef(name = "optionTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> optionTypeId;
    @XmlElementRef(name = "optionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> optionType;
    @XmlElementRef(name = "localizedOptionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedOptionType;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "bondTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bondTypeId;
    @XmlElementRef(name = "bondType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bondType;
    @XmlElementRef(name = "localizedBondType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBondType;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "bondClassId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> bondClassId;
    @XmlElementRef(name = "bondClass", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bondClass;
    @XmlElementRef(name = "localizedBondClass", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedBondClass;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "mutualFundTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> mutualFundTypeId;
    @XmlElementRef(name = "mutualFundType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mutualFundType;
    @XmlElementRef(name = "localizedMutualFundType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedMutualFundType;
    @XmlElementRef(name = "holdingTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> holdingTypeId;
    @XmlElementRef(name = "holdingType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> holdingType;
    @XmlElementRef(name = "localizedHoldingType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedHoldingType;
    @XmlElementRef(name = "holdingId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> holdingId;
    @XmlElementRef(name = "investmentAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentAccountId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "lastContributionDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastContributionDate;
    @XmlElementRef(name = "futureHoldingName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> futureHoldingName;
    @XmlElementRef(name = "totalPotentialValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalPotentialValue;
    @XmlElementRef(name = "remicHoldingName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> remicHoldingName;
    @XmlElementRef(name = "lastContribution", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastContribution;
    @XmlElementRef(name = "callTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> callTypeId;
    @XmlElementRef(name = "callType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> callType;
    @XmlElementRef(name = "localizedCallType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedCallType;
    @XmlElementRef(name = "faceValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> faceValue;
    @XmlElementRef(name = "dailyChange", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dailyChange;
    @XmlElementRef(name = "percentAllocation", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> percentAllocation;
    @XmlElementRef(name = "nextCouponDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> nextCouponDate;
    @XmlElementRef(name = "daysRemaining", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> daysRemaining;
    @XmlElementRef(name = "contractAdjustment", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> contractAdjustment;
    @XmlElementRef(name = "moodyRating", type = JAXBElement.class, required = false)
    protected JAXBElement<String> moodyRating;
    @XmlElementRef(name = "nextCallDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> nextCallDate;
    @XmlElementRef(name = "term", type = JAXBElement.class, required = false)
    protected JAXBElement<String> term;
    @XmlElementRef(name = "price", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> price;
    @XmlElementRef(name = "strikePrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> strikePrice;
    @XmlElementRef(name = "mfNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> mfNumber;
    @XmlElementRef(name = "interestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> interestRate;
    @XmlElementRef(name = "yieldToCall", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> yieldToCall;
    @XmlElementRef(name = "planNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> planNumber;
    @XmlElementRef(name = "costBasis", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> costBasis;
    @XmlElementRef(name = "employerContribution", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> employerContribution;
    @XmlElementRef(name = "vestedQuantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> vestedQuantity;
    @XmlElementRef(name = "isMarginable", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isMarginable;
    @XmlElementRef(name = "vestingDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> vestingDate;
    @XmlElementRef(name = "stockOptionTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> stockOptionTypeId;
    @XmlElementRef(name = "stockOptionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> stockOptionType;
    @XmlElementRef(name = "localizedStockOptionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedStockOptionType;
    @XmlElementRef(name = "yield", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> yield;
    @XmlElementRef(name = "newspaperAbbrev", type = JAXBElement.class, required = false)
    protected JAXBElement<String> newspaperAbbrev;
    @XmlElementRef(name = "shortDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> shortDescription;
    @XmlElementRef(name = "riskCategory", type = JAXBElement.class, required = false)
    protected JAXBElement<String> riskCategory;
    @XmlElementRef(name = "grantNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> grantNumber;
    @XmlElementRef(name = "cusipNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cusipNumber;
    @XmlElementRef(name = "isSettleTypeAmerican", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSettleTypeAmerican;
    @XmlElementRef(name = "isid", type = JAXBElement.class, required = false)
    protected JAXBElement<String> isid;
    @XmlElementRef(name = "mmfNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> mmfNumber;
    @XmlElementRef(name = "couponRate", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> couponRate;
    @XmlElementRef(name = "unvestedQuantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> unvestedQuantity;
    @XmlElementRef(name = "vestedValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> vestedValue;
    @XmlElementRef(name = "currencyType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> currencyType;
    @XmlElementRef(name = "commodityType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> commodityType;
    @XmlElementRef(name = "vestedSharesEx", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> vestedSharesEx;
    @XmlElementRef(name = "spRating", type = JAXBElement.class, required = false)
    protected JAXBElement<String> spRating;
    @XmlElementRef(name = "currentYield", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> currentYield;
    @XmlElementRef(name = "quantityGrantsAccepted", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> quantityGrantsAccepted;
    @XmlElementRef(name = "planName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> planName;
    @XmlElementRef(name = "assetClassId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> assetClassId;
    @XmlElementRef(name = "assetClass", type = JAXBElement.class, required = false)
    protected JAXBElement<String> assetClass;
    @XmlElementRef(name = "localizedAssetClass", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAssetClass;
    @XmlElementRef(name = "nominalYield", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> nominalYield;
    @XmlElementRef(name = "isRestricted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isRestricted;
    @XmlElementRef(name = "internalRefNo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> internalRefNo;
    @XmlElementRef(name = "quantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> quantity;
    @XmlElementRef(name = "fiAssetClass", type = JAXBElement.class, required = false)
    protected JAXBElement<String> fiAssetClass;
    @XmlElementRef(name = "chngSinceLastPriced", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> chngSinceLastPriced;
    @XmlElementRef(name = "value", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> value;
    @XmlElementRef(name = "employeeContribution", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> employeeContribution;
    @XmlElementRef(name = "parValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> parValue;
    @XmlElementRef(name = "percentageChange", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> percentageChange;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "contractQuantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> contractQuantity;
    @XmlElementRef(name = "grantDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> grantDate;
    @XmlElementRef(name = "companyName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> companyName;
    @XmlElementRef(name = "symbol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> symbol;
    @XmlElementRef(name = "quantityGrantsNotaccepted", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> quantityGrantsNotaccepted;
    @XmlElementRef(name = "isShort", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isShort;
    @XmlElementRef(name = "yieldToMaturity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> yieldToMaturity;
    @XmlElementRef(name = "couponFreqId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> couponFreqId;
    @XmlElementRef(name = "couponFreq", type = JAXBElement.class, required = false)
    protected JAXBElement<String> couponFreq;
    @XmlElementRef(name = "localizedCouponFreq", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedCouponFreq;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "unvestedValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unvestedValue;
    @XmlElementRef(name = "callPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> callPrice;
    @XmlElementRef(name = "adjustmentFactor", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> adjustmentFactor;
    @XmlElementRef(name = "expirationDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> expirationDate;
    @XmlElementRef(name = "maturityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> maturityDate;
    @XmlElementRef(name = "yieldAsofDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> yieldAsofDate;
    @XmlElementRef(name = "taxLots", type = JAXBElement.class, required = false)
    protected JAXBElement<List> taxLots;
    @XmlElementRef(name = "marketValueAdjustment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> marketValueAdjustment;
    @XmlElementRef(name = "lotSize", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lotSize;
    @XmlElementRef(name = "linkedBankAccountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> linkedBankAccountNumber;
    @XmlElementRef(name = "realizedGain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> realizedGain;
    @XmlElementRef(name = "priceAsOfDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> priceAsOfDate;
    @XmlElementRef(name = "planOptionType", type = JAXBElement.class, required = false)
    protected JAXBElement<PlanOption> planOptionType;
    @XmlElementRef(name = "isin", type = JAXBElement.class, required = false)
    protected JAXBElement<String> isin;
    @XmlElementRef(name = "sedol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sedol;
    @XmlElementRef(name = "exchange", type = JAXBElement.class, required = false)
    protected JAXBElement<Exchange> exchange;
    @XmlElementRef(name = "domicile", type = JAXBElement.class, required = false)
    protected JAXBElement<String> domicile;
    @XmlElementRef(name = "securityId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> securityId;
    @XmlElementRef(name = "securityInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<InvestmentSecurity> securityInfo;
    @XmlElementRef(name = "isUnderlyingSecurity", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isUnderlyingSecurity;
    @XmlElementRef(name = "scrapedPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> scrapedPrice;
    @XmlElementRef(name = "scrapedQuantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> scrapedQuantity;
    @XmlElementRef(name = "isSymbolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSymbolNormalized;
    @XmlElementRef(name = "isCusipNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isCusipNormalized;
    @XmlElementRef(name = "isIsinNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isIsinNormalized;
    @XmlElementRef(name = "isSedolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSedolNormalized;

    /**
     * Gets the value of the optionTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getOptionTypeId() {
        return optionTypeId;
    }

    /**
     * Sets the value of the optionTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setOptionTypeId(JAXBElement<Long> value) {
        this.optionTypeId = value;
    }

    /**
     * Gets the value of the optionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOptionType() {
        return optionType;
    }

    /**
     * Sets the value of the optionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOptionType(JAXBElement<String> value) {
        this.optionType = value;
    }

    /**
     * Gets the value of the localizedOptionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedOptionType() {
        return localizedOptionType;
    }

    /**
     * Sets the value of the localizedOptionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedOptionType(JAXBElement<String> value) {
        this.localizedOptionType = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the bondTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBondTypeId() {
        return bondTypeId;
    }

    /**
     * Sets the value of the bondTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBondTypeId(JAXBElement<Long> value) {
        this.bondTypeId = value;
    }

    /**
     * Gets the value of the bondType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBondType() {
        return bondType;
    }

    /**
     * Sets the value of the bondType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBondType(JAXBElement<String> value) {
        this.bondType = value;
    }

    /**
     * Gets the value of the localizedBondType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBondType() {
        return localizedBondType;
    }

    /**
     * Sets the value of the localizedBondType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBondType(JAXBElement<String> value) {
        this.localizedBondType = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the bondClassId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBondClassId() {
        return bondClassId;
    }

    /**
     * Sets the value of the bondClassId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBondClassId(JAXBElement<Long> value) {
        this.bondClassId = value;
    }

    /**
     * Gets the value of the bondClass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBondClass() {
        return bondClass;
    }

    /**
     * Sets the value of the bondClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBondClass(JAXBElement<String> value) {
        this.bondClass = value;
    }

    /**
     * Gets the value of the localizedBondClass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedBondClass() {
        return localizedBondClass;
    }

    /**
     * Sets the value of the localizedBondClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedBondClass(JAXBElement<String> value) {
        this.localizedBondClass = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the mutualFundTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getMutualFundTypeId() {
        return mutualFundTypeId;
    }

    /**
     * Sets the value of the mutualFundTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setMutualFundTypeId(JAXBElement<Long> value) {
        this.mutualFundTypeId = value;
    }

    /**
     * Gets the value of the mutualFundType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMutualFundType() {
        return mutualFundType;
    }

    /**
     * Sets the value of the mutualFundType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMutualFundType(JAXBElement<String> value) {
        this.mutualFundType = value;
    }

    /**
     * Gets the value of the localizedMutualFundType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedMutualFundType() {
        return localizedMutualFundType;
    }

    /**
     * Sets the value of the localizedMutualFundType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedMutualFundType(JAXBElement<String> value) {
        this.localizedMutualFundType = value;
    }

    /**
     * Gets the value of the holdingTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHoldingTypeId() {
        return holdingTypeId;
    }

    /**
     * Sets the value of the holdingTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHoldingTypeId(JAXBElement<Long> value) {
        this.holdingTypeId = value;
    }

    /**
     * Gets the value of the holdingType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHoldingType() {
        return holdingType;
    }

    /**
     * Sets the value of the holdingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHoldingType(JAXBElement<String> value) {
        this.holdingType = value;
    }

    /**
     * Gets the value of the localizedHoldingType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedHoldingType() {
        return localizedHoldingType;
    }

    /**
     * Sets the value of the localizedHoldingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedHoldingType(JAXBElement<String> value) {
        this.localizedHoldingType = value;
    }

    /**
     * Gets the value of the holdingId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHoldingId() {
        return holdingId;
    }

    /**
     * Sets the value of the holdingId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHoldingId(JAXBElement<Long> value) {
        this.holdingId = value;
    }

    /**
     * Gets the value of the investmentAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentAccountId() {
        return investmentAccountId;
    }

    /**
     * Sets the value of the investmentAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentAccountId(JAXBElement<Long> value) {
        this.investmentAccountId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the lastContributionDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastContributionDate() {
        return lastContributionDate;
    }

    /**
     * Sets the value of the lastContributionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastContributionDate(JAXBElement<YDate> value) {
        this.lastContributionDate = value;
    }

    /**
     * Gets the value of the futureHoldingName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFutureHoldingName() {
        return futureHoldingName;
    }

    /**
     * Sets the value of the futureHoldingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFutureHoldingName(JAXBElement<String> value) {
        this.futureHoldingName = value;
    }

    /**
     * Gets the value of the totalPotentialValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalPotentialValue() {
        return totalPotentialValue;
    }

    /**
     * Sets the value of the totalPotentialValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalPotentialValue(JAXBElement<YMoney> value) {
        this.totalPotentialValue = value;
    }

    /**
     * Gets the value of the remicHoldingName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRemicHoldingName() {
        return remicHoldingName;
    }

    /**
     * Sets the value of the remicHoldingName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRemicHoldingName(JAXBElement<String> value) {
        this.remicHoldingName = value;
    }

    /**
     * Gets the value of the lastContribution property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastContribution() {
        return lastContribution;
    }

    /**
     * Sets the value of the lastContribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastContribution(JAXBElement<YMoney> value) {
        this.lastContribution = value;
    }

    /**
     * Gets the value of the callTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCallTypeId() {
        return callTypeId;
    }

    /**
     * Sets the value of the callTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCallTypeId(JAXBElement<Long> value) {
        this.callTypeId = value;
    }

    /**
     * Gets the value of the callType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCallType() {
        return callType;
    }

    /**
     * Sets the value of the callType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCallType(JAXBElement<String> value) {
        this.callType = value;
    }

    /**
     * Gets the value of the localizedCallType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedCallType() {
        return localizedCallType;
    }

    /**
     * Sets the value of the localizedCallType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedCallType(JAXBElement<String> value) {
        this.localizedCallType = value;
    }

    /**
     * Gets the value of the faceValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFaceValue() {
        return faceValue;
    }

    /**
     * Sets the value of the faceValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFaceValue(JAXBElement<YMoney> value) {
        this.faceValue = value;
    }

    /**
     * Gets the value of the dailyChange property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDailyChange() {
        return dailyChange;
    }

    /**
     * Sets the value of the dailyChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDailyChange(JAXBElement<YMoney> value) {
        this.dailyChange = value;
    }

    /**
     * Gets the value of the percentAllocation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getPercentAllocation() {
        return percentAllocation;
    }

    /**
     * Sets the value of the percentAllocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setPercentAllocation(JAXBElement<Double> value) {
        this.percentAllocation = value;
    }

    /**
     * Gets the value of the nextCouponDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getNextCouponDate() {
        return nextCouponDate;
    }

    /**
     * Sets the value of the nextCouponDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setNextCouponDate(JAXBElement<YDate> value) {
        this.nextCouponDate = value;
    }

    /**
     * Gets the value of the daysRemaining property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getDaysRemaining() {
        return daysRemaining;
    }

    /**
     * Sets the value of the daysRemaining property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setDaysRemaining(JAXBElement<Double> value) {
        this.daysRemaining = value;
    }

    /**
     * Gets the value of the contractAdjustment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getContractAdjustment() {
        return contractAdjustment;
    }

    /**
     * Sets the value of the contractAdjustment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setContractAdjustment(JAXBElement<Double> value) {
        this.contractAdjustment = value;
    }

    /**
     * Gets the value of the moodyRating property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMoodyRating() {
        return moodyRating;
    }

    /**
     * Sets the value of the moodyRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMoodyRating(JAXBElement<String> value) {
        this.moodyRating = value;
    }

    /**
     * Gets the value of the nextCallDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getNextCallDate() {
        return nextCallDate;
    }

    /**
     * Sets the value of the nextCallDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setNextCallDate(JAXBElement<YDate> value) {
        this.nextCallDate = value;
    }

    /**
     * Gets the value of the term property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTerm() {
        return term;
    }

    /**
     * Sets the value of the term property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTerm(JAXBElement<String> value) {
        this.term = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrice(JAXBElement<YMoney> value) {
        this.price = value;
    }

    /**
     * Gets the value of the strikePrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStrikePrice() {
        return strikePrice;
    }

    /**
     * Sets the value of the strikePrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStrikePrice(JAXBElement<YMoney> value) {
        this.strikePrice = value;
    }

    /**
     * Gets the value of the mfNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getMfNumber() {
        return mfNumber;
    }

    /**
     * Sets the value of the mfNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setMfNumber(JAXBElement<Double> value) {
        this.mfNumber = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setInterestRate(JAXBElement<Double> value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the yieldToCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getYieldToCall() {
        return yieldToCall;
    }

    /**
     * Sets the value of the yieldToCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setYieldToCall(JAXBElement<Double> value) {
        this.yieldToCall = value;
    }

    /**
     * Gets the value of the planNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlanNumber() {
        return planNumber;
    }

    /**
     * Sets the value of the planNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlanNumber(JAXBElement<String> value) {
        this.planNumber = value;
    }

    /**
     * Gets the value of the costBasis property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCostBasis() {
        return costBasis;
    }

    /**
     * Sets the value of the costBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCostBasis(JAXBElement<YMoney> value) {
        this.costBasis = value;
    }

    /**
     * Gets the value of the employerContribution property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEmployerContribution() {
        return employerContribution;
    }

    /**
     * Sets the value of the employerContribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEmployerContribution(JAXBElement<YMoney> value) {
        this.employerContribution = value;
    }

    /**
     * Gets the value of the vestedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getVestedQuantity() {
        return vestedQuantity;
    }

    /**
     * Sets the value of the vestedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setVestedQuantity(JAXBElement<Double> value) {
        this.vestedQuantity = value;
    }

    /**
     * Gets the value of the isMarginable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsMarginable() {
        return isMarginable;
    }

    /**
     * Sets the value of the isMarginable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsMarginable(JAXBElement<Long> value) {
        this.isMarginable = value;
    }

    /**
     * Gets the value of the vestingDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getVestingDate() {
        return vestingDate;
    }

    /**
     * Sets the value of the vestingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setVestingDate(JAXBElement<YDate> value) {
        this.vestingDate = value;
    }

    /**
     * Gets the value of the stockOptionTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getStockOptionTypeId() {
        return stockOptionTypeId;
    }

    /**
     * Sets the value of the stockOptionTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setStockOptionTypeId(JAXBElement<Long> value) {
        this.stockOptionTypeId = value;
    }

    /**
     * Gets the value of the stockOptionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStockOptionType() {
        return stockOptionType;
    }

    /**
     * Sets the value of the stockOptionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStockOptionType(JAXBElement<String> value) {
        this.stockOptionType = value;
    }

    /**
     * Gets the value of the localizedStockOptionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedStockOptionType() {
        return localizedStockOptionType;
    }

    /**
     * Sets the value of the localizedStockOptionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedStockOptionType(JAXBElement<String> value) {
        this.localizedStockOptionType = value;
    }

    /**
     * Gets the value of the yield property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getYield() {
        return yield;
    }

    /**
     * Sets the value of the yield property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setYield(JAXBElement<Double> value) {
        this.yield = value;
    }

    /**
     * Gets the value of the newspaperAbbrev property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNewspaperAbbrev() {
        return newspaperAbbrev;
    }

    /**
     * Sets the value of the newspaperAbbrev property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNewspaperAbbrev(JAXBElement<String> value) {
        this.newspaperAbbrev = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShortDescription(JAXBElement<String> value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the riskCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRiskCategory() {
        return riskCategory;
    }

    /**
     * Sets the value of the riskCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRiskCategory(JAXBElement<String> value) {
        this.riskCategory = value;
    }

    /**
     * Gets the value of the grantNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getGrantNumber() {
        return grantNumber;
    }

    /**
     * Sets the value of the grantNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setGrantNumber(JAXBElement<String> value) {
        this.grantNumber = value;
    }

    /**
     * Gets the value of the cusipNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCusipNumber() {
        return cusipNumber;
    }

    /**
     * Sets the value of the cusipNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCusipNumber(JAXBElement<String> value) {
        this.cusipNumber = value;
    }

    /**
     * Gets the value of the isSettleTypeAmerican property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSettleTypeAmerican() {
        return isSettleTypeAmerican;
    }

    /**
     * Sets the value of the isSettleTypeAmerican property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSettleTypeAmerican(JAXBElement<Long> value) {
        this.isSettleTypeAmerican = value;
    }

    /**
     * Gets the value of the isid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsid() {
        return isid;
    }

    /**
     * Sets the value of the isid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsid(JAXBElement<String> value) {
        this.isid = value;
    }

    /**
     * Gets the value of the mmfNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getMmfNumber() {
        return mmfNumber;
    }

    /**
     * Sets the value of the mmfNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setMmfNumber(JAXBElement<Double> value) {
        this.mmfNumber = value;
    }

    /**
     * Gets the value of the couponRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getCouponRate() {
        return couponRate;
    }

    /**
     * Sets the value of the couponRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setCouponRate(JAXBElement<Double> value) {
        this.couponRate = value;
    }

    /**
     * Gets the value of the unvestedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getUnvestedQuantity() {
        return unvestedQuantity;
    }

    /**
     * Sets the value of the unvestedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setUnvestedQuantity(JAXBElement<Double> value) {
        this.unvestedQuantity = value;
    }

    /**
     * Gets the value of the vestedValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getVestedValue() {
        return vestedValue;
    }

    /**
     * Sets the value of the vestedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setVestedValue(JAXBElement<YMoney> value) {
        this.vestedValue = value;
    }

    /**
     * Gets the value of the currencyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrencyType() {
        return currencyType;
    }

    /**
     * Sets the value of the currencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrencyType(JAXBElement<String> value) {
        this.currencyType = value;
    }

    /**
     * Gets the value of the commodityType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCommodityType() {
        return commodityType;
    }

    /**
     * Sets the value of the commodityType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCommodityType(JAXBElement<String> value) {
        this.commodityType = value;
    }

    /**
     * Gets the value of the vestedSharesEx property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getVestedSharesEx() {
        return vestedSharesEx;
    }

    /**
     * Sets the value of the vestedSharesEx property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setVestedSharesEx(JAXBElement<Double> value) {
        this.vestedSharesEx = value;
    }

    /**
     * Gets the value of the spRating property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSpRating() {
        return spRating;
    }

    /**
     * Sets the value of the spRating property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSpRating(JAXBElement<String> value) {
        this.spRating = value;
    }

    /**
     * Gets the value of the currentYield property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getCurrentYield() {
        return currentYield;
    }

    /**
     * Sets the value of the currentYield property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setCurrentYield(JAXBElement<Double> value) {
        this.currentYield = value;
    }

    /**
     * Gets the value of the quantityGrantsAccepted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getQuantityGrantsAccepted() {
        return quantityGrantsAccepted;
    }

    /**
     * Sets the value of the quantityGrantsAccepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setQuantityGrantsAccepted(JAXBElement<Double> value) {
        this.quantityGrantsAccepted = value;
    }

    /**
     * Gets the value of the planName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlanName() {
        return planName;
    }

    /**
     * Sets the value of the planName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlanName(JAXBElement<String> value) {
        this.planName = value;
    }

    /**
     * Gets the value of the assetClassId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAssetClassId() {
        return assetClassId;
    }

    /**
     * Sets the value of the assetClassId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAssetClassId(JAXBElement<Long> value) {
        this.assetClassId = value;
    }

    /**
     * Gets the value of the assetClass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAssetClass() {
        return assetClass;
    }

    /**
     * Sets the value of the assetClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAssetClass(JAXBElement<String> value) {
        this.assetClass = value;
    }

    /**
     * Gets the value of the localizedAssetClass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAssetClass() {
        return localizedAssetClass;
    }

    /**
     * Sets the value of the localizedAssetClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAssetClass(JAXBElement<String> value) {
        this.localizedAssetClass = value;
    }

    /**
     * Gets the value of the nominalYield property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getNominalYield() {
        return nominalYield;
    }

    /**
     * Sets the value of the nominalYield property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setNominalYield(JAXBElement<Double> value) {
        this.nominalYield = value;
    }

    /**
     * Gets the value of the isRestricted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsRestricted() {
        return isRestricted;
    }

    /**
     * Sets the value of the isRestricted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsRestricted(JAXBElement<Long> value) {
        this.isRestricted = value;
    }

    /**
     * Gets the value of the internalRefNo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInternalRefNo() {
        return internalRefNo;
    }

    /**
     * Sets the value of the internalRefNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInternalRefNo(JAXBElement<String> value) {
        this.internalRefNo = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setQuantity(JAXBElement<Double> value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the fiAssetClass property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFiAssetClass() {
        return fiAssetClass;
    }

    /**
     * Sets the value of the fiAssetClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFiAssetClass(JAXBElement<String> value) {
        this.fiAssetClass = value;
    }

    /**
     * Gets the value of the chngSinceLastPriced property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getChngSinceLastPriced() {
        return chngSinceLastPriced;
    }

    /**
     * Sets the value of the chngSinceLastPriced property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setChngSinceLastPriced(JAXBElement<YMoney> value) {
        this.chngSinceLastPriced = value;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setValue(JAXBElement<YMoney> value) {
        this.value = value;
    }

    /**
     * Gets the value of the employeeContribution property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEmployeeContribution() {
        return employeeContribution;
    }

    /**
     * Sets the value of the employeeContribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEmployeeContribution(JAXBElement<YMoney> value) {
        this.employeeContribution = value;
    }

    /**
     * Gets the value of the parValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getParValue() {
        return parValue;
    }

    /**
     * Sets the value of the parValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setParValue(JAXBElement<YMoney> value) {
        this.parValue = value;
    }

    /**
     * Gets the value of the percentageChange property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getPercentageChange() {
        return percentageChange;
    }

    /**
     * Sets the value of the percentageChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setPercentageChange(JAXBElement<Double> value) {
        this.percentageChange = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the contractQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getContractQuantity() {
        return contractQuantity;
    }

    /**
     * Sets the value of the contractQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setContractQuantity(JAXBElement<Double> value) {
        this.contractQuantity = value;
    }

    /**
     * Gets the value of the grantDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getGrantDate() {
        return grantDate;
    }

    /**
     * Sets the value of the grantDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setGrantDate(JAXBElement<YDate> value) {
        this.grantDate = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyName(JAXBElement<String> value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the symbol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSymbol() {
        return symbol;
    }

    /**
     * Sets the value of the symbol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSymbol(JAXBElement<String> value) {
        this.symbol = value;
    }

    /**
     * Gets the value of the quantityGrantsNotaccepted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getQuantityGrantsNotaccepted() {
        return quantityGrantsNotaccepted;
    }

    /**
     * Sets the value of the quantityGrantsNotaccepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setQuantityGrantsNotaccepted(JAXBElement<Double> value) {
        this.quantityGrantsNotaccepted = value;
    }

    /**
     * Gets the value of the isShort property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsShort() {
        return isShort;
    }

    /**
     * Sets the value of the isShort property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsShort(JAXBElement<Long> value) {
        this.isShort = value;
    }

    /**
     * Gets the value of the yieldToMaturity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getYieldToMaturity() {
        return yieldToMaturity;
    }

    /**
     * Sets the value of the yieldToMaturity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setYieldToMaturity(JAXBElement<Double> value) {
        this.yieldToMaturity = value;
    }

    /**
     * Gets the value of the couponFreqId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCouponFreqId() {
        return couponFreqId;
    }

    /**
     * Sets the value of the couponFreqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCouponFreqId(JAXBElement<Long> value) {
        this.couponFreqId = value;
    }

    /**
     * Gets the value of the couponFreq property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCouponFreq() {
        return couponFreq;
    }

    /**
     * Sets the value of the couponFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCouponFreq(JAXBElement<String> value) {
        this.couponFreq = value;
    }

    /**
     * Gets the value of the localizedCouponFreq property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedCouponFreq() {
        return localizedCouponFreq;
    }

    /**
     * Sets the value of the localizedCouponFreq property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedCouponFreq(JAXBElement<String> value) {
        this.localizedCouponFreq = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the unvestedValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnvestedValue() {
        return unvestedValue;
    }

    /**
     * Sets the value of the unvestedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnvestedValue(JAXBElement<YMoney> value) {
        this.unvestedValue = value;
    }

    /**
     * Gets the value of the callPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCallPrice() {
        return callPrice;
    }

    /**
     * Sets the value of the callPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCallPrice(JAXBElement<YMoney> value) {
        this.callPrice = value;
    }

    /**
     * Gets the value of the adjustmentFactor property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAdjustmentFactor() {
        return adjustmentFactor;
    }

    /**
     * Sets the value of the adjustmentFactor property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAdjustmentFactor(JAXBElement<Double> value) {
        this.adjustmentFactor = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setExpirationDate(JAXBElement<YDate> value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setMaturityDate(JAXBElement<YDate> value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the yieldAsofDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getYieldAsofDate() {
        return yieldAsofDate;
    }

    /**
     * Sets the value of the yieldAsofDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setYieldAsofDate(JAXBElement<YDate> value) {
        this.yieldAsofDate = value;
    }

    /**
     * Gets the value of the taxLots property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getTaxLots() {
        return taxLots;
    }

    /**
     * Sets the value of the taxLots property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setTaxLots(JAXBElement<List> value) {
        this.taxLots = value;
    }

    /**
     * Gets the value of the marketValueAdjustment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMarketValueAdjustment() {
        return marketValueAdjustment;
    }

    /**
     * Sets the value of the marketValueAdjustment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMarketValueAdjustment(JAXBElement<YMoney> value) {
        this.marketValueAdjustment = value;
    }

    /**
     * Gets the value of the lotSize property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLotSize() {
        return lotSize;
    }

    /**
     * Sets the value of the lotSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLotSize(JAXBElement<Long> value) {
        this.lotSize = value;
    }

    /**
     * Gets the value of the linkedBankAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLinkedBankAccountNumber() {
        return linkedBankAccountNumber;
    }

    /**
     * Sets the value of the linkedBankAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLinkedBankAccountNumber(JAXBElement<String> value) {
        this.linkedBankAccountNumber = value;
    }

    /**
     * Gets the value of the realizedGain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRealizedGain() {
        return realizedGain;
    }

    /**
     * Sets the value of the realizedGain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRealizedGain(JAXBElement<YMoney> value) {
        this.realizedGain = value;
    }

    /**
     * Gets the value of the priceAsOfDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPriceAsOfDate() {
        return priceAsOfDate;
    }

    /**
     * Sets the value of the priceAsOfDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPriceAsOfDate(JAXBElement<YDate> value) {
        this.priceAsOfDate = value;
    }

    /**
     * Gets the value of the planOptionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PlanOption }{@code >}
     *     
     */
    public JAXBElement<PlanOption> getPlanOptionType() {
        return planOptionType;
    }

    /**
     * Sets the value of the planOptionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PlanOption }{@code >}
     *     
     */
    public void setPlanOptionType(JAXBElement<PlanOption> value) {
        this.planOptionType = value;
    }

    /**
     * Gets the value of the isin property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsin() {
        return isin;
    }

    /**
     * Sets the value of the isin property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsin(JAXBElement<String> value) {
        this.isin = value;
    }

    /**
     * Gets the value of the sedol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSedol() {
        return sedol;
    }

    /**
     * Sets the value of the sedol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSedol(JAXBElement<String> value) {
        this.sedol = value;
    }

    /**
     * Gets the value of the exchange property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Exchange }{@code >}
     *     
     */
    public JAXBElement<Exchange> getExchange() {
        return exchange;
    }

    /**
     * Sets the value of the exchange property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Exchange }{@code >}
     *     
     */
    public void setExchange(JAXBElement<Exchange> value) {
        this.exchange = value;
    }

    /**
     * Gets the value of the domicile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDomicile() {
        return domicile;
    }

    /**
     * Sets the value of the domicile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDomicile(JAXBElement<String> value) {
        this.domicile = value;
    }

    /**
     * Gets the value of the securityId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSecurityId() {
        return securityId;
    }

    /**
     * Sets the value of the securityId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSecurityId(JAXBElement<Long> value) {
        this.securityId = value;
    }

    /**
     * Gets the value of the securityInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public JAXBElement<InvestmentSecurity> getSecurityInfo() {
        return securityInfo;
    }

    /**
     * Sets the value of the securityInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public void setSecurityInfo(JAXBElement<InvestmentSecurity> value) {
        this.securityInfo = value;
    }

    /**
     * Gets the value of the isUnderlyingSecurity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsUnderlyingSecurity() {
        return isUnderlyingSecurity;
    }

    /**
     * Sets the value of the isUnderlyingSecurity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsUnderlyingSecurity(JAXBElement<Long> value) {
        this.isUnderlyingSecurity = value;
    }

    /**
     * Gets the value of the scrapedPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getScrapedPrice() {
        return scrapedPrice;
    }

    /**
     * Sets the value of the scrapedPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setScrapedPrice(JAXBElement<YMoney> value) {
        this.scrapedPrice = value;
    }

    /**
     * Gets the value of the scrapedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getScrapedQuantity() {
        return scrapedQuantity;
    }

    /**
     * Sets the value of the scrapedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setScrapedQuantity(JAXBElement<Double> value) {
        this.scrapedQuantity = value;
    }

    /**
     * Gets the value of the isSymbolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSymbolNormalized() {
        return isSymbolNormalized;
    }

    /**
     * Sets the value of the isSymbolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSymbolNormalized(JAXBElement<Long> value) {
        this.isSymbolNormalized = value;
    }

    /**
     * Gets the value of the isCusipNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsCusipNormalized() {
        return isCusipNormalized;
    }

    /**
     * Sets the value of the isCusipNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsCusipNormalized(JAXBElement<Long> value) {
        this.isCusipNormalized = value;
    }

    /**
     * Gets the value of the isIsinNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsIsinNormalized() {
        return isIsinNormalized;
    }

    /**
     * Sets the value of the isIsinNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsIsinNormalized(JAXBElement<Long> value) {
        this.isIsinNormalized = value;
    }

    /**
     * Gets the value of the isSedolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSedolNormalized() {
        return isSedolNormalized;
    }

    /**
     * Sets the value of the isSedolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSedolNormalized(JAXBElement<Long> value) {
        this.isSedolNormalized = value;
    }

}
