
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for InsCoverageLimitData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsCoverageLimitData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insCoverageLimitId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insCoverageId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isOutOfPocketLimit" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insPeriodTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insPeriodType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedInsPeriodType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="amount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="insCoverageLimitTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insCoverageLimitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedInsCoverageLimitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="insUnitTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insUnitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedInsUnitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsCoverageLimitData", propOrder = {
    "srcElementId",
    "isSeidMod",
    "isSeidFromDataSource",
    "insCoverageLimitId",
    "insCoverageId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "isOutOfPocketLimit",
    "insPeriodTypeId",
    "insPeriodType",
    "localizedInsPeriodType",
    "amount",
    "insCoverageLimitTypeId",
    "insCoverageLimitType",
    "localizedInsCoverageLimitType",
    "insUnitTypeId",
    "insUnitType",
    "localizedInsUnitType",
    "description"
})
public class InsCoverageLimitData
    extends BaseTagData
{

    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "insCoverageLimitId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insCoverageLimitId;
    @XmlElementRef(name = "insCoverageId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insCoverageId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "isOutOfPocketLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isOutOfPocketLimit;
    @XmlElementRef(name = "insPeriodTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insPeriodTypeId;
    @XmlElementRef(name = "insPeriodType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> insPeriodType;
    @XmlElementRef(name = "localizedInsPeriodType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedInsPeriodType;
    @XmlElementRef(name = "amount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amount;
    @XmlElementRef(name = "insCoverageLimitTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insCoverageLimitTypeId;
    @XmlElementRef(name = "insCoverageLimitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> insCoverageLimitType;
    @XmlElementRef(name = "localizedInsCoverageLimitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedInsCoverageLimitType;
    @XmlElementRef(name = "insUnitTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insUnitTypeId;
    @XmlElementRef(name = "insUnitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> insUnitType;
    @XmlElementRef(name = "localizedInsUnitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedInsUnitType;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the insCoverageLimitId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsCoverageLimitId() {
        return insCoverageLimitId;
    }

    /**
     * Sets the value of the insCoverageLimitId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsCoverageLimitId(JAXBElement<Long> value) {
        this.insCoverageLimitId = value;
    }

    /**
     * Gets the value of the insCoverageId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsCoverageId() {
        return insCoverageId;
    }

    /**
     * Sets the value of the insCoverageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsCoverageId(JAXBElement<Long> value) {
        this.insCoverageId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the isOutOfPocketLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsOutOfPocketLimit() {
        return isOutOfPocketLimit;
    }

    /**
     * Sets the value of the isOutOfPocketLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsOutOfPocketLimit(JAXBElement<Long> value) {
        this.isOutOfPocketLimit = value;
    }

    /**
     * Gets the value of the insPeriodTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsPeriodTypeId() {
        return insPeriodTypeId;
    }

    /**
     * Sets the value of the insPeriodTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsPeriodTypeId(JAXBElement<Long> value) {
        this.insPeriodTypeId = value;
    }

    /**
     * Gets the value of the insPeriodType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInsPeriodType() {
        return insPeriodType;
    }

    /**
     * Sets the value of the insPeriodType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInsPeriodType(JAXBElement<String> value) {
        this.insPeriodType = value;
    }

    /**
     * Gets the value of the localizedInsPeriodType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedInsPeriodType() {
        return localizedInsPeriodType;
    }

    /**
     * Sets the value of the localizedInsPeriodType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedInsPeriodType(JAXBElement<String> value) {
        this.localizedInsPeriodType = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmount(JAXBElement<YMoney> value) {
        this.amount = value;
    }

    /**
     * Gets the value of the insCoverageLimitTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsCoverageLimitTypeId() {
        return insCoverageLimitTypeId;
    }

    /**
     * Sets the value of the insCoverageLimitTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsCoverageLimitTypeId(JAXBElement<Long> value) {
        this.insCoverageLimitTypeId = value;
    }

    /**
     * Gets the value of the insCoverageLimitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInsCoverageLimitType() {
        return insCoverageLimitType;
    }

    /**
     * Sets the value of the insCoverageLimitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInsCoverageLimitType(JAXBElement<String> value) {
        this.insCoverageLimitType = value;
    }

    /**
     * Gets the value of the localizedInsCoverageLimitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedInsCoverageLimitType() {
        return localizedInsCoverageLimitType;
    }

    /**
     * Sets the value of the localizedInsCoverageLimitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedInsCoverageLimitType(JAXBElement<String> value) {
        this.localizedInsCoverageLimitType = value;
    }

    /**
     * Gets the value of the insUnitTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsUnitTypeId() {
        return insUnitTypeId;
    }

    /**
     * Sets the value of the insUnitTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsUnitTypeId(JAXBElement<Long> value) {
        this.insUnitTypeId = value;
    }

    /**
     * Gets the value of the insUnitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInsUnitType() {
        return insUnitType;
    }

    /**
     * Sets the value of the insUnitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInsUnitType(JAXBElement<String> value) {
        this.insUnitType = value;
    }

    /**
     * Gets the value of the localizedInsUnitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedInsUnitType() {
        return localizedInsUnitType;
    }

    /**
     * Sets the value of the localizedInsUnitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedInsUnitType(JAXBElement<String> value) {
        this.localizedInsUnitType = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

}
