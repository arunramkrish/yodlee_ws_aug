
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.AnnuityOption;
import com.yodlee.soap.core.dataservice.enums.BenefitFrequency;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for InsuranceData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuranceData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetupId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lienHolderId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="agentPersonInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPreferenceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insuranceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insLoginAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isGuranteedRenewPolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policyTermFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="transListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="transListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="premiumAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="adjustablePremiumAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="levelPremiumAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="deductible" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="minimumAmountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="installmentAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="lastPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="remainingBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cashValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="deathBenefit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accidentalDeathBenefit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="amountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="loanAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="loanAvailable" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="loanPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="annuityBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="paymentApartmentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentAddress1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentFulladdress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policyStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="policyStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedPolicyStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDoubleIndemnity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isFamilyMaintenancePolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="policyTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="asOf" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="applicableProviderNetwork" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="groupNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="effectiveDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="dueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isFamilyIncomePolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isGuranteedCostPolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastPaymentDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDerivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyApartmentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyAddress1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyFulladdress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policyTermToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="provider" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isOrdinaryLifePolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayEnrolled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isGroupInsurancePolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isPaidUpPolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="replacementValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isJointLifePolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lifeInsuranceTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lifeInsuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedLifeInsuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanApr" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isRenewedPolicy" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="groupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="homeInsuranceTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="homeInsuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedHomeInsuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="insuranceTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="insuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedInsuranceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stmtListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="stmtListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="expirationDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUserAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayScraped" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetup" type="{http://types.dataservice.core.soap.yodlee.com}ExtAutopaySetupData" minOccurs="0"/>
 *         &lt;element name="coverages" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="beneficiarys" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="claims" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="discounts" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="paymentDues" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="prescriptions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insuranceTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insuranceStatements" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="lienHolder" type="{http://types.dataservice.core.soap.yodlee.com}LienHolder" minOccurs="0"/>
 *         &lt;element name="personInformation" type="{http://types.dataservice.core.soap.yodlee.com}PersonData" minOccurs="0"/>
 *         &lt;element name="insPolicyHolders" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insuranceDrivers" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insureds" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insuranceVehicles" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insMutualFunds" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="billPreference" type="{http://types.dataservice.core.soap.yodlee.com}BillPreferenceData" minOccurs="0"/>
 *         &lt;element name="paymentDetails" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="insAnnuitys" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaperlessStmtOn" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="annuitantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="jointAnnuitantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="planName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="premiumPaymentTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="benefitAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="surrenderCharge" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="guaranteedDeathBenefit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="freeWithdrawalAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="annuityAccountValue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accruedInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="premiumPaymentFrequency" type="{http://enums.dataservice.core.soap.yodlee.com}BenefitFrequency" minOccurs="0"/>
 *         &lt;element name="guaranteedInterestRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="insuranceBenefitFrequency" type="{http://enums.dataservice.core.soap.yodlee.com}BenefitFrequency" minOccurs="0"/>
 *         &lt;element name="annuityOption" type="{http://enums.dataservice.core.soap.yodlee.com}AnnuityOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuranceData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "extAutopaySetupId",
    "lienHolderId",
    "agentPersonInformationId",
    "billPreferenceId",
    "insuranceId",
    "insLoginAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "accountNumber",
    "isGuranteedRenewPolicy",
    "accountHolder",
    "policyTermFromDate",
    "transListToDate",
    "transListFromDate",
    "premiumAmount",
    "adjustablePremiumAmount",
    "levelPremiumAmount",
    "deductible",
    "minimumAmountDue",
    "installmentAmount",
    "lastPayment",
    "remainingBalance",
    "cashValue",
    "deathBenefit",
    "accidentalDeathBenefit",
    "amountDue",
    "loanAmount",
    "loanAvailable",
    "loanPayment",
    "annuityBalance",
    "paymentApartmentNumber",
    "paymentAddress2",
    "paymentCountry",
    "paymentProvince",
    "paymentState",
    "paymentZip",
    "paymentAddress1",
    "paymentCity",
    "paymentFulladdress",
    "policyStatusId",
    "policyStatus",
    "localizedPolicyStatus",
    "isDoubleIndemnity",
    "isFamilyMaintenancePolicy",
    "policyTerm",
    "asOf",
    "applicableProviderNetwork",
    "groupNumber",
    "effectiveDate",
    "dueDate",
    "isFamilyIncomePolicy",
    "isGuranteedCostPolicy",
    "lastPaymentDate",
    "derivedAutopayEnrollmentStatusId",
    "derivedAutopayEnrollmentStatus",
    "localizedDerivedAutopayEnrollmentStatus",
    "propertyApartmentNumber",
    "propertyAddress2",
    "propertyCountry",
    "propertyProvince",
    "propertyState",
    "propertyZip",
    "propertyAddress1",
    "propertyCity",
    "propertyFulladdress",
    "policyTermToDate",
    "accountName",
    "provider",
    "isOrdinaryLifePolicy",
    "isExtAutopayEnrolled",
    "isGroupInsurancePolicy",
    "isPaidUpPolicy",
    "replacementValue",
    "isJointLifePolicy",
    "lifeInsuranceTypeId",
    "lifeInsuranceType",
    "localizedLifeInsuranceType",
    "userAutopayEnrollmentStatusLastUpdated",
    "loanApr",
    "isRenewedPolicy",
    "link",
    "groupName",
    "homeInsuranceTypeId",
    "homeInsuranceType",
    "localizedHomeInsuranceType",
    "insuranceTypeId",
    "insuranceType",
    "localizedInsuranceType",
    "stmtListToDate",
    "stmtListFromDate",
    "expirationDate",
    "userAutopayEnrollmentStatusId",
    "userAutopayEnrollmentStatus",
    "localizedUserAutopayEnrollmentStatus",
    "derivedAutopayEnrollmentStatusLastUpdated",
    "isExtAutopayScraped",
    "autopayEnrollmentStatusId",
    "autopayEnrollmentStatus",
    "localizedAutopayEnrollmentStatus",
    "extAutopaySetup",
    "coverages",
    "beneficiarys",
    "claims",
    "discounts",
    "paymentDues",
    "prescriptions",
    "insuranceTransactions",
    "insuranceStatements",
    "lienHolder",
    "personInformation",
    "insPolicyHolders",
    "insuranceDrivers",
    "insureds",
    "insuranceVehicles",
    "insMutualFunds",
    "billPreference",
    "paymentDetails",
    "insAnnuitys",
    "accountNicknameAtSrcSite",
    "isPaperlessStmtOn",
    "created",
    "accountOpenDate",
    "accountCloseDate",
    "secondaryAccountHolderName",
    "annuitantName",
    "jointAnnuitantName",
    "planName",
    "premiumPaymentTerm",
    "benefitAmount",
    "surrenderCharge",
    "guaranteedDeathBenefit",
    "freeWithdrawalAmount",
    "annuityAccountValue",
    "accruedInterest",
    "siteAccountStatus",
    "premiumPaymentFrequency",
    "guaranteedInterestRate",
    "insuranceBenefitFrequency",
    "annuityOption"
})
public class InsuranceData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "extAutopaySetupId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extAutopaySetupId;
    @XmlElementRef(name = "lienHolderId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lienHolderId;
    @XmlElementRef(name = "agentPersonInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> agentPersonInformationId;
    @XmlElementRef(name = "billPreferenceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPreferenceId;
    @XmlElementRef(name = "insuranceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insuranceId;
    @XmlElementRef(name = "insLoginAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insLoginAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "isGuranteedRenewPolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isGuranteedRenewPolicy;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "policyTermFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> policyTermFromDate;
    @XmlElementRef(name = "transListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListToDate;
    @XmlElementRef(name = "transListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListFromDate;
    @XmlElementRef(name = "premiumAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> premiumAmount;
    @XmlElementRef(name = "adjustablePremiumAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> adjustablePremiumAmount;
    @XmlElementRef(name = "levelPremiumAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> levelPremiumAmount;
    @XmlElementRef(name = "deductible", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> deductible;
    @XmlElementRef(name = "minimumAmountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> minimumAmountDue;
    @XmlElementRef(name = "installmentAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> installmentAmount;
    @XmlElementRef(name = "lastPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPayment;
    @XmlElementRef(name = "remainingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> remainingBalance;
    @XmlElementRef(name = "cashValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cashValue;
    @XmlElementRef(name = "deathBenefit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> deathBenefit;
    @XmlElementRef(name = "accidentalDeathBenefit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> accidentalDeathBenefit;
    @XmlElementRef(name = "amountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountDue;
    @XmlElementRef(name = "loanAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> loanAmount;
    @XmlElementRef(name = "loanAvailable", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> loanAvailable;
    @XmlElementRef(name = "loanPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> loanPayment;
    @XmlElementRef(name = "annuityBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> annuityBalance;
    @XmlElementRef(name = "paymentApartmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentApartmentNumber;
    @XmlElementRef(name = "paymentAddress2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentAddress2;
    @XmlElementRef(name = "paymentCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentCountry;
    @XmlElementRef(name = "paymentProvince", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentProvince;
    @XmlElementRef(name = "paymentState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentState;
    @XmlElementRef(name = "paymentZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentZip;
    @XmlElementRef(name = "paymentAddress1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentAddress1;
    @XmlElementRef(name = "paymentCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentCity;
    @XmlElementRef(name = "paymentFulladdress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentFulladdress;
    @XmlElementRef(name = "policyStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> policyStatusId;
    @XmlElementRef(name = "policyStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> policyStatus;
    @XmlElementRef(name = "localizedPolicyStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedPolicyStatus;
    @XmlElementRef(name = "isDoubleIndemnity", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDoubleIndemnity;
    @XmlElementRef(name = "isFamilyMaintenancePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isFamilyMaintenancePolicy;
    @XmlElementRef(name = "policyTerm", type = JAXBElement.class, required = false)
    protected JAXBElement<String> policyTerm;
    @XmlElementRef(name = "asOf", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asOf;
    @XmlElementRef(name = "applicableProviderNetwork", type = JAXBElement.class, required = false)
    protected JAXBElement<String> applicableProviderNetwork;
    @XmlElementRef(name = "groupNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> groupNumber;
    @XmlElementRef(name = "effectiveDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> effectiveDate;
    @XmlElementRef(name = "dueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dueDate;
    @XmlElementRef(name = "isFamilyIncomePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isFamilyIncomePolicy;
    @XmlElementRef(name = "isGuranteedCostPolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isGuranteedCostPolicy;
    @XmlElementRef(name = "lastPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPaymentDate;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusId;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> derivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedDerivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDerivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "propertyApartmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyApartmentNumber;
    @XmlElementRef(name = "propertyAddress2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyAddress2;
    @XmlElementRef(name = "propertyCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyCountry;
    @XmlElementRef(name = "propertyProvince", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyProvince;
    @XmlElementRef(name = "propertyState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyState;
    @XmlElementRef(name = "propertyZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyZip;
    @XmlElementRef(name = "propertyAddress1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyAddress1;
    @XmlElementRef(name = "propertyCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyCity;
    @XmlElementRef(name = "propertyFulladdress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyFulladdress;
    @XmlElementRef(name = "policyTermToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> policyTermToDate;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "provider", type = JAXBElement.class, required = false)
    protected JAXBElement<String> provider;
    @XmlElementRef(name = "isOrdinaryLifePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isOrdinaryLifePolicy;
    @XmlElementRef(name = "isExtAutopayEnrolled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayEnrolled;
    @XmlElementRef(name = "isGroupInsurancePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isGroupInsurancePolicy;
    @XmlElementRef(name = "isPaidUpPolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaidUpPolicy;
    @XmlElementRef(name = "replacementValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> replacementValue;
    @XmlElementRef(name = "isJointLifePolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isJointLifePolicy;
    @XmlElementRef(name = "lifeInsuranceTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lifeInsuranceTypeId;
    @XmlElementRef(name = "lifeInsuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> lifeInsuranceType;
    @XmlElementRef(name = "localizedLifeInsuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedLifeInsuranceType;
    @XmlElementRef(name = "userAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "loanApr", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> loanApr;
    @XmlElementRef(name = "isRenewedPolicy", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isRenewedPolicy;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "groupName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> groupName;
    @XmlElementRef(name = "homeInsuranceTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> homeInsuranceTypeId;
    @XmlElementRef(name = "homeInsuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> homeInsuranceType;
    @XmlElementRef(name = "localizedHomeInsuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedHomeInsuranceType;
    @XmlElementRef(name = "insuranceTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> insuranceTypeId;
    @XmlElementRef(name = "insuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> insuranceType;
    @XmlElementRef(name = "localizedInsuranceType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedInsuranceType;
    @XmlElementRef(name = "stmtListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListToDate;
    @XmlElementRef(name = "stmtListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListFromDate;
    @XmlElementRef(name = "expirationDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> expirationDate;
    @XmlElementRef(name = "userAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusId;
    @XmlElementRef(name = "userAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedUserAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUserAutopayEnrollmentStatus;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "isExtAutopayScraped", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayScraped;
    @XmlElementRef(name = "autopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> autopayEnrollmentStatusId;
    @XmlElementRef(name = "autopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> autopayEnrollmentStatus;
    @XmlElementRef(name = "localizedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAutopayEnrollmentStatus;
    @XmlElementRef(name = "extAutopaySetup", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtAutopaySetupData> extAutopaySetup;
    @XmlElementRef(name = "coverages", type = JAXBElement.class, required = false)
    protected JAXBElement<List> coverages;
    @XmlElementRef(name = "beneficiarys", type = JAXBElement.class, required = false)
    protected JAXBElement<List> beneficiarys;
    @XmlElementRef(name = "claims", type = JAXBElement.class, required = false)
    protected JAXBElement<List> claims;
    @XmlElementRef(name = "discounts", type = JAXBElement.class, required = false)
    protected JAXBElement<List> discounts;
    @XmlElementRef(name = "paymentDues", type = JAXBElement.class, required = false)
    protected JAXBElement<List> paymentDues;
    @XmlElementRef(name = "prescriptions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> prescriptions;
    @XmlElementRef(name = "insuranceTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insuranceTransactions;
    @XmlElementRef(name = "insuranceStatements", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insuranceStatements;
    @XmlElementRef(name = "lienHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<LienHolder> lienHolder;
    @XmlElementRef(name = "personInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonData> personInformation;
    @XmlElementRef(name = "insPolicyHolders", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insPolicyHolders;
    @XmlElementRef(name = "insuranceDrivers", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insuranceDrivers;
    @XmlElementRef(name = "insureds", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insureds;
    @XmlElementRef(name = "insuranceVehicles", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insuranceVehicles;
    @XmlElementRef(name = "insMutualFunds", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insMutualFunds;
    @XmlElementRef(name = "billPreference", type = JAXBElement.class, required = false)
    protected JAXBElement<BillPreferenceData> billPreference;
    @XmlElementRef(name = "paymentDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<List> paymentDetails;
    @XmlElementRef(name = "insAnnuitys", type = JAXBElement.class, required = false)
    protected JAXBElement<List> insAnnuitys;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "isPaperlessStmtOn", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaperlessStmtOn;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "annuitantName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> annuitantName;
    @XmlElementRef(name = "jointAnnuitantName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> jointAnnuitantName;
    @XmlElementRef(name = "planName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> planName;
    @XmlElementRef(name = "premiumPaymentTerm", type = JAXBElement.class, required = false)
    protected JAXBElement<String> premiumPaymentTerm;
    @XmlElementRef(name = "benefitAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> benefitAmount;
    @XmlElementRef(name = "surrenderCharge", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> surrenderCharge;
    @XmlElementRef(name = "guaranteedDeathBenefit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> guaranteedDeathBenefit;
    @XmlElementRef(name = "freeWithdrawalAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> freeWithdrawalAmount;
    @XmlElementRef(name = "annuityAccountValue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> annuityAccountValue;
    @XmlElementRef(name = "accruedInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> accruedInterest;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "premiumPaymentFrequency", type = JAXBElement.class, required = false)
    protected JAXBElement<BenefitFrequency> premiumPaymentFrequency;
    @XmlElementRef(name = "guaranteedInterestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> guaranteedInterestRate;
    @XmlElementRef(name = "insuranceBenefitFrequency", type = JAXBElement.class, required = false)
    protected JAXBElement<BenefitFrequency> insuranceBenefitFrequency;
    @XmlElementRef(name = "annuityOption", type = JAXBElement.class, required = false)
    protected JAXBElement<AnnuityOption> annuityOption;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the extAutopaySetupId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtAutopaySetupId() {
        return extAutopaySetupId;
    }

    /**
     * Sets the value of the extAutopaySetupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtAutopaySetupId(JAXBElement<Long> value) {
        this.extAutopaySetupId = value;
    }

    /**
     * Gets the value of the lienHolderId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLienHolderId() {
        return lienHolderId;
    }

    /**
     * Sets the value of the lienHolderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLienHolderId(JAXBElement<Long> value) {
        this.lienHolderId = value;
    }

    /**
     * Gets the value of the agentPersonInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAgentPersonInformationId() {
        return agentPersonInformationId;
    }

    /**
     * Sets the value of the agentPersonInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAgentPersonInformationId(JAXBElement<Long> value) {
        this.agentPersonInformationId = value;
    }

    /**
     * Gets the value of the billPreferenceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPreferenceId() {
        return billPreferenceId;
    }

    /**
     * Sets the value of the billPreferenceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPreferenceId(JAXBElement<Long> value) {
        this.billPreferenceId = value;
    }

    /**
     * Gets the value of the insuranceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsuranceId() {
        return insuranceId;
    }

    /**
     * Sets the value of the insuranceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsuranceId(JAXBElement<Long> value) {
        this.insuranceId = value;
    }

    /**
     * Gets the value of the insLoginAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsLoginAccountId() {
        return insLoginAccountId;
    }

    /**
     * Sets the value of the insLoginAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsLoginAccountId(JAXBElement<Long> value) {
        this.insLoginAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the isGuranteedRenewPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsGuranteedRenewPolicy() {
        return isGuranteedRenewPolicy;
    }

    /**
     * Sets the value of the isGuranteedRenewPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsGuranteedRenewPolicy(JAXBElement<Long> value) {
        this.isGuranteedRenewPolicy = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the policyTermFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPolicyTermFromDate() {
        return policyTermFromDate;
    }

    /**
     * Sets the value of the policyTermFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPolicyTermFromDate(JAXBElement<YDate> value) {
        this.policyTermFromDate = value;
    }

    /**
     * Gets the value of the transListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListToDate() {
        return transListToDate;
    }

    /**
     * Sets the value of the transListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListToDate(JAXBElement<YDate> value) {
        this.transListToDate = value;
    }

    /**
     * Gets the value of the transListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListFromDate() {
        return transListFromDate;
    }

    /**
     * Sets the value of the transListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListFromDate(JAXBElement<YDate> value) {
        this.transListFromDate = value;
    }

    /**
     * Gets the value of the premiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPremiumAmount() {
        return premiumAmount;
    }

    /**
     * Sets the value of the premiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPremiumAmount(JAXBElement<YMoney> value) {
        this.premiumAmount = value;
    }

    /**
     * Gets the value of the adjustablePremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdjustablePremiumAmount() {
        return adjustablePremiumAmount;
    }

    /**
     * Sets the value of the adjustablePremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdjustablePremiumAmount(JAXBElement<YMoney> value) {
        this.adjustablePremiumAmount = value;
    }

    /**
     * Gets the value of the levelPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLevelPremiumAmount() {
        return levelPremiumAmount;
    }

    /**
     * Sets the value of the levelPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLevelPremiumAmount(JAXBElement<YMoney> value) {
        this.levelPremiumAmount = value;
    }

    /**
     * Gets the value of the deductible property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDeductible() {
        return deductible;
    }

    /**
     * Sets the value of the deductible property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDeductible(JAXBElement<YMoney> value) {
        this.deductible = value;
    }

    /**
     * Gets the value of the minimumAmountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMinimumAmountDue() {
        return minimumAmountDue;
    }

    /**
     * Sets the value of the minimumAmountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMinimumAmountDue(JAXBElement<YMoney> value) {
        this.minimumAmountDue = value;
    }

    /**
     * Gets the value of the installmentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInstallmentAmount() {
        return installmentAmount;
    }

    /**
     * Sets the value of the installmentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInstallmentAmount(JAXBElement<YMoney> value) {
        this.installmentAmount = value;
    }

    /**
     * Gets the value of the lastPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPayment() {
        return lastPayment;
    }

    /**
     * Sets the value of the lastPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPayment(JAXBElement<YMoney> value) {
        this.lastPayment = value;
    }

    /**
     * Gets the value of the remainingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRemainingBalance() {
        return remainingBalance;
    }

    /**
     * Sets the value of the remainingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRemainingBalance(JAXBElement<YMoney> value) {
        this.remainingBalance = value;
    }

    /**
     * Gets the value of the cashValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCashValue() {
        return cashValue;
    }

    /**
     * Sets the value of the cashValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCashValue(JAXBElement<YMoney> value) {
        this.cashValue = value;
    }

    /**
     * Gets the value of the deathBenefit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDeathBenefit() {
        return deathBenefit;
    }

    /**
     * Sets the value of the deathBenefit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDeathBenefit(JAXBElement<YMoney> value) {
        this.deathBenefit = value;
    }

    /**
     * Gets the value of the accidentalDeathBenefit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAccidentalDeathBenefit() {
        return accidentalDeathBenefit;
    }

    /**
     * Sets the value of the accidentalDeathBenefit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAccidentalDeathBenefit(JAXBElement<YMoney> value) {
        this.accidentalDeathBenefit = value;
    }

    /**
     * Gets the value of the amountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountDue() {
        return amountDue;
    }

    /**
     * Sets the value of the amountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountDue(JAXBElement<YMoney> value) {
        this.amountDue = value;
    }

    /**
     * Gets the value of the loanAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLoanAmount() {
        return loanAmount;
    }

    /**
     * Sets the value of the loanAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLoanAmount(JAXBElement<YMoney> value) {
        this.loanAmount = value;
    }

    /**
     * Gets the value of the loanAvailable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLoanAvailable() {
        return loanAvailable;
    }

    /**
     * Sets the value of the loanAvailable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLoanAvailable(JAXBElement<YMoney> value) {
        this.loanAvailable = value;
    }

    /**
     * Gets the value of the loanPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLoanPayment() {
        return loanPayment;
    }

    /**
     * Sets the value of the loanPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLoanPayment(JAXBElement<YMoney> value) {
        this.loanPayment = value;
    }

    /**
     * Gets the value of the annuityBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAnnuityBalance() {
        return annuityBalance;
    }

    /**
     * Sets the value of the annuityBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAnnuityBalance(JAXBElement<YMoney> value) {
        this.annuityBalance = value;
    }

    /**
     * Gets the value of the paymentApartmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentApartmentNumber() {
        return paymentApartmentNumber;
    }

    /**
     * Sets the value of the paymentApartmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentApartmentNumber(JAXBElement<String> value) {
        this.paymentApartmentNumber = value;
    }

    /**
     * Gets the value of the paymentAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentAddress2() {
        return paymentAddress2;
    }

    /**
     * Sets the value of the paymentAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentAddress2(JAXBElement<String> value) {
        this.paymentAddress2 = value;
    }

    /**
     * Gets the value of the paymentCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentCountry() {
        return paymentCountry;
    }

    /**
     * Sets the value of the paymentCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentCountry(JAXBElement<String> value) {
        this.paymentCountry = value;
    }

    /**
     * Gets the value of the paymentProvince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentProvince() {
        return paymentProvince;
    }

    /**
     * Sets the value of the paymentProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentProvince(JAXBElement<String> value) {
        this.paymentProvince = value;
    }

    /**
     * Gets the value of the paymentState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentState() {
        return paymentState;
    }

    /**
     * Sets the value of the paymentState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentState(JAXBElement<String> value) {
        this.paymentState = value;
    }

    /**
     * Gets the value of the paymentZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentZip() {
        return paymentZip;
    }

    /**
     * Sets the value of the paymentZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentZip(JAXBElement<String> value) {
        this.paymentZip = value;
    }

    /**
     * Gets the value of the paymentAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentAddress1() {
        return paymentAddress1;
    }

    /**
     * Sets the value of the paymentAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentAddress1(JAXBElement<String> value) {
        this.paymentAddress1 = value;
    }

    /**
     * Gets the value of the paymentCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentCity() {
        return paymentCity;
    }

    /**
     * Sets the value of the paymentCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentCity(JAXBElement<String> value) {
        this.paymentCity = value;
    }

    /**
     * Gets the value of the paymentFulladdress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentFulladdress() {
        return paymentFulladdress;
    }

    /**
     * Sets the value of the paymentFulladdress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentFulladdress(JAXBElement<String> value) {
        this.paymentFulladdress = value;
    }

    /**
     * Gets the value of the policyStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPolicyStatusId() {
        return policyStatusId;
    }

    /**
     * Sets the value of the policyStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPolicyStatusId(JAXBElement<Long> value) {
        this.policyStatusId = value;
    }

    /**
     * Gets the value of the policyStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyStatus() {
        return policyStatus;
    }

    /**
     * Sets the value of the policyStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyStatus(JAXBElement<String> value) {
        this.policyStatus = value;
    }

    /**
     * Gets the value of the localizedPolicyStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedPolicyStatus() {
        return localizedPolicyStatus;
    }

    /**
     * Sets the value of the localizedPolicyStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedPolicyStatus(JAXBElement<String> value) {
        this.localizedPolicyStatus = value;
    }

    /**
     * Gets the value of the isDoubleIndemnity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDoubleIndemnity() {
        return isDoubleIndemnity;
    }

    /**
     * Sets the value of the isDoubleIndemnity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDoubleIndemnity(JAXBElement<Long> value) {
        this.isDoubleIndemnity = value;
    }

    /**
     * Gets the value of the isFamilyMaintenancePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsFamilyMaintenancePolicy() {
        return isFamilyMaintenancePolicy;
    }

    /**
     * Sets the value of the isFamilyMaintenancePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsFamilyMaintenancePolicy(JAXBElement<Long> value) {
        this.isFamilyMaintenancePolicy = value;
    }

    /**
     * Gets the value of the policyTerm property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyTerm() {
        return policyTerm;
    }

    /**
     * Sets the value of the policyTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyTerm(JAXBElement<String> value) {
        this.policyTerm = value;
    }

    /**
     * Gets the value of the asOf property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsOf() {
        return asOf;
    }

    /**
     * Sets the value of the asOf property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsOf(JAXBElement<YDate> value) {
        this.asOf = value;
    }

    /**
     * Gets the value of the applicableProviderNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApplicableProviderNetwork() {
        return applicableProviderNetwork;
    }

    /**
     * Sets the value of the applicableProviderNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApplicableProviderNetwork(JAXBElement<String> value) {
        this.applicableProviderNetwork = value;
    }

    /**
     * Gets the value of the groupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getGroupNumber() {
        return groupNumber;
    }

    /**
     * Sets the value of the groupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setGroupNumber(JAXBElement<String> value) {
        this.groupNumber = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setEffectiveDate(JAXBElement<YDate> value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDueDate(JAXBElement<YDate> value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the isFamilyIncomePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsFamilyIncomePolicy() {
        return isFamilyIncomePolicy;
    }

    /**
     * Sets the value of the isFamilyIncomePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsFamilyIncomePolicy(JAXBElement<Long> value) {
        this.isFamilyIncomePolicy = value;
    }

    /**
     * Gets the value of the isGuranteedCostPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsGuranteedCostPolicy() {
        return isGuranteedCostPolicy;
    }

    /**
     * Sets the value of the isGuranteedCostPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsGuranteedCostPolicy(JAXBElement<Long> value) {
        this.isGuranteedCostPolicy = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPaymentDate(JAXBElement<YDate> value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusId() {
        return derivedAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDerivedAutopayEnrollmentStatus() {
        return derivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.derivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDerivedAutopayEnrollmentStatus() {
        return localizedDerivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedDerivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the propertyApartmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyApartmentNumber() {
        return propertyApartmentNumber;
    }

    /**
     * Sets the value of the propertyApartmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyApartmentNumber(JAXBElement<String> value) {
        this.propertyApartmentNumber = value;
    }

    /**
     * Gets the value of the propertyAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyAddress2() {
        return propertyAddress2;
    }

    /**
     * Sets the value of the propertyAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyAddress2(JAXBElement<String> value) {
        this.propertyAddress2 = value;
    }

    /**
     * Gets the value of the propertyCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyCountry() {
        return propertyCountry;
    }

    /**
     * Sets the value of the propertyCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyCountry(JAXBElement<String> value) {
        this.propertyCountry = value;
    }

    /**
     * Gets the value of the propertyProvince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyProvince() {
        return propertyProvince;
    }

    /**
     * Sets the value of the propertyProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyProvince(JAXBElement<String> value) {
        this.propertyProvince = value;
    }

    /**
     * Gets the value of the propertyState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyState() {
        return propertyState;
    }

    /**
     * Sets the value of the propertyState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyState(JAXBElement<String> value) {
        this.propertyState = value;
    }

    /**
     * Gets the value of the propertyZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyZip() {
        return propertyZip;
    }

    /**
     * Sets the value of the propertyZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyZip(JAXBElement<String> value) {
        this.propertyZip = value;
    }

    /**
     * Gets the value of the propertyAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyAddress1() {
        return propertyAddress1;
    }

    /**
     * Sets the value of the propertyAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyAddress1(JAXBElement<String> value) {
        this.propertyAddress1 = value;
    }

    /**
     * Gets the value of the propertyCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyCity() {
        return propertyCity;
    }

    /**
     * Sets the value of the propertyCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyCity(JAXBElement<String> value) {
        this.propertyCity = value;
    }

    /**
     * Gets the value of the propertyFulladdress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyFulladdress() {
        return propertyFulladdress;
    }

    /**
     * Sets the value of the propertyFulladdress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyFulladdress(JAXBElement<String> value) {
        this.propertyFulladdress = value;
    }

    /**
     * Gets the value of the policyTermToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPolicyTermToDate() {
        return policyTermToDate;
    }

    /**
     * Sets the value of the policyTermToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPolicyTermToDate(JAXBElement<YDate> value) {
        this.policyTermToDate = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the provider property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProvider() {
        return provider;
    }

    /**
     * Sets the value of the provider property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProvider(JAXBElement<String> value) {
        this.provider = value;
    }

    /**
     * Gets the value of the isOrdinaryLifePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsOrdinaryLifePolicy() {
        return isOrdinaryLifePolicy;
    }

    /**
     * Sets the value of the isOrdinaryLifePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsOrdinaryLifePolicy(JAXBElement<Long> value) {
        this.isOrdinaryLifePolicy = value;
    }

    /**
     * Gets the value of the isExtAutopayEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayEnrolled() {
        return isExtAutopayEnrolled;
    }

    /**
     * Sets the value of the isExtAutopayEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayEnrolled(JAXBElement<Long> value) {
        this.isExtAutopayEnrolled = value;
    }

    /**
     * Gets the value of the isGroupInsurancePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsGroupInsurancePolicy() {
        return isGroupInsurancePolicy;
    }

    /**
     * Sets the value of the isGroupInsurancePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsGroupInsurancePolicy(JAXBElement<Long> value) {
        this.isGroupInsurancePolicy = value;
    }

    /**
     * Gets the value of the isPaidUpPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaidUpPolicy() {
        return isPaidUpPolicy;
    }

    /**
     * Sets the value of the isPaidUpPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaidUpPolicy(JAXBElement<Long> value) {
        this.isPaidUpPolicy = value;
    }

    /**
     * Gets the value of the replacementValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getReplacementValue() {
        return replacementValue;
    }

    /**
     * Sets the value of the replacementValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setReplacementValue(JAXBElement<YMoney> value) {
        this.replacementValue = value;
    }

    /**
     * Gets the value of the isJointLifePolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsJointLifePolicy() {
        return isJointLifePolicy;
    }

    /**
     * Sets the value of the isJointLifePolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsJointLifePolicy(JAXBElement<Long> value) {
        this.isJointLifePolicy = value;
    }

    /**
     * Gets the value of the lifeInsuranceTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLifeInsuranceTypeId() {
        return lifeInsuranceTypeId;
    }

    /**
     * Sets the value of the lifeInsuranceTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLifeInsuranceTypeId(JAXBElement<Long> value) {
        this.lifeInsuranceTypeId = value;
    }

    /**
     * Gets the value of the lifeInsuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLifeInsuranceType() {
        return lifeInsuranceType;
    }

    /**
     * Sets the value of the lifeInsuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLifeInsuranceType(JAXBElement<String> value) {
        this.lifeInsuranceType = value;
    }

    /**
     * Gets the value of the localizedLifeInsuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedLifeInsuranceType() {
        return localizedLifeInsuranceType;
    }

    /**
     * Sets the value of the localizedLifeInsuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedLifeInsuranceType(JAXBElement<String> value) {
        this.localizedLifeInsuranceType = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusLastUpdated() {
        return userAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the loanApr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getLoanApr() {
        return loanApr;
    }

    /**
     * Sets the value of the loanApr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setLoanApr(JAXBElement<Double> value) {
        this.loanApr = value;
    }

    /**
     * Gets the value of the isRenewedPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsRenewedPolicy() {
        return isRenewedPolicy;
    }

    /**
     * Sets the value of the isRenewedPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsRenewedPolicy(JAXBElement<Long> value) {
        this.isRenewedPolicy = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the groupName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getGroupName() {
        return groupName;
    }

    /**
     * Sets the value of the groupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setGroupName(JAXBElement<String> value) {
        this.groupName = value;
    }

    /**
     * Gets the value of the homeInsuranceTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHomeInsuranceTypeId() {
        return homeInsuranceTypeId;
    }

    /**
     * Sets the value of the homeInsuranceTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHomeInsuranceTypeId(JAXBElement<Long> value) {
        this.homeInsuranceTypeId = value;
    }

    /**
     * Gets the value of the homeInsuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHomeInsuranceType() {
        return homeInsuranceType;
    }

    /**
     * Sets the value of the homeInsuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHomeInsuranceType(JAXBElement<String> value) {
        this.homeInsuranceType = value;
    }

    /**
     * Gets the value of the localizedHomeInsuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedHomeInsuranceType() {
        return localizedHomeInsuranceType;
    }

    /**
     * Sets the value of the localizedHomeInsuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedHomeInsuranceType(JAXBElement<String> value) {
        this.localizedHomeInsuranceType = value;
    }

    /**
     * Gets the value of the insuranceTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInsuranceTypeId() {
        return insuranceTypeId;
    }

    /**
     * Sets the value of the insuranceTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInsuranceTypeId(JAXBElement<Long> value) {
        this.insuranceTypeId = value;
    }

    /**
     * Gets the value of the insuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInsuranceType() {
        return insuranceType;
    }

    /**
     * Sets the value of the insuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInsuranceType(JAXBElement<String> value) {
        this.insuranceType = value;
    }

    /**
     * Gets the value of the localizedInsuranceType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedInsuranceType() {
        return localizedInsuranceType;
    }

    /**
     * Sets the value of the localizedInsuranceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedInsuranceType(JAXBElement<String> value) {
        this.localizedInsuranceType = value;
    }

    /**
     * Gets the value of the stmtListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListToDate() {
        return stmtListToDate;
    }

    /**
     * Sets the value of the stmtListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListToDate(JAXBElement<YDate> value) {
        this.stmtListToDate = value;
    }

    /**
     * Gets the value of the stmtListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListFromDate() {
        return stmtListFromDate;
    }

    /**
     * Sets the value of the stmtListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListFromDate(JAXBElement<YDate> value) {
        this.stmtListFromDate = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setExpirationDate(JAXBElement<YDate> value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusId() {
        return userAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserAutopayEnrollmentStatus() {
        return userAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.userAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUserAutopayEnrollmentStatus() {
        return localizedUserAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedUserAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusLastUpdated() {
        return derivedAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the isExtAutopayScraped property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayScraped() {
        return isExtAutopayScraped;
    }

    /**
     * Sets the value of the isExtAutopayScraped property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayScraped(JAXBElement<Long> value) {
        this.isExtAutopayScraped = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAutopayEnrollmentStatusId() {
        return autopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the autopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.autopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAutopayEnrollmentStatus() {
        return autopayEnrollmentStatus;
    }

    /**
     * Sets the value of the autopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.autopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAutopayEnrollmentStatus() {
        return localizedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the extAutopaySetup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public JAXBElement<ExtAutopaySetupData> getExtAutopaySetup() {
        return extAutopaySetup;
    }

    /**
     * Sets the value of the extAutopaySetup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public void setExtAutopaySetup(JAXBElement<ExtAutopaySetupData> value) {
        this.extAutopaySetup = value;
    }

    /**
     * Gets the value of the coverages property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getCoverages() {
        return coverages;
    }

    /**
     * Sets the value of the coverages property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setCoverages(JAXBElement<List> value) {
        this.coverages = value;
    }

    /**
     * Gets the value of the beneficiarys property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBeneficiarys() {
        return beneficiarys;
    }

    /**
     * Sets the value of the beneficiarys property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBeneficiarys(JAXBElement<List> value) {
        this.beneficiarys = value;
    }

    /**
     * Gets the value of the claims property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getClaims() {
        return claims;
    }

    /**
     * Sets the value of the claims property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setClaims(JAXBElement<List> value) {
        this.claims = value;
    }

    /**
     * Gets the value of the discounts property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getDiscounts() {
        return discounts;
    }

    /**
     * Sets the value of the discounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setDiscounts(JAXBElement<List> value) {
        this.discounts = value;
    }

    /**
     * Gets the value of the paymentDues property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPaymentDues() {
        return paymentDues;
    }

    /**
     * Sets the value of the paymentDues property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPaymentDues(JAXBElement<List> value) {
        this.paymentDues = value;
    }

    /**
     * Gets the value of the prescriptions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPrescriptions() {
        return prescriptions;
    }

    /**
     * Sets the value of the prescriptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPrescriptions(JAXBElement<List> value) {
        this.prescriptions = value;
    }

    /**
     * Gets the value of the insuranceTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsuranceTransactions() {
        return insuranceTransactions;
    }

    /**
     * Sets the value of the insuranceTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsuranceTransactions(JAXBElement<List> value) {
        this.insuranceTransactions = value;
    }

    /**
     * Gets the value of the insuranceStatements property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsuranceStatements() {
        return insuranceStatements;
    }

    /**
     * Sets the value of the insuranceStatements property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsuranceStatements(JAXBElement<List> value) {
        this.insuranceStatements = value;
    }

    /**
     * Gets the value of the lienHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link LienHolder }{@code >}
     *     
     */
    public JAXBElement<LienHolder> getLienHolder() {
        return lienHolder;
    }

    /**
     * Sets the value of the lienHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link LienHolder }{@code >}
     *     
     */
    public void setLienHolder(JAXBElement<LienHolder> value) {
        this.lienHolder = value;
    }

    /**
     * Gets the value of the personInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public JAXBElement<PersonData> getPersonInformation() {
        return personInformation;
    }

    /**
     * Sets the value of the personInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public void setPersonInformation(JAXBElement<PersonData> value) {
        this.personInformation = value;
    }

    /**
     * Gets the value of the insPolicyHolders property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsPolicyHolders() {
        return insPolicyHolders;
    }

    /**
     * Sets the value of the insPolicyHolders property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsPolicyHolders(JAXBElement<List> value) {
        this.insPolicyHolders = value;
    }

    /**
     * Gets the value of the insuranceDrivers property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsuranceDrivers() {
        return insuranceDrivers;
    }

    /**
     * Sets the value of the insuranceDrivers property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsuranceDrivers(JAXBElement<List> value) {
        this.insuranceDrivers = value;
    }

    /**
     * Gets the value of the insureds property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsureds() {
        return insureds;
    }

    /**
     * Sets the value of the insureds property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsureds(JAXBElement<List> value) {
        this.insureds = value;
    }

    /**
     * Gets the value of the insuranceVehicles property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsuranceVehicles() {
        return insuranceVehicles;
    }

    /**
     * Sets the value of the insuranceVehicles property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsuranceVehicles(JAXBElement<List> value) {
        this.insuranceVehicles = value;
    }

    /**
     * Gets the value of the insMutualFunds property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsMutualFunds() {
        return insMutualFunds;
    }

    /**
     * Sets the value of the insMutualFunds property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsMutualFunds(JAXBElement<List> value) {
        this.insMutualFunds = value;
    }

    /**
     * Gets the value of the billPreference property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public JAXBElement<BillPreferenceData> getBillPreference() {
        return billPreference;
    }

    /**
     * Sets the value of the billPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public void setBillPreference(JAXBElement<BillPreferenceData> value) {
        this.billPreference = value;
    }

    /**
     * Gets the value of the paymentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPaymentDetails() {
        return paymentDetails;
    }

    /**
     * Sets the value of the paymentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPaymentDetails(JAXBElement<List> value) {
        this.paymentDetails = value;
    }

    /**
     * Gets the value of the insAnnuitys property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInsAnnuitys() {
        return insAnnuitys;
    }

    /**
     * Sets the value of the insAnnuitys property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInsAnnuitys(JAXBElement<List> value) {
        this.insAnnuitys = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the isPaperlessStmtOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaperlessStmtOn() {
        return isPaperlessStmtOn;
    }

    /**
     * Sets the value of the isPaperlessStmtOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaperlessStmtOn(JAXBElement<Long> value) {
        this.isPaperlessStmtOn = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the annuitantName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAnnuitantName() {
        return annuitantName;
    }

    /**
     * Sets the value of the annuitantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAnnuitantName(JAXBElement<String> value) {
        this.annuitantName = value;
    }

    /**
     * Gets the value of the jointAnnuitantName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getJointAnnuitantName() {
        return jointAnnuitantName;
    }

    /**
     * Sets the value of the jointAnnuitantName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setJointAnnuitantName(JAXBElement<String> value) {
        this.jointAnnuitantName = value;
    }

    /**
     * Gets the value of the planName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlanName() {
        return planName;
    }

    /**
     * Sets the value of the planName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlanName(JAXBElement<String> value) {
        this.planName = value;
    }

    /**
     * Gets the value of the premiumPaymentTerm property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPremiumPaymentTerm() {
        return premiumPaymentTerm;
    }

    /**
     * Sets the value of the premiumPaymentTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPremiumPaymentTerm(JAXBElement<String> value) {
        this.premiumPaymentTerm = value;
    }

    /**
     * Gets the value of the benefitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBenefitAmount() {
        return benefitAmount;
    }

    /**
     * Sets the value of the benefitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBenefitAmount(JAXBElement<YMoney> value) {
        this.benefitAmount = value;
    }

    /**
     * Gets the value of the surrenderCharge property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSurrenderCharge() {
        return surrenderCharge;
    }

    /**
     * Sets the value of the surrenderCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSurrenderCharge(JAXBElement<YMoney> value) {
        this.surrenderCharge = value;
    }

    /**
     * Gets the value of the guaranteedDeathBenefit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getGuaranteedDeathBenefit() {
        return guaranteedDeathBenefit;
    }

    /**
     * Sets the value of the guaranteedDeathBenefit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setGuaranteedDeathBenefit(JAXBElement<YMoney> value) {
        this.guaranteedDeathBenefit = value;
    }

    /**
     * Gets the value of the freeWithdrawalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFreeWithdrawalAmount() {
        return freeWithdrawalAmount;
    }

    /**
     * Sets the value of the freeWithdrawalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFreeWithdrawalAmount(JAXBElement<YMoney> value) {
        this.freeWithdrawalAmount = value;
    }

    /**
     * Gets the value of the annuityAccountValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAnnuityAccountValue() {
        return annuityAccountValue;
    }

    /**
     * Sets the value of the annuityAccountValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAnnuityAccountValue(JAXBElement<YMoney> value) {
        this.annuityAccountValue = value;
    }

    /**
     * Gets the value of the accruedInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAccruedInterest() {
        return accruedInterest;
    }

    /**
     * Sets the value of the accruedInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAccruedInterest(JAXBElement<YMoney> value) {
        this.accruedInterest = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the premiumPaymentFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public JAXBElement<BenefitFrequency> getPremiumPaymentFrequency() {
        return premiumPaymentFrequency;
    }

    /**
     * Sets the value of the premiumPaymentFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public void setPremiumPaymentFrequency(JAXBElement<BenefitFrequency> value) {
        this.premiumPaymentFrequency = value;
    }

    /**
     * Gets the value of the guaranteedInterestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getGuaranteedInterestRate() {
        return guaranteedInterestRate;
    }

    /**
     * Sets the value of the guaranteedInterestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setGuaranteedInterestRate(JAXBElement<Double> value) {
        this.guaranteedInterestRate = value;
    }

    /**
     * Gets the value of the insuranceBenefitFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public JAXBElement<BenefitFrequency> getInsuranceBenefitFrequency() {
        return insuranceBenefitFrequency;
    }

    /**
     * Sets the value of the insuranceBenefitFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public void setInsuranceBenefitFrequency(JAXBElement<BenefitFrequency> value) {
        this.insuranceBenefitFrequency = value;
    }

    /**
     * Gets the value of the annuityOption property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AnnuityOption }{@code >}
     *     
     */
    public JAXBElement<AnnuityOption> getAnnuityOption() {
        return annuityOption;
    }

    /**
     * Sets the value of the annuityOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AnnuityOption }{@code >}
     *     
     */
    public void setAnnuityOption(JAXBElement<AnnuityOption> value) {
        this.annuityOption = value;
    }

}
