
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.AccountClassification;
import com.yodlee.soap.core.dataservice.enums.BenefitFrequency;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for InvestmentData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InvestmentData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="acctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="invAcctBaseTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="invAcctBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedInvAcctBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="personInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="investmentAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="planNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tranListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="tranListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isOptionAllowed" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="planName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isMarginAllowed" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="cash" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalVestedBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalUnvestedBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="fundsOwed" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableLoan" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="buyingPower" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="marginBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="unsettledFunds" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cmaBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="shortBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cashoptionBp" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="marginBp" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="dayTradingMarginBp" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="dayTradingCashoptionBp" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="openCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cashCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="marginCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="fedCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="houseCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="dayTradingMarginCall" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accountEquity" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="moneyMarketBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="fundsAvailable" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalMvLong" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalMvShort" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalMvCashSecurities" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalMvMarginSecurities" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="deferredCompBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="deferredCompVested" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="annuityBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="annuityDeathBenefit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="loan_401k" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accountEquityPercentage" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="asofDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="investmentTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="holdings" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="personInformation" type="{http://types.dataservice.core.soap.yodlee.com}PersonData" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaperlessStmtOn" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="investmentAccBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountGain" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="mutualFundFolioNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="linkedBankAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomineeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalRealizedGain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalInvestedAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accruedInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="benefitAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="securitiesBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="intraDayCashBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="dividendEarnedAsPayOut" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="investmentBenefitFrequency" type="{http://enums.dataservice.core.soap.yodlee.com}BenefitFrequency" minOccurs="0"/>
 *         &lt;element name="accountClassification" type="{http://enums.dataservice.core.soap.yodlee.com}AccountClassification" minOccurs="0"/>
 *         &lt;element name="investmentPlanData" type="{http://types.dataservice.core.soap.yodlee.com}InvestmentPlanData" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvestmentData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "acctTypeId",
    "acctType",
    "localizedAcctType",
    "srcElementId",
    "invAcctBaseTypeId",
    "invAcctBaseType",
    "localizedInvAcctBaseType",
    "personInformationId",
    "investmentAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "accountNumber",
    "planNumber",
    "link",
    "accountHolder",
    "tranListToDate",
    "tranListFromDate",
    "isOptionAllowed",
    "planName",
    "isMarginAllowed",
    "cash",
    "totalBalance",
    "totalVestedBalance",
    "totalUnvestedBalance",
    "fundsOwed",
    "availableLoan",
    "buyingPower",
    "marginBalance",
    "unsettledFunds",
    "cmaBalance",
    "shortBalance",
    "cashoptionBp",
    "marginBp",
    "dayTradingMarginBp",
    "dayTradingCashoptionBp",
    "openCall",
    "cashCall",
    "marginCall",
    "fedCall",
    "houseCall",
    "dayTradingMarginCall",
    "accountEquity",
    "moneyMarketBalance",
    "fundsAvailable",
    "totalMvLong",
    "totalMvShort",
    "totalMvCashSecurities",
    "totalMvMarginSecurities",
    "deferredCompBalance",
    "deferredCompVested",
    "annuityBalance",
    "annuityDeathBenefit",
    "loan401K",
    "accountEquityPercentage",
    "accountName",
    "accountCurrency",
    "asofDate",
    "investmentTransactions",
    "holdings",
    "personInformation",
    "accountNicknameAtSrcSite",
    "isPaperlessStmtOn",
    "siteAccountStatus",
    "investmentAccBalance",
    "created",
    "accountGain",
    "accountOpenDate",
    "accountCloseDate",
    "mutualFundFolioNumber",
    "linkedBankAccountNumber",
    "nomineeName",
    "secondaryAccountHolderName",
    "totalRealizedGain",
    "totalInvestedAmount",
    "accruedInterest",
    "benefitAmount",
    "securitiesBalance",
    "intraDayCashBalance",
    "dividendEarnedAsPayOut",
    "investmentBenefitFrequency",
    "accountClassification",
    "investmentPlanData"
})
public class InvestmentData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "acctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> acctTypeId;
    @XmlElementRef(name = "acctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> acctType;
    @XmlElementRef(name = "localizedAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAcctType;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "invAcctBaseTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> invAcctBaseTypeId;
    @XmlElementRef(name = "invAcctBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> invAcctBaseType;
    @XmlElementRef(name = "localizedInvAcctBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedInvAcctBaseType;
    @XmlElementRef(name = "personInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> personInformationId;
    @XmlElementRef(name = "investmentAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "planNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> planNumber;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "tranListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListToDate;
    @XmlElementRef(name = "tranListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tranListFromDate;
    @XmlElementRef(name = "isOptionAllowed", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isOptionAllowed;
    @XmlElementRef(name = "planName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> planName;
    @XmlElementRef(name = "isMarginAllowed", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isMarginAllowed;
    @XmlElementRef(name = "cash", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cash;
    @XmlElementRef(name = "totalBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalBalance;
    @XmlElementRef(name = "totalVestedBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalVestedBalance;
    @XmlElementRef(name = "totalUnvestedBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalUnvestedBalance;
    @XmlElementRef(name = "fundsOwed", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> fundsOwed;
    @XmlElementRef(name = "availableLoan", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableLoan;
    @XmlElementRef(name = "buyingPower", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> buyingPower;
    @XmlElementRef(name = "marginBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> marginBalance;
    @XmlElementRef(name = "unsettledFunds", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unsettledFunds;
    @XmlElementRef(name = "cmaBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cmaBalance;
    @XmlElementRef(name = "shortBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> shortBalance;
    @XmlElementRef(name = "cashoptionBp", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cashoptionBp;
    @XmlElementRef(name = "marginBp", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> marginBp;
    @XmlElementRef(name = "dayTradingMarginBp", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dayTradingMarginBp;
    @XmlElementRef(name = "dayTradingCashoptionBp", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dayTradingCashoptionBp;
    @XmlElementRef(name = "openCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> openCall;
    @XmlElementRef(name = "cashCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cashCall;
    @XmlElementRef(name = "marginCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> marginCall;
    @XmlElementRef(name = "fedCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> fedCall;
    @XmlElementRef(name = "houseCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> houseCall;
    @XmlElementRef(name = "dayTradingMarginCall", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dayTradingMarginCall;
    @XmlElementRef(name = "accountEquity", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> accountEquity;
    @XmlElementRef(name = "moneyMarketBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> moneyMarketBalance;
    @XmlElementRef(name = "fundsAvailable", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> fundsAvailable;
    @XmlElementRef(name = "totalMvLong", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalMvLong;
    @XmlElementRef(name = "totalMvShort", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalMvShort;
    @XmlElementRef(name = "totalMvCashSecurities", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalMvCashSecurities;
    @XmlElementRef(name = "totalMvMarginSecurities", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalMvMarginSecurities;
    @XmlElementRef(name = "deferredCompBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> deferredCompBalance;
    @XmlElementRef(name = "deferredCompVested", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> deferredCompVested;
    @XmlElementRef(name = "annuityBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> annuityBalance;
    @XmlElementRef(name = "annuityDeathBenefit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> annuityDeathBenefit;
    @XmlElementRef(name = "loan_401k", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> loan401K;
    @XmlElementRef(name = "accountEquityPercentage", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> accountEquityPercentage;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "accountCurrency", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountCurrency;
    @XmlElementRef(name = "asofDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asofDate;
    @XmlElementRef(name = "investmentTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> investmentTransactions;
    @XmlElementRef(name = "holdings", type = JAXBElement.class, required = false)
    protected JAXBElement<List> holdings;
    @XmlElementRef(name = "personInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonData> personInformation;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "isPaperlessStmtOn", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaperlessStmtOn;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "investmentAccBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> investmentAccBalance;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "accountGain", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> accountGain;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "mutualFundFolioNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mutualFundFolioNumber;
    @XmlElementRef(name = "linkedBankAccountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> linkedBankAccountNumber;
    @XmlElementRef(name = "nomineeName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nomineeName;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "totalRealizedGain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalRealizedGain;
    @XmlElementRef(name = "totalInvestedAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalInvestedAmount;
    @XmlElementRef(name = "accruedInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> accruedInterest;
    @XmlElementRef(name = "benefitAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> benefitAmount;
    @XmlElementRef(name = "securitiesBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> securitiesBalance;
    @XmlElementRef(name = "intraDayCashBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> intraDayCashBalance;
    @XmlElementRef(name = "dividendEarnedAsPayOut", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> dividendEarnedAsPayOut;
    @XmlElementRef(name = "investmentBenefitFrequency", type = JAXBElement.class, required = false)
    protected JAXBElement<BenefitFrequency> investmentBenefitFrequency;
    @XmlElementRef(name = "accountClassification", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountClassification> accountClassification;
    @XmlElementRef(name = "investmentPlanData", type = JAXBElement.class, required = false)
    protected JAXBElement<InvestmentPlanData> investmentPlanData;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the acctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAcctTypeId() {
        return acctTypeId;
    }

    /**
     * Sets the value of the acctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAcctTypeId(JAXBElement<Long> value) {
        this.acctTypeId = value;
    }

    /**
     * Gets the value of the acctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAcctType() {
        return acctType;
    }

    /**
     * Sets the value of the acctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAcctType(JAXBElement<String> value) {
        this.acctType = value;
    }

    /**
     * Gets the value of the localizedAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAcctType() {
        return localizedAcctType;
    }

    /**
     * Sets the value of the localizedAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAcctType(JAXBElement<String> value) {
        this.localizedAcctType = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the invAcctBaseTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvAcctBaseTypeId() {
        return invAcctBaseTypeId;
    }

    /**
     * Sets the value of the invAcctBaseTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvAcctBaseTypeId(JAXBElement<Long> value) {
        this.invAcctBaseTypeId = value;
    }

    /**
     * Gets the value of the invAcctBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getInvAcctBaseType() {
        return invAcctBaseType;
    }

    /**
     * Sets the value of the invAcctBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setInvAcctBaseType(JAXBElement<String> value) {
        this.invAcctBaseType = value;
    }

    /**
     * Gets the value of the localizedInvAcctBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedInvAcctBaseType() {
        return localizedInvAcctBaseType;
    }

    /**
     * Sets the value of the localizedInvAcctBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedInvAcctBaseType(JAXBElement<String> value) {
        this.localizedInvAcctBaseType = value;
    }

    /**
     * Gets the value of the personInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPersonInformationId() {
        return personInformationId;
    }

    /**
     * Sets the value of the personInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPersonInformationId(JAXBElement<Long> value) {
        this.personInformationId = value;
    }

    /**
     * Gets the value of the investmentAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentAccountId() {
        return investmentAccountId;
    }

    /**
     * Sets the value of the investmentAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentAccountId(JAXBElement<Long> value) {
        this.investmentAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the planNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlanNumber() {
        return planNumber;
    }

    /**
     * Sets the value of the planNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlanNumber(JAXBElement<String> value) {
        this.planNumber = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the tranListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListToDate() {
        return tranListToDate;
    }

    /**
     * Sets the value of the tranListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListToDate(JAXBElement<YDate> value) {
        this.tranListToDate = value;
    }

    /**
     * Gets the value of the tranListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTranListFromDate() {
        return tranListFromDate;
    }

    /**
     * Sets the value of the tranListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTranListFromDate(JAXBElement<YDate> value) {
        this.tranListFromDate = value;
    }

    /**
     * Gets the value of the isOptionAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsOptionAllowed() {
        return isOptionAllowed;
    }

    /**
     * Sets the value of the isOptionAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsOptionAllowed(JAXBElement<Long> value) {
        this.isOptionAllowed = value;
    }

    /**
     * Gets the value of the planName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlanName() {
        return planName;
    }

    /**
     * Sets the value of the planName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlanName(JAXBElement<String> value) {
        this.planName = value;
    }

    /**
     * Gets the value of the isMarginAllowed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsMarginAllowed() {
        return isMarginAllowed;
    }

    /**
     * Sets the value of the isMarginAllowed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsMarginAllowed(JAXBElement<Long> value) {
        this.isMarginAllowed = value;
    }

    /**
     * Gets the value of the cash property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCash() {
        return cash;
    }

    /**
     * Sets the value of the cash property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCash(JAXBElement<YMoney> value) {
        this.cash = value;
    }

    /**
     * Gets the value of the totalBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalBalance() {
        return totalBalance;
    }

    /**
     * Sets the value of the totalBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalBalance(JAXBElement<YMoney> value) {
        this.totalBalance = value;
    }

    /**
     * Gets the value of the totalVestedBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalVestedBalance() {
        return totalVestedBalance;
    }

    /**
     * Sets the value of the totalVestedBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalVestedBalance(JAXBElement<YMoney> value) {
        this.totalVestedBalance = value;
    }

    /**
     * Gets the value of the totalUnvestedBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalUnvestedBalance() {
        return totalUnvestedBalance;
    }

    /**
     * Sets the value of the totalUnvestedBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalUnvestedBalance(JAXBElement<YMoney> value) {
        this.totalUnvestedBalance = value;
    }

    /**
     * Gets the value of the fundsOwed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFundsOwed() {
        return fundsOwed;
    }

    /**
     * Sets the value of the fundsOwed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFundsOwed(JAXBElement<YMoney> value) {
        this.fundsOwed = value;
    }

    /**
     * Gets the value of the availableLoan property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableLoan() {
        return availableLoan;
    }

    /**
     * Sets the value of the availableLoan property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableLoan(JAXBElement<YMoney> value) {
        this.availableLoan = value;
    }

    /**
     * Gets the value of the buyingPower property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBuyingPower() {
        return buyingPower;
    }

    /**
     * Sets the value of the buyingPower property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBuyingPower(JAXBElement<YMoney> value) {
        this.buyingPower = value;
    }

    /**
     * Gets the value of the marginBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMarginBalance() {
        return marginBalance;
    }

    /**
     * Sets the value of the marginBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMarginBalance(JAXBElement<YMoney> value) {
        this.marginBalance = value;
    }

    /**
     * Gets the value of the unsettledFunds property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnsettledFunds() {
        return unsettledFunds;
    }

    /**
     * Sets the value of the unsettledFunds property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnsettledFunds(JAXBElement<YMoney> value) {
        this.unsettledFunds = value;
    }

    /**
     * Gets the value of the cmaBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCmaBalance() {
        return cmaBalance;
    }

    /**
     * Sets the value of the cmaBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCmaBalance(JAXBElement<YMoney> value) {
        this.cmaBalance = value;
    }

    /**
     * Gets the value of the shortBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getShortBalance() {
        return shortBalance;
    }

    /**
     * Sets the value of the shortBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setShortBalance(JAXBElement<YMoney> value) {
        this.shortBalance = value;
    }

    /**
     * Gets the value of the cashoptionBp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCashoptionBp() {
        return cashoptionBp;
    }

    /**
     * Sets the value of the cashoptionBp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCashoptionBp(JAXBElement<YMoney> value) {
        this.cashoptionBp = value;
    }

    /**
     * Gets the value of the marginBp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMarginBp() {
        return marginBp;
    }

    /**
     * Sets the value of the marginBp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMarginBp(JAXBElement<YMoney> value) {
        this.marginBp = value;
    }

    /**
     * Gets the value of the dayTradingMarginBp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDayTradingMarginBp() {
        return dayTradingMarginBp;
    }

    /**
     * Sets the value of the dayTradingMarginBp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDayTradingMarginBp(JAXBElement<YMoney> value) {
        this.dayTradingMarginBp = value;
    }

    /**
     * Gets the value of the dayTradingCashoptionBp property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDayTradingCashoptionBp() {
        return dayTradingCashoptionBp;
    }

    /**
     * Sets the value of the dayTradingCashoptionBp property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDayTradingCashoptionBp(JAXBElement<YMoney> value) {
        this.dayTradingCashoptionBp = value;
    }

    /**
     * Gets the value of the openCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOpenCall() {
        return openCall;
    }

    /**
     * Sets the value of the openCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOpenCall(JAXBElement<YMoney> value) {
        this.openCall = value;
    }

    /**
     * Gets the value of the cashCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCashCall() {
        return cashCall;
    }

    /**
     * Sets the value of the cashCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCashCall(JAXBElement<YMoney> value) {
        this.cashCall = value;
    }

    /**
     * Gets the value of the marginCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMarginCall() {
        return marginCall;
    }

    /**
     * Sets the value of the marginCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMarginCall(JAXBElement<YMoney> value) {
        this.marginCall = value;
    }

    /**
     * Gets the value of the fedCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFedCall() {
        return fedCall;
    }

    /**
     * Sets the value of the fedCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFedCall(JAXBElement<YMoney> value) {
        this.fedCall = value;
    }

    /**
     * Gets the value of the houseCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getHouseCall() {
        return houseCall;
    }

    /**
     * Sets the value of the houseCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setHouseCall(JAXBElement<YMoney> value) {
        this.houseCall = value;
    }

    /**
     * Gets the value of the dayTradingMarginCall property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDayTradingMarginCall() {
        return dayTradingMarginCall;
    }

    /**
     * Sets the value of the dayTradingMarginCall property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDayTradingMarginCall(JAXBElement<YMoney> value) {
        this.dayTradingMarginCall = value;
    }

    /**
     * Gets the value of the accountEquity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAccountEquity() {
        return accountEquity;
    }

    /**
     * Sets the value of the accountEquity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAccountEquity(JAXBElement<YMoney> value) {
        this.accountEquity = value;
    }

    /**
     * Gets the value of the moneyMarketBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMoneyMarketBalance() {
        return moneyMarketBalance;
    }

    /**
     * Sets the value of the moneyMarketBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMoneyMarketBalance(JAXBElement<YMoney> value) {
        this.moneyMarketBalance = value;
    }

    /**
     * Gets the value of the fundsAvailable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFundsAvailable() {
        return fundsAvailable;
    }

    /**
     * Sets the value of the fundsAvailable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFundsAvailable(JAXBElement<YMoney> value) {
        this.fundsAvailable = value;
    }

    /**
     * Gets the value of the totalMvLong property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalMvLong() {
        return totalMvLong;
    }

    /**
     * Sets the value of the totalMvLong property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalMvLong(JAXBElement<YMoney> value) {
        this.totalMvLong = value;
    }

    /**
     * Gets the value of the totalMvShort property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalMvShort() {
        return totalMvShort;
    }

    /**
     * Sets the value of the totalMvShort property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalMvShort(JAXBElement<YMoney> value) {
        this.totalMvShort = value;
    }

    /**
     * Gets the value of the totalMvCashSecurities property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalMvCashSecurities() {
        return totalMvCashSecurities;
    }

    /**
     * Sets the value of the totalMvCashSecurities property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalMvCashSecurities(JAXBElement<YMoney> value) {
        this.totalMvCashSecurities = value;
    }

    /**
     * Gets the value of the totalMvMarginSecurities property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalMvMarginSecurities() {
        return totalMvMarginSecurities;
    }

    /**
     * Sets the value of the totalMvMarginSecurities property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalMvMarginSecurities(JAXBElement<YMoney> value) {
        this.totalMvMarginSecurities = value;
    }

    /**
     * Gets the value of the deferredCompBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDeferredCompBalance() {
        return deferredCompBalance;
    }

    /**
     * Sets the value of the deferredCompBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDeferredCompBalance(JAXBElement<YMoney> value) {
        this.deferredCompBalance = value;
    }

    /**
     * Gets the value of the deferredCompVested property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDeferredCompVested() {
        return deferredCompVested;
    }

    /**
     * Sets the value of the deferredCompVested property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDeferredCompVested(JAXBElement<YMoney> value) {
        this.deferredCompVested = value;
    }

    /**
     * Gets the value of the annuityBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAnnuityBalance() {
        return annuityBalance;
    }

    /**
     * Sets the value of the annuityBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAnnuityBalance(JAXBElement<YMoney> value) {
        this.annuityBalance = value;
    }

    /**
     * Gets the value of the annuityDeathBenefit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAnnuityDeathBenefit() {
        return annuityDeathBenefit;
    }

    /**
     * Sets the value of the annuityDeathBenefit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAnnuityDeathBenefit(JAXBElement<YMoney> value) {
        this.annuityDeathBenefit = value;
    }

    /**
     * Gets the value of the loan401K property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLoan401K() {
        return loan401K;
    }

    /**
     * Sets the value of the loan401K property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLoan401K(JAXBElement<YMoney> value) {
        this.loan401K = value;
    }

    /**
     * Gets the value of the accountEquityPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAccountEquityPercentage() {
        return accountEquityPercentage;
    }

    /**
     * Sets the value of the accountEquityPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAccountEquityPercentage(JAXBElement<Double> value) {
        this.accountEquityPercentage = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the accountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountCurrency() {
        return accountCurrency;
    }

    /**
     * Sets the value of the accountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountCurrency(JAXBElement<String> value) {
        this.accountCurrency = value;
    }

    /**
     * Gets the value of the asofDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsofDate() {
        return asofDate;
    }

    /**
     * Sets the value of the asofDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsofDate(JAXBElement<YDate> value) {
        this.asofDate = value;
    }

    /**
     * Gets the value of the investmentTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getInvestmentTransactions() {
        return investmentTransactions;
    }

    /**
     * Sets the value of the investmentTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setInvestmentTransactions(JAXBElement<List> value) {
        this.investmentTransactions = value;
    }

    /**
     * Gets the value of the holdings property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getHoldings() {
        return holdings;
    }

    /**
     * Sets the value of the holdings property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setHoldings(JAXBElement<List> value) {
        this.holdings = value;
    }

    /**
     * Gets the value of the personInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public JAXBElement<PersonData> getPersonInformation() {
        return personInformation;
    }

    /**
     * Sets the value of the personInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public void setPersonInformation(JAXBElement<PersonData> value) {
        this.personInformation = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the isPaperlessStmtOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaperlessStmtOn() {
        return isPaperlessStmtOn;
    }

    /**
     * Sets the value of the isPaperlessStmtOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaperlessStmtOn(JAXBElement<Long> value) {
        this.isPaperlessStmtOn = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the investmentAccBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInvestmentAccBalance() {
        return investmentAccBalance;
    }

    /**
     * Sets the value of the investmentAccBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInvestmentAccBalance(JAXBElement<YMoney> value) {
        this.investmentAccBalance = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the accountGain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAccountGain() {
        return accountGain;
    }

    /**
     * Sets the value of the accountGain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAccountGain(JAXBElement<Double> value) {
        this.accountGain = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the mutualFundFolioNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMutualFundFolioNumber() {
        return mutualFundFolioNumber;
    }

    /**
     * Sets the value of the mutualFundFolioNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMutualFundFolioNumber(JAXBElement<String> value) {
        this.mutualFundFolioNumber = value;
    }

    /**
     * Gets the value of the linkedBankAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLinkedBankAccountNumber() {
        return linkedBankAccountNumber;
    }

    /**
     * Sets the value of the linkedBankAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLinkedBankAccountNumber(JAXBElement<String> value) {
        this.linkedBankAccountNumber = value;
    }

    /**
     * Gets the value of the nomineeName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNomineeName() {
        return nomineeName;
    }

    /**
     * Sets the value of the nomineeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNomineeName(JAXBElement<String> value) {
        this.nomineeName = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the totalRealizedGain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalRealizedGain() {
        return totalRealizedGain;
    }

    /**
     * Sets the value of the totalRealizedGain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalRealizedGain(JAXBElement<YMoney> value) {
        this.totalRealizedGain = value;
    }

    /**
     * Gets the value of the totalInvestedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalInvestedAmount() {
        return totalInvestedAmount;
    }

    /**
     * Sets the value of the totalInvestedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalInvestedAmount(JAXBElement<YMoney> value) {
        this.totalInvestedAmount = value;
    }

    /**
     * Gets the value of the accruedInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAccruedInterest() {
        return accruedInterest;
    }

    /**
     * Sets the value of the accruedInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAccruedInterest(JAXBElement<YMoney> value) {
        this.accruedInterest = value;
    }

    /**
     * Gets the value of the benefitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBenefitAmount() {
        return benefitAmount;
    }

    /**
     * Sets the value of the benefitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBenefitAmount(JAXBElement<YMoney> value) {
        this.benefitAmount = value;
    }

    /**
     * Gets the value of the securitiesBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSecuritiesBalance() {
        return securitiesBalance;
    }

    /**
     * Sets the value of the securitiesBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSecuritiesBalance(JAXBElement<YMoney> value) {
        this.securitiesBalance = value;
    }

    /**
     * Gets the value of the intraDayCashBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getIntraDayCashBalance() {
        return intraDayCashBalance;
    }

    /**
     * Sets the value of the intraDayCashBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setIntraDayCashBalance(JAXBElement<YMoney> value) {
        this.intraDayCashBalance = value;
    }

    /**
     * Gets the value of the dividendEarnedAsPayOut property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getDividendEarnedAsPayOut() {
        return dividendEarnedAsPayOut;
    }

    /**
     * Sets the value of the dividendEarnedAsPayOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setDividendEarnedAsPayOut(JAXBElement<YMoney> value) {
        this.dividendEarnedAsPayOut = value;
    }

    /**
     * Gets the value of the investmentBenefitFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public JAXBElement<BenefitFrequency> getInvestmentBenefitFrequency() {
        return investmentBenefitFrequency;
    }

    /**
     * Sets the value of the investmentBenefitFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BenefitFrequency }{@code >}
     *     
     */
    public void setInvestmentBenefitFrequency(JAXBElement<BenefitFrequency> value) {
        this.investmentBenefitFrequency = value;
    }

    /**
     * Gets the value of the accountClassification property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public JAXBElement<AccountClassification> getAccountClassification() {
        return accountClassification;
    }

    /**
     * Sets the value of the accountClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountClassification }{@code >}
     *     
     */
    public void setAccountClassification(JAXBElement<AccountClassification> value) {
        this.accountClassification = value;
    }

    /**
     * Gets the value of the investmentPlanData property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link InvestmentPlanData }{@code >}
     *     
     */
    public JAXBElement<InvestmentPlanData> getInvestmentPlanData() {
        return investmentPlanData;
    }

    /**
     * Sets the value of the investmentPlanData property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link InvestmentPlanData }{@code >}
     *     
     */
    public void setInvestmentPlanData(JAXBElement<InvestmentPlanData> value) {
        this.investmentPlanData = value;
    }

}
