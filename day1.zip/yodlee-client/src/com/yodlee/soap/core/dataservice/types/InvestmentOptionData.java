
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.investment.InvestmentSecurity;


/**
 * <p>Java class for InvestmentOptionData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InvestmentOptionData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="investmentOptionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="investmentPlanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="holdingTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="holdingType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="symbol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cusipNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="price" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oneMonthReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="threeMonthReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="oneYearReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="threeYearReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="fiveYearReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="tenYearReturn" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sedol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="securityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="securityInfo" type="{http://investment.core.soap.yodlee.com}InvestmentSecurity" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="priceAsOfDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSymbolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isCusipNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isIsinNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSedolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvestmentOptionData", propOrder = {
    "investmentOptionId",
    "investmentPlanId",
    "holdingTypeId",
    "holdingType",
    "symbol",
    "cusipNumber",
    "description",
    "price",
    "srcElementId",
    "oneMonthReturn",
    "threeMonthReturn",
    "oneYearReturn",
    "threeYearReturn",
    "fiveYearReturn",
    "tenYearReturn",
    "isDeleted",
    "isin",
    "sedol",
    "securityId",
    "securityInfo",
    "isSeidMod",
    "link",
    "hasDetails",
    "isSeidFromDataSource",
    "priceAsOfDate",
    "lastUpdated",
    "isSymbolNormalized",
    "isCusipNormalized",
    "isIsinNormalized",
    "isSedolNormalized"
})
public class InvestmentOptionData
    extends BaseTagData
{

    @XmlElementRef(name = "investmentOptionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentOptionId;
    @XmlElementRef(name = "investmentPlanId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentPlanId;
    @XmlElementRef(name = "holdingTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> holdingTypeId;
    @XmlElementRef(name = "holdingType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> holdingType;
    @XmlElementRef(name = "symbol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> symbol;
    @XmlElementRef(name = "cusipNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cusipNumber;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "price", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> price;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "oneMonthReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> oneMonthReturn;
    @XmlElementRef(name = "threeMonthReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> threeMonthReturn;
    @XmlElementRef(name = "oneYearReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> oneYearReturn;
    @XmlElementRef(name = "threeYearReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> threeYearReturn;
    @XmlElementRef(name = "fiveYearReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> fiveYearReturn;
    @XmlElementRef(name = "tenYearReturn", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> tenYearReturn;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "isin", type = JAXBElement.class, required = false)
    protected JAXBElement<String> isin;
    @XmlElementRef(name = "sedol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sedol;
    @XmlElementRef(name = "securityId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> securityId;
    @XmlElementRef(name = "securityInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<InvestmentSecurity> securityInfo;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "priceAsOfDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> priceAsOfDate;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "isSymbolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSymbolNormalized;
    @XmlElementRef(name = "isCusipNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isCusipNormalized;
    @XmlElementRef(name = "isIsinNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isIsinNormalized;
    @XmlElementRef(name = "isSedolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSedolNormalized;

    /**
     * Gets the value of the investmentOptionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentOptionId() {
        return investmentOptionId;
    }

    /**
     * Sets the value of the investmentOptionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentOptionId(JAXBElement<Long> value) {
        this.investmentOptionId = value;
    }

    /**
     * Gets the value of the investmentPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentPlanId() {
        return investmentPlanId;
    }

    /**
     * Sets the value of the investmentPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentPlanId(JAXBElement<Long> value) {
        this.investmentPlanId = value;
    }

    /**
     * Gets the value of the holdingTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHoldingTypeId() {
        return holdingTypeId;
    }

    /**
     * Sets the value of the holdingTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHoldingTypeId(JAXBElement<Long> value) {
        this.holdingTypeId = value;
    }

    /**
     * Gets the value of the holdingType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHoldingType() {
        return holdingType;
    }

    /**
     * Sets the value of the holdingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHoldingType(JAXBElement<String> value) {
        this.holdingType = value;
    }

    /**
     * Gets the value of the symbol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSymbol() {
        return symbol;
    }

    /**
     * Sets the value of the symbol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSymbol(JAXBElement<String> value) {
        this.symbol = value;
    }

    /**
     * Gets the value of the cusipNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCusipNumber() {
        return cusipNumber;
    }

    /**
     * Sets the value of the cusipNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCusipNumber(JAXBElement<String> value) {
        this.cusipNumber = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrice(JAXBElement<YMoney> value) {
        this.price = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the oneMonthReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getOneMonthReturn() {
        return oneMonthReturn;
    }

    /**
     * Sets the value of the oneMonthReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setOneMonthReturn(JAXBElement<Double> value) {
        this.oneMonthReturn = value;
    }

    /**
     * Gets the value of the threeMonthReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getThreeMonthReturn() {
        return threeMonthReturn;
    }

    /**
     * Sets the value of the threeMonthReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setThreeMonthReturn(JAXBElement<Double> value) {
        this.threeMonthReturn = value;
    }

    /**
     * Gets the value of the oneYearReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getOneYearReturn() {
        return oneYearReturn;
    }

    /**
     * Sets the value of the oneYearReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setOneYearReturn(JAXBElement<Double> value) {
        this.oneYearReturn = value;
    }

    /**
     * Gets the value of the threeYearReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getThreeYearReturn() {
        return threeYearReturn;
    }

    /**
     * Sets the value of the threeYearReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setThreeYearReturn(JAXBElement<Double> value) {
        this.threeYearReturn = value;
    }

    /**
     * Gets the value of the fiveYearReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getFiveYearReturn() {
        return fiveYearReturn;
    }

    /**
     * Sets the value of the fiveYearReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setFiveYearReturn(JAXBElement<Double> value) {
        this.fiveYearReturn = value;
    }

    /**
     * Gets the value of the tenYearReturn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getTenYearReturn() {
        return tenYearReturn;
    }

    /**
     * Sets the value of the tenYearReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setTenYearReturn(JAXBElement<Double> value) {
        this.tenYearReturn = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the isin property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsin() {
        return isin;
    }

    /**
     * Sets the value of the isin property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsin(JAXBElement<String> value) {
        this.isin = value;
    }

    /**
     * Gets the value of the sedol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSedol() {
        return sedol;
    }

    /**
     * Sets the value of the sedol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSedol(JAXBElement<String> value) {
        this.sedol = value;
    }

    /**
     * Gets the value of the securityId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSecurityId() {
        return securityId;
    }

    /**
     * Sets the value of the securityId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSecurityId(JAXBElement<Long> value) {
        this.securityId = value;
    }

    /**
     * Gets the value of the securityInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public JAXBElement<InvestmentSecurity> getSecurityInfo() {
        return securityInfo;
    }

    /**
     * Sets the value of the securityInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public void setSecurityInfo(JAXBElement<InvestmentSecurity> value) {
        this.securityInfo = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the priceAsOfDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getPriceAsOfDate() {
        return priceAsOfDate;
    }

    /**
     * Sets the value of the priceAsOfDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setPriceAsOfDate(JAXBElement<YDate> value) {
        this.priceAsOfDate = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the isSymbolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSymbolNormalized() {
        return isSymbolNormalized;
    }

    /**
     * Sets the value of the isSymbolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSymbolNormalized(JAXBElement<Long> value) {
        this.isSymbolNormalized = value;
    }

    /**
     * Gets the value of the isCusipNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsCusipNormalized() {
        return isCusipNormalized;
    }

    /**
     * Sets the value of the isCusipNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsCusipNormalized(JAXBElement<Long> value) {
        this.isCusipNormalized = value;
    }

    /**
     * Gets the value of the isIsinNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsIsinNormalized() {
        return isIsinNormalized;
    }

    /**
     * Sets the value of the isIsinNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsIsinNormalized(JAXBElement<Long> value) {
        this.isIsinNormalized = value;
    }

    /**
     * Gets the value of the isSedolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSedolNormalized() {
        return isSedolNormalized;
    }

    /**
     * Sets the value of the isSedolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSedolNormalized(JAXBElement<Long> value) {
        this.isSedolNormalized = value;
    }

}
