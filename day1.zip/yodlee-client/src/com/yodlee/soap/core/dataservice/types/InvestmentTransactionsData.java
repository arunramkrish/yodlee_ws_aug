
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.Exchange;
import com.yodlee.soap.core.investment.InvestmentSecurity;


/**
 * <p>Java class for InvestmentTransactionsData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InvestmentTransactionsData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionBaseTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedTransactionBaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="refAcctTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="refAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedRefAcctType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="investmentTransactionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="investmentAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="transactionCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="settleDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="secFee" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="markupMarkdown" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="transDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isReimbursable" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="mcCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="price" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="runningBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="prevLastCategorised" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="confirmationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="parentId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="splitType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionPostingOrder" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="shortDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="commission" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isMedicalExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="cusipNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transactionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteCategoryType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="classUpdationSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastCategorised" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="grossAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="deferredCompType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txnHoldingDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="naicsCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="orderHandlingFee" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="quantity" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="categorisationSourceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="plainTextDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="calcRunningBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="categoryLevelId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contributionYear" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="prevTransactionCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isBusinessExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="descriptionViewPref" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="deferredCompSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="symbol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prevCategorisationSourceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="amount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isTaxDeductible" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="categorizationKeyword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tradeDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="installmentNumber" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="stampDuty" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="serviceTax" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="otherFees" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="exchange" type="{http://enums.dataservice.core.soap.yodlee.com}Exchange" minOccurs="0"/>
 *         &lt;element name="isin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sedol" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="domicile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="securityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="securityInfo" type="{http://investment.core.soap.yodlee.com}InvestmentSecurity" minOccurs="0"/>
 *         &lt;element name="isSymbolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isCusipNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isIsinNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSedolNormalized" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvestmentTransactionsData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "transactionTypeId",
    "transactionType",
    "localizedTransactionType",
    "transactionStatusId",
    "transactionStatus",
    "localizedTransactionStatus",
    "transactionBaseTypeId",
    "transactionBaseType",
    "localizedTransactionBaseType",
    "refAcctTypeId",
    "refAcctType",
    "localizedRefAcctType",
    "investmentTransactionId",
    "investmentAccountId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "transactionCategoryId",
    "settleDate",
    "secFee",
    "markupMarkdown",
    "transDate",
    "isReimbursable",
    "mcCode",
    "price",
    "runningBalance",
    "prevLastCategorised",
    "userDescription",
    "confirmationNumber",
    "parentId",
    "splitType",
    "transactionPostingOrder",
    "shortDescription",
    "commission",
    "isMedicalExpense",
    "cusipNumber",
    "transactionId",
    "siteCategoryType",
    "siteCategory",
    "isid",
    "classUpdationSource",
    "lastCategorised",
    "grossAmount",
    "deferredCompType",
    "txnHoldingDesc",
    "naicsCode",
    "orderHandlingFee",
    "quantity",
    "memo",
    "customCategoryId",
    "categorisationSourceId",
    "plainTextDescription",
    "calcRunningBalance",
    "categoryLevelId",
    "link",
    "contributionYear",
    "prevTransactionCategoryId",
    "isBusinessExpense",
    "descriptionViewPref",
    "deferredCompSource",
    "symbol",
    "prevCategorisationSourceId",
    "amount",
    "description",
    "isTaxDeductible",
    "categorizationKeyword",
    "tradeDate",
    "installmentNumber",
    "stampDuty",
    "serviceTax",
    "otherFees",
    "exchange",
    "isin",
    "sedol",
    "domicile",
    "securityId",
    "securityInfo",
    "isSymbolNormalized",
    "isCusipNormalized",
    "isIsinNormalized",
    "isSedolNormalized"
})
public class InvestmentTransactionsData
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "transactionTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionTypeId;
    @XmlElementRef(name = "transactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionType;
    @XmlElementRef(name = "localizedTransactionType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionType;
    @XmlElementRef(name = "transactionStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionStatusId;
    @XmlElementRef(name = "transactionStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionStatus;
    @XmlElementRef(name = "localizedTransactionStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionStatus;
    @XmlElementRef(name = "transactionBaseTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionBaseTypeId;
    @XmlElementRef(name = "transactionBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionBaseType;
    @XmlElementRef(name = "localizedTransactionBaseType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedTransactionBaseType;
    @XmlElementRef(name = "refAcctTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> refAcctTypeId;
    @XmlElementRef(name = "refAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> refAcctType;
    @XmlElementRef(name = "localizedRefAcctType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedRefAcctType;
    @XmlElementRef(name = "investmentTransactionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentTransactionId;
    @XmlElementRef(name = "investmentAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> investmentAccountId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "transactionCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionCategoryId;
    @XmlElementRef(name = "settleDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> settleDate;
    @XmlElementRef(name = "secFee", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> secFee;
    @XmlElementRef(name = "markupMarkdown", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> markupMarkdown;
    @XmlElementRef(name = "transDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transDate;
    @XmlElementRef(name = "isReimbursable", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isReimbursable;
    @XmlElementRef(name = "mcCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> mcCode;
    @XmlElementRef(name = "price", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> price;
    @XmlElementRef(name = "runningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> runningBalance;
    @XmlElementRef(name = "prevLastCategorised", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevLastCategorised;
    @XmlElementRef(name = "userDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userDescription;
    @XmlElementRef(name = "confirmationNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> confirmationNumber;
    @XmlElementRef(name = "parentId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> parentId;
    @XmlElementRef(name = "splitType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> splitType;
    @XmlElementRef(name = "transactionPostingOrder", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> transactionPostingOrder;
    @XmlElementRef(name = "shortDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> shortDescription;
    @XmlElementRef(name = "commission", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> commission;
    @XmlElementRef(name = "isMedicalExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isMedicalExpense;
    @XmlElementRef(name = "cusipNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cusipNumber;
    @XmlElementRef(name = "transactionId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> transactionId;
    @XmlElementRef(name = "siteCategoryType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> siteCategoryType;
    @XmlElementRef(name = "siteCategory", type = JAXBElement.class, required = false)
    protected JAXBElement<String> siteCategory;
    @XmlElementRef(name = "isid", type = JAXBElement.class, required = false)
    protected JAXBElement<String> isid;
    @XmlElementRef(name = "classUpdationSource", type = JAXBElement.class, required = false)
    protected JAXBElement<String> classUpdationSource;
    @XmlElementRef(name = "lastCategorised", type = JAXBElement.class, required = false)
    protected JAXBElement<String> lastCategorised;
    @XmlElementRef(name = "grossAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> grossAmount;
    @XmlElementRef(name = "deferredCompType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> deferredCompType;
    @XmlElementRef(name = "txnHoldingDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> txnHoldingDesc;
    @XmlElementRef(name = "naicsCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> naicsCode;
    @XmlElementRef(name = "orderHandlingFee", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> orderHandlingFee;
    @XmlElementRef(name = "quantity", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> quantity;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "customCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> customCategoryId;
    @XmlElementRef(name = "categorisationSourceId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> categorisationSourceId;
    @XmlElementRef(name = "plainTextDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> plainTextDescription;
    @XmlElementRef(name = "calcRunningBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> calcRunningBalance;
    @XmlElementRef(name = "categoryLevelId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> categoryLevelId;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "contributionYear", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> contributionYear;
    @XmlElementRef(name = "prevTransactionCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevTransactionCategoryId;
    @XmlElementRef(name = "isBusinessExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isBusinessExpense;
    @XmlElementRef(name = "descriptionViewPref", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> descriptionViewPref;
    @XmlElementRef(name = "deferredCompSource", type = JAXBElement.class, required = false)
    protected JAXBElement<String> deferredCompSource;
    @XmlElementRef(name = "symbol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> symbol;
    @XmlElementRef(name = "prevCategorisationSourceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prevCategorisationSourceId;
    @XmlElementRef(name = "amount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amount;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "isTaxDeductible", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isTaxDeductible;
    @XmlElementRef(name = "categorizationKeyword", type = JAXBElement.class, required = false)
    protected JAXBElement<String> categorizationKeyword;
    @XmlElementRef(name = "tradeDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> tradeDate;
    @XmlElementRef(name = "installmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> installmentNumber;
    @XmlElementRef(name = "stampDuty", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> stampDuty;
    @XmlElementRef(name = "serviceTax", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> serviceTax;
    @XmlElementRef(name = "otherFees", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> otherFees;
    @XmlElementRef(name = "exchange", type = JAXBElement.class, required = false)
    protected JAXBElement<Exchange> exchange;
    @XmlElementRef(name = "isin", type = JAXBElement.class, required = false)
    protected JAXBElement<String> isin;
    @XmlElementRef(name = "sedol", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sedol;
    @XmlElementRef(name = "domicile", type = JAXBElement.class, required = false)
    protected JAXBElement<String> domicile;
    @XmlElementRef(name = "securityId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> securityId;
    @XmlElementRef(name = "securityInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<InvestmentSecurity> securityInfo;
    @XmlElementRef(name = "isSymbolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSymbolNormalized;
    @XmlElementRef(name = "isCusipNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isCusipNormalized;
    @XmlElementRef(name = "isIsinNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isIsinNormalized;
    @XmlElementRef(name = "isSedolNormalized", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSedolNormalized;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the transactionTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionTypeId() {
        return transactionTypeId;
    }

    /**
     * Sets the value of the transactionTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionTypeId(JAXBElement<Long> value) {
        this.transactionTypeId = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionType(JAXBElement<String> value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the localizedTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionType() {
        return localizedTransactionType;
    }

    /**
     * Sets the value of the localizedTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionType(JAXBElement<String> value) {
        this.localizedTransactionType = value;
    }

    /**
     * Gets the value of the transactionStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionStatusId() {
        return transactionStatusId;
    }

    /**
     * Sets the value of the transactionStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionStatusId(JAXBElement<Long> value) {
        this.transactionStatusId = value;
    }

    /**
     * Gets the value of the transactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Sets the value of the transactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionStatus(JAXBElement<String> value) {
        this.transactionStatus = value;
    }

    /**
     * Gets the value of the localizedTransactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionStatus() {
        return localizedTransactionStatus;
    }

    /**
     * Sets the value of the localizedTransactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionStatus(JAXBElement<String> value) {
        this.localizedTransactionStatus = value;
    }

    /**
     * Gets the value of the transactionBaseTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionBaseTypeId() {
        return transactionBaseTypeId;
    }

    /**
     * Sets the value of the transactionBaseTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionBaseTypeId(JAXBElement<Long> value) {
        this.transactionBaseTypeId = value;
    }

    /**
     * Gets the value of the transactionBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionBaseType() {
        return transactionBaseType;
    }

    /**
     * Sets the value of the transactionBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionBaseType(JAXBElement<String> value) {
        this.transactionBaseType = value;
    }

    /**
     * Gets the value of the localizedTransactionBaseType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedTransactionBaseType() {
        return localizedTransactionBaseType;
    }

    /**
     * Sets the value of the localizedTransactionBaseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedTransactionBaseType(JAXBElement<String> value) {
        this.localizedTransactionBaseType = value;
    }

    /**
     * Gets the value of the refAcctTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRefAcctTypeId() {
        return refAcctTypeId;
    }

    /**
     * Sets the value of the refAcctTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRefAcctTypeId(JAXBElement<Long> value) {
        this.refAcctTypeId = value;
    }

    /**
     * Gets the value of the refAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRefAcctType() {
        return refAcctType;
    }

    /**
     * Sets the value of the refAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRefAcctType(JAXBElement<String> value) {
        this.refAcctType = value;
    }

    /**
     * Gets the value of the localizedRefAcctType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedRefAcctType() {
        return localizedRefAcctType;
    }

    /**
     * Sets the value of the localizedRefAcctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedRefAcctType(JAXBElement<String> value) {
        this.localizedRefAcctType = value;
    }

    /**
     * Gets the value of the investmentTransactionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentTransactionId() {
        return investmentTransactionId;
    }

    /**
     * Sets the value of the investmentTransactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentTransactionId(JAXBElement<Long> value) {
        this.investmentTransactionId = value;
    }

    /**
     * Gets the value of the investmentAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInvestmentAccountId() {
        return investmentAccountId;
    }

    /**
     * Sets the value of the investmentAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInvestmentAccountId(JAXBElement<Long> value) {
        this.investmentAccountId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the transactionCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionCategoryId() {
        return transactionCategoryId;
    }

    /**
     * Sets the value of the transactionCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionCategoryId(JAXBElement<String> value) {
        this.transactionCategoryId = value;
    }

    /**
     * Gets the value of the settleDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getSettleDate() {
        return settleDate;
    }

    /**
     * Sets the value of the settleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setSettleDate(JAXBElement<YDate> value) {
        this.settleDate = value;
    }

    /**
     * Gets the value of the secFee property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSecFee() {
        return secFee;
    }

    /**
     * Sets the value of the secFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSecFee(JAXBElement<YMoney> value) {
        this.secFee = value;
    }

    /**
     * Gets the value of the markupMarkdown property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMarkupMarkdown() {
        return markupMarkdown;
    }

    /**
     * Sets the value of the markupMarkdown property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMarkupMarkdown(JAXBElement<YMoney> value) {
        this.markupMarkdown = value;
    }

    /**
     * Gets the value of the transDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransDate() {
        return transDate;
    }

    /**
     * Sets the value of the transDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransDate(JAXBElement<YDate> value) {
        this.transDate = value;
    }

    /**
     * Gets the value of the isReimbursable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsReimbursable() {
        return isReimbursable;
    }

    /**
     * Sets the value of the isReimbursable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsReimbursable(JAXBElement<Long> value) {
        this.isReimbursable = value;
    }

    /**
     * Gets the value of the mcCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMcCode() {
        return mcCode;
    }

    /**
     * Sets the value of the mcCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMcCode(JAXBElement<String> value) {
        this.mcCode = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrice(JAXBElement<YMoney> value) {
        this.price = value;
    }

    /**
     * Gets the value of the runningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRunningBalance() {
        return runningBalance;
    }

    /**
     * Sets the value of the runningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRunningBalance(JAXBElement<YMoney> value) {
        this.runningBalance = value;
    }

    /**
     * Gets the value of the prevLastCategorised property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevLastCategorised() {
        return prevLastCategorised;
    }

    /**
     * Sets the value of the prevLastCategorised property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevLastCategorised(JAXBElement<Long> value) {
        this.prevLastCategorised = value;
    }

    /**
     * Gets the value of the userDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserDescription() {
        return userDescription;
    }

    /**
     * Sets the value of the userDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserDescription(JAXBElement<String> value) {
        this.userDescription = value;
    }

    /**
     * Gets the value of the confirmationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConfirmationNumber() {
        return confirmationNumber;
    }

    /**
     * Sets the value of the confirmationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConfirmationNumber(JAXBElement<String> value) {
        this.confirmationNumber = value;
    }

    /**
     * Gets the value of the parentId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getParentId() {
        return parentId;
    }

    /**
     * Sets the value of the parentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setParentId(JAXBElement<Long> value) {
        this.parentId = value;
    }

    /**
     * Gets the value of the splitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSplitType() {
        return splitType;
    }

    /**
     * Sets the value of the splitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSplitType(JAXBElement<String> value) {
        this.splitType = value;
    }

    /**
     * Gets the value of the transactionPostingOrder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getTransactionPostingOrder() {
        return transactionPostingOrder;
    }

    /**
     * Sets the value of the transactionPostingOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setTransactionPostingOrder(JAXBElement<Long> value) {
        this.transactionPostingOrder = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShortDescription(JAXBElement<String> value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the commission property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCommission() {
        return commission;
    }

    /**
     * Sets the value of the commission property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCommission(JAXBElement<YMoney> value) {
        this.commission = value;
    }

    /**
     * Gets the value of the isMedicalExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsMedicalExpense() {
        return isMedicalExpense;
    }

    /**
     * Sets the value of the isMedicalExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsMedicalExpense(JAXBElement<Long> value) {
        this.isMedicalExpense = value;
    }

    /**
     * Gets the value of the cusipNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCusipNumber() {
        return cusipNumber;
    }

    /**
     * Sets the value of the cusipNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCusipNumber(JAXBElement<String> value) {
        this.cusipNumber = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTransactionId(JAXBElement<String> value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the siteCategoryType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSiteCategoryType() {
        return siteCategoryType;
    }

    /**
     * Sets the value of the siteCategoryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSiteCategoryType(JAXBElement<String> value) {
        this.siteCategoryType = value;
    }

    /**
     * Gets the value of the siteCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSiteCategory() {
        return siteCategory;
    }

    /**
     * Sets the value of the siteCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSiteCategory(JAXBElement<String> value) {
        this.siteCategory = value;
    }

    /**
     * Gets the value of the isid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsid() {
        return isid;
    }

    /**
     * Sets the value of the isid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsid(JAXBElement<String> value) {
        this.isid = value;
    }

    /**
     * Gets the value of the classUpdationSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getClassUpdationSource() {
        return classUpdationSource;
    }

    /**
     * Sets the value of the classUpdationSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setClassUpdationSource(JAXBElement<String> value) {
        this.classUpdationSource = value;
    }

    /**
     * Gets the value of the lastCategorised property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLastCategorised() {
        return lastCategorised;
    }

    /**
     * Sets the value of the lastCategorised property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLastCategorised(JAXBElement<String> value) {
        this.lastCategorised = value;
    }

    /**
     * Gets the value of the grossAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getGrossAmount() {
        return grossAmount;
    }

    /**
     * Sets the value of the grossAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setGrossAmount(JAXBElement<YMoney> value) {
        this.grossAmount = value;
    }

    /**
     * Gets the value of the deferredCompType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDeferredCompType() {
        return deferredCompType;
    }

    /**
     * Sets the value of the deferredCompType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDeferredCompType(JAXBElement<String> value) {
        this.deferredCompType = value;
    }

    /**
     * Gets the value of the txnHoldingDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTxnHoldingDesc() {
        return txnHoldingDesc;
    }

    /**
     * Sets the value of the txnHoldingDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTxnHoldingDesc(JAXBElement<String> value) {
        this.txnHoldingDesc = value;
    }

    /**
     * Gets the value of the naicsCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNaicsCode() {
        return naicsCode;
    }

    /**
     * Sets the value of the naicsCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNaicsCode(JAXBElement<String> value) {
        this.naicsCode = value;
    }

    /**
     * Gets the value of the orderHandlingFee property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOrderHandlingFee() {
        return orderHandlingFee;
    }

    /**
     * Sets the value of the orderHandlingFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOrderHandlingFee(JAXBElement<YMoney> value) {
        this.orderHandlingFee = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setQuantity(JAXBElement<Double> value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the customCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCustomCategoryId() {
        return customCategoryId;
    }

    /**
     * Sets the value of the customCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCustomCategoryId(JAXBElement<Long> value) {
        this.customCategoryId = value;
    }

    /**
     * Gets the value of the categorisationSourceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategorisationSourceId() {
        return categorisationSourceId;
    }

    /**
     * Sets the value of the categorisationSourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategorisationSourceId(JAXBElement<String> value) {
        this.categorisationSourceId = value;
    }

    /**
     * Gets the value of the plainTextDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPlainTextDescription() {
        return plainTextDescription;
    }

    /**
     * Sets the value of the plainTextDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPlainTextDescription(JAXBElement<String> value) {
        this.plainTextDescription = value;
    }

    /**
     * Gets the value of the calcRunningBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCalcRunningBalance() {
        return calcRunningBalance;
    }

    /**
     * Sets the value of the calcRunningBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCalcRunningBalance(JAXBElement<YMoney> value) {
        this.calcRunningBalance = value;
    }

    /**
     * Gets the value of the categoryLevelId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCategoryLevelId() {
        return categoryLevelId;
    }

    /**
     * Sets the value of the categoryLevelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCategoryLevelId(JAXBElement<Long> value) {
        this.categoryLevelId = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the contributionYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getContributionYear() {
        return contributionYear;
    }

    /**
     * Sets the value of the contributionYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setContributionYear(JAXBElement<Double> value) {
        this.contributionYear = value;
    }

    /**
     * Gets the value of the prevTransactionCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevTransactionCategoryId() {
        return prevTransactionCategoryId;
    }

    /**
     * Sets the value of the prevTransactionCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevTransactionCategoryId(JAXBElement<Long> value) {
        this.prevTransactionCategoryId = value;
    }

    /**
     * Gets the value of the isBusinessExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsBusinessExpense() {
        return isBusinessExpense;
    }

    /**
     * Sets the value of the isBusinessExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsBusinessExpense(JAXBElement<Long> value) {
        this.isBusinessExpense = value;
    }

    /**
     * Gets the value of the descriptionViewPref property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDescriptionViewPref() {
        return descriptionViewPref;
    }

    /**
     * Sets the value of the descriptionViewPref property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDescriptionViewPref(JAXBElement<Long> value) {
        this.descriptionViewPref = value;
    }

    /**
     * Gets the value of the deferredCompSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDeferredCompSource() {
        return deferredCompSource;
    }

    /**
     * Sets the value of the deferredCompSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDeferredCompSource(JAXBElement<String> value) {
        this.deferredCompSource = value;
    }

    /**
     * Gets the value of the symbol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSymbol() {
        return symbol;
    }

    /**
     * Sets the value of the symbol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSymbol(JAXBElement<String> value) {
        this.symbol = value;
    }

    /**
     * Gets the value of the prevCategorisationSourceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrevCategorisationSourceId() {
        return prevCategorisationSourceId;
    }

    /**
     * Sets the value of the prevCategorisationSourceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrevCategorisationSourceId(JAXBElement<Long> value) {
        this.prevCategorisationSourceId = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmount(JAXBElement<YMoney> value) {
        this.amount = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the isTaxDeductible property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsTaxDeductible() {
        return isTaxDeductible;
    }

    /**
     * Sets the value of the isTaxDeductible property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsTaxDeductible(JAXBElement<Long> value) {
        this.isTaxDeductible = value;
    }

    /**
     * Gets the value of the categorizationKeyword property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategorizationKeyword() {
        return categorizationKeyword;
    }

    /**
     * Sets the value of the categorizationKeyword property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategorizationKeyword(JAXBElement<String> value) {
        this.categorizationKeyword = value;
    }

    /**
     * Gets the value of the tradeDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTradeDate() {
        return tradeDate;
    }

    /**
     * Sets the value of the tradeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTradeDate(JAXBElement<YDate> value) {
        this.tradeDate = value;
    }

    /**
     * Gets the value of the installmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getInstallmentNumber() {
        return installmentNumber;
    }

    /**
     * Sets the value of the installmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setInstallmentNumber(JAXBElement<Long> value) {
        this.installmentNumber = value;
    }

    /**
     * Gets the value of the stampDuty property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStampDuty() {
        return stampDuty;
    }

    /**
     * Sets the value of the stampDuty property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStampDuty(JAXBElement<YMoney> value) {
        this.stampDuty = value;
    }

    /**
     * Gets the value of the serviceTax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getServiceTax() {
        return serviceTax;
    }

    /**
     * Sets the value of the serviceTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setServiceTax(JAXBElement<YMoney> value) {
        this.serviceTax = value;
    }

    /**
     * Gets the value of the otherFees property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOtherFees() {
        return otherFees;
    }

    /**
     * Sets the value of the otherFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOtherFees(JAXBElement<YMoney> value) {
        this.otherFees = value;
    }

    /**
     * Gets the value of the exchange property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Exchange }{@code >}
     *     
     */
    public JAXBElement<Exchange> getExchange() {
        return exchange;
    }

    /**
     * Sets the value of the exchange property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Exchange }{@code >}
     *     
     */
    public void setExchange(JAXBElement<Exchange> value) {
        this.exchange = value;
    }

    /**
     * Gets the value of the isin property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsin() {
        return isin;
    }

    /**
     * Sets the value of the isin property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsin(JAXBElement<String> value) {
        this.isin = value;
    }

    /**
     * Gets the value of the sedol property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSedol() {
        return sedol;
    }

    /**
     * Sets the value of the sedol property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSedol(JAXBElement<String> value) {
        this.sedol = value;
    }

    /**
     * Gets the value of the domicile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDomicile() {
        return domicile;
    }

    /**
     * Sets the value of the domicile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDomicile(JAXBElement<String> value) {
        this.domicile = value;
    }

    /**
     * Gets the value of the securityId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSecurityId() {
        return securityId;
    }

    /**
     * Sets the value of the securityId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSecurityId(JAXBElement<Long> value) {
        this.securityId = value;
    }

    /**
     * Gets the value of the securityInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public JAXBElement<InvestmentSecurity> getSecurityInfo() {
        return securityInfo;
    }

    /**
     * Sets the value of the securityInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link InvestmentSecurity }{@code >}
     *     
     */
    public void setSecurityInfo(JAXBElement<InvestmentSecurity> value) {
        this.securityInfo = value;
    }

    /**
     * Gets the value of the isSymbolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSymbolNormalized() {
        return isSymbolNormalized;
    }

    /**
     * Sets the value of the isSymbolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSymbolNormalized(JAXBElement<Long> value) {
        this.isSymbolNormalized = value;
    }

    /**
     * Gets the value of the isCusipNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsCusipNormalized() {
        return isCusipNormalized;
    }

    /**
     * Sets the value of the isCusipNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsCusipNormalized(JAXBElement<Long> value) {
        this.isCusipNormalized = value;
    }

    /**
     * Gets the value of the isIsinNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsIsinNormalized() {
        return isIsinNormalized;
    }

    /**
     * Sets the value of the isIsinNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsIsinNormalized(JAXBElement<Long> value) {
        this.isIsinNormalized = value;
    }

    /**
     * Gets the value of the isSedolNormalized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSedolNormalized() {
        return isSedolNormalized;
    }

    /**
     * Sets the value of the isSedolNormalized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSedolNormalized(JAXBElement<Long> value) {
        this.isSedolNormalized = value;
    }

}
