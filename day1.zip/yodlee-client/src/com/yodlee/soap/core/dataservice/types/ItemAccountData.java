
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.collections.ArrayOfString;
import com.yodlee.soap.core.itemaccountmanagement.ItemAccountAdditionalInfo;
import com.yodlee.soap.core.progressiverefresh.ProgressiveRefreshStatus;


/**
 * <p>Java class for ItemAccountData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemAccountData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="nickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shortNickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemDataTableId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemAccountStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isTaxDeductible" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isBusinessExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isMedicalExpense" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isReimbursable" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="includeInNetworth" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isAsset" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="defTxnCategoryId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isLinkedItemAccount" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="rowLastUpdated" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemAccountAdditionalInfo" type="{http://itemaccountmanagement.core.soap.yodlee.com}ItemAccountAdditionalInfo" minOccurs="0"/>
 *         &lt;element name="categoryLevelId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemAccountExtensions" type="{http://collections.soap.yodlee.com}ArrayOfString" minOccurs="0"/>
 *         &lt;element name="isUpdatePastTransaction" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="isUpdateTxCategory" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="createOpeningTxn" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="progressiveRefreshStatus" type="{http://progressiverefresh.core.soap.yodlee.com}ProgressiveRefreshStatus" minOccurs="0"/>
 *         &lt;element name="isEbillEnrolledAccount" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemAccountData", propOrder = {
    "nickName",
    "shortNickName",
    "itemDataTableId",
    "itemAccountStatusId",
    "isTaxDeductible",
    "isBusinessExpense",
    "isMedicalExpense",
    "isReimbursable",
    "memo",
    "includeInNetworth",
    "isAsset",
    "defTxnCategoryId",
    "isLinkedItemAccount",
    "rowLastUpdated",
    "lastUpdated",
    "itemAccountAdditionalInfo",
    "categoryLevelId",
    "itemAccountExtensions",
    "isUpdatePastTransaction",
    "isUpdateTxCategory",
    "createOpeningTxn",
    "progressiveRefreshStatus",
    "isEbillEnrolledAccount"
})
@XmlSeeAlso({
    InsuranceData.class,
    OtherAssetsData.class,
    BillsData.class,
    InvestmentData.class,
    BillPayServiceData.class,
    TaxData.class,
    OtherLiabilitiesData.class,
    CardData.class,
    PrepayAccountData.class,
    Loan.class,
    BankData.class,
    HomeValueAccountData.class,
    RewardPgm.class
})
public class ItemAccountData
    extends BaseTagData
{

    @XmlElementRef(name = "nickName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> nickName;
    @XmlElementRef(name = "shortNickName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> shortNickName;
    @XmlElementRef(name = "itemDataTableId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> itemDataTableId;
    @XmlElementRef(name = "itemAccountStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> itemAccountStatusId;
    @XmlElementRef(name = "isTaxDeductible", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isTaxDeductible;
    @XmlElementRef(name = "isBusinessExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isBusinessExpense;
    @XmlElementRef(name = "isMedicalExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isMedicalExpense;
    @XmlElementRef(name = "isReimbursable", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isReimbursable;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "includeInNetworth", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> includeInNetworth;
    @XmlElementRef(name = "isAsset", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isAsset;
    @XmlElementRef(name = "defTxnCategoryId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> defTxnCategoryId;
    protected boolean isLinkedItemAccount;
    @XmlElementRef(name = "rowLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> rowLastUpdated;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "itemAccountAdditionalInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<ItemAccountAdditionalInfo> itemAccountAdditionalInfo;
    @XmlElementRef(name = "categoryLevelId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> categoryLevelId;
    @XmlElementRef(name = "itemAccountExtensions", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfString> itemAccountExtensions;
    protected boolean isUpdatePastTransaction;
    protected boolean isUpdateTxCategory;
    protected boolean createOpeningTxn;
    @XmlElementRef(name = "progressiveRefreshStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<ProgressiveRefreshStatus> progressiveRefreshStatus;
    protected boolean isEbillEnrolledAccount;

    /**
     * Gets the value of the nickName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNickName() {
        return nickName;
    }

    /**
     * Sets the value of the nickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNickName(JAXBElement<String> value) {
        this.nickName = value;
    }

    /**
     * Gets the value of the shortNickName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShortNickName() {
        return shortNickName;
    }

    /**
     * Sets the value of the shortNickName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShortNickName(JAXBElement<String> value) {
        this.shortNickName = value;
    }

    /**
     * Gets the value of the itemDataTableId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getItemDataTableId() {
        return itemDataTableId;
    }

    /**
     * Sets the value of the itemDataTableId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setItemDataTableId(JAXBElement<Long> value) {
        this.itemDataTableId = value;
    }

    /**
     * Gets the value of the itemAccountStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getItemAccountStatusId() {
        return itemAccountStatusId;
    }

    /**
     * Sets the value of the itemAccountStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setItemAccountStatusId(JAXBElement<Long> value) {
        this.itemAccountStatusId = value;
    }

    /**
     * Gets the value of the isTaxDeductible property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsTaxDeductible() {
        return isTaxDeductible;
    }

    /**
     * Sets the value of the isTaxDeductible property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsTaxDeductible(JAXBElement<Long> value) {
        this.isTaxDeductible = value;
    }

    /**
     * Gets the value of the isBusinessExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsBusinessExpense() {
        return isBusinessExpense;
    }

    /**
     * Sets the value of the isBusinessExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsBusinessExpense(JAXBElement<Long> value) {
        this.isBusinessExpense = value;
    }

    /**
     * Gets the value of the isMedicalExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsMedicalExpense() {
        return isMedicalExpense;
    }

    /**
     * Sets the value of the isMedicalExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsMedicalExpense(JAXBElement<Long> value) {
        this.isMedicalExpense = value;
    }

    /**
     * Gets the value of the isReimbursable property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsReimbursable() {
        return isReimbursable;
    }

    /**
     * Sets the value of the isReimbursable property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsReimbursable(JAXBElement<Long> value) {
        this.isReimbursable = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the includeInNetworth property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIncludeInNetworth() {
        return includeInNetworth;
    }

    /**
     * Sets the value of the includeInNetworth property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIncludeInNetworth(JAXBElement<Long> value) {
        this.includeInNetworth = value;
    }

    /**
     * Gets the value of the isAsset property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsAsset() {
        return isAsset;
    }

    /**
     * Sets the value of the isAsset property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsAsset(JAXBElement<Long> value) {
        this.isAsset = value;
    }

    /**
     * Gets the value of the defTxnCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDefTxnCategoryId() {
        return defTxnCategoryId;
    }

    /**
     * Sets the value of the defTxnCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDefTxnCategoryId(JAXBElement<Long> value) {
        this.defTxnCategoryId = value;
    }

    /**
     * Gets the value of the isLinkedItemAccount property.
     * 
     */
    public boolean isIsLinkedItemAccount() {
        return isLinkedItemAccount;
    }

    /**
     * Sets the value of the isLinkedItemAccount property.
     * 
     */
    public void setIsLinkedItemAccount(boolean value) {
        this.isLinkedItemAccount = value;
    }

    /**
     * Gets the value of the rowLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getRowLastUpdated() {
        return rowLastUpdated;
    }

    /**
     * Sets the value of the rowLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setRowLastUpdated(JAXBElement<XMLGregorianCalendar> value) {
        this.rowLastUpdated = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the itemAccountAdditionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ItemAccountAdditionalInfo }{@code >}
     *     
     */
    public JAXBElement<ItemAccountAdditionalInfo> getItemAccountAdditionalInfo() {
        return itemAccountAdditionalInfo;
    }

    /**
     * Sets the value of the itemAccountAdditionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ItemAccountAdditionalInfo }{@code >}
     *     
     */
    public void setItemAccountAdditionalInfo(JAXBElement<ItemAccountAdditionalInfo> value) {
        this.itemAccountAdditionalInfo = value;
    }

    /**
     * Gets the value of the categoryLevelId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCategoryLevelId() {
        return categoryLevelId;
    }

    /**
     * Sets the value of the categoryLevelId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCategoryLevelId(JAXBElement<Long> value) {
        this.categoryLevelId = value;
    }

    /**
     * Gets the value of the itemAccountExtensions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfString }{@code >}
     *     
     */
    public JAXBElement<ArrayOfString> getItemAccountExtensions() {
        return itemAccountExtensions;
    }

    /**
     * Sets the value of the itemAccountExtensions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfString }{@code >}
     *     
     */
    public void setItemAccountExtensions(JAXBElement<ArrayOfString> value) {
        this.itemAccountExtensions = value;
    }

    /**
     * Gets the value of the isUpdatePastTransaction property.
     * 
     */
    public boolean isIsUpdatePastTransaction() {
        return isUpdatePastTransaction;
    }

    /**
     * Sets the value of the isUpdatePastTransaction property.
     * 
     */
    public void setIsUpdatePastTransaction(boolean value) {
        this.isUpdatePastTransaction = value;
    }

    /**
     * Gets the value of the isUpdateTxCategory property.
     * 
     */
    public boolean isIsUpdateTxCategory() {
        return isUpdateTxCategory;
    }

    /**
     * Sets the value of the isUpdateTxCategory property.
     * 
     */
    public void setIsUpdateTxCategory(boolean value) {
        this.isUpdateTxCategory = value;
    }

    /**
     * Gets the value of the createOpeningTxn property.
     * 
     */
    public boolean isCreateOpeningTxn() {
        return createOpeningTxn;
    }

    /**
     * Sets the value of the createOpeningTxn property.
     * 
     */
    public void setCreateOpeningTxn(boolean value) {
        this.createOpeningTxn = value;
    }

    /**
     * Gets the value of the progressiveRefreshStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ProgressiveRefreshStatus }{@code >}
     *     
     */
    public JAXBElement<ProgressiveRefreshStatus> getProgressiveRefreshStatus() {
        return progressiveRefreshStatus;
    }

    /**
     * Sets the value of the progressiveRefreshStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ProgressiveRefreshStatus }{@code >}
     *     
     */
    public void setProgressiveRefreshStatus(JAXBElement<ProgressiveRefreshStatus> value) {
        this.progressiveRefreshStatus = value;
    }

    /**
     * Gets the value of the isEbillEnrolledAccount property.
     * 
     */
    public boolean isIsEbillEnrolledAccount() {
        return isEbillEnrolledAccount;
    }

    /**
     * Sets the value of the isEbillEnrolledAccount property.
     * 
     */
    public void setIsEbillEnrolledAccount(boolean value) {
        this.isEbillEnrolledAccount = value;
    }

}
