
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for Loan complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Loan">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loanInterestRateTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanInterestRateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedLoanInterestRateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetupId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="vehicleId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billPreferenceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanLoginAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayEnrolled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="transListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="lastPaymentAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="principalBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="originalLoanAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidLastYear" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="recurringPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="escrowBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pointsPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pointsPaidLastYear" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="insurancePaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="insurancePaidLastYear" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="propertyTaxPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="propertyTaxPaidLastYear" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableCredit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="creditLimit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="amountDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="minPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="paymentApartmentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentAddress1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="paymentFullAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentSchool" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loanTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedLoanType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originalSchool" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="firstPaymentDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="interestRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="loanFrequencyTypeId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanFrequencyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedLoanFrequencyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dueDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isFirstMortgage" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastPaymentDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDerivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyApartmentNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyAddress2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyProvince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyAddress1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="propertyFullAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gurantor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="collateral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="parcelNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stmtListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="stmtListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="propertyListId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originationDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="maturityDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUserAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayScraped" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetup" type="{http://types.dataservice.core.soap.yodlee.com}ExtAutopaySetupData" minOccurs="0"/>
 *         &lt;element name="loanTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="loanStatements" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="loanPayOffs" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="loanPaymentDues" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="borrowers" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="coSigners" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="vehicle" type="{http://types.dataservice.core.soap.yodlee.com}Vehicle" minOccurs="0"/>
 *         &lt;element name="billPreference" type="{http://types.dataservice.core.soap.yodlee.com}BillPreferenceData" minOccurs="0"/>
 *         &lt;element name="paymentDetails" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPaperlessStmtOn" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="asOfDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paymentsRemaining" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="additionalCapital" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="availableLoan" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxesWithheldYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxesPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestAccruedSinceLastPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="srcAccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="arrearsAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="unclearedBal" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Loan", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "loanInterestRateTypeId",
    "loanInterestRateType",
    "localizedLoanInterestRateType",
    "extAutopaySetupId",
    "vehicleId",
    "billPreferenceId",
    "loanId",
    "loanLoginAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "isExtAutopayEnrolled",
    "lender",
    "accountNumber",
    "accountHolder",
    "transListToDate",
    "transListFromDate",
    "lastPaymentAmount",
    "principalBalance",
    "originalLoanAmount",
    "interestPaidYtd",
    "interestPaidLastYear",
    "recurringPayment",
    "escrowBalance",
    "pointsPaidYtd",
    "pointsPaidLastYear",
    "insurancePaidYtd",
    "insurancePaidLastYear",
    "propertyTaxPaidYtd",
    "propertyTaxPaidLastYear",
    "availableCredit",
    "creditLimit",
    "amountDue",
    "minPayment",
    "paymentApartmentNumber",
    "paymentAddress2",
    "paymentCountry",
    "paymentProvince",
    "paymentState",
    "paymentZip",
    "paymentAddress1",
    "paymentCity",
    "paymentFullAddress",
    "currentSchool",
    "loanTerm",
    "userAutopayEnrollmentStatusLastUpdated",
    "loanTypeId",
    "loanType",
    "localizedLoanType",
    "originalSchool",
    "firstPaymentDate",
    "interestRate",
    "loanFrequencyTypeId",
    "loanFrequencyType",
    "localizedLoanFrequencyType",
    "dueDate",
    "link",
    "isFirstMortgage",
    "lastPaymentDate",
    "derivedAutopayEnrollmentStatusId",
    "derivedAutopayEnrollmentStatus",
    "localizedDerivedAutopayEnrollmentStatus",
    "propertyApartmentNumber",
    "propertyAddress2",
    "propertyCountry",
    "propertyProvince",
    "propertyState",
    "propertyZip",
    "propertyAddress1",
    "propertyCity",
    "propertyFullAddress",
    "gurantor",
    "collateral",
    "description",
    "parcelNumber",
    "accountName",
    "stmtListToDate",
    "stmtListFromDate",
    "propertyListId",
    "originationDate",
    "maturityDate",
    "userAutopayEnrollmentStatusId",
    "userAutopayEnrollmentStatus",
    "localizedUserAutopayEnrollmentStatus",
    "derivedAutopayEnrollmentStatusLastUpdated",
    "isExtAutopayScraped",
    "autopayEnrollmentStatusId",
    "autopayEnrollmentStatus",
    "localizedAutopayEnrollmentStatus",
    "extAutopaySetup",
    "loanTransactions",
    "loanStatements",
    "loanPayOffs",
    "loanPaymentDues",
    "borrowers",
    "coSigners",
    "vehicle",
    "billPreference",
    "paymentDetails",
    "accountNicknameAtSrcSite",
    "isPaperlessStmtOn",
    "asOfDate",
    "siteAccountStatus",
    "created",
    "paymentsRemaining",
    "secondaryAccountHolderName",
    "accountOpenDate",
    "accountCloseDate",
    "additionalCapital",
    "availableLoan",
    "taxesWithheldYtd",
    "taxesPaidYtd",
    "interestAccruedSinceLastPayment",
    "srcAccountType",
    "arrearsAmount",
    "unclearedBal"
})
public class Loan
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "loanInterestRateTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanInterestRateTypeId;
    @XmlElementRef(name = "loanInterestRateType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> loanInterestRateType;
    @XmlElementRef(name = "localizedLoanInterestRateType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedLoanInterestRateType;
    @XmlElementRef(name = "extAutopaySetupId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extAutopaySetupId;
    @XmlElementRef(name = "vehicleId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> vehicleId;
    @XmlElementRef(name = "billPreferenceId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billPreferenceId;
    @XmlElementRef(name = "loanId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanId;
    @XmlElementRef(name = "loanLoginAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanLoginAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "isExtAutopayEnrolled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayEnrolled;
    @XmlElementRef(name = "lender", type = JAXBElement.class, required = false)
    protected JAXBElement<String> lender;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "transListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListToDate;
    @XmlElementRef(name = "transListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListFromDate;
    @XmlElementRef(name = "lastPaymentAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPaymentAmount;
    @XmlElementRef(name = "principalBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> principalBalance;
    @XmlElementRef(name = "originalLoanAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> originalLoanAmount;
    @XmlElementRef(name = "interestPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidYtd;
    @XmlElementRef(name = "interestPaidLastYear", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidLastYear;
    @XmlElementRef(name = "recurringPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> recurringPayment;
    @XmlElementRef(name = "escrowBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> escrowBalance;
    @XmlElementRef(name = "pointsPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pointsPaidYtd;
    @XmlElementRef(name = "pointsPaidLastYear", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pointsPaidLastYear;
    @XmlElementRef(name = "insurancePaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> insurancePaidYtd;
    @XmlElementRef(name = "insurancePaidLastYear", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> insurancePaidLastYear;
    @XmlElementRef(name = "propertyTaxPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> propertyTaxPaidYtd;
    @XmlElementRef(name = "propertyTaxPaidLastYear", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> propertyTaxPaidLastYear;
    @XmlElementRef(name = "availableCredit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableCredit;
    @XmlElementRef(name = "creditLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> creditLimit;
    @XmlElementRef(name = "amountDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountDue;
    @XmlElementRef(name = "minPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> minPayment;
    @XmlElementRef(name = "paymentApartmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentApartmentNumber;
    @XmlElementRef(name = "paymentAddress2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentAddress2;
    @XmlElementRef(name = "paymentCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentCountry;
    @XmlElementRef(name = "paymentProvince", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentProvince;
    @XmlElementRef(name = "paymentState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentState;
    @XmlElementRef(name = "paymentZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentZip;
    @XmlElementRef(name = "paymentAddress1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentAddress1;
    @XmlElementRef(name = "paymentCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentCity;
    @XmlElementRef(name = "paymentFullAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentFullAddress;
    @XmlElementRef(name = "currentSchool", type = JAXBElement.class, required = false)
    protected JAXBElement<String> currentSchool;
    @XmlElementRef(name = "loanTerm", type = JAXBElement.class, required = false)
    protected JAXBElement<String> loanTerm;
    @XmlElementRef(name = "userAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "loanTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanTypeId;
    @XmlElementRef(name = "loanType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> loanType;
    @XmlElementRef(name = "localizedLoanType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedLoanType;
    @XmlElementRef(name = "originalSchool", type = JAXBElement.class, required = false)
    protected JAXBElement<String> originalSchool;
    @XmlElementRef(name = "firstPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> firstPaymentDate;
    @XmlElementRef(name = "interestRate", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> interestRate;
    @XmlElementRef(name = "loanFrequencyTypeId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanFrequencyTypeId;
    @XmlElementRef(name = "loanFrequencyType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> loanFrequencyType;
    @XmlElementRef(name = "localizedLoanFrequencyType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedLoanFrequencyType;
    @XmlElementRef(name = "dueDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dueDate;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "isFirstMortgage", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isFirstMortgage;
    @XmlElementRef(name = "lastPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPaymentDate;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusId;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> derivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedDerivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDerivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "propertyApartmentNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyApartmentNumber;
    @XmlElementRef(name = "propertyAddress2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyAddress2;
    @XmlElementRef(name = "propertyCountry", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyCountry;
    @XmlElementRef(name = "propertyProvince", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyProvince;
    @XmlElementRef(name = "propertyState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyState;
    @XmlElementRef(name = "propertyZip", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyZip;
    @XmlElementRef(name = "propertyAddress1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyAddress1;
    @XmlElementRef(name = "propertyCity", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyCity;
    @XmlElementRef(name = "propertyFullAddress", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyFullAddress;
    @XmlElementRef(name = "gurantor", type = JAXBElement.class, required = false)
    protected JAXBElement<String> gurantor;
    @XmlElementRef(name = "collateral", type = JAXBElement.class, required = false)
    protected JAXBElement<String> collateral;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "parcelNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> parcelNumber;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "stmtListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListToDate;
    @XmlElementRef(name = "stmtListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> stmtListFromDate;
    @XmlElementRef(name = "propertyListId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> propertyListId;
    @XmlElementRef(name = "originationDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> originationDate;
    @XmlElementRef(name = "maturityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> maturityDate;
    @XmlElementRef(name = "userAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusId;
    @XmlElementRef(name = "userAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedUserAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUserAutopayEnrollmentStatus;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "isExtAutopayScraped", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayScraped;
    @XmlElementRef(name = "autopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> autopayEnrollmentStatusId;
    @XmlElementRef(name = "autopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> autopayEnrollmentStatus;
    @XmlElementRef(name = "localizedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAutopayEnrollmentStatus;
    @XmlElementRef(name = "extAutopaySetup", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtAutopaySetupData> extAutopaySetup;
    @XmlElementRef(name = "loanTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> loanTransactions;
    @XmlElementRef(name = "loanStatements", type = JAXBElement.class, required = false)
    protected JAXBElement<List> loanStatements;
    @XmlElementRef(name = "loanPayOffs", type = JAXBElement.class, required = false)
    protected JAXBElement<List> loanPayOffs;
    @XmlElementRef(name = "loanPaymentDues", type = JAXBElement.class, required = false)
    protected JAXBElement<List> loanPaymentDues;
    @XmlElementRef(name = "borrowers", type = JAXBElement.class, required = false)
    protected JAXBElement<List> borrowers;
    @XmlElementRef(name = "coSigners", type = JAXBElement.class, required = false)
    protected JAXBElement<List> coSigners;
    @XmlElementRef(name = "vehicle", type = JAXBElement.class, required = false)
    protected JAXBElement<Vehicle> vehicle;
    @XmlElementRef(name = "billPreference", type = JAXBElement.class, required = false)
    protected JAXBElement<BillPreferenceData> billPreference;
    @XmlElementRef(name = "paymentDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<List> paymentDetails;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "isPaperlessStmtOn", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isPaperlessStmtOn;
    @XmlElementRef(name = "asOfDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asOfDate;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "paymentsRemaining", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paymentsRemaining;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "additionalCapital", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> additionalCapital;
    @XmlElementRef(name = "availableLoan", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> availableLoan;
    @XmlElementRef(name = "taxesWithheldYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxesWithheldYtd;
    @XmlElementRef(name = "taxesPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxesPaidYtd;
    @XmlElementRef(name = "interestAccruedSinceLastPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestAccruedSinceLastPayment;
    @XmlElementRef(name = "srcAccountType", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcAccountType;
    @XmlElementRef(name = "arrearsAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> arrearsAmount;
    @XmlElementRef(name = "unclearedBal", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unclearedBal;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the loanInterestRateTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanInterestRateTypeId() {
        return loanInterestRateTypeId;
    }

    /**
     * Sets the value of the loanInterestRateTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanInterestRateTypeId(JAXBElement<Long> value) {
        this.loanInterestRateTypeId = value;
    }

    /**
     * Gets the value of the loanInterestRateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLoanInterestRateType() {
        return loanInterestRateType;
    }

    /**
     * Sets the value of the loanInterestRateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLoanInterestRateType(JAXBElement<String> value) {
        this.loanInterestRateType = value;
    }

    /**
     * Gets the value of the localizedLoanInterestRateType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedLoanInterestRateType() {
        return localizedLoanInterestRateType;
    }

    /**
     * Sets the value of the localizedLoanInterestRateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedLoanInterestRateType(JAXBElement<String> value) {
        this.localizedLoanInterestRateType = value;
    }

    /**
     * Gets the value of the extAutopaySetupId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtAutopaySetupId() {
        return extAutopaySetupId;
    }

    /**
     * Sets the value of the extAutopaySetupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtAutopaySetupId(JAXBElement<Long> value) {
        this.extAutopaySetupId = value;
    }

    /**
     * Gets the value of the vehicleId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getVehicleId() {
        return vehicleId;
    }

    /**
     * Sets the value of the vehicleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setVehicleId(JAXBElement<Long> value) {
        this.vehicleId = value;
    }

    /**
     * Gets the value of the billPreferenceId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillPreferenceId() {
        return billPreferenceId;
    }

    /**
     * Sets the value of the billPreferenceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillPreferenceId(JAXBElement<Long> value) {
        this.billPreferenceId = value;
    }

    /**
     * Gets the value of the loanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanId() {
        return loanId;
    }

    /**
     * Sets the value of the loanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanId(JAXBElement<Long> value) {
        this.loanId = value;
    }

    /**
     * Gets the value of the loanLoginAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanLoginAccountId() {
        return loanLoginAccountId;
    }

    /**
     * Sets the value of the loanLoginAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanLoginAccountId(JAXBElement<Long> value) {
        this.loanLoginAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the isExtAutopayEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayEnrolled() {
        return isExtAutopayEnrolled;
    }

    /**
     * Sets the value of the isExtAutopayEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayEnrolled(JAXBElement<Long> value) {
        this.isExtAutopayEnrolled = value;
    }

    /**
     * Gets the value of the lender property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLender() {
        return lender;
    }

    /**
     * Sets the value of the lender property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLender(JAXBElement<String> value) {
        this.lender = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the transListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListToDate() {
        return transListToDate;
    }

    /**
     * Sets the value of the transListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListToDate(JAXBElement<YDate> value) {
        this.transListToDate = value;
    }

    /**
     * Gets the value of the transListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListFromDate() {
        return transListFromDate;
    }

    /**
     * Sets the value of the transListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListFromDate(JAXBElement<YDate> value) {
        this.transListFromDate = value;
    }

    /**
     * Gets the value of the lastPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Sets the value of the lastPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPaymentAmount(JAXBElement<YMoney> value) {
        this.lastPaymentAmount = value;
    }

    /**
     * Gets the value of the principalBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * Sets the value of the principalBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrincipalBalance(JAXBElement<YMoney> value) {
        this.principalBalance = value;
    }

    /**
     * Gets the value of the originalLoanAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOriginalLoanAmount() {
        return originalLoanAmount;
    }

    /**
     * Sets the value of the originalLoanAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOriginalLoanAmount(JAXBElement<YMoney> value) {
        this.originalLoanAmount = value;
    }

    /**
     * Gets the value of the interestPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidYtd() {
        return interestPaidYtd;
    }

    /**
     * Sets the value of the interestPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidYtd(JAXBElement<YMoney> value) {
        this.interestPaidYtd = value;
    }

    /**
     * Gets the value of the interestPaidLastYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidLastYear() {
        return interestPaidLastYear;
    }

    /**
     * Sets the value of the interestPaidLastYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidLastYear(JAXBElement<YMoney> value) {
        this.interestPaidLastYear = value;
    }

    /**
     * Gets the value of the recurringPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRecurringPayment() {
        return recurringPayment;
    }

    /**
     * Sets the value of the recurringPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRecurringPayment(JAXBElement<YMoney> value) {
        this.recurringPayment = value;
    }

    /**
     * Gets the value of the escrowBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEscrowBalance() {
        return escrowBalance;
    }

    /**
     * Sets the value of the escrowBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEscrowBalance(JAXBElement<YMoney> value) {
        this.escrowBalance = value;
    }

    /**
     * Gets the value of the pointsPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPointsPaidYtd() {
        return pointsPaidYtd;
    }

    /**
     * Sets the value of the pointsPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPointsPaidYtd(JAXBElement<YMoney> value) {
        this.pointsPaidYtd = value;
    }

    /**
     * Gets the value of the pointsPaidLastYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPointsPaidLastYear() {
        return pointsPaidLastYear;
    }

    /**
     * Sets the value of the pointsPaidLastYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPointsPaidLastYear(JAXBElement<YMoney> value) {
        this.pointsPaidLastYear = value;
    }

    /**
     * Gets the value of the insurancePaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInsurancePaidYtd() {
        return insurancePaidYtd;
    }

    /**
     * Sets the value of the insurancePaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInsurancePaidYtd(JAXBElement<YMoney> value) {
        this.insurancePaidYtd = value;
    }

    /**
     * Gets the value of the insurancePaidLastYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInsurancePaidLastYear() {
        return insurancePaidLastYear;
    }

    /**
     * Sets the value of the insurancePaidLastYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInsurancePaidLastYear(JAXBElement<YMoney> value) {
        this.insurancePaidLastYear = value;
    }

    /**
     * Gets the value of the propertyTaxPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPropertyTaxPaidYtd() {
        return propertyTaxPaidYtd;
    }

    /**
     * Sets the value of the propertyTaxPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPropertyTaxPaidYtd(JAXBElement<YMoney> value) {
        this.propertyTaxPaidYtd = value;
    }

    /**
     * Gets the value of the propertyTaxPaidLastYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPropertyTaxPaidLastYear() {
        return propertyTaxPaidLastYear;
    }

    /**
     * Sets the value of the propertyTaxPaidLastYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPropertyTaxPaidLastYear(JAXBElement<YMoney> value) {
        this.propertyTaxPaidLastYear = value;
    }

    /**
     * Gets the value of the availableCredit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableCredit() {
        return availableCredit;
    }

    /**
     * Sets the value of the availableCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableCredit(JAXBElement<YMoney> value) {
        this.availableCredit = value;
    }

    /**
     * Gets the value of the creditLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCreditLimit() {
        return creditLimit;
    }

    /**
     * Sets the value of the creditLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCreditLimit(JAXBElement<YMoney> value) {
        this.creditLimit = value;
    }

    /**
     * Gets the value of the amountDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountDue() {
        return amountDue;
    }

    /**
     * Sets the value of the amountDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountDue(JAXBElement<YMoney> value) {
        this.amountDue = value;
    }

    /**
     * Gets the value of the minPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMinPayment() {
        return minPayment;
    }

    /**
     * Sets the value of the minPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMinPayment(JAXBElement<YMoney> value) {
        this.minPayment = value;
    }

    /**
     * Gets the value of the paymentApartmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentApartmentNumber() {
        return paymentApartmentNumber;
    }

    /**
     * Sets the value of the paymentApartmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentApartmentNumber(JAXBElement<String> value) {
        this.paymentApartmentNumber = value;
    }

    /**
     * Gets the value of the paymentAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentAddress2() {
        return paymentAddress2;
    }

    /**
     * Sets the value of the paymentAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentAddress2(JAXBElement<String> value) {
        this.paymentAddress2 = value;
    }

    /**
     * Gets the value of the paymentCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentCountry() {
        return paymentCountry;
    }

    /**
     * Sets the value of the paymentCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentCountry(JAXBElement<String> value) {
        this.paymentCountry = value;
    }

    /**
     * Gets the value of the paymentProvince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentProvince() {
        return paymentProvince;
    }

    /**
     * Sets the value of the paymentProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentProvince(JAXBElement<String> value) {
        this.paymentProvince = value;
    }

    /**
     * Gets the value of the paymentState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentState() {
        return paymentState;
    }

    /**
     * Sets the value of the paymentState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentState(JAXBElement<String> value) {
        this.paymentState = value;
    }

    /**
     * Gets the value of the paymentZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentZip() {
        return paymentZip;
    }

    /**
     * Sets the value of the paymentZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentZip(JAXBElement<String> value) {
        this.paymentZip = value;
    }

    /**
     * Gets the value of the paymentAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentAddress1() {
        return paymentAddress1;
    }

    /**
     * Sets the value of the paymentAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentAddress1(JAXBElement<String> value) {
        this.paymentAddress1 = value;
    }

    /**
     * Gets the value of the paymentCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentCity() {
        return paymentCity;
    }

    /**
     * Sets the value of the paymentCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentCity(JAXBElement<String> value) {
        this.paymentCity = value;
    }

    /**
     * Gets the value of the paymentFullAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentFullAddress() {
        return paymentFullAddress;
    }

    /**
     * Sets the value of the paymentFullAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentFullAddress(JAXBElement<String> value) {
        this.paymentFullAddress = value;
    }

    /**
     * Gets the value of the currentSchool property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrentSchool() {
        return currentSchool;
    }

    /**
     * Sets the value of the currentSchool property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrentSchool(JAXBElement<String> value) {
        this.currentSchool = value;
    }

    /**
     * Gets the value of the loanTerm property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLoanTerm() {
        return loanTerm;
    }

    /**
     * Sets the value of the loanTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLoanTerm(JAXBElement<String> value) {
        this.loanTerm = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusLastUpdated() {
        return userAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the loanTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanTypeId() {
        return loanTypeId;
    }

    /**
     * Sets the value of the loanTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanTypeId(JAXBElement<Long> value) {
        this.loanTypeId = value;
    }

    /**
     * Gets the value of the loanType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLoanType() {
        return loanType;
    }

    /**
     * Sets the value of the loanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLoanType(JAXBElement<String> value) {
        this.loanType = value;
    }

    /**
     * Gets the value of the localizedLoanType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedLoanType() {
        return localizedLoanType;
    }

    /**
     * Sets the value of the localizedLoanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedLoanType(JAXBElement<String> value) {
        this.localizedLoanType = value;
    }

    /**
     * Gets the value of the originalSchool property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getOriginalSchool() {
        return originalSchool;
    }

    /**
     * Sets the value of the originalSchool property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setOriginalSchool(JAXBElement<String> value) {
        this.originalSchool = value;
    }

    /**
     * Gets the value of the firstPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getFirstPaymentDate() {
        return firstPaymentDate;
    }

    /**
     * Sets the value of the firstPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setFirstPaymentDate(JAXBElement<YDate> value) {
        this.firstPaymentDate = value;
    }

    /**
     * Gets the value of the interestRate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getInterestRate() {
        return interestRate;
    }

    /**
     * Sets the value of the interestRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setInterestRate(JAXBElement<Double> value) {
        this.interestRate = value;
    }

    /**
     * Gets the value of the loanFrequencyTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanFrequencyTypeId() {
        return loanFrequencyTypeId;
    }

    /**
     * Sets the value of the loanFrequencyTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanFrequencyTypeId(JAXBElement<Long> value) {
        this.loanFrequencyTypeId = value;
    }

    /**
     * Gets the value of the loanFrequencyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLoanFrequencyType() {
        return loanFrequencyType;
    }

    /**
     * Sets the value of the loanFrequencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLoanFrequencyType(JAXBElement<String> value) {
        this.loanFrequencyType = value;
    }

    /**
     * Gets the value of the localizedLoanFrequencyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedLoanFrequencyType() {
        return localizedLoanFrequencyType;
    }

    /**
     * Sets the value of the localizedLoanFrequencyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedLoanFrequencyType(JAXBElement<String> value) {
        this.localizedLoanFrequencyType = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDueDate(JAXBElement<YDate> value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the isFirstMortgage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsFirstMortgage() {
        return isFirstMortgage;
    }

    /**
     * Sets the value of the isFirstMortgage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsFirstMortgage(JAXBElement<Long> value) {
        this.isFirstMortgage = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPaymentDate(JAXBElement<YDate> value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusId() {
        return derivedAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDerivedAutopayEnrollmentStatus() {
        return derivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.derivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDerivedAutopayEnrollmentStatus() {
        return localizedDerivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedDerivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the propertyApartmentNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyApartmentNumber() {
        return propertyApartmentNumber;
    }

    /**
     * Sets the value of the propertyApartmentNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyApartmentNumber(JAXBElement<String> value) {
        this.propertyApartmentNumber = value;
    }

    /**
     * Gets the value of the propertyAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyAddress2() {
        return propertyAddress2;
    }

    /**
     * Sets the value of the propertyAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyAddress2(JAXBElement<String> value) {
        this.propertyAddress2 = value;
    }

    /**
     * Gets the value of the propertyCountry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyCountry() {
        return propertyCountry;
    }

    /**
     * Sets the value of the propertyCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyCountry(JAXBElement<String> value) {
        this.propertyCountry = value;
    }

    /**
     * Gets the value of the propertyProvince property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyProvince() {
        return propertyProvince;
    }

    /**
     * Sets the value of the propertyProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyProvince(JAXBElement<String> value) {
        this.propertyProvince = value;
    }

    /**
     * Gets the value of the propertyState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyState() {
        return propertyState;
    }

    /**
     * Sets the value of the propertyState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyState(JAXBElement<String> value) {
        this.propertyState = value;
    }

    /**
     * Gets the value of the propertyZip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyZip() {
        return propertyZip;
    }

    /**
     * Sets the value of the propertyZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyZip(JAXBElement<String> value) {
        this.propertyZip = value;
    }

    /**
     * Gets the value of the propertyAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyAddress1() {
        return propertyAddress1;
    }

    /**
     * Sets the value of the propertyAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyAddress1(JAXBElement<String> value) {
        this.propertyAddress1 = value;
    }

    /**
     * Gets the value of the propertyCity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyCity() {
        return propertyCity;
    }

    /**
     * Sets the value of the propertyCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyCity(JAXBElement<String> value) {
        this.propertyCity = value;
    }

    /**
     * Gets the value of the propertyFullAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyFullAddress() {
        return propertyFullAddress;
    }

    /**
     * Sets the value of the propertyFullAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyFullAddress(JAXBElement<String> value) {
        this.propertyFullAddress = value;
    }

    /**
     * Gets the value of the gurantor property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getGurantor() {
        return gurantor;
    }

    /**
     * Sets the value of the gurantor property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setGurantor(JAXBElement<String> value) {
        this.gurantor = value;
    }

    /**
     * Gets the value of the collateral property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCollateral() {
        return collateral;
    }

    /**
     * Sets the value of the collateral property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCollateral(JAXBElement<String> value) {
        this.collateral = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the parcelNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getParcelNumber() {
        return parcelNumber;
    }

    /**
     * Sets the value of the parcelNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setParcelNumber(JAXBElement<String> value) {
        this.parcelNumber = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the stmtListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListToDate() {
        return stmtListToDate;
    }

    /**
     * Sets the value of the stmtListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListToDate(JAXBElement<YDate> value) {
        this.stmtListToDate = value;
    }

    /**
     * Gets the value of the stmtListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getStmtListFromDate() {
        return stmtListFromDate;
    }

    /**
     * Sets the value of the stmtListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setStmtListFromDate(JAXBElement<YDate> value) {
        this.stmtListFromDate = value;
    }

    /**
     * Gets the value of the propertyListId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPropertyListId() {
        return propertyListId;
    }

    /**
     * Sets the value of the propertyListId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPropertyListId(JAXBElement<String> value) {
        this.propertyListId = value;
    }

    /**
     * Gets the value of the originationDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getOriginationDate() {
        return originationDate;
    }

    /**
     * Sets the value of the originationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setOriginationDate(JAXBElement<YDate> value) {
        this.originationDate = value;
    }

    /**
     * Gets the value of the maturityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getMaturityDate() {
        return maturityDate;
    }

    /**
     * Sets the value of the maturityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setMaturityDate(JAXBElement<YDate> value) {
        this.maturityDate = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusId() {
        return userAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserAutopayEnrollmentStatus() {
        return userAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.userAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUserAutopayEnrollmentStatus() {
        return localizedUserAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedUserAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusLastUpdated() {
        return derivedAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the isExtAutopayScraped property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayScraped() {
        return isExtAutopayScraped;
    }

    /**
     * Sets the value of the isExtAutopayScraped property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayScraped(JAXBElement<Long> value) {
        this.isExtAutopayScraped = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAutopayEnrollmentStatusId() {
        return autopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the autopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.autopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAutopayEnrollmentStatus() {
        return autopayEnrollmentStatus;
    }

    /**
     * Sets the value of the autopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.autopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAutopayEnrollmentStatus() {
        return localizedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the extAutopaySetup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public JAXBElement<ExtAutopaySetupData> getExtAutopaySetup() {
        return extAutopaySetup;
    }

    /**
     * Sets the value of the extAutopaySetup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public void setExtAutopaySetup(JAXBElement<ExtAutopaySetupData> value) {
        this.extAutopaySetup = value;
    }

    /**
     * Gets the value of the loanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getLoanTransactions() {
        return loanTransactions;
    }

    /**
     * Sets the value of the loanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setLoanTransactions(JAXBElement<List> value) {
        this.loanTransactions = value;
    }

    /**
     * Gets the value of the loanStatements property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getLoanStatements() {
        return loanStatements;
    }

    /**
     * Sets the value of the loanStatements property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setLoanStatements(JAXBElement<List> value) {
        this.loanStatements = value;
    }

    /**
     * Gets the value of the loanPayOffs property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getLoanPayOffs() {
        return loanPayOffs;
    }

    /**
     * Sets the value of the loanPayOffs property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setLoanPayOffs(JAXBElement<List> value) {
        this.loanPayOffs = value;
    }

    /**
     * Gets the value of the loanPaymentDues property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getLoanPaymentDues() {
        return loanPaymentDues;
    }

    /**
     * Sets the value of the loanPaymentDues property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setLoanPaymentDues(JAXBElement<List> value) {
        this.loanPaymentDues = value;
    }

    /**
     * Gets the value of the borrowers property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getBorrowers() {
        return borrowers;
    }

    /**
     * Sets the value of the borrowers property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setBorrowers(JAXBElement<List> value) {
        this.borrowers = value;
    }

    /**
     * Gets the value of the coSigners property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getCoSigners() {
        return coSigners;
    }

    /**
     * Sets the value of the coSigners property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setCoSigners(JAXBElement<List> value) {
        this.coSigners = value;
    }

    /**
     * Gets the value of the vehicle property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Vehicle }{@code >}
     *     
     */
    public JAXBElement<Vehicle> getVehicle() {
        return vehicle;
    }

    /**
     * Sets the value of the vehicle property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Vehicle }{@code >}
     *     
     */
    public void setVehicle(JAXBElement<Vehicle> value) {
        this.vehicle = value;
    }

    /**
     * Gets the value of the billPreference property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public JAXBElement<BillPreferenceData> getBillPreference() {
        return billPreference;
    }

    /**
     * Sets the value of the billPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BillPreferenceData }{@code >}
     *     
     */
    public void setBillPreference(JAXBElement<BillPreferenceData> value) {
        this.billPreference = value;
    }

    /**
     * Gets the value of the paymentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPaymentDetails() {
        return paymentDetails;
    }

    /**
     * Sets the value of the paymentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPaymentDetails(JAXBElement<List> value) {
        this.paymentDetails = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the isPaperlessStmtOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsPaperlessStmtOn() {
        return isPaperlessStmtOn;
    }

    /**
     * Sets the value of the isPaperlessStmtOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsPaperlessStmtOn(JAXBElement<Long> value) {
        this.isPaperlessStmtOn = value;
    }

    /**
     * Gets the value of the asOfDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsOfDate() {
        return asOfDate;
    }

    /**
     * Sets the value of the asOfDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsOfDate(JAXBElement<YDate> value) {
        this.asOfDate = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the paymentsRemaining property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPaymentsRemaining() {
        return paymentsRemaining;
    }

    /**
     * Sets the value of the paymentsRemaining property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPaymentsRemaining(JAXBElement<Long> value) {
        this.paymentsRemaining = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the additionalCapital property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAdditionalCapital() {
        return additionalCapital;
    }

    /**
     * Sets the value of the additionalCapital property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAdditionalCapital(JAXBElement<YMoney> value) {
        this.additionalCapital = value;
    }

    /**
     * Gets the value of the availableLoan property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAvailableLoan() {
        return availableLoan;
    }

    /**
     * Sets the value of the availableLoan property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAvailableLoan(JAXBElement<YMoney> value) {
        this.availableLoan = value;
    }

    /**
     * Gets the value of the taxesWithheldYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxesWithheldYtd() {
        return taxesWithheldYtd;
    }

    /**
     * Sets the value of the taxesWithheldYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxesWithheldYtd(JAXBElement<YMoney> value) {
        this.taxesWithheldYtd = value;
    }

    /**
     * Gets the value of the taxesPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxesPaidYtd() {
        return taxesPaidYtd;
    }

    /**
     * Sets the value of the taxesPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxesPaidYtd(JAXBElement<YMoney> value) {
        this.taxesPaidYtd = value;
    }

    /**
     * Gets the value of the interestAccruedSinceLastPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestAccruedSinceLastPayment() {
        return interestAccruedSinceLastPayment;
    }

    /**
     * Sets the value of the interestAccruedSinceLastPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestAccruedSinceLastPayment(JAXBElement<YMoney> value) {
        this.interestAccruedSinceLastPayment = value;
    }

    /**
     * Gets the value of the srcAccountType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcAccountType() {
        return srcAccountType;
    }

    /**
     * Sets the value of the srcAccountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcAccountType(JAXBElement<String> value) {
        this.srcAccountType = value;
    }

    /**
     * Gets the value of the arrearsAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getArrearsAmount() {
        return arrearsAmount;
    }

    /**
     * Sets the value of the arrearsAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setArrearsAmount(JAXBElement<YMoney> value) {
        this.arrearsAmount = value;
    }

    /**
     * Gets the value of the unclearedBal property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnclearedBal() {
        return unclearedBal;
    }

    /**
     * Sets the value of the unclearedBal property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnclearedBal(JAXBElement<YMoney> value) {
        this.unclearedBal = value;
    }

}
