
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for LoanStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanStatement">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="billId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanStatementId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="loanId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="miscFeeDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="interestAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="principalAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="latechargesDue" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="currentBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="insurancePaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="escrow" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="propertyTax" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="propertyTaxPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="insuranceEscrow" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="propertyTaxEscrow" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidYtd" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="interestPaidLastYear" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="miscFees" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="transListToDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="transListFromDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="loanTransactions" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="bill" type="{http://types.dataservice.core.soap.yodlee.com}Bill" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanStatement", propOrder = {
    "srcElementId",
    "isSeidMod",
    "isSeidFromDataSource",
    "billId",
    "loanStatementId",
    "loanId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "miscFeeDescription",
    "interestAmount",
    "principalAmount",
    "latechargesDue",
    "currentBalance",
    "insurancePaidYtd",
    "escrow",
    "propertyTax",
    "propertyTaxPaidYtd",
    "insuranceEscrow",
    "propertyTaxEscrow",
    "interestPaidYtd",
    "interestPaidLastYear",
    "miscFees",
    "transListToDate",
    "transListFromDate",
    "loanTransactions",
    "bill"
})
public class LoanStatement
    extends BaseTagData
{

    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "billId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> billId;
    @XmlElementRef(name = "loanStatementId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanStatementId;
    @XmlElementRef(name = "loanId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> loanId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "miscFeeDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> miscFeeDescription;
    @XmlElementRef(name = "interestAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestAmount;
    @XmlElementRef(name = "principalAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> principalAmount;
    @XmlElementRef(name = "latechargesDue", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> latechargesDue;
    @XmlElementRef(name = "currentBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> currentBalance;
    @XmlElementRef(name = "insurancePaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> insurancePaidYtd;
    @XmlElementRef(name = "escrow", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> escrow;
    @XmlElementRef(name = "propertyTax", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> propertyTax;
    @XmlElementRef(name = "propertyTaxPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> propertyTaxPaidYtd;
    @XmlElementRef(name = "insuranceEscrow", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> insuranceEscrow;
    @XmlElementRef(name = "propertyTaxEscrow", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> propertyTaxEscrow;
    @XmlElementRef(name = "interestPaidYtd", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidYtd;
    @XmlElementRef(name = "interestPaidLastYear", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestPaidLastYear;
    @XmlElementRef(name = "miscFees", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> miscFees;
    @XmlElementRef(name = "transListToDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListToDate;
    @XmlElementRef(name = "transListFromDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> transListFromDate;
    @XmlElementRef(name = "loanTransactions", type = JAXBElement.class, required = false)
    protected JAXBElement<List> loanTransactions;
    @XmlElementRef(name = "bill", type = JAXBElement.class, required = false)
    protected JAXBElement<Bill> bill;

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setBillId(JAXBElement<Long> value) {
        this.billId = value;
    }

    /**
     * Gets the value of the loanStatementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanStatementId() {
        return loanStatementId;
    }

    /**
     * Sets the value of the loanStatementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanStatementId(JAXBElement<Long> value) {
        this.loanStatementId = value;
    }

    /**
     * Gets the value of the loanId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLoanId() {
        return loanId;
    }

    /**
     * Sets the value of the loanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLoanId(JAXBElement<Long> value) {
        this.loanId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the miscFeeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMiscFeeDescription() {
        return miscFeeDescription;
    }

    /**
     * Sets the value of the miscFeeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMiscFeeDescription(JAXBElement<String> value) {
        this.miscFeeDescription = value;
    }

    /**
     * Gets the value of the interestAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestAmount() {
        return interestAmount;
    }

    /**
     * Sets the value of the interestAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestAmount(JAXBElement<YMoney> value) {
        this.interestAmount = value;
    }

    /**
     * Gets the value of the principalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPrincipalAmount() {
        return principalAmount;
    }

    /**
     * Sets the value of the principalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPrincipalAmount(JAXBElement<YMoney> value) {
        this.principalAmount = value;
    }

    /**
     * Gets the value of the latechargesDue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLatechargesDue() {
        return latechargesDue;
    }

    /**
     * Sets the value of the latechargesDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLatechargesDue(JAXBElement<YMoney> value) {
        this.latechargesDue = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCurrentBalance(JAXBElement<YMoney> value) {
        this.currentBalance = value;
    }

    /**
     * Gets the value of the insurancePaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInsurancePaidYtd() {
        return insurancePaidYtd;
    }

    /**
     * Sets the value of the insurancePaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInsurancePaidYtd(JAXBElement<YMoney> value) {
        this.insurancePaidYtd = value;
    }

    /**
     * Gets the value of the escrow property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEscrow() {
        return escrow;
    }

    /**
     * Sets the value of the escrow property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEscrow(JAXBElement<YMoney> value) {
        this.escrow = value;
    }

    /**
     * Gets the value of the propertyTax property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPropertyTax() {
        return propertyTax;
    }

    /**
     * Sets the value of the propertyTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPropertyTax(JAXBElement<YMoney> value) {
        this.propertyTax = value;
    }

    /**
     * Gets the value of the propertyTaxPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPropertyTaxPaidYtd() {
        return propertyTaxPaidYtd;
    }

    /**
     * Sets the value of the propertyTaxPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPropertyTaxPaidYtd(JAXBElement<YMoney> value) {
        this.propertyTaxPaidYtd = value;
    }

    /**
     * Gets the value of the insuranceEscrow property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInsuranceEscrow() {
        return insuranceEscrow;
    }

    /**
     * Sets the value of the insuranceEscrow property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInsuranceEscrow(JAXBElement<YMoney> value) {
        this.insuranceEscrow = value;
    }

    /**
     * Gets the value of the propertyTaxEscrow property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPropertyTaxEscrow() {
        return propertyTaxEscrow;
    }

    /**
     * Sets the value of the propertyTaxEscrow property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPropertyTaxEscrow(JAXBElement<YMoney> value) {
        this.propertyTaxEscrow = value;
    }

    /**
     * Gets the value of the interestPaidYtd property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidYtd() {
        return interestPaidYtd;
    }

    /**
     * Sets the value of the interestPaidYtd property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidYtd(JAXBElement<YMoney> value) {
        this.interestPaidYtd = value;
    }

    /**
     * Gets the value of the interestPaidLastYear property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestPaidLastYear() {
        return interestPaidLastYear;
    }

    /**
     * Sets the value of the interestPaidLastYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestPaidLastYear(JAXBElement<YMoney> value) {
        this.interestPaidLastYear = value;
    }

    /**
     * Gets the value of the miscFees property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getMiscFees() {
        return miscFees;
    }

    /**
     * Sets the value of the miscFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setMiscFees(JAXBElement<YMoney> value) {
        this.miscFees = value;
    }

    /**
     * Gets the value of the transListToDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListToDate() {
        return transListToDate;
    }

    /**
     * Sets the value of the transListToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListToDate(JAXBElement<YDate> value) {
        this.transListToDate = value;
    }

    /**
     * Gets the value of the transListFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getTransListFromDate() {
        return transListFromDate;
    }

    /**
     * Sets the value of the transListFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setTransListFromDate(JAXBElement<YDate> value) {
        this.transListFromDate = value;
    }

    /**
     * Gets the value of the loanTransactions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getLoanTransactions() {
        return loanTransactions;
    }

    /**
     * Sets the value of the loanTransactions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setLoanTransactions(JAXBElement<List> value) {
        this.loanTransactions = value;
    }

    /**
     * Gets the value of the bill property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Bill }{@code >}
     *     
     */
    public JAXBElement<Bill> getBill() {
        return bill;
    }

    /**
     * Sets the value of the bill property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Bill }{@code >}
     *     
     */
    public void setBill(JAXBElement<Bill> value) {
        this.bill = value;
    }

}
