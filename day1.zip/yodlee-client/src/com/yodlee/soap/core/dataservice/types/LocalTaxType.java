
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for LocalTaxType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocalTaxType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="amountWithHeld" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="localityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocalTaxType", propOrder = {
    "amountWithHeld",
    "localityName",
    "localDist"
})
public class LocalTaxType {

    @XmlElementRef(name = "amountWithHeld", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountWithHeld;
    @XmlElementRef(name = "localityName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localityName;
    @XmlElementRef(name = "localDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> localDist;

    /**
     * Gets the value of the amountWithHeld property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountWithHeld() {
        return amountWithHeld;
    }

    /**
     * Sets the value of the amountWithHeld property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountWithHeld(JAXBElement<YMoney> value) {
        this.amountWithHeld = value;
    }

    /**
     * Gets the value of the localityName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalityName() {
        return localityName;
    }

    /**
     * Sets the value of the localityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalityName(JAXBElement<String> value) {
        this.localityName = value;
    }

    /**
     * Gets the value of the localDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLocalDist() {
        return localDist;
    }

    /**
     * Sets the value of the localDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLocalDist(JAXBElement<YMoney> value) {
        this.localDist = value;
    }

}
