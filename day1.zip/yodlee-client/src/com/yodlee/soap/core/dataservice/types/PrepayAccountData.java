
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;
import com.yodlee.soap.core.dataservice.enums.SiteAccountStatus;


/**
 * <p>Java class for PrepayAccountData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PrepayAccountData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}ItemAccountData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="extAutopaySetupId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="individualInformationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="prepayAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="customName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayEnrolled" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastPaymentDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedDerivedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="remainingBalance" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="lastPayment" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="accountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedUserAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="derivedAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isExtAutopayScraped" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="autopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="localizedAutopayEnrollmentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="asofDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="userAutopayEnrollmentStatusLastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="extAutopaySetup" type="{http://types.dataservice.core.soap.yodlee.com}ExtAutopaySetupData" minOccurs="0"/>
 *         &lt;element name="paymentDetails" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="individualInformation" type="{http://types.dataservice.core.soap.yodlee.com}IndividualInformation" minOccurs="0"/>
 *         &lt;element name="created" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="accountCloseDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="secondaryAccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountNicknameAtSrcSite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="siteAccountStatus" type="{http://enums.dataservice.core.soap.yodlee.com}SiteAccountStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PrepayAccountData", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "extAutopaySetupId",
    "individualInformationId",
    "prepayAccountId",
    "customName",
    "customDescription",
    "isDeleted",
    "hasDetails",
    "isExtAutopayEnrolled",
    "accountNumber",
    "link",
    "lastPaymentDate",
    "accountHolder",
    "derivedAutopayEnrollmentStatusId",
    "derivedAutopayEnrollmentStatus",
    "localizedDerivedAutopayEnrollmentStatus",
    "remainingBalance",
    "lastPayment",
    "accountName",
    "userAutopayEnrollmentStatusId",
    "userAutopayEnrollmentStatus",
    "localizedUserAutopayEnrollmentStatus",
    "derivedAutopayEnrollmentStatusLastUpdated",
    "isExtAutopayScraped",
    "autopayEnrollmentStatusId",
    "autopayEnrollmentStatus",
    "localizedAutopayEnrollmentStatus",
    "asofDate",
    "userAutopayEnrollmentStatusLastUpdated",
    "extAutopaySetup",
    "paymentDetails",
    "individualInformation",
    "created",
    "accountOpenDate",
    "accountCloseDate",
    "secondaryAccountHolderName",
    "accountNicknameAtSrcSite",
    "siteAccountStatus"
})
public class PrepayAccountData
    extends ItemAccountData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "extAutopaySetupId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> extAutopaySetupId;
    @XmlElementRef(name = "individualInformationId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> individualInformationId;
    @XmlElementRef(name = "prepayAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> prepayAccountId;
    @XmlElementRef(name = "customName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customName;
    @XmlElementRef(name = "customDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customDescription;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "isExtAutopayEnrolled", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayEnrolled;
    @XmlElementRef(name = "accountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNumber;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "lastPaymentDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> lastPaymentDate;
    @XmlElementRef(name = "accountHolder", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountHolder;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusId;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> derivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedDerivedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedDerivedAutopayEnrollmentStatus;
    @XmlElementRef(name = "remainingBalance", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> remainingBalance;
    @XmlElementRef(name = "lastPayment", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> lastPayment;
    @XmlElementRef(name = "accountName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountName;
    @XmlElementRef(name = "userAutopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusId;
    @XmlElementRef(name = "userAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userAutopayEnrollmentStatus;
    @XmlElementRef(name = "localizedUserAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedUserAutopayEnrollmentStatus;
    @XmlElementRef(name = "derivedAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> derivedAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "isExtAutopayScraped", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isExtAutopayScraped;
    @XmlElementRef(name = "autopayEnrollmentStatusId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> autopayEnrollmentStatusId;
    @XmlElementRef(name = "autopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> autopayEnrollmentStatus;
    @XmlElementRef(name = "localizedAutopayEnrollmentStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<String> localizedAutopayEnrollmentStatus;
    @XmlElementRef(name = "asofDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> asofDate;
    @XmlElementRef(name = "userAutopayEnrollmentStatusLastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> userAutopayEnrollmentStatusLastUpdated;
    @XmlElementRef(name = "extAutopaySetup", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtAutopaySetupData> extAutopaySetup;
    @XmlElementRef(name = "paymentDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<List> paymentDetails;
    @XmlElementRef(name = "individualInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<IndividualInformation> individualInformation;
    @XmlElementRef(name = "created", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> created;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountOpenDate;
    @XmlElementRef(name = "accountCloseDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> accountCloseDate;
    @XmlElementRef(name = "secondaryAccountHolderName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountHolderName;
    @XmlElementRef(name = "accountNicknameAtSrcSite", type = JAXBElement.class, required = false)
    protected JAXBElement<String> accountNicknameAtSrcSite;
    @XmlElementRef(name = "siteAccountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<SiteAccountStatus> siteAccountStatus;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the extAutopaySetupId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getExtAutopaySetupId() {
        return extAutopaySetupId;
    }

    /**
     * Sets the value of the extAutopaySetupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setExtAutopaySetupId(JAXBElement<Long> value) {
        this.extAutopaySetupId = value;
    }

    /**
     * Gets the value of the individualInformationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIndividualInformationId() {
        return individualInformationId;
    }

    /**
     * Sets the value of the individualInformationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIndividualInformationId(JAXBElement<Long> value) {
        this.individualInformationId = value;
    }

    /**
     * Gets the value of the prepayAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPrepayAccountId() {
        return prepayAccountId;
    }

    /**
     * Sets the value of the prepayAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPrepayAccountId(JAXBElement<Long> value) {
        this.prepayAccountId = value;
    }

    /**
     * Gets the value of the customName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomName() {
        return customName;
    }

    /**
     * Sets the value of the customName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomName(JAXBElement<String> value) {
        this.customName = value;
    }

    /**
     * Gets the value of the customDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomDescription() {
        return customDescription;
    }

    /**
     * Sets the value of the customDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomDescription(JAXBElement<String> value) {
        this.customDescription = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the isExtAutopayEnrolled property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayEnrolled() {
        return isExtAutopayEnrolled;
    }

    /**
     * Sets the value of the isExtAutopayEnrolled property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayEnrolled(JAXBElement<Long> value) {
        this.isExtAutopayEnrolled = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNumber(JAXBElement<String> value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setLastPaymentDate(JAXBElement<YDate> value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the accountHolder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountHolder() {
        return accountHolder;
    }

    /**
     * Sets the value of the accountHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountHolder(JAXBElement<String> value) {
        this.accountHolder = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusId() {
        return derivedAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDerivedAutopayEnrollmentStatus() {
        return derivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.derivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedDerivedAutopayEnrollmentStatus() {
        return localizedDerivedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedDerivedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedDerivedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedDerivedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the remainingBalance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getRemainingBalance() {
        return remainingBalance;
    }

    /**
     * Sets the value of the remainingBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setRemainingBalance(JAXBElement<YMoney> value) {
        this.remainingBalance = value;
    }

    /**
     * Gets the value of the lastPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getLastPayment() {
        return lastPayment;
    }

    /**
     * Sets the value of the lastPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setLastPayment(JAXBElement<YMoney> value) {
        this.lastPayment = value;
    }

    /**
     * Gets the value of the accountName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountName() {
        return accountName;
    }

    /**
     * Sets the value of the accountName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountName(JAXBElement<String> value) {
        this.accountName = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusId() {
        return userAutopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserAutopayEnrollmentStatus() {
        return userAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.userAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedUserAutopayEnrollmentStatus() {
        return localizedUserAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedUserAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedUserAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedUserAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getDerivedAutopayEnrollmentStatusLastUpdated() {
        return derivedAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the derivedAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setDerivedAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.derivedAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the isExtAutopayScraped property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsExtAutopayScraped() {
        return isExtAutopayScraped;
    }

    /**
     * Sets the value of the isExtAutopayScraped property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsExtAutopayScraped(JAXBElement<Long> value) {
        this.isExtAutopayScraped = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getAutopayEnrollmentStatusId() {
        return autopayEnrollmentStatusId;
    }

    /**
     * Sets the value of the autopayEnrollmentStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatusId(JAXBElement<Long> value) {
        this.autopayEnrollmentStatusId = value;
    }

    /**
     * Gets the value of the autopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAutopayEnrollmentStatus() {
        return autopayEnrollmentStatus;
    }

    /**
     * Sets the value of the autopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.autopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLocalizedAutopayEnrollmentStatus() {
        return localizedAutopayEnrollmentStatus;
    }

    /**
     * Sets the value of the localizedAutopayEnrollmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLocalizedAutopayEnrollmentStatus(JAXBElement<String> value) {
        this.localizedAutopayEnrollmentStatus = value;
    }

    /**
     * Gets the value of the asofDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAsofDate() {
        return asofDate;
    }

    /**
     * Sets the value of the asofDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAsofDate(JAXBElement<YDate> value) {
        this.asofDate = value;
    }

    /**
     * Gets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getUserAutopayEnrollmentStatusLastUpdated() {
        return userAutopayEnrollmentStatusLastUpdated;
    }

    /**
     * Sets the value of the userAutopayEnrollmentStatusLastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setUserAutopayEnrollmentStatusLastUpdated(JAXBElement<Long> value) {
        this.userAutopayEnrollmentStatusLastUpdated = value;
    }

    /**
     * Gets the value of the extAutopaySetup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public JAXBElement<ExtAutopaySetupData> getExtAutopaySetup() {
        return extAutopaySetup;
    }

    /**
     * Sets the value of the extAutopaySetup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtAutopaySetupData }{@code >}
     *     
     */
    public void setExtAutopaySetup(JAXBElement<ExtAutopaySetupData> value) {
        this.extAutopaySetup = value;
    }

    /**
     * Gets the value of the paymentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getPaymentDetails() {
        return paymentDetails;
    }

    /**
     * Sets the value of the paymentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setPaymentDetails(JAXBElement<List> value) {
        this.paymentDetails = value;
    }

    /**
     * Gets the value of the individualInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public JAXBElement<IndividualInformation> getIndividualInformation() {
        return individualInformation;
    }

    /**
     * Sets the value of the individualInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link IndividualInformation }{@code >}
     *     
     */
    public void setIndividualInformation(JAXBElement<IndividualInformation> value) {
        this.individualInformation = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setCreated(JAXBElement<Long> value) {
        this.created = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<YDate> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the accountCloseDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * Sets the value of the accountCloseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setAccountCloseDate(JAXBElement<YDate> value) {
        this.accountCloseDate = value;
    }

    /**
     * Gets the value of the secondaryAccountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountHolderName() {
        return secondaryAccountHolderName;
    }

    /**
     * Sets the value of the secondaryAccountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountHolderName(JAXBElement<String> value) {
        this.secondaryAccountHolderName = value;
    }

    /**
     * Gets the value of the accountNicknameAtSrcSite property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAccountNicknameAtSrcSite() {
        return accountNicknameAtSrcSite;
    }

    /**
     * Sets the value of the accountNicknameAtSrcSite property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAccountNicknameAtSrcSite(JAXBElement<String> value) {
        this.accountNicknameAtSrcSite = value;
    }

    /**
     * Gets the value of the siteAccountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public JAXBElement<SiteAccountStatus> getSiteAccountStatus() {
        return siteAccountStatus;
    }

    /**
     * Sets the value of the siteAccountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SiteAccountStatus }{@code >}
     *     
     */
    public void setSiteAccountStatus(JAXBElement<SiteAccountStatus> value) {
        this.siteAccountStatus = value;
    }

}
