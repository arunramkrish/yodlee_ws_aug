
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for ProceedsInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProceedsInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateAcquired" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="isVariousAcquireDate" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="dateOfSale" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="securityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numberOfShares" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="costBasis" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="salesPrice" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="holdingPeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isWashSale" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="fedTaxWithheld" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProceedsInformationType", propOrder = {
    "dateAcquired",
    "isVariousAcquireDate",
    "dateOfSale",
    "securityName",
    "numberOfShares",
    "costBasis",
    "salesPrice",
    "holdingPeriod",
    "isWashSale",
    "fedTaxWithheld"
})
public class ProceedsInformationType {

    @XmlElementRef(name = "dateAcquired", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dateAcquired;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isVariousAcquireDate;
    @XmlElementRef(name = "dateOfSale", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dateOfSale;
    @XmlElementRef(name = "securityName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> securityName;
    @XmlElementRef(name = "numberOfShares", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> numberOfShares;
    @XmlElementRef(name = "costBasis", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> costBasis;
    @XmlElementRef(name = "salesPrice", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> salesPrice;
    @XmlElementRef(name = "holdingPeriod", type = JAXBElement.class, required = false)
    protected JAXBElement<String> holdingPeriod;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isWashSale;
    @XmlElementRef(name = "fedTaxWithheld", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> fedTaxWithheld;

    /**
     * Gets the value of the dateAcquired property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDateAcquired() {
        return dateAcquired;
    }

    /**
     * Sets the value of the dateAcquired property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDateAcquired(JAXBElement<YDate> value) {
        this.dateAcquired = value;
    }

    /**
     * Gets the value of the isVariousAcquireDate property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsVariousAcquireDate() {
        return isVariousAcquireDate;
    }

    /**
     * Sets the value of the isVariousAcquireDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsVariousAcquireDate(Boolean value) {
        this.isVariousAcquireDate = value;
    }

    /**
     * Gets the value of the dateOfSale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDateOfSale() {
        return dateOfSale;
    }

    /**
     * Sets the value of the dateOfSale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDateOfSale(JAXBElement<YDate> value) {
        this.dateOfSale = value;
    }

    /**
     * Gets the value of the securityName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecurityName() {
        return securityName;
    }

    /**
     * Sets the value of the securityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecurityName(JAXBElement<String> value) {
        this.securityName = value;
    }

    /**
     * Gets the value of the numberOfShares property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getNumberOfShares() {
        return numberOfShares;
    }

    /**
     * Sets the value of the numberOfShares property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setNumberOfShares(JAXBElement<Double> value) {
        this.numberOfShares = value;
    }

    /**
     * Gets the value of the costBasis property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCostBasis() {
        return costBasis;
    }

    /**
     * Sets the value of the costBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCostBasis(JAXBElement<YMoney> value) {
        this.costBasis = value;
    }

    /**
     * Gets the value of the salesPrice property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSalesPrice() {
        return salesPrice;
    }

    /**
     * Sets the value of the salesPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSalesPrice(JAXBElement<YMoney> value) {
        this.salesPrice = value;
    }

    /**
     * Gets the value of the holdingPeriod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getHoldingPeriod() {
        return holdingPeriod;
    }

    /**
     * Sets the value of the holdingPeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setHoldingPeriod(JAXBElement<String> value) {
        this.holdingPeriod = value;
    }

    /**
     * Gets the value of the isWashSale property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsWashSale() {
        return isWashSale;
    }

    /**
     * Sets the value of the isWashSale property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsWashSale(Boolean value) {
        this.isWashSale = value;
    }

    /**
     * Gets the value of the fedTaxWithheld property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFedTaxWithheld() {
        return fedTaxWithheld;
    }

    /**
     * Sets the value of the fedTaxWithheld property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFedTaxWithheld(JAXBElement<YMoney> value) {
        this.fedTaxWithheld = value;
    }

}
