
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YDate;


/**
 * <p>Java class for RewardActivity complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RewardActivity">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}BaseTagData">
 *       &lt;sequence>
 *         &lt;element name="isSeidFromDataSource" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSeidMod" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="srcElementId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="baseUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bonusUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="rewardActivityId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="rewardPgmId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isDeleted" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="lastUpdated" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="hasDetails" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="baseAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="baseDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="bonusAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="link" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bonusAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bonusDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityDate" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="baseAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RewardActivity", propOrder = {
    "isSeidFromDataSource",
    "isSeidMod",
    "srcElementId",
    "baseUnit",
    "totalUnit",
    "bonusUnit",
    "rewardActivityId",
    "rewardPgmId",
    "isDeleted",
    "lastUpdated",
    "hasDetails",
    "baseAmt",
    "baseDesc",
    "totalAmt",
    "totalDesc",
    "totalAmount",
    "bonusAmount",
    "description",
    "link",
    "bonusAmt",
    "bonusDesc",
    "activityDate",
    "baseAmount"
})
public class RewardActivity
    extends BaseTagData
{

    @XmlElementRef(name = "isSeidFromDataSource", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidFromDataSource;
    @XmlElementRef(name = "isSeidMod", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isSeidMod;
    @XmlElementRef(name = "srcElementId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> srcElementId;
    @XmlElementRef(name = "baseUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> baseUnit;
    @XmlElementRef(name = "totalUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> totalUnit;
    @XmlElementRef(name = "bonusUnit", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bonusUnit;
    @XmlElementRef(name = "rewardActivityId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> rewardActivityId;
    @XmlElementRef(name = "rewardPgmId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> rewardPgmId;
    @XmlElementRef(name = "isDeleted", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> isDeleted;
    @XmlElementRef(name = "lastUpdated", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastUpdated;
    @XmlElementRef(name = "hasDetails", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> hasDetails;
    @XmlElementRef(name = "baseAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<String> baseAmt;
    @XmlElementRef(name = "baseDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> baseDesc;
    @XmlElementRef(name = "totalAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<String> totalAmt;
    @XmlElementRef(name = "totalDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> totalDesc;
    @XmlElementRef(name = "totalAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> totalAmount;
    @XmlElementRef(name = "bonusAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> bonusAmount;
    @XmlElementRef(name = "description", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "link", type = JAXBElement.class, required = false)
    protected JAXBElement<String> link;
    @XmlElementRef(name = "bonusAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bonusAmt;
    @XmlElementRef(name = "bonusDesc", type = JAXBElement.class, required = false)
    protected JAXBElement<String> bonusDesc;
    @XmlElementRef(name = "activityDate", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> activityDate;
    @XmlElementRef(name = "baseAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> baseAmount;

    /**
     * Gets the value of the isSeidFromDataSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidFromDataSource() {
        return isSeidFromDataSource;
    }

    /**
     * Sets the value of the isSeidFromDataSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidFromDataSource(JAXBElement<Long> value) {
        this.isSeidFromDataSource = value;
    }

    /**
     * Gets the value of the isSeidMod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsSeidMod() {
        return isSeidMod;
    }

    /**
     * Sets the value of the isSeidMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsSeidMod(JAXBElement<Long> value) {
        this.isSeidMod = value;
    }

    /**
     * Gets the value of the srcElementId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSrcElementId() {
        return srcElementId;
    }

    /**
     * Sets the value of the srcElementId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSrcElementId(JAXBElement<String> value) {
        this.srcElementId = value;
    }

    /**
     * Gets the value of the baseUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBaseUnit() {
        return baseUnit;
    }

    /**
     * Sets the value of the baseUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBaseUnit(JAXBElement<String> value) {
        this.baseUnit = value;
    }

    /**
     * Gets the value of the totalUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTotalUnit() {
        return totalUnit;
    }

    /**
     * Sets the value of the totalUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTotalUnit(JAXBElement<String> value) {
        this.totalUnit = value;
    }

    /**
     * Gets the value of the bonusUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBonusUnit() {
        return bonusUnit;
    }

    /**
     * Sets the value of the bonusUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBonusUnit(JAXBElement<String> value) {
        this.bonusUnit = value;
    }

    /**
     * Gets the value of the rewardActivityId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRewardActivityId() {
        return rewardActivityId;
    }

    /**
     * Sets the value of the rewardActivityId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRewardActivityId(JAXBElement<Long> value) {
        this.rewardActivityId = value;
    }

    /**
     * Gets the value of the rewardPgmId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getRewardPgmId() {
        return rewardPgmId;
    }

    /**
     * Sets the value of the rewardPgmId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setRewardPgmId(JAXBElement<Long> value) {
        this.rewardPgmId = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setIsDeleted(JAXBElement<Long> value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the lastUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Sets the value of the lastUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastUpdated(JAXBElement<Long> value) {
        this.lastUpdated = value;
    }

    /**
     * Gets the value of the hasDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getHasDetails() {
        return hasDetails;
    }

    /**
     * Sets the value of the hasDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setHasDetails(JAXBElement<Long> value) {
        this.hasDetails = value;
    }

    /**
     * Gets the value of the baseAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBaseAmt() {
        return baseAmt;
    }

    /**
     * Sets the value of the baseAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBaseAmt(JAXBElement<String> value) {
        this.baseAmt = value;
    }

    /**
     * Gets the value of the baseDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBaseDesc() {
        return baseDesc;
    }

    /**
     * Sets the value of the baseDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBaseDesc(JAXBElement<String> value) {
        this.baseDesc = value;
    }

    /**
     * Gets the value of the totalAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTotalAmt() {
        return totalAmt;
    }

    /**
     * Sets the value of the totalAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTotalAmt(JAXBElement<String> value) {
        this.totalAmt = value;
    }

    /**
     * Gets the value of the totalDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTotalDesc() {
        return totalDesc;
    }

    /**
     * Sets the value of the totalDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTotalDesc(JAXBElement<String> value) {
        this.totalDesc = value;
    }

    /**
     * Gets the value of the totalAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getTotalAmount() {
        return totalAmount;
    }

    /**
     * Sets the value of the totalAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setTotalAmount(JAXBElement<Double> value) {
        this.totalAmount = value;
    }

    /**
     * Gets the value of the bonusAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getBonusAmount() {
        return bonusAmount;
    }

    /**
     * Sets the value of the bonusAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setBonusAmount(JAXBElement<Double> value) {
        this.bonusAmount = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the link property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLink() {
        return link;
    }

    /**
     * Sets the value of the link property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLink(JAXBElement<String> value) {
        this.link = value;
    }

    /**
     * Gets the value of the bonusAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBonusAmt() {
        return bonusAmt;
    }

    /**
     * Sets the value of the bonusAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBonusAmt(JAXBElement<String> value) {
        this.bonusAmt = value;
    }

    /**
     * Gets the value of the bonusDesc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBonusDesc() {
        return bonusDesc;
    }

    /**
     * Sets the value of the bonusDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBonusDesc(JAXBElement<String> value) {
        this.bonusDesc = value;
    }

    /**
     * Gets the value of the activityDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getActivityDate() {
        return activityDate;
    }

    /**
     * Sets the value of the activityDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setActivityDate(JAXBElement<YDate> value) {
        this.activityDate = value;
    }

    /**
     * Gets the value of the baseAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getBaseAmount() {
        return baseAmount;
    }

    /**
     * Sets the value of the baseAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setBaseAmount(JAXBElement<Double> value) {
        this.baseAmount = value;
    }

}
