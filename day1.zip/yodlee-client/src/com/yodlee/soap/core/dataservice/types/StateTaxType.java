
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for StateTaxType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StateTaxType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="amountWithheld" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="payerState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payerStateID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stateDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StateTaxType", propOrder = {
    "amountWithheld",
    "payerState",
    "payerStateID",
    "stateDist"
})
public class StateTaxType {

    @XmlElementRef(name = "amountWithheld", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> amountWithheld;
    @XmlElementRef(name = "payerState", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payerState;
    @XmlElementRef(name = "payerStateID", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payerStateID;
    @XmlElementRef(name = "stateDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> stateDist;

    /**
     * Gets the value of the amountWithheld property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAmountWithheld() {
        return amountWithheld;
    }

    /**
     * Sets the value of the amountWithheld property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAmountWithheld(JAXBElement<YMoney> value) {
        this.amountWithheld = value;
    }

    /**
     * Gets the value of the payerState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayerState() {
        return payerState;
    }

    /**
     * Sets the value of the payerState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayerState(JAXBElement<String> value) {
        this.payerState = value;
    }

    /**
     * Gets the value of the payerStateID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayerStateID() {
        return payerStateID;
    }

    /**
     * Sets the value of the payerStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayerStateID(JAXBElement<String> value) {
        this.payerStateID = value;
    }

    /**
     * Gets the value of the stateDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStateDist() {
        return stateDist;
    }

    /**
     * Sets the value of the stateDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStateDist(JAXBElement<YMoney> value) {
        this.stateDist = value;
    }

}
