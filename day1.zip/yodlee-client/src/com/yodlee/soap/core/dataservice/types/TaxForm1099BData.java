
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.dataservice.types.ArrayOfExtendedInformationType;
import com.yodlee.soap.core.dataservice.YDate;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for TaxForm1099BData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxForm1099BData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}TaxForm1099Data">
 *       &lt;sequence>
 *         &lt;element name="dateOfSale" type="{http://dataservice.core.soap.yodlee.com}YDate" minOccurs="0"/>
 *         &lt;element name="cusipNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stockBondAmount" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isGrossProceeds" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="isGrossCommOption" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bartering" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="briefDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="profitLossRealized" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="postMay5Profit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="unrelProfitPrev" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="unrelProfitCurr" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="aggregateProfit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="postMay5AggProfit" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="extendedInformation" type="{http://types.dataservice.core.collections.soap.yodlee.com}ArrayOfExtendedInformationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxForm1099BData", propOrder = {
    "dateOfSale",
    "cusipNumber",
    "stockBondAmount",
    "isGrossProceeds",
    "isGrossCommOption",
    "bartering",
    "briefDescription",
    "profitLossRealized",
    "postMay5Profit",
    "unrelProfitPrev",
    "unrelProfitCurr",
    "aggregateProfit",
    "postMay5AggProfit",
    "extendedInformation"
})
public class TaxForm1099BData
    extends TaxForm1099Data
{

    @XmlElementRef(name = "dateOfSale", type = JAXBElement.class, required = false)
    protected JAXBElement<YDate> dateOfSale;
    @XmlElementRef(name = "cusipNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> cusipNumber;
    @XmlElementRef(name = "stockBondAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> stockBondAmount;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isGrossProceeds;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isGrossCommOption;
    @XmlElementRef(name = "bartering", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> bartering;
    @XmlElementRef(name = "briefDescription", type = JAXBElement.class, required = false)
    protected JAXBElement<String> briefDescription;
    @XmlElementRef(name = "profitLossRealized", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> profitLossRealized;
    @XmlElementRef(name = "postMay5Profit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> postMay5Profit;
    @XmlElementRef(name = "unrelProfitPrev", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unrelProfitPrev;
    @XmlElementRef(name = "unrelProfitCurr", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unrelProfitCurr;
    @XmlElementRef(name = "aggregateProfit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> aggregateProfit;
    @XmlElementRef(name = "postMay5AggProfit", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> postMay5AggProfit;
    @XmlElementRef(name = "extendedInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfExtendedInformationType> extendedInformation;

    /**
     * Gets the value of the dateOfSale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public JAXBElement<YDate> getDateOfSale() {
        return dateOfSale;
    }

    /**
     * Sets the value of the dateOfSale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YDate }{@code >}
     *     
     */
    public void setDateOfSale(JAXBElement<YDate> value) {
        this.dateOfSale = value;
    }

    /**
     * Gets the value of the cusipNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCusipNumber() {
        return cusipNumber;
    }

    /**
     * Sets the value of the cusipNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCusipNumber(JAXBElement<String> value) {
        this.cusipNumber = value;
    }

    /**
     * Gets the value of the stockBondAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getStockBondAmount() {
        return stockBondAmount;
    }

    /**
     * Sets the value of the stockBondAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setStockBondAmount(JAXBElement<YMoney> value) {
        this.stockBondAmount = value;
    }

    /**
     * Gets the value of the isGrossProceeds property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsGrossProceeds() {
        return isGrossProceeds;
    }

    /**
     * Sets the value of the isGrossProceeds property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsGrossProceeds(Boolean value) {
        this.isGrossProceeds = value;
    }

    /**
     * Gets the value of the isGrossCommOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsGrossCommOption() {
        return isGrossCommOption;
    }

    /**
     * Sets the value of the isGrossCommOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsGrossCommOption(Boolean value) {
        this.isGrossCommOption = value;
    }

    /**
     * Gets the value of the bartering property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getBartering() {
        return bartering;
    }

    /**
     * Sets the value of the bartering property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setBartering(JAXBElement<YMoney> value) {
        this.bartering = value;
    }

    /**
     * Gets the value of the briefDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBriefDescription() {
        return briefDescription;
    }

    /**
     * Sets the value of the briefDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBriefDescription(JAXBElement<String> value) {
        this.briefDescription = value;
    }

    /**
     * Gets the value of the profitLossRealized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getProfitLossRealized() {
        return profitLossRealized;
    }

    /**
     * Sets the value of the profitLossRealized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setProfitLossRealized(JAXBElement<YMoney> value) {
        this.profitLossRealized = value;
    }

    /**
     * Gets the value of the postMay5Profit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPostMay5Profit() {
        return postMay5Profit;
    }

    /**
     * Sets the value of the postMay5Profit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPostMay5Profit(JAXBElement<YMoney> value) {
        this.postMay5Profit = value;
    }

    /**
     * Gets the value of the unrelProfitPrev property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnrelProfitPrev() {
        return unrelProfitPrev;
    }

    /**
     * Sets the value of the unrelProfitPrev property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnrelProfitPrev(JAXBElement<YMoney> value) {
        this.unrelProfitPrev = value;
    }

    /**
     * Gets the value of the unrelProfitCurr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnrelProfitCurr() {
        return unrelProfitCurr;
    }

    /**
     * Sets the value of the unrelProfitCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnrelProfitCurr(JAXBElement<YMoney> value) {
        this.unrelProfitCurr = value;
    }

    /**
     * Gets the value of the aggregateProfit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAggregateProfit() {
        return aggregateProfit;
    }

    /**
     * Sets the value of the aggregateProfit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAggregateProfit(JAXBElement<YMoney> value) {
        this.aggregateProfit = value;
    }

    /**
     * Gets the value of the postMay5AggProfit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPostMay5AggProfit() {
        return postMay5AggProfit;
    }

    /**
     * Sets the value of the postMay5AggProfit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPostMay5AggProfit(JAXBElement<YMoney> value) {
        this.postMay5AggProfit = value;
    }

    /**
     * Gets the value of the extendedInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfExtendedInformationType }{@code >}
     *     
     */
    public JAXBElement<ArrayOfExtendedInformationType> getExtendedInformation() {
        return extendedInformation;
    }

    /**
     * Sets the value of the extendedInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfExtendedInformationType }{@code >}
     *     
     */
    public void setExtendedInformation(JAXBElement<ArrayOfExtendedInformationType> value) {
        this.extendedInformation = value;
    }

}
