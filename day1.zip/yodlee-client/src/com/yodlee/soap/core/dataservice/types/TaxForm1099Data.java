
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for TaxForm1099Data complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxForm1099Data">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}TaxFormData">
 *       &lt;sequence>
 *         &lt;element name="sourceReferenceIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isVoid" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="fedTaxWithHeld" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="payerInformation" type="{http://types.dataservice.core.soap.yodlee.com}PersonData" minOccurs="0"/>
 *         &lt;element name="recipientInformation" type="{http://types.dataservice.core.soap.yodlee.com}PersonData" minOccurs="0"/>
 *         &lt;element name="recipientId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recipientAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payerFedIdNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxForm1099Data", propOrder = {
    "sourceReferenceIdentifier",
    "isVoid",
    "fedTaxWithHeld",
    "payerInformation",
    "recipientInformation",
    "recipientId",
    "recipientAccountNumber",
    "payerFedIdNumber"
})
@XmlSeeAlso({
    TaxForm1099IntData.class,
    TaxForm1099DivData.class,
    TaxForm1099BData.class,
    TaxForm1099RData.class
})
public abstract class TaxForm1099Data
    extends TaxFormData
{

    @XmlElementRef(name = "sourceReferenceIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sourceReferenceIdentifier;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isVoid;
    @XmlElementRef(name = "fedTaxWithHeld", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> fedTaxWithHeld;
    @XmlElementRef(name = "payerInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonData> payerInformation;
    @XmlElementRef(name = "recipientInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<PersonData> recipientInformation;
    @XmlElementRef(name = "recipientId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recipientId;
    @XmlElementRef(name = "recipientAccountNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recipientAccountNumber;
    @XmlElementRef(name = "payerFedIdNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payerFedIdNumber;

    /**
     * Gets the value of the sourceReferenceIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSourceReferenceIdentifier() {
        return sourceReferenceIdentifier;
    }

    /**
     * Sets the value of the sourceReferenceIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSourceReferenceIdentifier(JAXBElement<String> value) {
        this.sourceReferenceIdentifier = value;
    }

    /**
     * Gets the value of the isVoid property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsVoid() {
        return isVoid;
    }

    /**
     * Sets the value of the isVoid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsVoid(Boolean value) {
        this.isVoid = value;
    }

    /**
     * Gets the value of the fedTaxWithHeld property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getFedTaxWithHeld() {
        return fedTaxWithHeld;
    }

    /**
     * Sets the value of the fedTaxWithHeld property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setFedTaxWithHeld(JAXBElement<YMoney> value) {
        this.fedTaxWithHeld = value;
    }

    /**
     * Gets the value of the payerInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public JAXBElement<PersonData> getPayerInformation() {
        return payerInformation;
    }

    /**
     * Sets the value of the payerInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public void setPayerInformation(JAXBElement<PersonData> value) {
        this.payerInformation = value;
    }

    /**
     * Gets the value of the recipientInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public JAXBElement<PersonData> getRecipientInformation() {
        return recipientInformation;
    }

    /**
     * Sets the value of the recipientInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PersonData }{@code >}
     *     
     */
    public void setRecipientInformation(JAXBElement<PersonData> value) {
        this.recipientInformation = value;
    }

    /**
     * Gets the value of the recipientId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRecipientId() {
        return recipientId;
    }

    /**
     * Sets the value of the recipientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRecipientId(JAXBElement<String> value) {
        this.recipientId = value;
    }

    /**
     * Gets the value of the recipientAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRecipientAccountNumber() {
        return recipientAccountNumber;
    }

    /**
     * Sets the value of the recipientAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRecipientAccountNumber(JAXBElement<String> value) {
        this.recipientAccountNumber = value;
    }

    /**
     * Gets the value of the payerFedIdNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayerFedIdNumber() {
        return payerFedIdNumber;
    }

    /**
     * Sets the value of the payerFedIdNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayerFedIdNumber(JAXBElement<String> value) {
        this.payerFedIdNumber = value;
    }

}
