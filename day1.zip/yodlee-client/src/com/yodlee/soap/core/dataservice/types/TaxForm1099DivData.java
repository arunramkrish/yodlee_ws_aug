
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for TaxForm1099DivData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxForm1099DivData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}TaxForm1099Data">
 *       &lt;sequence>
 *         &lt;element name="isSecondTinNotification" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="foreignCountryPossession" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="foreignTaxPaid" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="investmentExpense" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="cashLiquidDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="nonCashLiquidDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="ordinaryDividends" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="pc28Gain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="nonTaxDistribution" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="qualifiedDividends" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="sec1202Gain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="totalCapitalGain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="unRecapSec1250Gain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxForm1099DivData", propOrder = {
    "isSecondTinNotification",
    "foreignCountryPossession",
    "foreignTaxPaid",
    "investmentExpense",
    "cashLiquidDist",
    "nonCashLiquidDist",
    "ordinaryDividends",
    "pc28Gain",
    "nonTaxDistribution",
    "qualifiedDividends",
    "sec1202Gain",
    "totalCapitalGain",
    "unRecapSec1250Gain"
})
public class TaxForm1099DivData
    extends TaxForm1099Data
{

    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isSecondTinNotification;
    @XmlElementRef(name = "foreignCountryPossession", type = JAXBElement.class, required = false)
    protected JAXBElement<String> foreignCountryPossession;
    @XmlElementRef(name = "foreignTaxPaid", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> foreignTaxPaid;
    @XmlElementRef(name = "investmentExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> investmentExpense;
    @XmlElementRef(name = "cashLiquidDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> cashLiquidDist;
    @XmlElementRef(name = "nonCashLiquidDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> nonCashLiquidDist;
    @XmlElementRef(name = "ordinaryDividends", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> ordinaryDividends;
    @XmlElementRef(name = "pc28Gain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> pc28Gain;
    @XmlElementRef(name = "nonTaxDistribution", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> nonTaxDistribution;
    @XmlElementRef(name = "qualifiedDividends", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> qualifiedDividends;
    @XmlElementRef(name = "sec1202Gain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> sec1202Gain;
    @XmlElementRef(name = "totalCapitalGain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalCapitalGain;
    @XmlElementRef(name = "unRecapSec1250Gain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> unRecapSec1250Gain;

    /**
     * Gets the value of the isSecondTinNotification property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSecondTinNotification() {
        return isSecondTinNotification;
    }

    /**
     * Sets the value of the isSecondTinNotification property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSecondTinNotification(Boolean value) {
        this.isSecondTinNotification = value;
    }

    /**
     * Gets the value of the foreignCountryPossession property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getForeignCountryPossession() {
        return foreignCountryPossession;
    }

    /**
     * Sets the value of the foreignCountryPossession property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setForeignCountryPossession(JAXBElement<String> value) {
        this.foreignCountryPossession = value;
    }

    /**
     * Gets the value of the foreignTaxPaid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getForeignTaxPaid() {
        return foreignTaxPaid;
    }

    /**
     * Sets the value of the foreignTaxPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setForeignTaxPaid(JAXBElement<YMoney> value) {
        this.foreignTaxPaid = value;
    }

    /**
     * Gets the value of the investmentExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInvestmentExpense() {
        return investmentExpense;
    }

    /**
     * Sets the value of the investmentExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInvestmentExpense(JAXBElement<YMoney> value) {
        this.investmentExpense = value;
    }

    /**
     * Gets the value of the cashLiquidDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCashLiquidDist() {
        return cashLiquidDist;
    }

    /**
     * Sets the value of the cashLiquidDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCashLiquidDist(JAXBElement<YMoney> value) {
        this.cashLiquidDist = value;
    }

    /**
     * Gets the value of the nonCashLiquidDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getNonCashLiquidDist() {
        return nonCashLiquidDist;
    }

    /**
     * Sets the value of the nonCashLiquidDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setNonCashLiquidDist(JAXBElement<YMoney> value) {
        this.nonCashLiquidDist = value;
    }

    /**
     * Gets the value of the ordinaryDividends property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getOrdinaryDividends() {
        return ordinaryDividends;
    }

    /**
     * Sets the value of the ordinaryDividends property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setOrdinaryDividends(JAXBElement<YMoney> value) {
        this.ordinaryDividends = value;
    }

    /**
     * Gets the value of the pc28Gain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getPc28Gain() {
        return pc28Gain;
    }

    /**
     * Sets the value of the pc28Gain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setPc28Gain(JAXBElement<YMoney> value) {
        this.pc28Gain = value;
    }

    /**
     * Gets the value of the nonTaxDistribution property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getNonTaxDistribution() {
        return nonTaxDistribution;
    }

    /**
     * Sets the value of the nonTaxDistribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setNonTaxDistribution(JAXBElement<YMoney> value) {
        this.nonTaxDistribution = value;
    }

    /**
     * Gets the value of the qualifiedDividends property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getQualifiedDividends() {
        return qualifiedDividends;
    }

    /**
     * Sets the value of the qualifiedDividends property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setQualifiedDividends(JAXBElement<YMoney> value) {
        this.qualifiedDividends = value;
    }

    /**
     * Gets the value of the sec1202Gain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSec1202Gain() {
        return sec1202Gain;
    }

    /**
     * Sets the value of the sec1202Gain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSec1202Gain(JAXBElement<YMoney> value) {
        this.sec1202Gain = value;
    }

    /**
     * Gets the value of the totalCapitalGain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalCapitalGain() {
        return totalCapitalGain;
    }

    /**
     * Sets the value of the totalCapitalGain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalCapitalGain(JAXBElement<YMoney> value) {
        this.totalCapitalGain = value;
    }

    /**
     * Gets the value of the unRecapSec1250Gain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getUnRecapSec1250Gain() {
        return unRecapSec1250Gain;
    }

    /**
     * Sets the value of the unRecapSec1250Gain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setUnRecapSec1250Gain(JAXBElement<YMoney> value) {
        this.unRecapSec1250Gain = value;
    }

}
