
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for TaxForm1099IntData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxForm1099IntData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}TaxForm1099Data">
 *       &lt;sequence>
 *         &lt;element name="payerRtn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="foreignCountryPossession" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isSecondTinNotification" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="interestIncome" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="earlyWdrlPenalty" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="intUsBndTrsy" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="investmentExpense" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="foreignTaxPaid" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxExemptInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="spPvtBndInterest" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxForm1099IntData", propOrder = {
    "payerRtn",
    "foreignCountryPossession",
    "isSecondTinNotification",
    "interestIncome",
    "earlyWdrlPenalty",
    "intUsBndTrsy",
    "investmentExpense",
    "foreignTaxPaid",
    "taxExemptInterest",
    "spPvtBndInterest"
})
public class TaxForm1099IntData
    extends TaxForm1099Data
{

    @XmlElementRef(name = "payerRtn", type = JAXBElement.class, required = false)
    protected JAXBElement<String> payerRtn;
    @XmlElementRef(name = "foreignCountryPossession", type = JAXBElement.class, required = false)
    protected JAXBElement<String> foreignCountryPossession;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isSecondTinNotification;
    @XmlElementRef(name = "interestIncome", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> interestIncome;
    @XmlElementRef(name = "earlyWdrlPenalty", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> earlyWdrlPenalty;
    @XmlElementRef(name = "intUsBndTrsy", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> intUsBndTrsy;
    @XmlElementRef(name = "investmentExpense", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> investmentExpense;
    @XmlElementRef(name = "foreignTaxPaid", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> foreignTaxPaid;
    @XmlElementRef(name = "taxExemptInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxExemptInterest;
    @XmlElementRef(name = "spPvtBndInterest", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> spPvtBndInterest;

    /**
     * Gets the value of the payerRtn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPayerRtn() {
        return payerRtn;
    }

    /**
     * Sets the value of the payerRtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPayerRtn(JAXBElement<String> value) {
        this.payerRtn = value;
    }

    /**
     * Gets the value of the foreignCountryPossession property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getForeignCountryPossession() {
        return foreignCountryPossession;
    }

    /**
     * Sets the value of the foreignCountryPossession property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setForeignCountryPossession(JAXBElement<String> value) {
        this.foreignCountryPossession = value;
    }

    /**
     * Gets the value of the isSecondTinNotification property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsSecondTinNotification() {
        return isSecondTinNotification;
    }

    /**
     * Sets the value of the isSecondTinNotification property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsSecondTinNotification(Boolean value) {
        this.isSecondTinNotification = value;
    }

    /**
     * Gets the value of the interestIncome property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInterestIncome() {
        return interestIncome;
    }

    /**
     * Sets the value of the interestIncome property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInterestIncome(JAXBElement<YMoney> value) {
        this.interestIncome = value;
    }

    /**
     * Gets the value of the earlyWdrlPenalty property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEarlyWdrlPenalty() {
        return earlyWdrlPenalty;
    }

    /**
     * Sets the value of the earlyWdrlPenalty property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEarlyWdrlPenalty(JAXBElement<YMoney> value) {
        this.earlyWdrlPenalty = value;
    }

    /**
     * Gets the value of the intUsBndTrsy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getIntUsBndTrsy() {
        return intUsBndTrsy;
    }

    /**
     * Sets the value of the intUsBndTrsy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setIntUsBndTrsy(JAXBElement<YMoney> value) {
        this.intUsBndTrsy = value;
    }

    /**
     * Gets the value of the investmentExpense property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getInvestmentExpense() {
        return investmentExpense;
    }

    /**
     * Sets the value of the investmentExpense property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setInvestmentExpense(JAXBElement<YMoney> value) {
        this.investmentExpense = value;
    }

    /**
     * Gets the value of the foreignTaxPaid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getForeignTaxPaid() {
        return foreignTaxPaid;
    }

    /**
     * Sets the value of the foreignTaxPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setForeignTaxPaid(JAXBElement<YMoney> value) {
        this.foreignTaxPaid = value;
    }

    /**
     * Gets the value of the taxExemptInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxExemptInterest() {
        return taxExemptInterest;
    }

    /**
     * Sets the value of the taxExemptInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxExemptInterest(JAXBElement<YMoney> value) {
        this.taxExemptInterest = value;
    }

    /**
     * Gets the value of the spPvtBndInterest property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getSpPvtBndInterest() {
        return spPvtBndInterest;
    }

    /**
     * Sets the value of the spPvtBndInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setSpPvtBndInterest(JAXBElement<YMoney> value) {
        this.spPvtBndInterest = value;
    }

}
