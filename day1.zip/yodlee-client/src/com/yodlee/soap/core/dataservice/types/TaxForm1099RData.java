
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.dataservice.types.ArrayOfLocalTaxType;
import com.yodlee.soap.collections.core.dataservice.types.ArrayOfStateTaxType;
import com.yodlee.soap.core.dataservice.YMoney;


/**
 * <p>Java class for TaxForm1099RData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxForm1099RData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://types.dataservice.core.soap.yodlee.com}TaxForm1099Data">
 *       &lt;sequence>
 *         &lt;element name="grossDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="taxAmt" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="isTaxAmtNotDetermined" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="isTotalDist" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="capitalGain" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="employeeContrib" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="netUnrealized" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="distributionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isIraSepSimple" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="annualContDist" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="annualContPct" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="pctTotalDist" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="totalEmpContrib" type="{http://dataservice.core.soap.yodlee.com}YMoney" minOccurs="0"/>
 *         &lt;element name="stateTaxInformation" type="{http://types.dataservice.core.collections.soap.yodlee.com}ArrayOfStateTaxType" minOccurs="0"/>
 *         &lt;element name="localTaxInformation" type="{http://types.dataservice.core.collections.soap.yodlee.com}ArrayOfLocalTaxType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxForm1099RData", propOrder = {
    "grossDist",
    "taxAmt",
    "isTaxAmtNotDetermined",
    "isTotalDist",
    "capitalGain",
    "employeeContrib",
    "netUnrealized",
    "distributionCode",
    "isIraSepSimple",
    "annualContDist",
    "annualContPct",
    "pctTotalDist",
    "totalEmpContrib",
    "stateTaxInformation",
    "localTaxInformation"
})
public class TaxForm1099RData
    extends TaxForm1099Data
{

    @XmlElementRef(name = "grossDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> grossDist;
    @XmlElementRef(name = "taxAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> taxAmt;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isTaxAmtNotDetermined;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isTotalDist;
    @XmlElementRef(name = "capitalGain", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> capitalGain;
    @XmlElementRef(name = "employeeContrib", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> employeeContrib;
    @XmlElementRef(name = "netUnrealized", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> netUnrealized;
    @XmlElementRef(name = "distributionCode", type = JAXBElement.class, required = false)
    protected JAXBElement<String> distributionCode;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean isIraSepSimple;
    @XmlElementRef(name = "annualContDist", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> annualContDist;
    @XmlElementRef(name = "annualContPct", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> annualContPct;
    @XmlElementRef(name = "pctTotalDist", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> pctTotalDist;
    @XmlElementRef(name = "totalEmpContrib", type = JAXBElement.class, required = false)
    protected JAXBElement<YMoney> totalEmpContrib;
    @XmlElementRef(name = "stateTaxInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfStateTaxType> stateTaxInformation;
    @XmlElementRef(name = "localTaxInformation", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfLocalTaxType> localTaxInformation;

    /**
     * Gets the value of the grossDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getGrossDist() {
        return grossDist;
    }

    /**
     * Sets the value of the grossDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setGrossDist(JAXBElement<YMoney> value) {
        this.grossDist = value;
    }

    /**
     * Gets the value of the taxAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTaxAmt() {
        return taxAmt;
    }

    /**
     * Sets the value of the taxAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTaxAmt(JAXBElement<YMoney> value) {
        this.taxAmt = value;
    }

    /**
     * Gets the value of the isTaxAmtNotDetermined property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsTaxAmtNotDetermined() {
        return isTaxAmtNotDetermined;
    }

    /**
     * Sets the value of the isTaxAmtNotDetermined property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsTaxAmtNotDetermined(Boolean value) {
        this.isTaxAmtNotDetermined = value;
    }

    /**
     * Gets the value of the isTotalDist property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsTotalDist() {
        return isTotalDist;
    }

    /**
     * Sets the value of the isTotalDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsTotalDist(Boolean value) {
        this.isTotalDist = value;
    }

    /**
     * Gets the value of the capitalGain property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getCapitalGain() {
        return capitalGain;
    }

    /**
     * Sets the value of the capitalGain property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setCapitalGain(JAXBElement<YMoney> value) {
        this.capitalGain = value;
    }

    /**
     * Gets the value of the employeeContrib property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getEmployeeContrib() {
        return employeeContrib;
    }

    /**
     * Sets the value of the employeeContrib property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setEmployeeContrib(JAXBElement<YMoney> value) {
        this.employeeContrib = value;
    }

    /**
     * Gets the value of the netUnrealized property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getNetUnrealized() {
        return netUnrealized;
    }

    /**
     * Sets the value of the netUnrealized property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setNetUnrealized(JAXBElement<YMoney> value) {
        this.netUnrealized = value;
    }

    /**
     * Gets the value of the distributionCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDistributionCode() {
        return distributionCode;
    }

    /**
     * Sets the value of the distributionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDistributionCode(JAXBElement<String> value) {
        this.distributionCode = value;
    }

    /**
     * Gets the value of the isIraSepSimple property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsIraSepSimple() {
        return isIraSepSimple;
    }

    /**
     * Sets the value of the isIraSepSimple property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsIraSepSimple(Boolean value) {
        this.isIraSepSimple = value;
    }

    /**
     * Gets the value of the annualContDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getAnnualContDist() {
        return annualContDist;
    }

    /**
     * Sets the value of the annualContDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setAnnualContDist(JAXBElement<YMoney> value) {
        this.annualContDist = value;
    }

    /**
     * Gets the value of the annualContPct property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAnnualContPct() {
        return annualContPct;
    }

    /**
     * Sets the value of the annualContPct property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAnnualContPct(JAXBElement<Double> value) {
        this.annualContPct = value;
    }

    /**
     * Gets the value of the pctTotalDist property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getPctTotalDist() {
        return pctTotalDist;
    }

    /**
     * Sets the value of the pctTotalDist property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setPctTotalDist(JAXBElement<Double> value) {
        this.pctTotalDist = value;
    }

    /**
     * Gets the value of the totalEmpContrib property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public JAXBElement<YMoney> getTotalEmpContrib() {
        return totalEmpContrib;
    }

    /**
     * Sets the value of the totalEmpContrib property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link YMoney }{@code >}
     *     
     */
    public void setTotalEmpContrib(JAXBElement<YMoney> value) {
        this.totalEmpContrib = value;
    }

    /**
     * Gets the value of the stateTaxInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfStateTaxType }{@code >}
     *     
     */
    public JAXBElement<ArrayOfStateTaxType> getStateTaxInformation() {
        return stateTaxInformation;
    }

    /**
     * Sets the value of the stateTaxInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfStateTaxType }{@code >}
     *     
     */
    public void setStateTaxInformation(JAXBElement<ArrayOfStateTaxType> value) {
        this.stateTaxInformation = value;
    }

    /**
     * Gets the value of the localTaxInformation property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLocalTaxType }{@code >}
     *     
     */
    public JAXBElement<ArrayOfLocalTaxType> getLocalTaxInformation() {
        return localTaxInformation;
    }

    /**
     * Sets the value of the localTaxInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLocalTaxType }{@code >}
     *     
     */
    public void setLocalTaxInformation(JAXBElement<ArrayOfLocalTaxType> value) {
        this.localTaxInformation = value;
    }

}
