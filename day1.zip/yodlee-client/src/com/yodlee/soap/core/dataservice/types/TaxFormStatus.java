
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxFormStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxFormStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ORIGINAL"/>
 *     &lt;enumeration value="CORRECTED"/>
 *     &lt;enumeration value="ERRATA"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxFormStatus")
@XmlEnum
public enum TaxFormStatus {

    ORIGINAL,
    CORRECTED,
    ERRATA;

    public String value() {
        return name();
    }

    public static TaxFormStatus fromValue(String v) {
        return valueOf(v);
    }

}
