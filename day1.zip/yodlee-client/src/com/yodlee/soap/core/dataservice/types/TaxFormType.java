
package com.yodlee.soap.core.dataservice.types;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TaxFormType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TaxFormType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FORM_1099_INT"/>
 *     &lt;enumeration value="FORM_1099_DIV"/>
 *     &lt;enumeration value="FORM_1099_R"/>
 *     &lt;enumeration value="FORM_1099_B"/>
 *     &lt;enumeration value="FORM_1099_MISC"/>
 *     &lt;enumeration value="FORM_1099_OID"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "TaxFormType")
@XmlEnum
public enum TaxFormType {

    FORM_1099_INT,
    FORM_1099_DIV,
    FORM_1099_R,
    FORM_1099_B,
    FORM_1099_MISC,
    FORM_1099_OID;

    public String value() {
        return name();
    }

    public static TaxFormType fromValue(String v) {
        return valueOf(v);
    }

}
