
package com.yodlee.soap.core.investment;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.core.investment.ArrayOfAssetClassification;
import com.yodlee.soap.core.dataservice.enums.Exchange;
import com.yodlee.soap.core.dataservice.enums.HoldingType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.investment package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InvestmentSecurityCusipNumber_QNAME = new QName("", "cusipNumber");
    private final static QName _InvestmentSecurityDomicile_QNAME = new QName("", "domicile");
    private final static QName _InvestmentSecurityCurrencyCode_QNAME = new QName("", "currencyCode");
    private final static QName _InvestmentSecuritySymbol_QNAME = new QName("", "symbol");
    private final static QName _InvestmentSecurityDescription_QNAME = new QName("", "description");
    private final static QName _InvestmentSecuritySecurityId_QNAME = new QName("", "securityId");
    private final static QName _InvestmentSecurityLastUpdatedDate_QNAME = new QName("", "lastUpdatedDate");
    private final static QName _InvestmentSecurityHoldingType_QNAME = new QName("", "holdingType");
    private final static QName _InvestmentSecuritySedol_QNAME = new QName("", "sedol");
    private final static QName _InvestmentSecurityCreatedDate_QNAME = new QName("", "createdDate");
    private final static QName _InvestmentSecurityAssetClassifications_QNAME = new QName("", "assetClassifications");
    private final static QName _InvestmentSecurityExchange_QNAME = new QName("", "exchange");
    private final static QName _InvestmentSecurityIsin_QNAME = new QName("", "isin");
    private final static QName _AssetClassificationCategoryName_QNAME = new QName("", "categoryName");
    private final static QName _AssetClassificationClassificationName_QNAME = new QName("", "classificationName");
    private final static QName _AssetClassificationAllocation_QNAME = new QName("", "allocation");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.investment
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AssetClassification }
     * 
     */
    public AssetClassification createAssetClassification() {
        return new AssetClassification();
    }

    /**
     * Create an instance of {@link InvestmentSecurity }
     * 
     */
    public InvestmentSecurity createInvestmentSecurity() {
        return new InvestmentSecurity();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "cusipNumber", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecurityCusipNumber(String value) {
        return new JAXBElement<String>(_InvestmentSecurityCusipNumber_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "domicile", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecurityDomicile(String value) {
        return new JAXBElement<String>(_InvestmentSecurityDomicile_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currencyCode", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecurityCurrencyCode(String value) {
        return new JAXBElement<String>(_InvestmentSecurityCurrencyCode_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "symbol", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecuritySymbol(String value) {
        return new JAXBElement<String>(_InvestmentSecuritySymbol_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecurityDescription(String value) {
        return new JAXBElement<String>(_InvestmentSecurityDescription_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "securityId", scope = InvestmentSecurity.class)
    public JAXBElement<Long> createInvestmentSecuritySecurityId(Long value) {
        return new JAXBElement<Long>(_InvestmentSecuritySecurityId_QNAME, Long.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastUpdatedDate", scope = InvestmentSecurity.class)
    public JAXBElement<XMLGregorianCalendar> createInvestmentSecurityLastUpdatedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InvestmentSecurityLastUpdatedDate_QNAME, XMLGregorianCalendar.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link HoldingType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "holdingType", scope = InvestmentSecurity.class)
    public JAXBElement<HoldingType> createInvestmentSecurityHoldingType(HoldingType value) {
        return new JAXBElement<HoldingType>(_InvestmentSecurityHoldingType_QNAME, HoldingType.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sedol", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecuritySedol(String value) {
        return new JAXBElement<String>(_InvestmentSecuritySedol_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "createdDate", scope = InvestmentSecurity.class)
    public JAXBElement<XMLGregorianCalendar> createInvestmentSecurityCreatedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InvestmentSecurityCreatedDate_QNAME, XMLGregorianCalendar.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAssetClassification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "assetClassifications", scope = InvestmentSecurity.class)
    public JAXBElement<ArrayOfAssetClassification> createInvestmentSecurityAssetClassifications(ArrayOfAssetClassification value) {
        return new JAXBElement<ArrayOfAssetClassification>(_InvestmentSecurityAssetClassifications_QNAME, ArrayOfAssetClassification.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Exchange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "exchange", scope = InvestmentSecurity.class)
    public JAXBElement<Exchange> createInvestmentSecurityExchange(Exchange value) {
        return new JAXBElement<Exchange>(_InvestmentSecurityExchange_QNAME, Exchange.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "isin", scope = InvestmentSecurity.class)
    public JAXBElement<String> createInvestmentSecurityIsin(String value) {
        return new JAXBElement<String>(_InvestmentSecurityIsin_QNAME, String.class, InvestmentSecurity.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "categoryName", scope = AssetClassification.class)
    public JAXBElement<String> createAssetClassificationCategoryName(String value) {
        return new JAXBElement<String>(_AssetClassificationCategoryName_QNAME, String.class, AssetClassification.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "classificationName", scope = AssetClassification.class)
    public JAXBElement<String> createAssetClassificationClassificationName(String value) {
        return new JAXBElement<String>(_AssetClassificationClassificationName_QNAME, String.class, AssetClassification.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "allocation", scope = AssetClassification.class)
    public JAXBElement<Double> createAssetClassificationAllocation(Double value) {
        return new JAXBElement<Double>(_AssetClassificationAllocation_QNAME, Double.class, AssetClassification.class, value);
    }

}
