@javax.xml.bind.annotation.XmlSchema(namespace = "http://investment.core.soap.yodlee.com")
package com.yodlee.soap.core.investment;
