
package com.yodlee.soap.core.itemaccountmanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountOpeningChannel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccountOpeningChannel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ONLINE"/>
 *     &lt;enumeration value="CALLCENTER"/>
 *     &lt;enumeration value="BRANCH"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AccountOpeningChannel")
@XmlEnum
public enum AccountOpeningChannel {

    ONLINE,
    CALLCENTER,
    BRANCH,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static AccountOpeningChannel fromValue(String v) {
        return valueOf(v);
    }

}
