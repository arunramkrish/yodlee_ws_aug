
package com.yodlee.soap.core.itemaccountmanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountRelationType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccountRelationType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="OWNER"/>
 *     &lt;enumeration value="POWER_OF_ATTORNEY"/>
 *     &lt;enumeration value="TRUSTEE"/>
 *     &lt;enumeration value="JOINT_OWNER"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AccountRelationType")
@XmlEnum
public enum AccountRelationType {

    UNKNOWN,
    OWNER,
    POWER_OF_ATTORNEY,
    TRUSTEE,
    JOINT_OWNER;

    public String value() {
        return name();
    }

    public static AccountRelationType fromValue(String v) {
        return valueOf(v);
    }

}
