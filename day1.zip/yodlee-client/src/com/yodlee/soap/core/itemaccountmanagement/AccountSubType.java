
package com.yodlee.soap.core.itemaccountmanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountSubType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccountSubType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="UNKNOWN"/>
 *     &lt;enumeration value="BUSINESS"/>
 *     &lt;enumeration value="INDIVIDUAL"/>
 *     &lt;enumeration value="JOINT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AccountSubType")
@XmlEnum
public enum AccountSubType {

    UNKNOWN,
    BUSINESS,
    INDIVIDUAL,
    JOINT;

    public String value() {
        return name();
    }

    public static AccountSubType fromValue(String v) {
        return valueOf(v);
    }

}
