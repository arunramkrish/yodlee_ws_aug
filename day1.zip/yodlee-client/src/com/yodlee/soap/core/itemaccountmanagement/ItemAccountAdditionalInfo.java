
package com.yodlee.soap.core.itemaccountmanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.collections.common.ArrayOfNVPair;


/**
 * <p>Java class for ItemAccountAdditionalInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ItemAccountAdditionalInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="primaryAccountFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="primaryAccountLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secondaryAccountFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="secondaryAccountLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="addressLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="zipCode1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="zipCode2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postBox" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="country" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountSubType" type="{http://itemaccountmanagement.core.soap.yodlee.com}AccountSubType" minOccurs="0"/>
 *         &lt;element name="accountRelationShip" type="{http://itemaccountmanagement.core.soap.yodlee.com}AccountRelationType" minOccurs="0"/>
 *         &lt;element name="lastDepositAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="lastDebitAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="lastDepositDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="lastDebitDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="accountOpenDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="consumerSinceDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="addressType" type="{http://itemaccountmanagement.core.soap.yodlee.com}AddressType" minOccurs="0"/>
 *         &lt;element name="accountStatus" type="{http://itemaccountmanagement.core.soap.yodlee.com}AccountStatus" minOccurs="0"/>
 *         &lt;element name="avgMonActivityAmt" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="overDraftLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="accountOpeningChannel" type="{http://itemaccountmanagement.core.soap.yodlee.com}AccountOpeningChannel" minOccurs="0"/>
 *         &lt;element name="customAttributes" type="{http://common.collections.soap.yodlee.com}ArrayOfNVPair" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ItemAccountAdditionalInfo", propOrder = {
    "primaryAccountFirstName",
    "primaryAccountLastName",
    "secondaryAccountFirstName",
    "secondaryAccountLastName",
    "addressLine1",
    "addressLine2",
    "addressLine3",
    "zipCode1",
    "zipCode2",
    "postBox",
    "country",
    "state",
    "city",
    "accountSubType",
    "accountRelationShip",
    "lastDepositAmount",
    "lastDebitAmount",
    "lastDepositDate",
    "lastDebitDate",
    "accountOpenDate",
    "consumerSinceDate",
    "addressType",
    "accountStatus",
    "avgMonActivityAmt",
    "overDraftLimit",
    "accountOpeningChannel",
    "customAttributes"
})
public class ItemAccountAdditionalInfo {

    @XmlElementRef(name = "primaryAccountFirstName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> primaryAccountFirstName;
    @XmlElementRef(name = "primaryAccountLastName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> primaryAccountLastName;
    @XmlElementRef(name = "secondaryAccountFirstName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountFirstName;
    @XmlElementRef(name = "secondaryAccountLastName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> secondaryAccountLastName;
    @XmlElementRef(name = "addressLine1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> addressLine1;
    @XmlElementRef(name = "addressLine2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> addressLine2;
    @XmlElementRef(name = "addressLine3", type = JAXBElement.class, required = false)
    protected JAXBElement<String> addressLine3;
    @XmlElementRef(name = "zipCode1", type = JAXBElement.class, required = false)
    protected JAXBElement<String> zipCode1;
    @XmlElementRef(name = "zipCode2", type = JAXBElement.class, required = false)
    protected JAXBElement<String> zipCode2;
    @XmlElementRef(name = "postBox", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> postBox;
    @XmlElementRef(name = "country", type = JAXBElement.class, required = false)
    protected JAXBElement<String> country;
    @XmlElementRef(name = "state", type = JAXBElement.class, required = false)
    protected JAXBElement<String> state;
    @XmlElementRef(name = "city", type = JAXBElement.class, required = false)
    protected JAXBElement<String> city;
    @XmlElementRef(name = "accountSubType", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountSubType> accountSubType;
    @XmlElementRef(name = "accountRelationShip", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountRelationType> accountRelationShip;
    @XmlElementRef(name = "lastDepositAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> lastDepositAmount;
    @XmlElementRef(name = "lastDebitAmount", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> lastDebitAmount;
    @XmlElementRef(name = "lastDepositDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> lastDepositDate;
    @XmlElementRef(name = "lastDebitDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> lastDebitDate;
    @XmlElementRef(name = "accountOpenDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> accountOpenDate;
    @XmlElementRef(name = "consumerSinceDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> consumerSinceDate;
    @XmlElementRef(name = "addressType", type = JAXBElement.class, required = false)
    protected JAXBElement<AddressType> addressType;
    @XmlElementRef(name = "accountStatus", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountStatus> accountStatus;
    @XmlElementRef(name = "avgMonActivityAmt", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> avgMonActivityAmt;
    @XmlElementRef(name = "overDraftLimit", type = JAXBElement.class, required = false)
    protected JAXBElement<Double> overDraftLimit;
    @XmlElementRef(name = "accountOpeningChannel", type = JAXBElement.class, required = false)
    protected JAXBElement<AccountOpeningChannel> accountOpeningChannel;
    @XmlElementRef(name = "customAttributes", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfNVPair> customAttributes;

    /**
     * Gets the value of the primaryAccountFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPrimaryAccountFirstName() {
        return primaryAccountFirstName;
    }

    /**
     * Sets the value of the primaryAccountFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPrimaryAccountFirstName(JAXBElement<String> value) {
        this.primaryAccountFirstName = value;
    }

    /**
     * Gets the value of the primaryAccountLastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPrimaryAccountLastName() {
        return primaryAccountLastName;
    }

    /**
     * Sets the value of the primaryAccountLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPrimaryAccountLastName(JAXBElement<String> value) {
        this.primaryAccountLastName = value;
    }

    /**
     * Gets the value of the secondaryAccountFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountFirstName() {
        return secondaryAccountFirstName;
    }

    /**
     * Sets the value of the secondaryAccountFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountFirstName(JAXBElement<String> value) {
        this.secondaryAccountFirstName = value;
    }

    /**
     * Gets the value of the secondaryAccountLastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSecondaryAccountLastName() {
        return secondaryAccountLastName;
    }

    /**
     * Sets the value of the secondaryAccountLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSecondaryAccountLastName(JAXBElement<String> value) {
        this.secondaryAccountLastName = value;
    }

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddressLine1(JAXBElement<String> value) {
        this.addressLine1 = value;
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddressLine2(JAXBElement<String> value) {
        this.addressLine2 = value;
    }

    /**
     * Gets the value of the addressLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddressLine3() {
        return addressLine3;
    }

    /**
     * Sets the value of the addressLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddressLine3(JAXBElement<String> value) {
        this.addressLine3 = value;
    }

    /**
     * Gets the value of the zipCode1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getZipCode1() {
        return zipCode1;
    }

    /**
     * Sets the value of the zipCode1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setZipCode1(JAXBElement<String> value) {
        this.zipCode1 = value;
    }

    /**
     * Gets the value of the zipCode2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getZipCode2() {
        return zipCode2;
    }

    /**
     * Sets the value of the zipCode2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setZipCode2(JAXBElement<String> value) {
        this.zipCode2 = value;
    }

    /**
     * Gets the value of the postBox property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getPostBox() {
        return postBox;
    }

    /**
     * Sets the value of the postBox property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setPostBox(JAXBElement<Long> value) {
        this.postBox = value;
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCountry(JAXBElement<String> value) {
        this.country = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setState(JAXBElement<String> value) {
        this.state = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCity(JAXBElement<String> value) {
        this.city = value;
    }

    /**
     * Gets the value of the accountSubType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountSubType }{@code >}
     *     
     */
    public JAXBElement<AccountSubType> getAccountSubType() {
        return accountSubType;
    }

    /**
     * Sets the value of the accountSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountSubType }{@code >}
     *     
     */
    public void setAccountSubType(JAXBElement<AccountSubType> value) {
        this.accountSubType = value;
    }

    /**
     * Gets the value of the accountRelationShip property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountRelationType }{@code >}
     *     
     */
    public JAXBElement<AccountRelationType> getAccountRelationShip() {
        return accountRelationShip;
    }

    /**
     * Sets the value of the accountRelationShip property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountRelationType }{@code >}
     *     
     */
    public void setAccountRelationShip(JAXBElement<AccountRelationType> value) {
        this.accountRelationShip = value;
    }

    /**
     * Gets the value of the lastDepositAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getLastDepositAmount() {
        return lastDepositAmount;
    }

    /**
     * Sets the value of the lastDepositAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setLastDepositAmount(JAXBElement<Double> value) {
        this.lastDepositAmount = value;
    }

    /**
     * Gets the value of the lastDebitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getLastDebitAmount() {
        return lastDebitAmount;
    }

    /**
     * Sets the value of the lastDebitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setLastDebitAmount(JAXBElement<Double> value) {
        this.lastDebitAmount = value;
    }

    /**
     * Gets the value of the lastDepositDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastDepositDate() {
        return lastDepositDate;
    }

    /**
     * Sets the value of the lastDepositDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastDepositDate(JAXBElement<XMLGregorianCalendar> value) {
        this.lastDepositDate = value;
    }

    /**
     * Gets the value of the lastDebitDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastDebitDate() {
        return lastDebitDate;
    }

    /**
     * Sets the value of the lastDebitDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastDebitDate(JAXBElement<XMLGregorianCalendar> value) {
        this.lastDebitDate = value;
    }

    /**
     * Gets the value of the accountOpenDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getAccountOpenDate() {
        return accountOpenDate;
    }

    /**
     * Sets the value of the accountOpenDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setAccountOpenDate(JAXBElement<XMLGregorianCalendar> value) {
        this.accountOpenDate = value;
    }

    /**
     * Gets the value of the consumerSinceDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getConsumerSinceDate() {
        return consumerSinceDate;
    }

    /**
     * Sets the value of the consumerSinceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setConsumerSinceDate(JAXBElement<XMLGregorianCalendar> value) {
        this.consumerSinceDate = value;
    }

    /**
     * Gets the value of the addressType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AddressType }{@code >}
     *     
     */
    public JAXBElement<AddressType> getAddressType() {
        return addressType;
    }

    /**
     * Sets the value of the addressType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AddressType }{@code >}
     *     
     */
    public void setAddressType(JAXBElement<AddressType> value) {
        this.addressType = value;
    }

    /**
     * Gets the value of the accountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountStatus }{@code >}
     *     
     */
    public JAXBElement<AccountStatus> getAccountStatus() {
        return accountStatus;
    }

    /**
     * Sets the value of the accountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountStatus }{@code >}
     *     
     */
    public void setAccountStatus(JAXBElement<AccountStatus> value) {
        this.accountStatus = value;
    }

    /**
     * Gets the value of the avgMonActivityAmt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getAvgMonActivityAmt() {
        return avgMonActivityAmt;
    }

    /**
     * Sets the value of the avgMonActivityAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setAvgMonActivityAmt(JAXBElement<Double> value) {
        this.avgMonActivityAmt = value;
    }

    /**
     * Gets the value of the overDraftLimit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public JAXBElement<Double> getOverDraftLimit() {
        return overDraftLimit;
    }

    /**
     * Sets the value of the overDraftLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Double }{@code >}
     *     
     */
    public void setOverDraftLimit(JAXBElement<Double> value) {
        this.overDraftLimit = value;
    }

    /**
     * Gets the value of the accountOpeningChannel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccountOpeningChannel }{@code >}
     *     
     */
    public JAXBElement<AccountOpeningChannel> getAccountOpeningChannel() {
        return accountOpeningChannel;
    }

    /**
     * Sets the value of the accountOpeningChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccountOpeningChannel }{@code >}
     *     
     */
    public void setAccountOpeningChannel(JAXBElement<AccountOpeningChannel> value) {
        this.accountOpeningChannel = value;
    }

    /**
     * Gets the value of the customAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public JAXBElement<ArrayOfNVPair> getCustomAttributes() {
        return customAttributes;
    }

    /**
     * Sets the value of the customAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public void setCustomAttributes(JAXBElement<ArrayOfNVPair> value) {
        this.customAttributes = value;
    }

}
