
package com.yodlee.soap.core.itemaccountmanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.common.ArrayOfNVPair;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.itemaccountmanagement package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ItemAccountAdditionalInfoLastDebitDate_QNAME = new QName("", "lastDebitDate");
    private final static QName _ItemAccountAdditionalInfoAccountOpenDate_QNAME = new QName("", "accountOpenDate");
    private final static QName _ItemAccountAdditionalInfoSecondaryAccountLastName_QNAME = new QName("", "secondaryAccountLastName");
    private final static QName _ItemAccountAdditionalInfoState_QNAME = new QName("", "state");
    private final static QName _ItemAccountAdditionalInfoConsumerSinceDate_QNAME = new QName("", "consumerSinceDate");
    private final static QName _ItemAccountAdditionalInfoLastDebitAmount_QNAME = new QName("", "lastDebitAmount");
    private final static QName _ItemAccountAdditionalInfoAccountSubType_QNAME = new QName("", "accountSubType");
    private final static QName _ItemAccountAdditionalInfoCustomAttributes_QNAME = new QName("", "customAttributes");
    private final static QName _ItemAccountAdditionalInfoCity_QNAME = new QName("", "city");
    private final static QName _ItemAccountAdditionalInfoAvgMonActivityAmt_QNAME = new QName("", "avgMonActivityAmt");
    private final static QName _ItemAccountAdditionalInfoAccountStatus_QNAME = new QName("", "accountStatus");
    private final static QName _ItemAccountAdditionalInfoLastDepositAmount_QNAME = new QName("", "lastDepositAmount");
    private final static QName _ItemAccountAdditionalInfoLastDepositDate_QNAME = new QName("", "lastDepositDate");
    private final static QName _ItemAccountAdditionalInfoZipCode1_QNAME = new QName("", "zipCode1");
    private final static QName _ItemAccountAdditionalInfoOverDraftLimit_QNAME = new QName("", "overDraftLimit");
    private final static QName _ItemAccountAdditionalInfoAccountOpeningChannel_QNAME = new QName("", "accountOpeningChannel");
    private final static QName _ItemAccountAdditionalInfoAddressType_QNAME = new QName("", "addressType");
    private final static QName _ItemAccountAdditionalInfoAddressLine3_QNAME = new QName("", "addressLine3");
    private final static QName _ItemAccountAdditionalInfoAddressLine2_QNAME = new QName("", "addressLine2");
    private final static QName _ItemAccountAdditionalInfoAddressLine1_QNAME = new QName("", "addressLine1");
    private final static QName _ItemAccountAdditionalInfoCountry_QNAME = new QName("", "country");
    private final static QName _ItemAccountAdditionalInfoPostBox_QNAME = new QName("", "postBox");
    private final static QName _ItemAccountAdditionalInfoZipCode2_QNAME = new QName("", "zipCode2");
    private final static QName _ItemAccountAdditionalInfoSecondaryAccountFirstName_QNAME = new QName("", "secondaryAccountFirstName");
    private final static QName _ItemAccountAdditionalInfoAccountRelationShip_QNAME = new QName("", "accountRelationShip");
    private final static QName _ItemAccountAdditionalInfoPrimaryAccountLastName_QNAME = new QName("", "primaryAccountLastName");
    private final static QName _ItemAccountAdditionalInfoPrimaryAccountFirstName_QNAME = new QName("", "primaryAccountFirstName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.itemaccountmanagement
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ItemAccountAdditionalInfo }
     * 
     */
    public ItemAccountAdditionalInfo createItemAccountAdditionalInfo() {
        return new ItemAccountAdditionalInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastDebitDate", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemAccountAdditionalInfoLastDebitDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemAccountAdditionalInfoLastDebitDate_QNAME, XMLGregorianCalendar.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountOpenDate", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemAccountAdditionalInfoAccountOpenDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemAccountAdditionalInfoAccountOpenDate_QNAME, XMLGregorianCalendar.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "secondaryAccountLastName", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoSecondaryAccountLastName(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoSecondaryAccountLastName_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoState(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoState_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "consumerSinceDate", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemAccountAdditionalInfoConsumerSinceDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemAccountAdditionalInfoConsumerSinceDate_QNAME, XMLGregorianCalendar.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastDebitAmount", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<Double> createItemAccountAdditionalInfoLastDebitAmount(Double value) {
        return new JAXBElement<Double>(_ItemAccountAdditionalInfoLastDebitAmount_QNAME, Double.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountSubType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountSubType", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<AccountSubType> createItemAccountAdditionalInfoAccountSubType(AccountSubType value) {
        return new JAXBElement<AccountSubType>(_ItemAccountAdditionalInfoAccountSubType_QNAME, AccountSubType.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "customAttributes", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<ArrayOfNVPair> createItemAccountAdditionalInfoCustomAttributes(ArrayOfNVPair value) {
        return new JAXBElement<ArrayOfNVPair>(_ItemAccountAdditionalInfoCustomAttributes_QNAME, ArrayOfNVPair.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "city", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoCity(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoCity_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "avgMonActivityAmt", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<Double> createItemAccountAdditionalInfoAvgMonActivityAmt(Double value) {
        return new JAXBElement<Double>(_ItemAccountAdditionalInfoAvgMonActivityAmt_QNAME, Double.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountStatus", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<AccountStatus> createItemAccountAdditionalInfoAccountStatus(AccountStatus value) {
        return new JAXBElement<AccountStatus>(_ItemAccountAdditionalInfoAccountStatus_QNAME, AccountStatus.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastDepositAmount", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<Double> createItemAccountAdditionalInfoLastDepositAmount(Double value) {
        return new JAXBElement<Double>(_ItemAccountAdditionalInfoLastDepositAmount_QNAME, Double.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastDepositDate", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<XMLGregorianCalendar> createItemAccountAdditionalInfoLastDepositDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_ItemAccountAdditionalInfoLastDepositDate_QNAME, XMLGregorianCalendar.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "zipCode1", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoZipCode1(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoZipCode1_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "overDraftLimit", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<Double> createItemAccountAdditionalInfoOverDraftLimit(Double value) {
        return new JAXBElement<Double>(_ItemAccountAdditionalInfoOverDraftLimit_QNAME, Double.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountOpeningChannel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountOpeningChannel", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<AccountOpeningChannel> createItemAccountAdditionalInfoAccountOpeningChannel(AccountOpeningChannel value) {
        return new JAXBElement<AccountOpeningChannel>(_ItemAccountAdditionalInfoAccountOpeningChannel_QNAME, AccountOpeningChannel.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressType", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<AddressType> createItemAccountAdditionalInfoAddressType(AddressType value) {
        return new JAXBElement<AddressType>(_ItemAccountAdditionalInfoAddressType_QNAME, AddressType.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressLine3", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoAddressLine3(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoAddressLine3_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressLine2", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoAddressLine2(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoAddressLine2_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "addressLine1", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoAddressLine1(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoAddressLine1_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "country", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoCountry(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoCountry_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "postBox", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<Long> createItemAccountAdditionalInfoPostBox(Long value) {
        return new JAXBElement<Long>(_ItemAccountAdditionalInfoPostBox_QNAME, Long.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "zipCode2", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoZipCode2(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoZipCode2_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "secondaryAccountFirstName", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoSecondaryAccountFirstName(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoSecondaryAccountFirstName_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccountRelationType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accountRelationShip", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<AccountRelationType> createItemAccountAdditionalInfoAccountRelationShip(AccountRelationType value) {
        return new JAXBElement<AccountRelationType>(_ItemAccountAdditionalInfoAccountRelationShip_QNAME, AccountRelationType.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "primaryAccountLastName", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoPrimaryAccountLastName(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoPrimaryAccountLastName_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "primaryAccountFirstName", scope = ItemAccountAdditionalInfo.class)
    public JAXBElement<String> createItemAccountAdditionalInfoPrimaryAccountFirstName(String value) {
        return new JAXBElement<String>(_ItemAccountAdditionalInfoPrimaryAccountFirstName_QNAME, String.class, ItemAccountAdditionalInfo.class, value);
    }

}
