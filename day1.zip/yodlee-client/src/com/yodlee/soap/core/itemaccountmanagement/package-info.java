@javax.xml.bind.annotation.XmlSchema(namespace = "http://itemaccountmanagement.core.soap.yodlee.com")
package com.yodlee.soap.core.itemaccountmanagement;
