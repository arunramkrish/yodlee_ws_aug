
package com.yodlee.soap.core.paymentservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.core.paymentservice.ArrayOfSharedPaymentAccountLimit;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.paymentservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SharedPaymentAccountLimitSharedPaymentAccountLimitType_QNAME = new QName("", "sharedPaymentAccountLimitType");
    private final static QName _SharedPaymentAccountLimitOwnerMemId_QNAME = new QName("", "ownerMemId");
    private final static QName _SharedPaymentAccountLimitParamAclId_QNAME = new QName("", "paramAclId");
    private final static QName _SharedPaymentAccountLimitSharedAccountId_QNAME = new QName("", "sharedAccountId");
    private final static QName _SharedPaymentAccountLimitSharedAccountPermissionId_QNAME = new QName("", "sharedAccountPermissionId");
    private final static QName _SharedPaymentAccountLimitSharedToMemId_QNAME = new QName("", "sharedToMemId");
    private final static QName _SharedPaymentAccountLimitAclValue_QNAME = new QName("", "aclValue");
    private final static QName _PaymentAccountSharingInfoSharedPaymentAccountLimits_QNAME = new QName("", "sharedPaymentAccountLimits");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.paymentservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SharedPaymentAccountLimit }
     * 
     */
    public SharedPaymentAccountLimit createSharedPaymentAccountLimit() {
        return new SharedPaymentAccountLimit();
    }

    /**
     * Create an instance of {@link PaymentAccountSharingInfo }
     * 
     */
    public PaymentAccountSharingInfo createPaymentAccountSharingInfo() {
        return new PaymentAccountSharingInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SharedPaymentAccountLimitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedPaymentAccountLimitType", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<SharedPaymentAccountLimitType> createSharedPaymentAccountLimitSharedPaymentAccountLimitType(SharedPaymentAccountLimitType value) {
        return new JAXBElement<SharedPaymentAccountLimitType>(_SharedPaymentAccountLimitSharedPaymentAccountLimitType_QNAME, SharedPaymentAccountLimitType.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ownerMemId", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<Long> createSharedPaymentAccountLimitOwnerMemId(Long value) {
        return new JAXBElement<Long>(_SharedPaymentAccountLimitOwnerMemId_QNAME, Long.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "paramAclId", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<Long> createSharedPaymentAccountLimitParamAclId(Long value) {
        return new JAXBElement<Long>(_SharedPaymentAccountLimitParamAclId_QNAME, Long.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedAccountId", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<Long> createSharedPaymentAccountLimitSharedAccountId(Long value) {
        return new JAXBElement<Long>(_SharedPaymentAccountLimitSharedAccountId_QNAME, Long.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedAccountPermissionId", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<Long> createSharedPaymentAccountLimitSharedAccountPermissionId(Long value) {
        return new JAXBElement<Long>(_SharedPaymentAccountLimitSharedAccountPermissionId_QNAME, Long.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedToMemId", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<Long> createSharedPaymentAccountLimitSharedToMemId(Long value) {
        return new JAXBElement<Long>(_SharedPaymentAccountLimitSharedToMemId_QNAME, Long.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "aclValue", scope = SharedPaymentAccountLimit.class)
    public JAXBElement<String> createSharedPaymentAccountLimitAclValue(String value) {
        return new JAXBElement<String>(_SharedPaymentAccountLimitAclValue_QNAME, String.class, SharedPaymentAccountLimit.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfSharedPaymentAccountLimit }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedPaymentAccountLimits", scope = PaymentAccountSharingInfo.class)
    public JAXBElement<ArrayOfSharedPaymentAccountLimit> createPaymentAccountSharingInfoSharedPaymentAccountLimits(ArrayOfSharedPaymentAccountLimit value) {
        return new JAXBElement<ArrayOfSharedPaymentAccountLimit>(_PaymentAccountSharingInfoSharedPaymentAccountLimits_QNAME, ArrayOfSharedPaymentAccountLimit.class, PaymentAccountSharingInfo.class, value);
    }

}
