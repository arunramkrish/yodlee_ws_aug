
package com.yodlee.soap.core.paymentservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.core.paymentservice.ArrayOfSharedPaymentAccountLimit;
import com.yodlee.soap.core.sharedaccount.SharedAccountInfo;


/**
 * <p>Java class for PaymentAccountSharingInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentAccountSharingInfo">
 *   &lt;complexContent>
 *     &lt;extension base="{http://sharedaccount.core.soap.yodlee.com}SharedAccountInfo">
 *       &lt;sequence>
 *         &lt;element name="sharedPaymentAccountLimits" type="{http://paymentservice.core.collections.soap.yodlee.com}ArrayOfSharedPaymentAccountLimit" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentAccountSharingInfo", propOrder = {
    "sharedPaymentAccountLimits"
})
public class PaymentAccountSharingInfo
    extends SharedAccountInfo
{

    @XmlElementRef(name = "sharedPaymentAccountLimits", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfSharedPaymentAccountLimit> sharedPaymentAccountLimits;

    /**
     * Gets the value of the sharedPaymentAccountLimits property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfSharedPaymentAccountLimit }{@code >}
     *     
     */
    public JAXBElement<ArrayOfSharedPaymentAccountLimit> getSharedPaymentAccountLimits() {
        return sharedPaymentAccountLimits;
    }

    /**
     * Sets the value of the sharedPaymentAccountLimits property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfSharedPaymentAccountLimit }{@code >}
     *     
     */
    public void setSharedPaymentAccountLimits(JAXBElement<ArrayOfSharedPaymentAccountLimit> value) {
        this.sharedPaymentAccountLimits = value;
    }

}
