
package com.yodlee.soap.core.paymentservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SharedPaymentAccountLimit complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SharedPaymentAccountLimit">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sharedAccountPermissionId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sharedAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="ownerMemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sharedToMemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="paramAclId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="aclValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sharedPaymentAccountLimitType" type="{http://paymentservice.core.soap.yodlee.com}SharedPaymentAccountLimitType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SharedPaymentAccountLimit", propOrder = {
    "sharedAccountPermissionId",
    "sharedAccountId",
    "ownerMemId",
    "sharedToMemId",
    "paramAclId",
    "aclValue",
    "sharedPaymentAccountLimitType"
})
public class SharedPaymentAccountLimit {

    @XmlElementRef(name = "sharedAccountPermissionId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> sharedAccountPermissionId;
    @XmlElementRef(name = "sharedAccountId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> sharedAccountId;
    @XmlElementRef(name = "ownerMemId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> ownerMemId;
    @XmlElementRef(name = "sharedToMemId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> sharedToMemId;
    @XmlElementRef(name = "paramAclId", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> paramAclId;
    @XmlElementRef(name = "aclValue", type = JAXBElement.class, required = false)
    protected JAXBElement<String> aclValue;
    @XmlElementRef(name = "sharedPaymentAccountLimitType", type = JAXBElement.class, required = false)
    protected JAXBElement<SharedPaymentAccountLimitType> sharedPaymentAccountLimitType;

    /**
     * Gets the value of the sharedAccountPermissionId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSharedAccountPermissionId() {
        return sharedAccountPermissionId;
    }

    /**
     * Sets the value of the sharedAccountPermissionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSharedAccountPermissionId(JAXBElement<Long> value) {
        this.sharedAccountPermissionId = value;
    }

    /**
     * Gets the value of the sharedAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSharedAccountId() {
        return sharedAccountId;
    }

    /**
     * Sets the value of the sharedAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSharedAccountId(JAXBElement<Long> value) {
        this.sharedAccountId = value;
    }

    /**
     * Gets the value of the ownerMemId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getOwnerMemId() {
        return ownerMemId;
    }

    /**
     * Sets the value of the ownerMemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setOwnerMemId(JAXBElement<Long> value) {
        this.ownerMemId = value;
    }

    /**
     * Gets the value of the sharedToMemId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getSharedToMemId() {
        return sharedToMemId;
    }

    /**
     * Sets the value of the sharedToMemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setSharedToMemId(JAXBElement<Long> value) {
        this.sharedToMemId = value;
    }

    /**
     * Gets the value of the paramAclId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getParamAclId() {
        return paramAclId;
    }

    /**
     * Sets the value of the paramAclId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setParamAclId(JAXBElement<Long> value) {
        this.paramAclId = value;
    }

    /**
     * Gets the value of the aclValue property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAclValue() {
        return aclValue;
    }

    /**
     * Sets the value of the aclValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAclValue(JAXBElement<String> value) {
        this.aclValue = value;
    }

    /**
     * Gets the value of the sharedPaymentAccountLimitType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SharedPaymentAccountLimitType }{@code >}
     *     
     */
    public JAXBElement<SharedPaymentAccountLimitType> getSharedPaymentAccountLimitType() {
        return sharedPaymentAccountLimitType;
    }

    /**
     * Sets the value of the sharedPaymentAccountLimitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SharedPaymentAccountLimitType }{@code >}
     *     
     */
    public void setSharedPaymentAccountLimitType(JAXBElement<SharedPaymentAccountLimitType> value) {
        this.sharedPaymentAccountLimitType = value;
    }

}
