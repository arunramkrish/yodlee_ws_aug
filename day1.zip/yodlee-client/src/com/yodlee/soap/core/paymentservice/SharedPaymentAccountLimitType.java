
package com.yodlee.soap.core.paymentservice;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SharedPaymentAccountLimitType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SharedPaymentAccountLimitType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MONTHLY_PERMISSION"/>
 *     &lt;enumeration value="YEARLY_PERMISSION"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SharedPaymentAccountLimitType")
@XmlEnum
public enum SharedPaymentAccountLimitType {

    MONTHLY_PERMISSION,
    YEARLY_PERMISSION;

    public String value() {
        return name();
    }

    public static SharedPaymentAccountLimitType fromValue(String v) {
        return valueOf(v);
    }

}
