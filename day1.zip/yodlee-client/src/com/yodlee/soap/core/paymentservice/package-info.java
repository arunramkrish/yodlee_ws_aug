@javax.xml.bind.annotation.XmlSchema(namespace = "http://paymentservice.core.soap.yodlee.com")
package com.yodlee.soap.core.paymentservice;
