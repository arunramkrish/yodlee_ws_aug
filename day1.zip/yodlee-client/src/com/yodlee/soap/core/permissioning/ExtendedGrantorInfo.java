
package com.yodlee.soap.core.permissioning;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.Locale;


/**
 * <p>Java class for ExtendedGrantorInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedGrantorInfo">
 *   &lt;complexContent>
 *     &lt;extension base="{http://permissioning.core.soap.yodlee.com}GrantorInfo">
 *       &lt;sequence>
 *         &lt;element name="obo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="locale" type="{http://collections.soap.yodlee.com}Locale" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedGrantorInfo", propOrder = {
    "obo",
    "locale"
})
public class ExtendedGrantorInfo
    extends GrantorInfo
{

    protected boolean obo;
    @XmlElementRef(name = "locale", type = JAXBElement.class, required = false)
    protected JAXBElement<Locale> locale;

    /**
     * Gets the value of the obo property.
     * 
     */
    public boolean isObo() {
        return obo;
    }

    /**
     * Sets the value of the obo property.
     * 
     */
    public void setObo(boolean value) {
        this.obo = value;
    }

    /**
     * Gets the value of the locale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public JAXBElement<Locale> getLocale() {
        return locale;
    }

    /**
     * Sets the value of the locale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Locale }{@code >}
     *     
     */
    public void setLocale(JAXBElement<Locale> value) {
        this.locale = value;
    }

}
