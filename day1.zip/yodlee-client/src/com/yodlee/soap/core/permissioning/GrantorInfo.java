
package com.yodlee.soap.core.permissioning;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.UserType;
import com.yodlee.soap.core.permissioning.searchmanagement.GrantorSearchInfo;


/**
 * <p>Java class for GrantorInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GrantorInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="grantorToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="namespaceId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userType" type="{http://common.soap.yodlee.com}UserType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GrantorInfo", propOrder = {
    "grantorToken",
    "namespaceId",
    "userType"
})
@XmlSeeAlso({
    GrantorSearchInfo.class,
    GrantorInfoWithData.class,
    ExtendedGrantorInfo.class
})
public class GrantorInfo {

    @XmlElementRef(name = "grantorToken", type = JAXBElement.class, required = false)
    protected JAXBElement<String> grantorToken;
    protected Long namespaceId;
    @XmlElementRef(name = "userType", type = JAXBElement.class, required = false)
    protected JAXBElement<UserType> userType;

    /**
     * Gets the value of the grantorToken property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getGrantorToken() {
        return grantorToken;
    }

    /**
     * Sets the value of the grantorToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setGrantorToken(JAXBElement<String> value) {
        this.grantorToken = value;
    }

    /**
     * Gets the value of the namespaceId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getNamespaceId() {
        return namespaceId;
    }

    /**
     * Sets the value of the namespaceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setNamespaceId(Long value) {
        this.namespaceId = value;
    }

    /**
     * Gets the value of the userType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link UserType }{@code >}
     *     
     */
    public JAXBElement<UserType> getUserType() {
        return userType;
    }

    /**
     * Sets the value of the userType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link UserType }{@code >}
     *     
     */
    public void setUserType(JAXBElement<UserType> value) {
        this.userType = value;
    }

}
