
package com.yodlee.soap.core.permissioning;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.collections.Map;


/**
 * <p>Java class for GrantorInfoWithData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GrantorInfoWithData">
 *   &lt;complexContent>
 *     &lt;extension base="{http://permissioning.core.soap.yodlee.com}GrantorInfo">
 *       &lt;sequence>
 *         &lt;element name="profileFields" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="netWorth" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/>
 *         &lt;element name="aggregateData" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="accountStatus" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="advisorList" type="{http://collections.soap.yodlee.com}List" minOccurs="0"/>
 *         &lt;element name="lastAccessTime" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="userName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GrantorInfoWithData", propOrder = {
    "profileFields",
    "netWorth",
    "aggregateData",
    "accountStatus",
    "advisorList",
    "lastAccessTime",
    "userName"
})
public class GrantorInfoWithData
    extends GrantorInfo
{

    @XmlElementRef(name = "profileFields", type = JAXBElement.class, required = false)
    protected JAXBElement<List> profileFields;
    @XmlElementRef(name = "netWorth", type = JAXBElement.class, required = false)
    protected JAXBElement<Object> netWorth;
    @XmlElementRef(name = "aggregateData", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> aggregateData;
    protected Long accountStatus;
    @XmlElementRef(name = "advisorList", type = JAXBElement.class, required = false)
    protected JAXBElement<List> advisorList;
    @XmlElementRef(name = "lastAccessTime", type = JAXBElement.class, required = false)
    protected JAXBElement<Long> lastAccessTime;
    @XmlElementRef(name = "userName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> userName;

    /**
     * Gets the value of the profileFields property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getProfileFields() {
        return profileFields;
    }

    /**
     * Sets the value of the profileFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setProfileFields(JAXBElement<List> value) {
        this.profileFields = value;
    }

    /**
     * Gets the value of the netWorth property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Object }{@code >}
     *     
     */
    public JAXBElement<Object> getNetWorth() {
        return netWorth;
    }

    /**
     * Sets the value of the netWorth property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Object }{@code >}
     *     
     */
    public void setNetWorth(JAXBElement<Object> value) {
        this.netWorth = value;
    }

    /**
     * Gets the value of the aggregateData property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getAggregateData() {
        return aggregateData;
    }

    /**
     * Sets the value of the aggregateData property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setAggregateData(JAXBElement<Map> value) {
        this.aggregateData = value;
    }

    /**
     * Gets the value of the accountStatus property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAccountStatus() {
        return accountStatus;
    }

    /**
     * Sets the value of the accountStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAccountStatus(Long value) {
        this.accountStatus = value;
    }

    /**
     * Gets the value of the advisorList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public JAXBElement<List> getAdvisorList() {
        return advisorList;
    }

    /**
     * Sets the value of the advisorList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link List }{@code >}
     *     
     */
    public void setAdvisorList(JAXBElement<List> value) {
        this.advisorList = value;
    }

    /**
     * Gets the value of the lastAccessTime property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public JAXBElement<Long> getLastAccessTime() {
        return lastAccessTime;
    }

    /**
     * Sets the value of the lastAccessTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Long }{@code >}
     *     
     */
    public void setLastAccessTime(JAXBElement<Long> value) {
        this.lastAccessTime = value;
    }

    /**
     * Gets the value of the userName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserName() {
        return userName;
    }

    /**
     * Sets the value of the userName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserName(JAXBElement<String> value) {
        this.userName = value;
    }

}
