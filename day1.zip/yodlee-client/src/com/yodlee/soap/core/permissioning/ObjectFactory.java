
package com.yodlee.soap.core.permissioning;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.List;
import com.yodlee.soap.collections.Locale;
import com.yodlee.soap.collections.Map;
import com.yodlee.soap.common.UserType;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.permissioning package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GrantorInfoGrantorToken_QNAME = new QName("", "grantorToken");
    private final static QName _GrantorInfoUserType_QNAME = new QName("", "userType");
    private final static QName _GrantorInfoWithDataNetWorth_QNAME = new QName("", "netWorth");
    private final static QName _GrantorInfoWithDataLastAccessTime_QNAME = new QName("", "lastAccessTime");
    private final static QName _GrantorInfoWithDataAdvisorList_QNAME = new QName("", "advisorList");
    private final static QName _GrantorInfoWithDataUserName_QNAME = new QName("", "userName");
    private final static QName _GrantorInfoWithDataAggregateData_QNAME = new QName("", "aggregateData");
    private final static QName _GrantorInfoWithDataProfileFields_QNAME = new QName("", "profileFields");
    private final static QName _ExtendedGrantorInfoLocale_QNAME = new QName("", "locale");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.permissioning
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GrantorInfoWithData }
     * 
     */
    public GrantorInfoWithData createGrantorInfoWithData() {
        return new GrantorInfoWithData();
    }

    /**
     * Create an instance of {@link ExtendedGrantorInfo }
     * 
     */
    public ExtendedGrantorInfo createExtendedGrantorInfo() {
        return new ExtendedGrantorInfo();
    }

    /**
     * Create an instance of {@link GrantorInfo }
     * 
     */
    public GrantorInfo createGrantorInfo() {
        return new GrantorInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "grantorToken", scope = GrantorInfo.class)
    public JAXBElement<String> createGrantorInfoGrantorToken(String value) {
        return new JAXBElement<String>(_GrantorInfoGrantorToken_QNAME, String.class, GrantorInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UserType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userType", scope = GrantorInfo.class)
    public JAXBElement<UserType> createGrantorInfoUserType(UserType value) {
        return new JAXBElement<UserType>(_GrantorInfoUserType_QNAME, UserType.class, GrantorInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "netWorth", scope = GrantorInfoWithData.class)
    public JAXBElement<Object> createGrantorInfoWithDataNetWorth(Object value) {
        return new JAXBElement<Object>(_GrantorInfoWithDataNetWorth_QNAME, Object.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastAccessTime", scope = GrantorInfoWithData.class)
    public JAXBElement<Long> createGrantorInfoWithDataLastAccessTime(Long value) {
        return new JAXBElement<Long>(_GrantorInfoWithDataLastAccessTime_QNAME, Long.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "advisorList", scope = GrantorInfoWithData.class)
    public JAXBElement<List> createGrantorInfoWithDataAdvisorList(List value) {
        return new JAXBElement<List>(_GrantorInfoWithDataAdvisorList_QNAME, List.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "userName", scope = GrantorInfoWithData.class)
    public JAXBElement<String> createGrantorInfoWithDataUserName(String value) {
        return new JAXBElement<String>(_GrantorInfoWithDataUserName_QNAME, String.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "aggregateData", scope = GrantorInfoWithData.class)
    public JAXBElement<Map> createGrantorInfoWithDataAggregateData(Map value) {
        return new JAXBElement<Map>(_GrantorInfoWithDataAggregateData_QNAME, Map.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "profileFields", scope = GrantorInfoWithData.class)
    public JAXBElement<List> createGrantorInfoWithDataProfileFields(List value) {
        return new JAXBElement<List>(_GrantorInfoWithDataProfileFields_QNAME, List.class, GrantorInfoWithData.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Locale }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "locale", scope = ExtendedGrantorInfo.class)
    public JAXBElement<Locale> createExtendedGrantorInfoLocale(Locale value) {
        return new JAXBElement<Locale>(_ExtendedGrantorInfoLocale_QNAME, Locale.class, ExtendedGrantorInfo.class, value);
    }

}
