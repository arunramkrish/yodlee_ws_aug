@javax.xml.bind.annotation.XmlSchema(namespace = "http://permissioning.core.soap.yodlee.com")
package com.yodlee.soap.core.permissioning;
