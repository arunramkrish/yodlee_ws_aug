
package com.yodlee.soap.core.permissioning.searchmanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.collections.common.ArrayOfNVPair;
import com.yodlee.soap.core.permissioning.GrantorInfo;


/**
 * <p>Java class for GrantorSearchInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GrantorSearchInfo">
 *   &lt;complexContent>
 *     &lt;extension base="{http://permissioning.core.soap.yodlee.com}GrantorInfo">
 *       &lt;sequence>
 *         &lt;element name="profileFields" type="{http://common.collections.soap.yodlee.com}ArrayOfNVPair" minOccurs="0"/>
 *         &lt;element name="searchInfo" type="{http://common.collections.soap.yodlee.com}ArrayOfNVPair" minOccurs="0"/>
 *         &lt;element name="date" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GrantorSearchInfo", propOrder = {
    "profileFields",
    "searchInfo",
    "date"
})
public class GrantorSearchInfo
    extends GrantorInfo
{

    @XmlElementRef(name = "profileFields", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfNVPair> profileFields;
    @XmlElementRef(name = "searchInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<ArrayOfNVPair> searchInfo;
    @XmlElementRef(name = "date", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> date;

    /**
     * Gets the value of the profileFields property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public JAXBElement<ArrayOfNVPair> getProfileFields() {
        return profileFields;
    }

    /**
     * Sets the value of the profileFields property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public void setProfileFields(JAXBElement<ArrayOfNVPair> value) {
        this.profileFields = value;
    }

    /**
     * Gets the value of the searchInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public JAXBElement<ArrayOfNVPair> getSearchInfo() {
        return searchInfo;
    }

    /**
     * Sets the value of the searchInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}
     *     
     */
    public void setSearchInfo(JAXBElement<ArrayOfNVPair> value) {
        this.searchInfo = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setDate(JAXBElement<XMLGregorianCalendar> value) {
        this.date = value;
    }

}
