
package com.yodlee.soap.core.permissioning.searchmanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.common.ArrayOfNVPair;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.permissioning.searchmanagement package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GrantorSearchInfoSearchInfo_QNAME = new QName("", "searchInfo");
    private final static QName _GrantorSearchInfoProfileFields_QNAME = new QName("", "profileFields");
    private final static QName _GrantorSearchInfoDate_QNAME = new QName("", "date");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.permissioning.searchmanagement
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GrantorSearchInfo }
     * 
     */
    public GrantorSearchInfo createGrantorSearchInfo() {
        return new GrantorSearchInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "searchInfo", scope = GrantorSearchInfo.class)
    public JAXBElement<ArrayOfNVPair> createGrantorSearchInfoSearchInfo(ArrayOfNVPair value) {
        return new JAXBElement<ArrayOfNVPair>(_GrantorSearchInfoSearchInfo_QNAME, ArrayOfNVPair.class, GrantorSearchInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfNVPair }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "profileFields", scope = GrantorSearchInfo.class)
    public JAXBElement<ArrayOfNVPair> createGrantorSearchInfoProfileFields(ArrayOfNVPair value) {
        return new JAXBElement<ArrayOfNVPair>(_GrantorSearchInfoProfileFields_QNAME, ArrayOfNVPair.class, GrantorSearchInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "date", scope = GrantorSearchInfo.class)
    public JAXBElement<XMLGregorianCalendar> createGrantorSearchInfoDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_GrantorSearchInfoDate_QNAME, XMLGregorianCalendar.class, GrantorSearchInfo.class, value);
    }

}
