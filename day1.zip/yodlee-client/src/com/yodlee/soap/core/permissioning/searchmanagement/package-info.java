@javax.xml.bind.annotation.XmlSchema(namespace = "http://searchmanagement.permissioning.core.soap.yodlee.com")
package com.yodlee.soap.core.permissioning.searchmanagement;
