
package com.yodlee.soap.core.progressiverefresh;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgressiveRefreshStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ProgressiveRefreshStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="STATUS_UNKNOWN"/>
 *     &lt;enumeration value="IN_PROGRESS"/>
 *     &lt;enumeration value="PARTIAL_COMPLETE"/>
 *     &lt;enumeration value="COMPLETED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "ProgressiveRefreshStatus", namespace = "http://progressiverefresh.core.soap.yodlee.com")
@XmlEnum
public enum ProgressiveRefreshStatus {

    STATUS_UNKNOWN,
    IN_PROGRESS,
    PARTIAL_COMPLETE,
    COMPLETED;

    public String value() {
        return name();
    }

    public static ProgressiveRefreshStatus fromValue(String v) {
        return valueOf(v);
    }

}
