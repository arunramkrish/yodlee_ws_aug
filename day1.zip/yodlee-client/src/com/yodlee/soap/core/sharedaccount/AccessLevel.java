
package com.yodlee.soap.core.sharedaccount;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccessLevel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="AccessLevel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="VIEW"/>
 *     &lt;enumeration value="VIEW_ALERT"/>
 *     &lt;enumeration value="FULL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "AccessLevel")
@XmlEnum
public enum AccessLevel {

    VIEW,
    VIEW_ALERT,
    FULL;

    public String value() {
        return name();
    }

    public static AccessLevel fromValue(String v) {
        return valueOf(v);
    }

}
