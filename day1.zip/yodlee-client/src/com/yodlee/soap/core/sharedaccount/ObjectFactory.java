
package com.yodlee.soap.core.sharedaccount;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.sharedaccount package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SharedAccountInfoMemo_QNAME = new QName("", "memo");
    private final static QName _SharedAccountInfoRequestId_QNAME = new QName("", "requestId");
    private final static QName _SharedAccountInfoRecipientName_QNAME = new QName("", "recipientName");
    private final static QName _SharedAccountInfoExpiryDate_QNAME = new QName("", "expiryDate");
    private final static QName _SharedAccountInfoSharer_QNAME = new QName("", "sharer");
    private final static QName _SharedAccountInfoPersonalMessage_QNAME = new QName("", "personalMessage");
    private final static QName _SharedAccountInfoSharedOn_QNAME = new QName("", "sharedOn");
    private final static QName _SharedAccountInfoAcceptedOn_QNAME = new QName("", "acceptedOn");
    private final static QName _SharedAccountInfoAccessLevel_QNAME = new QName("", "accessLevel");
    private final static QName _SharedAccountInfoRecipient_QNAME = new QName("", "recipient");
    private final static QName _SharedAccountInfoExpiredOn_QNAME = new QName("", "expiredOn");
    private final static QName _SharedAccountInfoRecipientEmailId_QNAME = new QName("", "recipientEmailId");
    private final static QName _SharedAccountUserLastName_QNAME = new QName("", "lastName");
    private final static QName _SharedAccountUserFirstName_QNAME = new QName("", "firstName");
    private final static QName _SharedAccountUserLoginName_QNAME = new QName("", "loginName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.sharedaccount
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SharedAccountInfo }
     * 
     */
    public SharedAccountInfo createSharedAccountInfo() {
        return new SharedAccountInfo();
    }

    /**
     * Create an instance of {@link SharedAccountUser }
     * 
     */
    public SharedAccountUser createSharedAccountUser() {
        return new SharedAccountUser();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "memo", scope = SharedAccountInfo.class)
    public JAXBElement<String> createSharedAccountInfoMemo(String value) {
        return new JAXBElement<String>(_SharedAccountInfoMemo_QNAME, String.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "requestId", scope = SharedAccountInfo.class)
    public JAXBElement<String> createSharedAccountInfoRequestId(String value) {
        return new JAXBElement<String>(_SharedAccountInfoRequestId_QNAME, String.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "recipientName", scope = SharedAccountInfo.class)
    public JAXBElement<String> createSharedAccountInfoRecipientName(String value) {
        return new JAXBElement<String>(_SharedAccountInfoRecipientName_QNAME, String.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "expiryDate", scope = SharedAccountInfo.class)
    public JAXBElement<XMLGregorianCalendar> createSharedAccountInfoExpiryDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SharedAccountInfoExpiryDate_QNAME, XMLGregorianCalendar.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharer", scope = SharedAccountInfo.class)
    public JAXBElement<SharedAccountUser> createSharedAccountInfoSharer(SharedAccountUser value) {
        return new JAXBElement<SharedAccountUser>(_SharedAccountInfoSharer_QNAME, SharedAccountUser.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "personalMessage", scope = SharedAccountInfo.class)
    public JAXBElement<String> createSharedAccountInfoPersonalMessage(String value) {
        return new JAXBElement<String>(_SharedAccountInfoPersonalMessage_QNAME, String.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharedOn", scope = SharedAccountInfo.class)
    public JAXBElement<XMLGregorianCalendar> createSharedAccountInfoSharedOn(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SharedAccountInfoSharedOn_QNAME, XMLGregorianCalendar.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "acceptedOn", scope = SharedAccountInfo.class)
    public JAXBElement<XMLGregorianCalendar> createSharedAccountInfoAcceptedOn(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SharedAccountInfoAcceptedOn_QNAME, XMLGregorianCalendar.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AccessLevel }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "accessLevel", scope = SharedAccountInfo.class)
    public JAXBElement<AccessLevel> createSharedAccountInfoAccessLevel(AccessLevel value) {
        return new JAXBElement<AccessLevel>(_SharedAccountInfoAccessLevel_QNAME, AccessLevel.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "recipient", scope = SharedAccountInfo.class)
    public JAXBElement<SharedAccountUser> createSharedAccountInfoRecipient(SharedAccountUser value) {
        return new JAXBElement<SharedAccountUser>(_SharedAccountInfoRecipient_QNAME, SharedAccountUser.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "expiredOn", scope = SharedAccountInfo.class)
    public JAXBElement<XMLGregorianCalendar> createSharedAccountInfoExpiredOn(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SharedAccountInfoExpiredOn_QNAME, XMLGregorianCalendar.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "recipientEmailId", scope = SharedAccountInfo.class)
    public JAXBElement<String> createSharedAccountInfoRecipientEmailId(String value) {
        return new JAXBElement<String>(_SharedAccountInfoRecipientEmailId_QNAME, String.class, SharedAccountInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "lastName", scope = SharedAccountUser.class)
    public JAXBElement<String> createSharedAccountUserLastName(String value) {
        return new JAXBElement<String>(_SharedAccountUserLastName_QNAME, String.class, SharedAccountUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "firstName", scope = SharedAccountUser.class)
    public JAXBElement<String> createSharedAccountUserFirstName(String value) {
        return new JAXBElement<String>(_SharedAccountUserFirstName_QNAME, String.class, SharedAccountUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loginName", scope = SharedAccountUser.class)
    public JAXBElement<String> createSharedAccountUserLoginName(String value) {
        return new JAXBElement<String>(_SharedAccountUserLoginName_QNAME, String.class, SharedAccountUser.class, value);
    }

}
