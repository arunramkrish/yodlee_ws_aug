
package com.yodlee.soap.core.sharedaccount;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.yodlee.soap.core.paymentservice.PaymentAccountSharingInfo;


/**
 * <p>Java class for SharedAccountInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SharedAccountInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sharedAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="memItemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemAccountId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accessLevel" type="{http://sharedaccount.core.soap.yodlee.com}AccessLevel" minOccurs="0"/>
 *         &lt;element name="sharer" type="{http://sharedaccount.core.soap.yodlee.com}SharedAccountUser" minOccurs="0"/>
 *         &lt;element name="recipient" type="{http://sharedaccount.core.soap.yodlee.com}SharedAccountUser" minOccurs="0"/>
 *         &lt;element name="sharedByUserId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sharedToUserId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isShared" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="unsharedReasonCode" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="isSecretTokenRequired" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="recipientEmailId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="recipientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requestId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sharedOn" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="expiryDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="acceptedOn" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="expiredOn" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="personalMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SharedAccountInfo", propOrder = {
    "sharedAccountId",
    "memItemId",
    "itemAccountId",
    "memo",
    "accessLevel",
    "sharer",
    "recipient",
    "sharedByUserId",
    "sharedToUserId",
    "isShared",
    "unsharedReasonCode",
    "isSecretTokenRequired",
    "recipientEmailId",
    "recipientName",
    "requestId",
    "sharedOn",
    "expiryDate",
    "acceptedOn",
    "expiredOn",
    "personalMessage"
})
@XmlSeeAlso({
    PaymentAccountSharingInfo.class
})
public class SharedAccountInfo {

    protected Long sharedAccountId;
    protected Long memItemId;
    protected Long itemAccountId;
    @XmlElementRef(name = "memo", type = JAXBElement.class, required = false)
    protected JAXBElement<String> memo;
    @XmlElementRef(name = "accessLevel", type = JAXBElement.class, required = false)
    protected JAXBElement<AccessLevel> accessLevel;
    @XmlElementRef(name = "sharer", type = JAXBElement.class, required = false)
    protected JAXBElement<SharedAccountUser> sharer;
    @XmlElementRef(name = "recipient", type = JAXBElement.class, required = false)
    protected JAXBElement<SharedAccountUser> recipient;
    protected Long sharedByUserId;
    protected Long sharedToUserId;
    protected boolean isShared;
    protected Long unsharedReasonCode;
    protected boolean isSecretTokenRequired;
    @XmlElementRef(name = "recipientEmailId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recipientEmailId;
    @XmlElementRef(name = "recipientName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> recipientName;
    @XmlElementRef(name = "requestId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> requestId;
    @XmlElementRef(name = "sharedOn", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> sharedOn;
    @XmlElementRef(name = "expiryDate", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> expiryDate;
    @XmlElementRef(name = "acceptedOn", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> acceptedOn;
    @XmlElementRef(name = "expiredOn", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> expiredOn;
    @XmlElementRef(name = "personalMessage", type = JAXBElement.class, required = false)
    protected JAXBElement<String> personalMessage;

    /**
     * Gets the value of the sharedAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSharedAccountId() {
        return sharedAccountId;
    }

    /**
     * Sets the value of the sharedAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSharedAccountId(Long value) {
        this.sharedAccountId = value;
    }

    /**
     * Gets the value of the memItemId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMemItemId() {
        return memItemId;
    }

    /**
     * Sets the value of the memItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMemItemId(Long value) {
        this.memItemId = value;
    }

    /**
     * Gets the value of the itemAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getItemAccountId() {
        return itemAccountId;
    }

    /**
     * Sets the value of the itemAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setItemAccountId(Long value) {
        this.itemAccountId = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMemo(JAXBElement<String> value) {
        this.memo = value;
    }

    /**
     * Gets the value of the accessLevel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link AccessLevel }{@code >}
     *     
     */
    public JAXBElement<AccessLevel> getAccessLevel() {
        return accessLevel;
    }

    /**
     * Sets the value of the accessLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link AccessLevel }{@code >}
     *     
     */
    public void setAccessLevel(JAXBElement<AccessLevel> value) {
        this.accessLevel = value;
    }

    /**
     * Gets the value of the sharer property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}
     *     
     */
    public JAXBElement<SharedAccountUser> getSharer() {
        return sharer;
    }

    /**
     * Sets the value of the sharer property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}
     *     
     */
    public void setSharer(JAXBElement<SharedAccountUser> value) {
        this.sharer = value;
    }

    /**
     * Gets the value of the recipient property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}
     *     
     */
    public JAXBElement<SharedAccountUser> getRecipient() {
        return recipient;
    }

    /**
     * Sets the value of the recipient property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link SharedAccountUser }{@code >}
     *     
     */
    public void setRecipient(JAXBElement<SharedAccountUser> value) {
        this.recipient = value;
    }

    /**
     * Gets the value of the sharedByUserId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSharedByUserId() {
        return sharedByUserId;
    }

    /**
     * Sets the value of the sharedByUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSharedByUserId(Long value) {
        this.sharedByUserId = value;
    }

    /**
     * Gets the value of the sharedToUserId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getSharedToUserId() {
        return sharedToUserId;
    }

    /**
     * Sets the value of the sharedToUserId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setSharedToUserId(Long value) {
        this.sharedToUserId = value;
    }

    /**
     * Gets the value of the isShared property.
     * 
     */
    public boolean isIsShared() {
        return isShared;
    }

    /**
     * Sets the value of the isShared property.
     * 
     */
    public void setIsShared(boolean value) {
        this.isShared = value;
    }

    /**
     * Gets the value of the unsharedReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUnsharedReasonCode() {
        return unsharedReasonCode;
    }

    /**
     * Sets the value of the unsharedReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUnsharedReasonCode(Long value) {
        this.unsharedReasonCode = value;
    }

    /**
     * Gets the value of the isSecretTokenRequired property.
     * 
     */
    public boolean isIsSecretTokenRequired() {
        return isSecretTokenRequired;
    }

    /**
     * Sets the value of the isSecretTokenRequired property.
     * 
     */
    public void setIsSecretTokenRequired(boolean value) {
        this.isSecretTokenRequired = value;
    }

    /**
     * Gets the value of the recipientEmailId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRecipientEmailId() {
        return recipientEmailId;
    }

    /**
     * Sets the value of the recipientEmailId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRecipientEmailId(JAXBElement<String> value) {
        this.recipientEmailId = value;
    }

    /**
     * Gets the value of the recipientName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRecipientName() {
        return recipientName;
    }

    /**
     * Sets the value of the recipientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRecipientName(JAXBElement<String> value) {
        this.recipientName = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRequestId(JAXBElement<String> value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the sharedOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getSharedOn() {
        return sharedOn;
    }

    /**
     * Sets the value of the sharedOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setSharedOn(JAXBElement<XMLGregorianCalendar> value) {
        this.sharedOn = value;
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setExpiryDate(JAXBElement<XMLGregorianCalendar> value) {
        this.expiryDate = value;
    }

    /**
     * Gets the value of the acceptedOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getAcceptedOn() {
        return acceptedOn;
    }

    /**
     * Sets the value of the acceptedOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setAcceptedOn(JAXBElement<XMLGregorianCalendar> value) {
        this.acceptedOn = value;
    }

    /**
     * Gets the value of the expiredOn property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getExpiredOn() {
        return expiredOn;
    }

    /**
     * Sets the value of the expiredOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setExpiredOn(JAXBElement<XMLGregorianCalendar> value) {
        this.expiredOn = value;
    }

    /**
     * Gets the value of the personalMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPersonalMessage() {
        return personalMessage;
    }

    /**
     * Sets the value of the personalMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPersonalMessage(JAXBElement<String> value) {
        this.personalMessage = value;
    }

}
