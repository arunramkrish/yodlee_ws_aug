@javax.xml.bind.annotation.XmlSchema(namespace = "http://sharedaccount.core.soap.yodlee.com")
package com.yodlee.soap.core.sharedaccount;
