
package com.yodlee.soap.core.system.config.settings;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.List;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.core.system.config.settings package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConfigValueDescription_QNAME = new QName("", "description");
    private final static QName _ConfigValueModuleName_QNAME = new QName("", "moduleName");
    private final static QName _ConfigValueValueOrder_QNAME = new QName("", "valueOrder");
    private final static QName _ConfigValueGroupModuleName_QNAME = new QName("", "groupModuleName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.core.system.config.settings
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConfigValue }
     * 
     */
    public ConfigValue createConfigValue() {
        return new ConfigValue();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "description", scope = ConfigValue.class)
    public JAXBElement<String> createConfigValueDescription(String value) {
        return new JAXBElement<String>(_ConfigValueDescription_QNAME, String.class, ConfigValue.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "moduleName", scope = ConfigValue.class)
    public JAXBElement<String> createConfigValueModuleName(String value) {
        return new JAXBElement<String>(_ConfigValueModuleName_QNAME, String.class, ConfigValue.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link List }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "valueOrder", scope = ConfigValue.class)
    public JAXBElement<List> createConfigValueValueOrder(List value) {
        return new JAXBElement<List>(_ConfigValueValueOrder_QNAME, List.class, ConfigValue.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "groupModuleName", scope = ConfigValue.class)
    public JAXBElement<String> createConfigValueGroupModuleName(String value) {
        return new JAXBElement<String>(_ConfigValueGroupModuleName_QNAME, String.class, ConfigValue.class, value);
    }

}
