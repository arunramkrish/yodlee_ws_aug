@javax.xml.bind.annotation.XmlSchema(namespace = "http://settings.config.system.core.soap.yodlee.com")
package com.yodlee.soap.core.system.config.settings;
