@javax.xml.bind.annotation.XmlSchema(namespace = "http://usermanagement.core.soap.yodlee.com")
package com.yodlee.soap.core.usermanagement;
