
package com.yodlee.soap.ext.ccw;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.ExternalAuthenticationCredentials;


/**
 * <p>Java class for CCWCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CCWCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://login.ext.soap.yodlee.com}ExternalAuthenticationCredentials">
 *       &lt;sequence>
 *         &lt;element name="ccwToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CCWCredentials", propOrder = {
    "ccwToken"
})
public class CCWCredentials
    extends ExternalAuthenticationCredentials
{

    @XmlElementRef(name = "ccwToken", type = JAXBElement.class, required = false)
    protected JAXBElement<String> ccwToken;

    /**
     * Gets the value of the ccwToken property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCcwToken() {
        return ccwToken;
    }

    /**
     * Sets the value of the ccwToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCcwToken(JAXBElement<String> value) {
        this.ccwToken = value;
    }

}
