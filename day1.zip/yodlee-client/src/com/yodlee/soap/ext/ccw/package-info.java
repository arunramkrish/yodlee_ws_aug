@javax.xml.bind.annotation.XmlSchema(namespace = "http://ccw.ext.soap.yodlee.com")
package com.yodlee.soap.ext.ccw;
