
package com.yodlee.soap.ext.login;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.UserCredentials;
import com.yodlee.soap.ext.ccw.CCWCredentials;
import com.yodlee.soap.ext.saml.SAMLCredentials;


/**
 * <p>Java class for ExternalAuthenticationCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExternalAuthenticationCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}UserCredentials">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExternalAuthenticationCredentials")
@XmlSeeAlso({
    CCWCredentials.class,
    SAMLCredentials.class
})
public class ExternalAuthenticationCredentials
    extends UserCredentials
{


}
