
package com.yodlee.soap.ext.login;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.UserCredentials;
import com.yodlee.soap.core.usermanagement.ExternalUserCredentials;


/**
 * <p>Java class for OAuthAccessCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OAuthAccessCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}UserCredentials">
 *       &lt;sequence>
 *         &lt;element name="applicationIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tokenSecret" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="signatureMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="signedToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="memId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="longLifeToken" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="externalUserCredentials" type="{http://usermanagement.core.soap.yodlee.com}ExternalUserCredentials" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OAuthAccessCredentials", propOrder = {
    "applicationIdentifier",
    "token",
    "tokenSecret",
    "signatureMethod",
    "signedToken",
    "memId",
    "longLifeToken",
    "externalUserCredentials"
})
public class OAuthAccessCredentials
    extends UserCredentials
{

    @XmlElementRef(name = "applicationIdentifier", type = JAXBElement.class, required = false)
    protected JAXBElement<String> applicationIdentifier;
    @XmlElementRef(name = "token", type = JAXBElement.class, required = false)
    protected JAXBElement<String> token;
    @XmlElementRef(name = "tokenSecret", type = JAXBElement.class, required = false)
    protected JAXBElement<String> tokenSecret;
    @XmlElementRef(name = "signatureMethod", type = JAXBElement.class, required = false)
    protected JAXBElement<String> signatureMethod;
    @XmlElementRef(name = "signedToken", type = JAXBElement.class, required = false)
    protected JAXBElement<String> signedToken;
    protected Long memId;
    protected boolean longLifeToken;
    @XmlElementRef(name = "externalUserCredentials", type = JAXBElement.class, required = false)
    protected JAXBElement<ExternalUserCredentials> externalUserCredentials;

    /**
     * Gets the value of the applicationIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApplicationIdentifier() {
        return applicationIdentifier;
    }

    /**
     * Sets the value of the applicationIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApplicationIdentifier(JAXBElement<String> value) {
        this.applicationIdentifier = value;
    }

    /**
     * Gets the value of the token property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setToken(JAXBElement<String> value) {
        this.token = value;
    }

    /**
     * Gets the value of the tokenSecret property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTokenSecret() {
        return tokenSecret;
    }

    /**
     * Sets the value of the tokenSecret property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTokenSecret(JAXBElement<String> value) {
        this.tokenSecret = value;
    }

    /**
     * Gets the value of the signatureMethod property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSignatureMethod() {
        return signatureMethod;
    }

    /**
     * Sets the value of the signatureMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSignatureMethod(JAXBElement<String> value) {
        this.signatureMethod = value;
    }

    /**
     * Gets the value of the signedToken property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSignedToken() {
        return signedToken;
    }

    /**
     * Sets the value of the signedToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSignedToken(JAXBElement<String> value) {
        this.signedToken = value;
    }

    /**
     * Gets the value of the memId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMemId() {
        return memId;
    }

    /**
     * Sets the value of the memId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMemId(Long value) {
        this.memId = value;
    }

    /**
     * Gets the value of the longLifeToken property.
     * 
     */
    public boolean isLongLifeToken() {
        return longLifeToken;
    }

    /**
     * Sets the value of the longLifeToken property.
     * 
     */
    public void setLongLifeToken(boolean value) {
        this.longLifeToken = value;
    }

    /**
     * Gets the value of the externalUserCredentials property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExternalUserCredentials }{@code >}
     *     
     */
    public JAXBElement<ExternalUserCredentials> getExternalUserCredentials() {
        return externalUserCredentials;
    }

    /**
     * Sets the value of the externalUserCredentials property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExternalUserCredentials }{@code >}
     *     
     */
    public void setExternalUserCredentials(JAXBElement<ExternalUserCredentials> value) {
        this.externalUserCredentials = value;
    }

}
