
package com.yodlee.soap.ext.login;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.core.usermanagement.ExternalUserCredentials;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.ext.login package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _TokenizedCredentialsToken_QNAME = new QName("", "token");
    private final static QName _PasswordCredentialsPassword_QNAME = new QName("", "password");
    private final static QName _PasswordCredentialsLoginName_QNAME = new QName("", "loginName");
    private final static QName _SMSCredentialsSmsNumber_QNAME = new QName("", "smsNumber");
    private final static QName _OAuthAccessCredentialsApplicationIdentifier_QNAME = new QName("", "applicationIdentifier");
    private final static QName _OAuthAccessCredentialsSignatureMethod_QNAME = new QName("", "signatureMethod");
    private final static QName _OAuthAccessCredentialsTokenSecret_QNAME = new QName("", "tokenSecret");
    private final static QName _OAuthAccessCredentialsSignedToken_QNAME = new QName("", "signedToken");
    private final static QName _OAuthAccessCredentialsExternalUserCredentials_QNAME = new QName("", "externalUserCredentials");
    private final static QName _YSSOCredentialsYssoLoginName_QNAME = new QName("", "yssoLoginName");
    private final static QName _YSSOCredentialsYssoPassword_QNAME = new QName("", "yssoPassword");
    private final static QName _PWSSessionCredentialsSessionToken_QNAME = new QName("", "sessionToken");
    private final static QName _PinCredentialsPin_QNAME = new QName("", "pin");
    private final static QName _SharedLoginCredentialsSharerToken_QNAME = new QName("", "sharerToken");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.ext.login
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SessionCredentials }
     * 
     */
    public SessionCredentials createSessionCredentials() {
        return new SessionCredentials();
    }

    /**
     * Create an instance of {@link SMSCredentials }
     * 
     */
    public SMSCredentials createSMSCredentials() {
        return new SMSCredentials();
    }

    /**
     * Create an instance of {@link TokenizedCredentials }
     * 
     */
    public TokenizedCredentials createTokenizedCredentials() {
        return new TokenizedCredentials();
    }

    /**
     * Create an instance of {@link SharedLoginCredentials }
     * 
     */
    public SharedLoginCredentials createSharedLoginCredentials() {
        return new SharedLoginCredentials();
    }

    /**
     * Create an instance of {@link YSSOCredentials }
     * 
     */
    public YSSOCredentials createYSSOCredentials() {
        return new YSSOCredentials();
    }

    /**
     * Create an instance of {@link PasswordCredentials }
     * 
     */
    public PasswordCredentials createPasswordCredentials() {
        return new PasswordCredentials();
    }

    /**
     * Create an instance of {@link PinCredentials }
     * 
     */
    public PinCredentials createPinCredentials() {
        return new PinCredentials();
    }

    /**
     * Create an instance of {@link OAuthAccessCredentials }
     * 
     */
    public OAuthAccessCredentials createOAuthAccessCredentials() {
        return new OAuthAccessCredentials();
    }

    /**
     * Create an instance of {@link CobrandPasswordCredentials }
     * 
     */
    public CobrandPasswordCredentials createCobrandPasswordCredentials() {
        return new CobrandPasswordCredentials();
    }

    /**
     * Create an instance of {@link ExternalAuthenticationCredentials }
     * 
     */
    public ExternalAuthenticationCredentials createExternalAuthenticationCredentials() {
        return new ExternalAuthenticationCredentials();
    }

    /**
     * Create an instance of {@link UncertifiedSessionCredentials }
     * 
     */
    public UncertifiedSessionCredentials createUncertifiedSessionCredentials() {
        return new UncertifiedSessionCredentials();
    }

    /**
     * Create an instance of {@link PWSSessionCredentials }
     * 
     */
    public PWSSessionCredentials createPWSSessionCredentials() {
        return new PWSSessionCredentials();
    }

    /**
     * Create an instance of {@link PWSCredentials }
     * 
     */
    public PWSCredentials createPWSCredentials() {
        return new PWSCredentials();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "token", scope = TokenizedCredentials.class)
    public JAXBElement<String> createTokenizedCredentialsToken(String value) {
        return new JAXBElement<String>(_TokenizedCredentialsToken_QNAME, String.class, TokenizedCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "password", scope = PasswordCredentials.class)
    public JAXBElement<String> createPasswordCredentialsPassword(String value) {
        return new JAXBElement<String>(_PasswordCredentialsPassword_QNAME, String.class, PasswordCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loginName", scope = PasswordCredentials.class)
    public JAXBElement<String> createPasswordCredentialsLoginName(String value) {
        return new JAXBElement<String>(_PasswordCredentialsLoginName_QNAME, String.class, PasswordCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "smsNumber", scope = SMSCredentials.class)
    public JAXBElement<String> createSMSCredentialsSmsNumber(String value) {
        return new JAXBElement<String>(_SMSCredentialsSmsNumber_QNAME, String.class, SMSCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "applicationIdentifier", scope = OAuthAccessCredentials.class)
    public JAXBElement<String> createOAuthAccessCredentialsApplicationIdentifier(String value) {
        return new JAXBElement<String>(_OAuthAccessCredentialsApplicationIdentifier_QNAME, String.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "signatureMethod", scope = OAuthAccessCredentials.class)
    public JAXBElement<String> createOAuthAccessCredentialsSignatureMethod(String value) {
        return new JAXBElement<String>(_OAuthAccessCredentialsSignatureMethod_QNAME, String.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "token", scope = OAuthAccessCredentials.class)
    public JAXBElement<String> createOAuthAccessCredentialsToken(String value) {
        return new JAXBElement<String>(_TokenizedCredentialsToken_QNAME, String.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "tokenSecret", scope = OAuthAccessCredentials.class)
    public JAXBElement<String> createOAuthAccessCredentialsTokenSecret(String value) {
        return new JAXBElement<String>(_OAuthAccessCredentialsTokenSecret_QNAME, String.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "signedToken", scope = OAuthAccessCredentials.class)
    public JAXBElement<String> createOAuthAccessCredentialsSignedToken(String value) {
        return new JAXBElement<String>(_OAuthAccessCredentialsSignedToken_QNAME, String.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExternalUserCredentials }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "externalUserCredentials", scope = OAuthAccessCredentials.class)
    public JAXBElement<ExternalUserCredentials> createOAuthAccessCredentialsExternalUserCredentials(ExternalUserCredentials value) {
        return new JAXBElement<ExternalUserCredentials>(_OAuthAccessCredentialsExternalUserCredentials_QNAME, ExternalUserCredentials.class, OAuthAccessCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "yssoLoginName", scope = YSSOCredentials.class)
    public JAXBElement<String> createYSSOCredentialsYssoLoginName(String value) {
        return new JAXBElement<String>(_YSSOCredentialsYssoLoginName_QNAME, String.class, YSSOCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "yssoPassword", scope = YSSOCredentials.class)
    public JAXBElement<String> createYSSOCredentialsYssoPassword(String value) {
        return new JAXBElement<String>(_YSSOCredentialsYssoPassword_QNAME, String.class, YSSOCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sessionToken", scope = PWSSessionCredentials.class)
    public JAXBElement<String> createPWSSessionCredentialsSessionToken(String value) {
        return new JAXBElement<String>(_PWSSessionCredentialsSessionToken_QNAME, String.class, PWSSessionCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sessionToken", scope = UncertifiedSessionCredentials.class)
    public JAXBElement<String> createUncertifiedSessionCredentialsSessionToken(String value) {
        return new JAXBElement<String>(_PWSSessionCredentialsSessionToken_QNAME, String.class, UncertifiedSessionCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "password", scope = PWSCredentials.class)
    public JAXBElement<String> createPWSCredentialsPassword(String value) {
        return new JAXBElement<String>(_PasswordCredentialsPassword_QNAME, String.class, PWSCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loginName", scope = PWSCredentials.class)
    public JAXBElement<String> createPWSCredentialsLoginName(String value) {
        return new JAXBElement<String>(_PasswordCredentialsLoginName_QNAME, String.class, PWSCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "pin", scope = PinCredentials.class)
    public JAXBElement<String> createPinCredentialsPin(String value) {
        return new JAXBElement<String>(_PinCredentialsPin_QNAME, String.class, PinCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loginName", scope = PinCredentials.class)
    public JAXBElement<String> createPinCredentialsLoginName(String value) {
        return new JAXBElement<String>(_PasswordCredentialsLoginName_QNAME, String.class, PinCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sharerToken", scope = SharedLoginCredentials.class)
    public JAXBElement<String> createSharedLoginCredentialsSharerToken(String value) {
        return new JAXBElement<String>(_SharedLoginCredentialsSharerToken_QNAME, String.class, SharedLoginCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sessionToken", scope = SessionCredentials.class)
    public JAXBElement<String> createSessionCredentialsSessionToken(String value) {
        return new JAXBElement<String>(_PWSSessionCredentialsSessionToken_QNAME, String.class, SessionCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "password", scope = CobrandPasswordCredentials.class)
    public JAXBElement<String> createCobrandPasswordCredentialsPassword(String value) {
        return new JAXBElement<String>(_PasswordCredentialsPassword_QNAME, String.class, CobrandPasswordCredentials.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "loginName", scope = CobrandPasswordCredentials.class)
    public JAXBElement<String> createCobrandPasswordCredentialsLoginName(String value) {
        return new JAXBElement<String>(_PasswordCredentialsLoginName_QNAME, String.class, CobrandPasswordCredentials.class, value);
    }

}
