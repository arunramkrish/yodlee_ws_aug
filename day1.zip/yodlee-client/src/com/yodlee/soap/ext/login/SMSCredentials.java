
package com.yodlee.soap.ext.login;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.UserCredentials;


/**
 * <p>Java class for SMSCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SMSCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}UserCredentials">
 *       &lt;sequence>
 *         &lt;element name="smsNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SMSCredentials", propOrder = {
    "smsNumber"
})
public class SMSCredentials
    extends UserCredentials
{

    @XmlElementRef(name = "smsNumber", type = JAXBElement.class, required = false)
    protected JAXBElement<String> smsNumber;

    /**
     * Gets the value of the smsNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSmsNumber() {
        return smsNumber;
    }

    /**
     * Sets the value of the smsNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSmsNumber(JAXBElement<String> value) {
        this.smsNumber = value;
    }

}
