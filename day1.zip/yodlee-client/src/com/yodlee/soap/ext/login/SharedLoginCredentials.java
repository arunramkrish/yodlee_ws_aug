
package com.yodlee.soap.ext.login;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SharedLoginCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SharedLoginCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://login.ext.soap.yodlee.com}SessionCredentials">
 *       &lt;sequence>
 *         &lt;element name="sharerToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SharedLoginCredentials", propOrder = {
    "sharerToken"
})
public class SharedLoginCredentials
    extends SessionCredentials
{

    @XmlElementRef(name = "sharerToken", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sharerToken;

    /**
     * Gets the value of the sharerToken property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSharerToken() {
        return sharerToken;
    }

    /**
     * Sets the value of the sharerToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSharerToken(JAXBElement<String> value) {
        this.sharerToken = value;
    }

}
