
package com.yodlee.soap.ext.login;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.common.UserCredentials;


/**
 * <p>Java class for YSSOCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="YSSOCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.soap.yodlee.com}UserCredentials">
 *       &lt;sequence>
 *         &lt;element name="yssoLoginName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="yssoPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "YSSOCredentials", propOrder = {
    "yssoLoginName",
    "yssoPassword"
})
public class YSSOCredentials
    extends UserCredentials
{

    @XmlElementRef(name = "yssoLoginName", type = JAXBElement.class, required = false)
    protected JAXBElement<String> yssoLoginName;
    @XmlElementRef(name = "yssoPassword", type = JAXBElement.class, required = false)
    protected JAXBElement<String> yssoPassword;

    /**
     * Gets the value of the yssoLoginName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getYssoLoginName() {
        return yssoLoginName;
    }

    /**
     * Sets the value of the yssoLoginName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setYssoLoginName(JAXBElement<String> value) {
        this.yssoLoginName = value;
    }

    /**
     * Gets the value of the yssoPassword property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getYssoPassword() {
        return yssoPassword;
    }

    /**
     * Sets the value of the yssoPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setYssoPassword(JAXBElement<String> value) {
        this.yssoPassword = value;
    }

}
