@javax.xml.bind.annotation.XmlSchema(namespace = "http://login.ext.soap.yodlee.com")
package com.yodlee.soap.ext.login;
