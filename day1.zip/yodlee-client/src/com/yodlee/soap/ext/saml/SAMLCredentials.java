
package com.yodlee.soap.ext.saml;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.ext.login.ExternalAuthenticationCredentials;


/**
 * <p>Java class for SAMLCredentials complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SAMLCredentials">
 *   &lt;complexContent>
 *     &lt;extension base="{http://login.ext.soap.yodlee.com}ExternalAuthenticationCredentials">
 *       &lt;sequence>
 *         &lt;element name="samlResponse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="issuerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="artifactProfile" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="sourceID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="decrypted" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="source" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="validateAssertionID" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SAMLCredentials", propOrder = {
    "samlResponse",
    "issuerId",
    "artifactProfile",
    "sourceID",
    "decrypted",
    "source",
    "validateAssertionID"
})
public class SAMLCredentials
    extends ExternalAuthenticationCredentials
{

    @XmlElementRef(name = "samlResponse", type = JAXBElement.class, required = false)
    protected JAXBElement<String> samlResponse;
    @XmlElementRef(name = "issuerId", type = JAXBElement.class, required = false)
    protected JAXBElement<String> issuerId;
    protected boolean artifactProfile;
    @XmlElementRef(name = "sourceID", type = JAXBElement.class, required = false)
    protected JAXBElement<String> sourceID;
    protected boolean decrypted;
    @XmlElementRef(name = "source", type = JAXBElement.class, required = false)
    protected JAXBElement<String> source;
    protected boolean validateAssertionID;

    /**
     * Gets the value of the samlResponse property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSamlResponse() {
        return samlResponse;
    }

    /**
     * Sets the value of the samlResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSamlResponse(JAXBElement<String> value) {
        this.samlResponse = value;
    }

    /**
     * Gets the value of the issuerId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIssuerId() {
        return issuerId;
    }

    /**
     * Sets the value of the issuerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIssuerId(JAXBElement<String> value) {
        this.issuerId = value;
    }

    /**
     * Gets the value of the artifactProfile property.
     * 
     */
    public boolean isArtifactProfile() {
        return artifactProfile;
    }

    /**
     * Sets the value of the artifactProfile property.
     * 
     */
    public void setArtifactProfile(boolean value) {
        this.artifactProfile = value;
    }

    /**
     * Gets the value of the sourceID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSourceID() {
        return sourceID;
    }

    /**
     * Sets the value of the sourceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSourceID(JAXBElement<String> value) {
        this.sourceID = value;
    }

    /**
     * Gets the value of the decrypted property.
     * 
     */
    public boolean isDecrypted() {
        return decrypted;
    }

    /**
     * Sets the value of the decrypted property.
     * 
     */
    public void setDecrypted(boolean value) {
        this.decrypted = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSource(JAXBElement<String> value) {
        this.source = value;
    }

    /**
     * Gets the value of the validateAssertionID property.
     * 
     */
    public boolean isValidateAssertionID() {
        return validateAssertionID;
    }

    /**
     * Sets the value of the validateAssertionID property.
     * 
     */
    public void setValidateAssertionID(boolean value) {
        this.validateAssertionID = value;
    }

}
