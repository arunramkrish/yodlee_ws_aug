@javax.xml.bind.annotation.XmlSchema(namespace = "http://saml.ext.soap.yodlee.com")
package com.yodlee.soap.ext.saml;
