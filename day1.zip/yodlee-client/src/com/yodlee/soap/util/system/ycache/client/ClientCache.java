
package com.yodlee.soap.util.system.ycache.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.Map;
import com.yodlee.soap.util.system.ycache.AbstractCacheable;


/**
 * <p>Java class for ClientCache complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClientCache">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ycache.system.util.soap.yodlee.com}AbstractCacheable">
 *       &lt;sequence>
 *         &lt;element name="appCobParamsMap" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="returnNull" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="messageCatalogInfo" type="{http://client.ycache.system.util.soap.yodlee.com}MessageCatalogInfo" minOccurs="0"/>
 *         &lt;element name="isAppCobParamLoaded" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientCache", propOrder = {
    "appCobParamsMap",
    "returnNull",
    "messageCatalogInfo",
    "isAppCobParamLoaded"
})
@XmlSeeAlso({
    ClientGenericCache.class,
    ClientCobrandCache.class
})
public abstract class ClientCache
    extends AbstractCacheable
{

    @XmlElementRef(name = "appCobParamsMap", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> appCobParamsMap;
    protected boolean returnNull;
    @XmlElementRef(name = "messageCatalogInfo", type = JAXBElement.class, required = false)
    protected JAXBElement<MessageCatalogInfo> messageCatalogInfo;
    protected boolean isAppCobParamLoaded;

    /**
     * Gets the value of the appCobParamsMap property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getAppCobParamsMap() {
        return appCobParamsMap;
    }

    /**
     * Sets the value of the appCobParamsMap property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setAppCobParamsMap(JAXBElement<Map> value) {
        this.appCobParamsMap = value;
    }

    /**
     * Gets the value of the returnNull property.
     * 
     */
    public boolean isReturnNull() {
        return returnNull;
    }

    /**
     * Sets the value of the returnNull property.
     * 
     */
    public void setReturnNull(boolean value) {
        this.returnNull = value;
    }

    /**
     * Gets the value of the messageCatalogInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MessageCatalogInfo }{@code >}
     *     
     */
    public JAXBElement<MessageCatalogInfo> getMessageCatalogInfo() {
        return messageCatalogInfo;
    }

    /**
     * Sets the value of the messageCatalogInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MessageCatalogInfo }{@code >}
     *     
     */
    public void setMessageCatalogInfo(JAXBElement<MessageCatalogInfo> value) {
        this.messageCatalogInfo = value;
    }

    /**
     * Gets the value of the isAppCobParamLoaded property.
     * 
     */
    public boolean isIsAppCobParamLoaded() {
        return isAppCobParamLoaded;
    }

    /**
     * Sets the value of the isAppCobParamLoaded property.
     * 
     */
    public void setIsAppCobParamLoaded(boolean value) {
        this.isAppCobParamLoaded = value;
    }

}
