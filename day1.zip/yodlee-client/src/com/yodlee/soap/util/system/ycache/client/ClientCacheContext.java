
package com.yodlee.soap.util.system.ycache.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClientCacheContext complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClientCacheContext">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="clientCobrandCache" type="{http://client.ycache.system.util.soap.yodlee.com}ClientCobrandCache" minOccurs="0"/>
 *         &lt;element name="clientGenericCache" type="{http://client.ycache.system.util.soap.yodlee.com}ClientGenericCache" minOccurs="0"/>
 *         &lt;element name="clientChannelCache" type="{http://client.ycache.system.util.soap.yodlee.com}ClientCobrandCache" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientCacheContext", propOrder = {
    "clientCobrandCache",
    "clientGenericCache",
    "clientChannelCache"
})
public class ClientCacheContext {

    @XmlElementRef(name = "clientCobrandCache", type = JAXBElement.class, required = false)
    protected JAXBElement<ClientCobrandCache> clientCobrandCache;
    @XmlElementRef(name = "clientGenericCache", type = JAXBElement.class, required = false)
    protected JAXBElement<ClientGenericCache> clientGenericCache;
    @XmlElementRef(name = "clientChannelCache", type = JAXBElement.class, required = false)
    protected JAXBElement<ClientCobrandCache> clientChannelCache;

    /**
     * Gets the value of the clientCobrandCache property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}
     *     
     */
    public JAXBElement<ClientCobrandCache> getClientCobrandCache() {
        return clientCobrandCache;
    }

    /**
     * Sets the value of the clientCobrandCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}
     *     
     */
    public void setClientCobrandCache(JAXBElement<ClientCobrandCache> value) {
        this.clientCobrandCache = value;
    }

    /**
     * Gets the value of the clientGenericCache property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ClientGenericCache }{@code >}
     *     
     */
    public JAXBElement<ClientGenericCache> getClientGenericCache() {
        return clientGenericCache;
    }

    /**
     * Sets the value of the clientGenericCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ClientGenericCache }{@code >}
     *     
     */
    public void setClientGenericCache(JAXBElement<ClientGenericCache> value) {
        this.clientGenericCache = value;
    }

    /**
     * Gets the value of the clientChannelCache property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}
     *     
     */
    public JAXBElement<ClientCobrandCache> getClientChannelCache() {
        return clientChannelCache;
    }

    /**
     * Sets the value of the clientChannelCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}
     *     
     */
    public void setClientChannelCache(JAXBElement<ClientCobrandCache> value) {
        this.clientChannelCache = value;
    }

}
