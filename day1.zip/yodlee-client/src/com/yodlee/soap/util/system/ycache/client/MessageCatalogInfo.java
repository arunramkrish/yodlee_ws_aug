
package com.yodlee.soap.util.system.ycache.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.yodlee.soap.collections.Map;


/**
 * <p>Java class for MessageCatalogInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageCatalogInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="catalogs" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="formats" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="resourceRegistry" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="messageCache" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *         &lt;element name="messageLookup" type="{http://collections.soap.yodlee.com}Map" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageCatalogInfo", propOrder = {
    "catalogs",
    "formats",
    "resourceRegistry",
    "messageCache",
    "messageLookup"
})
public class MessageCatalogInfo {

    @XmlElementRef(name = "catalogs", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> catalogs;
    @XmlElementRef(name = "formats", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> formats;
    @XmlElementRef(name = "resourceRegistry", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> resourceRegistry;
    @XmlElementRef(name = "messageCache", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> messageCache;
    @XmlElementRef(name = "messageLookup", type = JAXBElement.class, required = false)
    protected JAXBElement<Map> messageLookup;

    /**
     * Gets the value of the catalogs property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getCatalogs() {
        return catalogs;
    }

    /**
     * Sets the value of the catalogs property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setCatalogs(JAXBElement<Map> value) {
        this.catalogs = value;
    }

    /**
     * Gets the value of the formats property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getFormats() {
        return formats;
    }

    /**
     * Sets the value of the formats property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setFormats(JAXBElement<Map> value) {
        this.formats = value;
    }

    /**
     * Gets the value of the resourceRegistry property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getResourceRegistry() {
        return resourceRegistry;
    }

    /**
     * Sets the value of the resourceRegistry property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setResourceRegistry(JAXBElement<Map> value) {
        this.resourceRegistry = value;
    }

    /**
     * Gets the value of the messageCache property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getMessageCache() {
        return messageCache;
    }

    /**
     * Sets the value of the messageCache property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setMessageCache(JAXBElement<Map> value) {
        this.messageCache = value;
    }

    /**
     * Gets the value of the messageLookup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public JAXBElement<Map> getMessageLookup() {
        return messageLookup;
    }

    /**
     * Sets the value of the messageLookup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Map }{@code >}
     *     
     */
    public void setMessageLookup(JAXBElement<Map> value) {
        this.messageLookup = value;
    }

}
