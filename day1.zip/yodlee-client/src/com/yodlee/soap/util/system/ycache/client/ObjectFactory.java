
package com.yodlee.soap.util.system.ycache.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.yodlee.soap.collections.Map;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yodlee.soap.util.system.ycache.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ClientCacheContextClientGenericCache_QNAME = new QName("", "clientGenericCache");
    private final static QName _ClientCacheContextClientChannelCache_QNAME = new QName("", "clientChannelCache");
    private final static QName _ClientCacheContextClientCobrandCache_QNAME = new QName("", "clientCobrandCache");
    private final static QName _MessageCatalogInfoResourceRegistry_QNAME = new QName("", "resourceRegistry");
    private final static QName _MessageCatalogInfoMessageCache_QNAME = new QName("", "messageCache");
    private final static QName _MessageCatalogInfoCatalogs_QNAME = new QName("", "catalogs");
    private final static QName _MessageCatalogInfoMessageLookup_QNAME = new QName("", "messageLookup");
    private final static QName _MessageCatalogInfoFormats_QNAME = new QName("", "formats");
    private final static QName _ClientCacheAppCobParamsMap_QNAME = new QName("", "appCobParamsMap");
    private final static QName _ClientCacheMessageCatalogInfo_QNAME = new QName("", "messageCatalogInfo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yodlee.soap.util.system.ycache.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MessageCatalogInfo }
     * 
     */
    public MessageCatalogInfo createMessageCatalogInfo() {
        return new MessageCatalogInfo();
    }

    /**
     * Create an instance of {@link ClientGenericCache }
     * 
     */
    public ClientGenericCache createClientGenericCache() {
        return new ClientGenericCache();
    }

    /**
     * Create an instance of {@link ClientCobrandCache }
     * 
     */
    public ClientCobrandCache createClientCobrandCache() {
        return new ClientCobrandCache();
    }

    /**
     * Create an instance of {@link ClientCacheContext }
     * 
     */
    public ClientCacheContext createClientCacheContext() {
        return new ClientCacheContext();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClientGenericCache }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "clientGenericCache", scope = ClientCacheContext.class)
    public JAXBElement<ClientGenericCache> createClientCacheContextClientGenericCache(ClientGenericCache value) {
        return new JAXBElement<ClientGenericCache>(_ClientCacheContextClientGenericCache_QNAME, ClientGenericCache.class, ClientCacheContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "clientChannelCache", scope = ClientCacheContext.class)
    public JAXBElement<ClientCobrandCache> createClientCacheContextClientChannelCache(ClientCobrandCache value) {
        return new JAXBElement<ClientCobrandCache>(_ClientCacheContextClientChannelCache_QNAME, ClientCobrandCache.class, ClientCacheContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClientCobrandCache }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "clientCobrandCache", scope = ClientCacheContext.class)
    public JAXBElement<ClientCobrandCache> createClientCacheContextClientCobrandCache(ClientCobrandCache value) {
        return new JAXBElement<ClientCobrandCache>(_ClientCacheContextClientCobrandCache_QNAME, ClientCobrandCache.class, ClientCacheContext.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "resourceRegistry", scope = MessageCatalogInfo.class)
    public JAXBElement<Map> createMessageCatalogInfoResourceRegistry(Map value) {
        return new JAXBElement<Map>(_MessageCatalogInfoResourceRegistry_QNAME, Map.class, MessageCatalogInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "messageCache", scope = MessageCatalogInfo.class)
    public JAXBElement<Map> createMessageCatalogInfoMessageCache(Map value) {
        return new JAXBElement<Map>(_MessageCatalogInfoMessageCache_QNAME, Map.class, MessageCatalogInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "catalogs", scope = MessageCatalogInfo.class)
    public JAXBElement<Map> createMessageCatalogInfoCatalogs(Map value) {
        return new JAXBElement<Map>(_MessageCatalogInfoCatalogs_QNAME, Map.class, MessageCatalogInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "messageLookup", scope = MessageCatalogInfo.class)
    public JAXBElement<Map> createMessageCatalogInfoMessageLookup(Map value) {
        return new JAXBElement<Map>(_MessageCatalogInfoMessageLookup_QNAME, Map.class, MessageCatalogInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "formats", scope = MessageCatalogInfo.class)
    public JAXBElement<Map> createMessageCatalogInfoFormats(Map value) {
        return new JAXBElement<Map>(_MessageCatalogInfoFormats_QNAME, Map.class, MessageCatalogInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Map }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "appCobParamsMap", scope = ClientCache.class)
    public JAXBElement<Map> createClientCacheAppCobParamsMap(Map value) {
        return new JAXBElement<Map>(_ClientCacheAppCobParamsMap_QNAME, Map.class, ClientCache.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageCatalogInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "messageCatalogInfo", scope = ClientCache.class)
    public JAXBElement<MessageCatalogInfo> createClientCacheMessageCatalogInfo(MessageCatalogInfo value) {
        return new JAXBElement<MessageCatalogInfo>(_ClientCacheMessageCatalogInfo_QNAME, MessageCatalogInfo.class, ClientCache.class, value);
    }

}
