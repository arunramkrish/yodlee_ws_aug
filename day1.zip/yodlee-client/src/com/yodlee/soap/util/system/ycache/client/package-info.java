@javax.xml.bind.annotation.XmlSchema(namespace = "http://client.ycache.system.util.soap.yodlee.com")
package com.yodlee.soap.util.system.ycache.client;
