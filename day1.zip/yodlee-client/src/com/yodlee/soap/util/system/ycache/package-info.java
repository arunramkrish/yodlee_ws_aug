@javax.xml.bind.annotation.XmlSchema(namespace = "http://ycache.system.util.soap.yodlee.com")
package com.yodlee.soap.util.system.ycache;
